# -*- coding: utf-8 -*-
"""
UI 测试用例生成 Agent - 多层级页面探索与用例生成。

角色定义：你是一个 UI 测试用例生成 Agent，负责对被测页面进行多层级探索，
识别可操作元素，设计 UI 自动化测试用例，并规划下一步可点击操作进入子页面，
循环执行直至用户指定的探索深度结束。

执行流程：
  1. 进入被测页面
  2. 页面分析：识别页面可操作元素（按钮、输入框、链接等）
  3. 用例设计：调用 CaseDesigner 进行 UI 自动化测试用例设计
  4. 规划下一步：识别可点击操作项，进入下一层级页面
  5. 循环执行 1-4，直至探索深度达到用户指定的 max_depth
"""

import logging
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional

from langchain_core.language_models import BaseChatModel
from omegaconf import OmegaConf

from browser_use import project_root
from browser_use.agent.chat_models import build_models
from browser_use.agent.service import Agent
from browser_use.agent.tasks import Tasks
from browser_use.browser.browser import Browser, BrowserConfig
from browser_use.browser.context import BrowserContext, BrowserContextConfig
from browser_use.case_generator.case_designer import CaseDesigner
from browser_use.case_generator.error_collector import ErrorCollector, ExplorationIssue
from browser_use.case_generator.exploration_planner import ExplorationPlanner
from browser_use.case_generator.intent_parser import IntentParser, ParsedIntent
from browser_use.case_generator.models import PageAnalysisResult, TestCaseDesign
from browser_use.case_generator.page_analyzer import PageAnalyzer
from browser_use.case_generator.summary_reporter import (
    AnalysisRecord,
    CaseRecord,
    ExplorationRecord,
    SummaryData,
    SummaryReporter,
)
from browser_use.case_generator.visual_error_detector import VisualErrorDetector
from browser_use.case_generator.yaml_generator import YamlGenerator

logger = logging.getLogger(__name__)

# 角色定义：UI 测试用例生成 Agent
AGENT_ROLE = (
    "你是一个 UI 测试用例生成 Agent。"
    "负责进入被测页面、分析可操作元素、设计 UI 自动化测试用例、规划下一步可点击操作进入子页面，"
    "循环执行直至用户指定的探索深度结束。"
)


class CaseGeneratorAgent:
    """
    UI 测试用例生成 Agent。
    执行流程：进入页面 -> 分析可操作元素 -> 用例设计 -> 规划下一步 -> 循环直至 max_depth。
    """

    def __init__(
        self,
        page_analysis_llm: Optional[BaseChatModel] = None,
        case_design_llm: Optional[BaseChatModel] = None,
        yaml_gen_llm: Optional[BaseChatModel] = None,
    ):
        if page_analysis_llm is None or case_design_llm is None or yaml_gen_llm is None:
            _, _, _, aux = build_models()
            llm = aux.get("page_extraction_llm")
            if llm is None:
                raise RuntimeError(
                    "page_extraction_llm is None. Set UI_EXTERNAL_API_KEY and UI_EXTERNAL_BASE_URL."
                )
            page_analysis_llm = page_analysis_llm or llm
            case_design_llm = case_design_llm or llm
            yaml_gen_llm = yaml_gen_llm or llm

        self.page_analyzer = PageAnalyzer(llm=page_analysis_llm)
        self.case_designer = CaseDesigner(llm=case_design_llm)
        self.yaml_generator = YamlGenerator(llm=yaml_gen_llm)
        self.exploration_planner = ExplorationPlanner(llm=page_analysis_llm)
        self.intent_parser = IntentParser(llm=page_analysis_llm)
        self.visual_error_detector = VisualErrorDetector(llm=page_analysis_llm)
        self.summary_reporter = SummaryReporter()

    async def run(
        self,
        url: str,
        output_dir: Optional[str] = None,
        project_name: str = "uiTest",
        max_depth: int = 1,
        login_config: Optional[Dict[str, Any]] = None,
        browser_context: Optional[BrowserContext] = None,
        headless: bool = True,
        user_input: Optional[str] = None,
        collect_exploration_errors: bool = True,
        visual_error_check: bool = True,
    ) -> List[Path]:
        """
        执行 UI 测试用例生成任务。

        流程：进入被测页面 -> (可选)定位模块 -> 分析可操作元素 -> 用例设计 -> 规划下一步 -> 循环直至 max_depth。

        - user_input: 自然语言输入，如「帮我测试投放管理模块」，解析出 url、module_name
        - max_depth=1：单页流程，仅分析当前页
        - max_depth>=2：多层级探索，循环执行直至探索深度结束

        Returns:
            生成的用例文件路径列表
        """
        target_module: Optional[str] = None
        if user_input and user_input.strip():
            intent = await self.intent_parser.parse(user_input)
            if intent.has_url:
                url = intent.url
                logger.info("Parsed url from user_input: %s", url)
            if intent.has_module:
                target_module = intent.module_name
                logger.info("Parsed module from user_input: %s", target_module)

        if not url or not url.strip():
            raise ValueError(
                "URL is required. Provide --url or include URL in --user-input (e.g. '帮我测试 http://xxx/ 的投放管理模块')."
            )

        depth_limit = int(os.environ.get("CASE_GEN_MAX_DEPTH", str(max_depth)))
        if depth_limit != max_depth:
            max_depth = depth_limit

        base = os.environ.get("CASE_GEN_OUTPUT_DIR") or os.path.expanduser("~/uiTest")
        out = Path(output_dir or f"{base}/{project_name}")
        out.mkdir(parents=True, exist_ok=True)
        logger.info("Output dir: %s", out)

        ctx = browser_context
        own_browser = False
        if ctx is None:
            browser = Browser(config=BrowserConfig(headless=headless))
            ctx = BrowserContext(browser=browser, config=BrowserContextConfig())
            own_browser = True

        try:
            if login_config:
                await self._run_login(ctx, login_config)

            if max_depth <= 1:
                return await self._run_single_page(
                    ctx,
                    url,
                    out,
                    target_module=target_module,
                    collect_errors=collect_exploration_errors,
                    visual_check=visual_error_check,
                )
            return await self._run_multi_level(
                ctx,
                url,
                out,
                max_depth,
                target_module=target_module,
                collect_errors=collect_exploration_errors,
                visual_check=visual_error_check,
            )
        finally:
            if own_browser and ctx is not None:
                try:
                    await ctx.close()
                except Exception:
                    pass
                if hasattr(ctx, "browser") and ctx.browser:
                    try:
                        await ctx.browser.close()
                    except Exception:
                        pass

    async def _navigate_to_module(
        self, ctx: BrowserContext, module_name: str
    ) -> bool:
        """
        使用 Planner + Actor 在当前页面上找到并进入指定模块。
        Returns True on success, False on failure.
        """
        desc = f"找到并点击进入「{module_name}」模块或菜单，确保进入该模块对应页面"
        return await self._execute_single_ai_react(ctx, desc)

    async def _run_single_page(
        self,
        ctx: BrowserContext,
        url: str,
        out: Path,
        target_module: Optional[str] = None,
        collect_errors: bool = True,
        visual_check: bool = True,
    ) -> List[Path]:
        """
        单页流程（max_depth=1）：
        1. 进入被测页面
        2. (可选) 定位并进入指定模块
        3. 页面分析，识别可操作元素
        4. 用例设计
        5. 生成 YAML 并写入
        6. 采集探索错误、视觉检测，生成汇总报告
        """
        # 用户主动关闭浏览器时，直接返回
        if not ctx.is_browser_available():
            logger.warning("Browser closed by user, skipping single-page case generation")
            return []

        # Step 1: 进入被测页面
        await ctx.navigate_to(url)
        await ctx.get_state()

        path = "首页"
        error_collector = ErrorCollector() if collect_errors else None
        if collect_errors:
            page = await ctx.get_current_page()
            error_collector.attach(page, url=url, path=path)

        # Step 2: 若指定模块，使用 Planner + Actor 定位并进入
        if target_module:
            logger.info("Navigating to module: %s", target_module)
            success = await self._navigate_to_module(ctx, target_module)
            if not success:
                logger.warning(
                    "Failed to navigate to module '%s', continuing with current page",
                    target_module,
                )
            else:
                await ctx.get_state()

        # Step 3: 页面分析，识别可操作元素
        analysis = await self.page_analyzer.analyze(ctx)
        logger.info("Page analysis: %s", analysis.page_type)

        if analysis.is_login_page:
            logger.warning("Login page detected, skipping case generation: %s", url)
            return []

        # 记录分析结果
        session = await ctx.get_session()
        target_url = session.cached_state.url if session.cached_state else url
        n_actionable = len(analysis.actionable_elements) + len(analysis.navigable_actions or [])
        analysis_records = [
            AnalysisRecord(
                path=path,
                url=target_url,
                page_type=analysis.page_type,
                page_title=analysis.page_title or "",
                actionable_count=n_actionable,
                actionable_elements=analysis.actionable_elements or [],
                non_actionable_elements=analysis.non_actionable_elements or [],
            )
        ]

        # Step 4: 用例设计
        cases = await self.case_designer.design(analysis)
        logger.info("Designed %d cases", len(cases))

        case_names = [c.case_name or "" for c in cases]
        case_records = [
            CaseRecord(path=path, case_count=len(cases), case_names=case_names, cases=cases)
        ]

        # Step 4.1: 导出 Markdown 表格到本地
        md_path = out / "cases_design.md"
        self.case_designer.export_to_markdown_table(
            cases, md_path, page_title=analysis.page_title
        )

        # Step 5: 生成 YAML 并写入
        session = await ctx.get_session()
        target_url = session.cached_state.url if session.cached_state else url
        yaml_contents = await self.yaml_generator.generate(cases, target_url)

        written: List[Path] = []
        for i, (case, content) in enumerate(zip(cases, yaml_contents)):
            safe_name = self._sanitize_filename(case.case_name) or f"case_{i + 1:02d}"
            case_id = case.case_id or str(i + 1).zfill(2)
            fpath = out / f"{case_id}-{safe_name}.yaml"
            fpath.write_text(content, encoding="utf-8")
            written.append(fpath)
            logger.info("Wrote %s", fpath)

        # 采集错误、视觉检测、生成汇总
        issues: List[ExplorationIssue] = []
        if error_collector:
            issues = error_collector.collect(url=target_url, path=path)
            for i in issues:
                if not i.log_snippet and (i.message or i.detail):
                    i.log_snippet = f"{i.message}\n{i.detail}".strip()
            error_collector.detach()
        if visual_check and session.cached_state and session.cached_state.screenshot:
            visual_issues = await self.visual_error_detector.detect(
                session.cached_state.screenshot, url=target_url, path=path
            )
            for vi in visual_issues:
                vi.screenshot_base64 = session.cached_state.screenshot
            issues.extend(visual_issues)
        exploration_records = [ExplorationRecord(path=path, url=target_url, issues=issues)]
        summary_data = SummaryData(
            target_url=target_url,
            analysis_records=analysis_records,
            case_records=case_records,
            exploration_records=exploration_records,
        )
        logs_dir = out / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        self.summary_reporter.generate(summary_data, logs_dir / "summary_report.md")
        return written

    async def _run_multi_level(
        self,
        ctx: BrowserContext,
        url: str,
        out: Path,
        max_depth: int,
        target_module: Optional[str] = None,
        collect_errors: bool = True,
        visual_check: bool = True,
    ) -> List[Path]:
        """
        多层级探索流程（max_depth>=2），循环执行直至探索深度结束：
        1. 进入被测页面
        2. (仅 depth=0) 若指定模块，定位并进入
        3. 页面分析，识别可操作元素
        4. 用例设计
        5. 规划下一步可点击操作项，进入下一层级页面
        6. 循环 1-5，直至 depth >= max_depth
        7. 采集探索错误、视觉检测，生成汇总报告
        """
        from collections import deque

        logger.info("Starting case generator for %s, max_depth=%d", url, max_depth)
        queue: deque = deque([(0, url, "首页")])
        visited_urls: set = set()
        visited_paths: set = set()
        written: List[Path] = []
        summary_data = SummaryData(target_url=url)
        error_collector = ErrorCollector() if collect_errors else None

        while queue:
            # 用户主动关闭浏览器时，立即退出任务
            if not ctx.is_browser_available():
                logger.warning("Browser closed by user, stopping case generator")
                break
            depth, page_url, path = queue.popleft()
            if depth > max_depth:
                continue
            if page_url in visited_urls:
                continue
            visited_urls.add(page_url)
            visited_paths.add(path)

            logger.info("Level %d: %s (%s)", depth, path, page_url)

            # Step 1: 进入被测页面
            await ctx.navigate_to(page_url)
            await ctx.get_state()

            if error_collector:
                error_collector.clear()
                page = await ctx.get_current_page()
                error_collector.attach(page, url=page_url, path=path)

            # Step 2: 仅 depth=0 时，若指定模块，使用 Planner + Actor 定位并进入
            if depth == 0 and target_module:
                logger.info("Navigating to module: %s", target_module)
                success = await self._navigate_to_module(ctx, target_module)
                if not success:
                    logger.warning(
                        "Failed to navigate to module '%s', continuing with current page",
                        target_module,
                    )
                else:
                    await ctx.get_state()

            # Step 3: 页面分析，识别可操作元素
            analysis = await self.page_analyzer.analyze(ctx)
            if analysis.is_login_page:
                logger.warning(
                    "Login page detected, skipping case generation: %s", page_url
                )
                continue

            session = await ctx.get_session()
            current_url = session.cached_state.url if session.cached_state else page_url
            n_actionable = len(analysis.actionable_elements) + len(
                analysis.navigable_actions or []
            )
            summary_data.analysis_records.append(
                AnalysisRecord(
                    path=path,
                    url=current_url,
                    page_type=analysis.page_type,
                    page_title=analysis.page_title or "",
                    actionable_count=n_actionable,
                    actionable_elements=analysis.actionable_elements or [],
                    non_actionable_elements=analysis.non_actionable_elements or [],
                )
            )

            # Step 3: 用例设计
            cases = await self.case_designer.design(analysis)
            logger.info("Level %d: designed %d cases for %s", depth, len(cases), path)

            case_names = [c.case_name or "" for c in cases]
            summary_data.case_records.append(
                CaseRecord(path=path, case_count=len(cases), case_names=case_names, cases=cases)
            )

            # Step 3.1: 导出 Markdown 表格到本地
            safe_path = path.replace("/", "_")
            md_path = out / f"L{depth}_{safe_path}_cases_design.md"
            self.case_designer.export_to_markdown_table(
                cases, md_path, page_title=analysis.page_title
            )

            yaml_contents = await self.yaml_generator.generate(cases, page_url)

            for i, (case, content) in enumerate(zip(cases, yaml_contents)):
                safe_path = path.replace("/", "_")
                safe_name = self._sanitize_filename(case.case_name) or f"case_{i + 1:02d}"
                case_id = case.case_id or str(i + 1).zfill(2)
                fpath = out / f"L{depth}_{safe_path}_{case_id}-{safe_name}.yaml"
                fpath.write_text(content, encoding="utf-8")
                written.append(fpath)
                logger.info("Wrote %s", fpath)

            # Step 4: 规划下一步可点击操作项，进入下一层级页面
            if depth < max_depth:
                plan = await self.exploration_planner.plan(
                    analysis, depth, max_depth, visited_paths
                )
                logger.info(
                    "Exploration plan: %d next actions", len(plan.next_actions)
                )
                for action in plan.next_actions:
                    if not ctx.is_browser_available():
                        logger.warning("Browser closed by user, stopping case generator")
                        break
                    desc = action.get("description") or action.get("label", "")
                    logger.info("Executing exploration: %s", desc)
                    success = await self._execute_single_ai_react(ctx, desc)
                    if success:
                        session = await ctx.get_session()
                        new_url = (
                            session.cached_state.url
                            if session.cached_state
                            else page_url
                        )
                        new_path = f"{path}/{action.get('label', 'sub')}"
                        if new_url not in visited_urls:
                            queue.append((depth + 1, new_url, new_path))
                    else:
                        if error_collector:
                            error_collector.add_exploration_failed(
                                desc, url=current_url, path=path
                            )
                        logger.warning(
                            "Exploration action failed, skipping: %s",
                            action.get("label", ""),
                        )

            # 采集错误、视觉检测，追加探索记录
            issues: List[ExplorationIssue] = []
            if error_collector:
                issues = error_collector.collect(url=current_url, path=path)
                for i in issues:
                    if not i.log_snippet and (i.message or i.detail):
                        i.log_snippet = f"{i.message}\n{i.detail}".strip()
            if visual_check and session.cached_state and session.cached_state.screenshot:
                visual_issues = await self.visual_error_detector.detect(
                    session.cached_state.screenshot,
                    url=current_url,
                    path=path,
                )
                for vi in visual_issues:
                    vi.screenshot_base64 = session.cached_state.screenshot
                issues.extend(visual_issues)
            summary_data.exploration_records.append(
                ExplorationRecord(path=path, url=current_url, issues=issues)
            )
            if error_collector:
                error_collector.clear()

        if error_collector:
            error_collector.detach()

        # Step 5: 任务结束，生成汇总报告
        logs_dir = out / "logs"
        logs_dir.mkdir(parents=True, exist_ok=True)
        self.summary_reporter.generate(summary_data, logs_dir / "summary_report.md")
        logger.info(
            "Case generator completed. Total %d files written", len(written)
        )
        return written

    async def _run_login(self, ctx: BrowserContext, login_config: Dict[str, Any]) -> None:
        """Run login flow from config. Executes login task via Agent."""
        task_file = login_config.get("task_file")
        if not task_file or not Path(task_file).exists():
            logger.warning("login_config.task_file not found, skipping login")
            return
        try:
            tasks = Tasks(task_yaml_path=task_file)
            target_url = tasks.tasks_config.target.url
            cfg = OmegaConf.load(project_root / "static/configs/default.yaml")
            log_dir = tempfile.mkdtemp(prefix="case_gen_login_")
            OmegaConf.update(cfg, "task_file", str(task_file))
            OmegaConf.update(cfg, "log_dir", log_dir)

            actor, planner, asserter, aux_llms = build_models()
            agent = Agent(
                config=cfg,
                tasks=tasks,
                llm=actor,
                planner=planner,
                asserter=asserter,
                aux_llms=aux_llms,
                browser_context=ctx,
                initial_actions=[{"go_to_url": {"url": target_url}}],
                log_dir=log_dir,
            )
            logger.info("Executing login flow at %s", target_url)
            await agent.run()
            logger.info("Login flow completed")
        except Exception as e:
            logger.warning("Login flow failed: %s", e)

    def _sanitize_filename(self, name: str) -> str:
        """Convert case name to safe filename."""
        invalid = '<>:"/\\|?*'
        for c in invalid:
            name = name.replace(c, "_")
        return name.strip() or "case"

    async def _execute_single_ai_react(
        self,
        ctx: BrowserContext,
        description: str,
    ) -> bool:
        """
        Execute a single aiReAct task on the current page.
        Returns True on success, False on failure.
        """
        try:
            tasks = Tasks(task=description)
            cfg = OmegaConf.load(project_root / "static/configs/default.yaml")
            log_dir = tempfile.mkdtemp(prefix="case_gen_explore_")
            OmegaConf.update(cfg, "task_file", "explore")
            OmegaConf.update(cfg, "log_dir", log_dir)

            actor, planner, asserter, aux_llms = build_models()
            agent = Agent(
                config=cfg,
                tasks=tasks,
                llm=actor,
                planner=planner,
                asserter=asserter,
                aux_llms=aux_llms,
                browser_context=ctx,
                initial_actions=[],
                log_dir=log_dir,
            )
            await agent.run()
            return True
        except Exception as e:
            logger.warning("Exploration action failed: %s", e)
            return False
