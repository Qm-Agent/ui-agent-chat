# -*- coding: utf-8 -*-
"""UI test case generation agent module."""

# 原有的 CaseGeneratorAgent（兼容保留）
from browser_use.case_generator.agent import CaseGeneratorAgent
from browser_use.case_generator.models import (
    PageAnalysisResult,
    TestCaseDesign,
    StepDesign,
    ValidationPoint,
)

# V5 新增：智能测试助手
from browser_use.case_generator.assistant import (
    TestAssistant,
    ExecutionMode,
    TestAssistantResult,
)
from browser_use.case_generator.ai_login import AILoginHandler
from browser_use.case_generator.module_navigator import ModuleNavigator
from browser_use.case_generator.case_executor import (
    CaseExecutor,
    CaseExecutionResult,
)

__all__ = [
    # 原有模块（兼容）
    "CaseGeneratorAgent",
    "PageAnalysisResult",
    "TestCaseDesign",
    "StepDesign",
    "ValidationPoint",

    # V5 新增：智能测试助手
    "TestAssistant",
    "ExecutionMode",
    "TestAssistantResult",
    "AILoginHandler",
    "ModuleNavigator",
    "CaseExecutor",
    "CaseExecutionResult",
]
