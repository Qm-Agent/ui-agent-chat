# -*- coding: utf-8 -*-
"""Data models for case generator."""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# 可操作元素类型（参考 browser-use Planner 的 [index]<type>text</type> 格式）
ACTIONABLE_ELEMENT_TYPES = (
    "button",       # 按钮
    "input",        # 普通输入框
    "input_search", # 搜索框
    "input_password",  # 密码输入框
    "checkbox",     # 复选框
    "select",       # 下拉选择
    "link",         # 链接
    "radio",        # 单选
    "textarea",     # 多行文本
    "scrollable",   # 可滚动区域
    "other_actionable",  # 其他可操作
)

# 不可操作元素类型
NON_ACTIONABLE_ELEMENT_TYPES = (
    "label",    # 标签/标题
    "text",     # 纯文本
    "image",    # 图片（无可点击）
    "divider",  # 分隔符
    "other",    # 其他不可操作
)


@dataclass
class PageAnalysisResult:
    """Result of page analysis from PageAnalyzer."""

    page_type: str  # list | form | detail | dashboard
    page_title: str
    sections: List[Dict[str, Any]] = field(default_factory=list)
    main_actions: List[str] = field(default_factory=list)
    forms: List[Dict[str, Any]] = field(default_factory=list)
    suggested_cases: List[str] = field(default_factory=list)
    is_login_page: bool = False
    navigable_actions: List[Dict[str, str]] = field(default_factory=list)
    # 可操作元素：含 index、element_type、label、description
    actionable_elements: List[Dict[str, Any]] = field(default_factory=list)
    # 不可操作元素：含 element_type、text
    non_actionable_elements: List[Dict[str, Any]] = field(default_factory=list)
    # 弹窗检测：若存在遮挡主内容的弹窗/通知/蒙层
    has_popup: bool = False
    popup_close_hint: Optional[str] = None  # 关闭动作提示，如 "点击知道了"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PageAnalysisResult":
        nav_actions = data.get("navigable_actions", [])
        if isinstance(nav_actions, list):
            nav_actions = [
                x if isinstance(x, dict) else {"label": str(x), "description": str(x)}
                for x in nav_actions
            ]
        else:
            nav_actions = []

        actionables = data.get("actionable_elements", [])
        if not isinstance(actionables, list):
            actionables = []
        non_actionables = data.get("non_actionable_elements", [])
        if not isinstance(non_actionables, list):
            non_actionables = []

        return cls(
            page_type=data.get("page_type", "list"),
            page_title=data.get("page_title", ""),
            sections=data.get("sections", []),
            main_actions=data.get("main_actions", []),
            forms=data.get("forms", []),
            suggested_cases=data.get("suggested_cases", []),
            is_login_page=bool(data.get("is_login_page", False)),
            navigable_actions=nav_actions,
            actionable_elements=actionables,
            non_actionable_elements=non_actionables,
            has_popup=bool(data.get("has_popup", False)),
            popup_close_hint=data.get("popup_close_hint") or None,
        )


@dataclass
class ExplorationPlan:
    """Plan for next exploration actions."""

    next_actions: List[Dict[str, str]]
    reason: str
    is_done: bool


@dataclass
class ExplorationState:
    """State at one exploration level."""

    depth: int
    url: str
    path: str
    page_analysis: PageAnalysisResult
    cases: List["TestCaseDesign"]


@dataclass
class StepDesign:
    """Step design in test case."""

    order: int
    action_type: str  # wait | input | click | select | scroll | assert | navigate
    target_description: str
    value: Optional[str] = None
    ui_type_hint: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "StepDesign":
        return cls(
            order=data.get("order", 0),
            action_type=data.get("action_type", "click"),
            target_description=data.get("target_description", ""),
            value=data.get("value"),
            ui_type_hint=data.get("ui_type_hint"),
        )


@dataclass
class ValidationPoint:
    """Validation point in test case."""

    step_order: int
    validation_type: str
    expected_description: str
    ui_type: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ValidationPoint":
        return cls(
            step_order=data.get("step_order", 0),
            validation_type=data.get("validation_type", "element_visible"),
            expected_description=data.get("expected_description", ""),
            ui_type=data.get("ui_type"),
        )


@dataclass
class TestCaseDesign:
    """Test case design from CaseDesigner."""

    case_id: str
    case_name: str
    description: str
    ui_type: str = "unknown"
    preconditions: List[str] = field(default_factory=list)
    steps: List[StepDesign] = field(default_factory=list)
    test_data: Dict[str, Any] = field(default_factory=dict)
    validation_points: List[ValidationPoint] = field(default_factory=list)
    suggested_flow_type: str = ""
    generation_reason: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TestCaseDesign":
        steps = [StepDesign.from_dict(s) for s in data.get("steps", [])]
        validation_points = [
            ValidationPoint.from_dict(v) for v in data.get("validation_points", [])
        ]
        test_data = data.get("test_data")
        if not isinstance(test_data, dict):
            test_data = {}
        generation_reason = data.get("generation_reason") or data.get("生成原因") or ""
        return cls(
            case_id=data.get("case_id", ""),
            case_name=data.get("case_name", ""),
            description=data.get("description", ""),
            ui_type=data.get("ui_type", "unknown"),
            preconditions=data.get("preconditions", []),
            steps=steps,
            test_data=test_data,
            validation_points=validation_points,
            suggested_flow_type=data.get("suggested_flow_type", ""),
            generation_reason=generation_reason,
        )
