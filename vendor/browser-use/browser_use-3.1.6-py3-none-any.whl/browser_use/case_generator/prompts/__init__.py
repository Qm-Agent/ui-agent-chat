# -*- coding: utf-8 -*-
"""Prompt classes for case generator."""

import importlib.resources
import json
from typing import Any, Dict, List, Optional

from langchain_core.messages import HumanMessage, SystemMessage

from browser_use.case_generator.models import PageAnalysisResult, TestCaseDesign


class PageAnalysisPrompt:
    """Prompt for page analysis phase."""

    @classmethod
    def get_system_message(cls) -> SystemMessage:
        try:
            with importlib.resources.files("browser_use.case_generator.prompts").joinpath(
                "page_analysis_prompt.md"
            ).open("r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            raise RuntimeError(f"Failed to load page_analysis_prompt: {e}") from e
        return SystemMessage(content=content)

    @staticmethod
    def get_user_message(
        page_description: str,
        url: str,
        screenshot_base64: str,
    ) -> HumanMessage:
        text = f"""[Current state starts here]
Current date and time: The current page state
Current url: {url}
Available tabs: The current page

Interactive elements from top layer of the current page inside the viewport:

[On-screen Elements start]
{page_description}
[On-screen Elements end]

[Current state ends here]

Your task: Analyze the page, classify all elements, and output JSON with actionable_elements and non_actionable_elements.

**EXTRACTION RULES - FOLLOW CAREFULLY:**

The input format is: `[index]<type>text</type>  {{"box_2d": [...]}}`
- **index** = the number in square brackets [N]
- **type** = the HTML tag name between angle brackets <tagname> ← THIS IS YOUR element_type
- **text** = the visible content between the tags

**Input -> Output Mapping Examples:**
- Input: `[1]<a>新闻</a>  {{...}}` → Output: `{{"index": 1, "element_type": "a", "label": "新闻"}}`
- Input: `[5]<button>搜索</button>  {{...}}` → Output: `{{"index": 5, "element_type": "button", "label": "搜索"}}`
- Input: `[12]<input>搜索框</input>  {{...}}` → Output: `{{"index": 12, "element_type": "input", "label": "搜索框"}}`
- Input: `[8]<select>下拉框</select>  {{...}}` → Output: `{{"index": 8, "element_type": "select", "label": "下拉框"}}`

**CRITICAL - element_type must match exactly:**
- Use `"a"` NOT `"link"` or `"nav"`
- Use `"button"` NOT `"btn"` or `"action"`
- Use `"input"` NOT `"field"` or `"textbox"`
- NEVER use `"unknown"` - always extract from the actual tag in < >

Output valid JSON only, no markdown code blocks.
"""
        return HumanMessage(
            content=[
                {"type": "text", "text": text},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/png;base64,{screenshot_base64}"},
                },
            ]
        )


class PageAnalysisVisionPrompt:
    """Vision-only page analysis: image input only, no DOM. Outputs elements with position description."""

    @classmethod
    def get_system_message(cls) -> SystemMessage:
        try:
            with importlib.resources.files("browser_use.case_generator.prompts").joinpath(
                "page_analysis_vision_prompt.md"
            ).open("r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            raise RuntimeError(f"Failed to load page_analysis_vision_prompt: {e}") from e
        return SystemMessage(content=content)

    @staticmethod
    def get_user_message(
        url: str,
        screenshot_base64: str,
        page_width: int = None,
        page_height: int = None,
    ) -> HumanMessage:
        text = f"""Current url: {url}
Analyze the screenshot and output a valid JSON object with actionable_elements, navigable_actions, etc. For each actionable/navigable element, the "description" MUST include the element's position on the page (e.g. left sidebar 2nd item, top search bar right button) so the execution Agent can locate it without ambiguity.
"""
        if page_width is not None and page_height is not None:
            text += f"\nScreenshot dimensions: {page_width} x {page_height} pixels. If you return box_2d, use pixel coordinates [top, left, bottom, right]."
        text += "\nOutput valid JSON only, no markdown code blocks."
        return HumanMessage(
            content=[
                {"type": "text", "text": text},
                {
                    "type": "image_url",
                    "image_url": {"url": f"data:image/png;base64,{screenshot_base64}"},
                },
            ]
        )


class CaseDesignPrompt:
    """Prompt for case design phase."""

    @classmethod
    def get_system_message(cls) -> SystemMessage:
        try:
            with importlib.resources.files("browser_use.case_generator.prompts").joinpath(
                "case_design_prompt.md"
            ).open("r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            raise RuntimeError(f"Failed to load case_design_prompt: {e}") from e
        return SystemMessage(content=content)

    @staticmethod
    def get_user_message(
        page_analysis: PageAnalysisResult,
        max_cases: int = 5,
        screenshot_base64: Optional[str] = None,
    ) -> HumanMessage:
        analysis_dict: Dict[str, Any] = {
            "page_type": page_analysis.page_type,
            "page_title": page_analysis.page_title,
            "sections": page_analysis.sections,
            "main_actions": page_analysis.main_actions,
            "forms": page_analysis.forms,
            "suggested_cases": page_analysis.suggested_cases,
            "actionable_elements": page_analysis.actionable_elements,
            "non_actionable_elements": page_analysis.non_actionable_elements,
        }
        text = f"""
Page analysis result:
{json.dumps(analysis_dict, ensure_ascii=False, indent=2)}

IMPORTANT CONSTRAINTS:
- Maximum number of test cases to generate: {max_cases}
- Focus on P0 (must test) and P1 (should test) features only
- Skip P2 (could test) features if exceeding the limit
- Prioritize: core business flow > high-risk operations > common operations

Design test cases following the rules in the system prompt. Your output MUST be a valid JSON object with:
- "overall_design_reason" (总体用例设计原因, required): one sentence for overall design rationale; if you output 0 cases, this field MUST explain why (e.g. no core actionable features, decorative-only elements).
- "cases" (array): each case MUST include "generation_reason" (生成原因). Output JSON only (no markdown, no code block).
"""
        if screenshot_base64:
            return HumanMessage(
                content=[
                    {"type": "text", "text": text},
                    {
                        "type": "image_url",
                        "image_url": {"url": f"data:image/png;base64,{screenshot_base64}"},
                    },
                ]
            )
        return HumanMessage(content=text)


class YamlGenerationPrompt:
    """Prompt for YAML generation phase."""

    @classmethod
    def get_system_message(cls) -> SystemMessage:
        try:
            with importlib.resources.files("browser_use.case_generator.prompts").joinpath(
                "yaml_generation_prompt.md"
            ).open("r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            raise RuntimeError(f"Failed to load yaml_generation_prompt: {e}") from e
        return SystemMessage(content=content)

    @staticmethod
    def get_user_message(
        cases: List[TestCaseDesign],
        target_url: str,
    ) -> HumanMessage:
        cases_data = [
            {
                "case_id": c.case_id,
                "case_name": c.case_name,
                "description": c.description,
                "ui_type": c.ui_type,
                "preconditions": c.preconditions,
                "steps": [
                    {
                        "order": s.order,
                        "action_type": s.action_type,
                        "target_description": s.target_description,
                        "value": s.value,
                    }
                    for s in c.steps
                ],
                "test_data": c.test_data,
                "validation_points": [
                    {
                        "step_order": v.step_order,
                        "validation_type": v.validation_type,
                        "expected_description": v.expected_description,
                    }
                    for v in c.validation_points
                ],
            }
            for c in cases
        ]
        text = f"""
target_url: {target_url}

Test case designs:
{json.dumps(cases_data, ensure_ascii=False, indent=2)}

Convert each case to browser-use YAML. Output one YAML document per case, separated by "---". Flow must NOT start with "前往 url".
"""
        return HumanMessage(content=text)


class ExplorationPlanPrompt:
    """Prompt for exploration planning phase."""

    @classmethod
    def get_system_message(cls) -> SystemMessage:
        try:
            with importlib.resources.files("browser_use.case_generator.prompts").joinpath(
                "exploration_plan_prompt.md"
            ).open("r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            raise RuntimeError(f"Failed to load exploration_plan_prompt: {e}") from e
        return SystemMessage(content=content)

    @staticmethod
    def get_user_message(
        analysis: PageAnalysisResult,
        depth: int,
        max_depth: int,
        visited_paths: List[str],
        nav_actions: List[Dict[str, str]],
        path_chain: Optional[List[str]] = None,
    ) -> HumanMessage:
        lines = [
            f"Page: {analysis.page_title} (type: {analysis.page_type})",
            f"Depth: {depth}/{max_depth}",
            f"Already visited paths: {visited_paths}",
        ]
        if path_chain:
            breadcrumb = " > ".join(path_chain)
            lines.append(f"Current path (breadcrumb): {breadcrumb}")
            lines.append(
                "Prefer actions that go forward from this path; avoid selecting items that match the breadcrumb (e.g. same-level or parent menu) as they would go back."
            )
        lines.append("")
        lines.append(f"Navigable actions: {json.dumps(nav_actions, ensure_ascii=False, indent=2)}")
        lines.append("")
        lines.append("Select 1-3 actions to explore. Output a valid JSON object only (no markdown, no code block).")
        text = "\n".join(lines)
        return HumanMessage(content=text)


class VisualErrorPrompt:
    """Prompt for visual error detection phase."""

    @classmethod
    def get_system_message(cls) -> SystemMessage:
        try:
            with importlib.resources.files("browser_use.case_generator.prompts").joinpath(
                "visual_error_prompt.md"
            ).open("r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            raise RuntimeError("Failed to load visual_error_prompt: %s" % e) from e
        return SystemMessage(content=content)

    @staticmethod
    def get_user_message(url: str, screenshot_base64: str) -> HumanMessage:
        text = "Current url: %s\n\nAnalyze the screenshot. Output a valid JSON object only (no markdown, no code block)." % url
        return HumanMessage(
            content=[
                {"type": "text", "text": text},
                {
                    "type": "image_url",
                    "image_url": {"url": "data:image/png;base64,%s" % screenshot_base64},
                },
            ]
        )
