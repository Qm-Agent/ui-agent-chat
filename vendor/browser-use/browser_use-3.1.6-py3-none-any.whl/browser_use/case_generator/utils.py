# -*- coding: utf-8 -*-
"""
case_generator 包工具函数

复用 browser_use/agent/chat_models.py 的模型创建逻辑
参考 browser_use/agent/service.py 的 LLM 调用模式
"""

import asyncio
import json
import logging
import os
import re
from typing import Any, Dict, List, Tuple

from langchain_core.messages import BaseMessage

# 复用 chat_models 和 utils 的函数
from browser_use.agent.chat_models import build_models
from browser_use.utils import invoke_llm_with_retry

logger = logging.getLogger(__name__)


def _parse_json_parsing_function(raw_output: str) -> dict:
    """
    通用的 JSON 解析函数

    参考 page_analyzer.py 和 case_designer.py 中的 _parse_json 实现
    """
    content = raw_output.strip()
    # 移除 markdown 代码块
    match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", content)
    if match:
        content = match.group(1).strip()
    return json.loads(content)


async def ainvoke_with_retry(
    llm: Any,
    messages: List[BaseMessage],
    parsing_func=None,
    max_retry: int = 3,
) -> Any:
    """
    异步调用 LLM，带重试机制

    参考 browser_use/agent/service.py 的实现，复用 invoke_llm_with_retry

    Args:
        llm: LLM 实例
        messages: 消息列表
        parsing_func: 解析函数（可选，默认使用 JSON 解析）
        max_retry: 最大重试次数，默认 3 次

    Returns:
        解析后的输出
    """
    if parsing_func is None:
        parsing_func = _parse_json_parsing_function

    # 使用 asyncio.to_thread 在异步上下文中运行同步的 invoke_llm_with_retry
    try:
        result = await asyncio.to_thread(
            invoke_llm_with_retry,
            llm,
            messages,
            parsing_func,
            max_retry,
        )
        return result
    except Exception as e:
        logger.exception(f"❌ LLM invoke failed after {max_retry} retries: {e}")
        raise


def build_models_for_case_generator() -> Tuple[Any, Any, Any, Dict[str, Any]]:
    """Use the same explicit external model settings as the CLI."""
    return build_models()
