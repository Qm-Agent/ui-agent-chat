# -*- coding: utf-8 -*-
"""
探索错误采集器：在页面探索过程中采集 Console、未捕获异常、网络失败等错误。

职责：绑定到 Playwright Page，注册 console/pageerror/response 监听器，
采集探索过程中发现的缺陷，供汇总报告使用。
"""

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING, Callable, Dict, List, Optional, Set, Tuple

if TYPE_CHECKING:
    from playwright.async_api import Page

logger = logging.getLogger(__name__)


@dataclass
class ExplorationIssue:
    """探索过程中发现的缺陷。"""

    type: str  # console_error, page_error, network_error, exploration_failed, visual_error
    message: str
    url: str = ""
    path: str = ""
    detail: str = ""
    timestamp: Optional[float] = None
    screenshot_base64: Optional[str] = None  # 截图（如 visual_error 时附带的页面截图）
    log_snippet: Optional[str] = None  # 日志片段（如 console/page/network 错误时的日志）

    def __hash__(self) -> int:
        return hash((self.type, self.message, self.url, self.path))

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, ExplorationIssue):
            return False
        return (
            self.type == other.type
            and self.message == other.message
            and self.url == other.url
            and self.path == other.path
        )


class ErrorCollector:
    """
    绑定到 Playwright Page，采集 console.error/warn、pageerror、response(status>=400)。
    """

    def __init__(self) -> None:
        self._page: Optional["Page"] = None
        self._issues: List[ExplorationIssue] = []
        self._seen: Set[Tuple[str, str, str, str]] = set()  # 用于去重
        self._handlers: Dict[str, Callable[..., None]] = {}

    def attach(self, page: "Page", url: str = "", path: str = "") -> None:
        """
        绑定到指定 page，注册监听器。
        若已绑定其他 page，先 detach。
        """
        self.detach()
        self._page = page
        self._base_url = url
        self._base_path = path

        def on_console(msg) -> None:
            try:
                msg_type = getattr(msg, "type", "") or ""
            except Exception:
                msg_type = ""
            if msg_type not in ("error", "warning"):
                return
            try:
                text = msg.text
            except Exception:
                text = str(msg)
            issue = ExplorationIssue(
                type="console_error",
                message=text[:500],
                url=url,
                path=path,
                detail="type=%s" % msg_type,
            )
            self._add_issue(issue)

        def on_pageerror(exception) -> None:
            msg = str(exception)
            issue = ExplorationIssue(
                type="page_error",
                message=msg[:500],
                url=url,
                path=path,
                detail="uncaught exception",
            )
            self._add_issue(issue)

        def on_response(response) -> None:
            try:
                status = response.status
                if status < 400:
                    return
                req = response.request
                req_url = req.url if req else ""
                issue = ExplorationIssue(
                    type="network_error",
                    message="%s %s" % (response.status, req_url[:200]),
                    url=url,
                    path=path,
                    detail="status=%d" % status,
                )
                self._add_issue(issue)
            except Exception as e:
                logger.debug("Error in response handler: %s", e)

        page.on("console", on_console)
        page.on("pageerror", on_pageerror)
        page.on("response", on_response)
        self._handlers = {
            "console": on_console,
            "pageerror": on_pageerror,
            "response": on_response,
        }
        logger.debug("ErrorCollector attached to page, url=%s path=%s", url[:80], path)

    def _add_issue(self, issue: ExplorationIssue) -> None:
        key = (issue.type, issue.message, issue.url, issue.path)
        if key in self._seen:
            return
        self._seen.add(key)
        self._issues.append(issue)

    def add_exploration_failed(self, message: str, url: str = "", path: str = "") -> None:
        """记录探索动作失败。"""
        issue = ExplorationIssue(
            type="exploration_failed",
            message=message,
            url=url,
            path=path,
            detail="",
        )
        self._add_issue(issue)

    def add_visual_error(self, message: str, url: str = "", path: str = "") -> None:
        """记录视觉检测到的系统级报错。"""
        issue = ExplorationIssue(
            type="visual_error",
            message=message,
            url=url,
            path=path,
            detail="",
        )
        self._add_issue(issue)

    def collect(self, url: str = "", path: str = "") -> List[ExplorationIssue]:
        """
        返回当前采集到的错误列表。
        url/path 用于补充未设置的 issue 字段。
        """
        for i in self._issues:
            if not i.url and url:
                i.url = url
            if not i.path and path:
                i.path = path
        return list(self._issues)

    def clear(self) -> None:
        """清空缓冲区，用于新页面/新探索前重置。"""
        self._issues.clear()
        self._seen.clear()

    def detach(self) -> None:
        """移除监听器，解除与 page 的绑定。"""
        if self._page and self._handlers:
            try:
                self._page.remove_listener("console", self._handlers.get("console"))
                self._page.remove_listener("pageerror", self._handlers.get("pageerror"))
                self._page.remove_listener("response", self._handlers.get("response"))
            except Exception as e:
                logger.debug("ErrorCollector detach: %s", e)
            self._handlers = {}
        self._page = None
