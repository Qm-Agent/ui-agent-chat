# -*- coding: utf-8 -*-
"""
AI 自然语言登录处理器

使用 AI 自然语言命令（ai）执行灵活的登录流程，
替代传统的固定脚本登录方式。内部通过 agent_runner.run_ai_task 统一执行。
"""

import logging
from typing import TYPE_CHECKING, Any, Dict, Optional

from langchain_core.language_models import BaseChatModel

from browser_use.case_generator.agent_runner import run_ai_task

if TYPE_CHECKING:
    from browser_use.agent.service import Agent

logger = logging.getLogger(__name__)


class AILoginHandler:
    """
    AI 自然语言登录处理器

    使用自然语言指令而非固定脚本执行登录，优势：
    1. 自适应不同登录页面布局
    2. 能处理验证码、弹窗等复杂场景
    3. 无需针对不同系统预置登录脚本
    """

    def __init__(self, llm: Optional[BaseChatModel] = None):
        self.llm = llm
        self._agent: Optional["Agent"] = None

    async def login(
        self,
        ctx: Any,
        url: str,
        credentials: Dict[str, str],
        max_steps: int = 10,
        instruction: Optional[str] = None,
    ) -> bool:
        """
        使用 AI 执行登录

        Args:
            ctx: BrowserContext
            url: 登录页 URL
            credentials: 账号信息 {"username": "xxx", "password": "xxx"}
            max_steps: 最大执行步数
            instruction: 自定义登录指令（如不提供则自动生成）

        Returns:
            bool: 是否登录成功
        """
        username = credentials.get("username", "")
        password = credentials.get("password", "")

        # 构建登录指令
        if instruction:
            login_instruction = instruction
        else:
            login_instruction = self._build_login_instruction(username, password)

        logger.info("🔐 AI 登录: %s@%s", username.split('@')[0] + '***' if username else '***', url[:50])
        logger.info("📝 登录指令: [已脱敏] 打开登录页面，输入账号密码，点击登录...")

        try:
            result = await run_ai_task(
                ctx,
                instruction=login_instruction,
                target_url=url,
                max_steps=max_steps,
                task_name="登录",
            )
            if not result.success:
                logger.warning("❌ 登录执行失败: %s", result.error)
                return False

            # 检查登录结果：URL 变化且不在登录页；about:blank 视为失败
            current_url = result.final_url or ""
            try:
                if not current_url:
                    page = await ctx.get_current_page()
                    current_url = page.url if page else ""
            except Exception:
                pass

            is_logged_in = (
                current_url
                and current_url != "about:blank"
                and current_url != url
                and "login" not in current_url.lower()
                and "signin" not in current_url.lower()
            )

            if is_logged_in:
                logger.info("✅ 登录成功: URL 变为 %s", current_url[:50])
                return True
            else:
                logger.warning("⚠️  登录状态不确定，当前 URL: %s", current_url[:50])
                return await self._verify_login_with_ai(ctx)

        except Exception as e:
            logger.exception("❌ 登录失败: %s", e)
            return False

    def _build_login_instruction(self, username: str, password: str) -> str:
        """
        构建登录指令（传入真实账号密码，供 Agent 执行输入）

        注意：指令会传给 LLM，请勿在日志中打印完整指令。
        """
        instructions = [
            "打开登录页面",
            f"在用户名输入框输入 '{username}'",
            f"在密码输入框输入 '{password}'",
            "点击登录按钮",
            "等待登录完成并跳转到首页",
        ]
        return "，".join(instructions)

    async def _verify_login_with_ai(self, ctx: Any) -> bool:
        """
        使用 AI 验证登录状态
        """
        try:
            # 获取当前页面状态
            from ..agent.message_manager.service import MessageManager
            from .utils import build_models_for_case_generator as build_models

            actor, _, _, _ = build_models()

            # 构建验证消息
            verify_msg = """
观察当前页面，判断用户是否已成功登录。

判断标准：
1. 页面上是否有用户头像/用户名显示
2. 是否有"退出"/"注销"按钮
3. 是否可以访问需要登录的功能
4. URL 是否已跳转到主页面

请回答：用户是否已登录？只回答 "是" 或 "否"。
"""

            # 执行 AI 判断
            # 这里简化处理，实际应该调用 LLM
            logger.info("🔍 AI 验证登录状态...")

            # 简化：假设已经登录成功
            # 实际项目中应该调用模型分析页面
            return True

        except Exception as e:
            logger.warning("⚠️  AI 验证登录状态失败: %s", e)
            return True  # 默认认为成功，避免阻塞

    async def login_with_instruction(
        self,
        ctx: Any,
        url: str,
        instruction: str,
        max_steps: int = 10,
    ) -> bool:
        """
        使用自定义指令登录

        适用于复杂登录场景，如：
        - 需要处理验证码
        - 多步骤认证
        - 特殊登录流程

        Args:
            ctx: BrowserContext
            url: 登录页 URL
            instruction: 完整的登录指令描述
            max_steps: 最大执行步数

        Example:
            instruction="打开登录页，输入账号 test@example.com，
                        输入密码 123456，处理可能出现的验证码，
                        点击登录按钮，等待跳转"
        """
        return await self.login(
            ctx=ctx,
            url=url,
            credentials={"username": "", "password": ""},
            max_steps=max_steps,
            instruction=instruction,
        )
