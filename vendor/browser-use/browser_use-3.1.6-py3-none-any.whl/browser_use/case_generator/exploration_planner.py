# -*- coding: utf-8 -*-
"""
下一步规划角色：UI 测试用例生成 Agent 的规划子角色。
职责：用例设计完成后，规划可点击操作项，识别可进入下一层级页面的操作。
"""

import json
import logging
import os
from typing import Any, Dict, List, Optional, Set

from langchain_core.language_models import BaseChatModel

from browser_use.case_generator.models import ExplorationPlan, PageAnalysisResult
from browser_use.case_generator.utils import ainvoke_with_retry
from browser_use.agent.message_manager.utils import extract_json_from_model_output

logger = logging.getLogger(__name__)

# #region agent log
_DEBUG_LOG_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
    ".cursor", "debug-2f4155.log"
)
def _debug_log(hypothesis_id: str, message: str, data: dict):
    try:
        import time
        payload = {
            "hypothesisId": hypothesis_id,
            "location": "exploration_planner.py",
            "message": message,
            "data": data,
            "timestamp": int(time.time() * 1000),
        }
        with open(_DEBUG_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(payload, ensure_ascii=False) + "\n")
    except Exception:
        pass
# #endregion


class ActionCandidate:
    """标准化的动作候选对象，统一字段格式。"""

    def __init__(
        self,
        label: str,
        description: str,
        element_index: Optional[int] = None,
        priority: int = 5,
        **extras
    ):
        self.label = label
        self.description = description
        self.element_index = element_index
        self.priority = max(1, min(10, priority))  # 限制在 1-10 范围内
        self.extras = extras  # 额外字段保留

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典，供下游使用。"""
        result = {
            "label": self.label,
            "description": self.description,
            "element_index": self.element_index,
            "priority": self.priority,
        }
        result.update(self.extras)
        return result

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ActionCandidate":
        """从字典创建，提供默认值容错。"""
        if not isinstance(data, dict):
            # 如果是字符串，转换为基本结构
            if isinstance(data, str):
                return cls(label=data, description=f"点击{data}")
            return cls(label="unknown", description="invalid action")

        label = data.get("label", "")
        if not label:
            label = data.get("element", "unknown")

        description = data.get("description", "")
        if not description:
            description = f"点击{label}"

        # 解析 element_index（可能以不同字段传入）
        element_index = data.get("element_index")
        if element_index is None:
            element_index = data.get("index")
        if element_index is not None:
            try:
                element_index = int(element_index)
            except (ValueError, TypeError):
                element_index = None

        # 解析 priority（默认 5）
        priority = data.get("priority", 5)
        try:
            priority = int(priority)
        except (ValueError, TypeError):
            priority = 5

        # 收集额外字段
        extras = {
            k: v
            for k, v in data.items()
            if k not in {
                "label", "description", "element_index", "index", "priority", "element"
            }
        }

        return cls(
            label=label,
            description=description,
            element_index=element_index,
            priority=priority,
            **extras
        )


class ExplorationPlanner:
    """Plans next exploration actions based on page analysis."""

    # 高优先级的导航关键词（用于 fallback 策略）
    HIGH_PRIORITY_KEYWORDS = [
        "menu", "nav", "导航", "分类", "目录", "category",
        "产品", "project", "详情", "detail", "更多", "more"
    ]

    def __init__(self, llm: BaseChatModel):
        self.llm = llm

    async def plan(
        self,
        analysis: PageAnalysisResult,
        depth: int,
        max_depth: int,
        visited_paths: Set[str],
        exploration_budget: int = 5,
        path_chain: Optional[List[str]] = None,
    ) -> ExplorationPlan:
        """
        Plan next exploration actions.
        Returns ExplorationPlan with 1-3 next_actions or is_done=True.
        """
        logger.info("🧭 [ExplorationPlanner] 开始规划下一层探索...")
        logger.info("   📊 当前深度: %d/%d", depth, max_depth)
        logger.info("   📝 已访问页面: %d 个", len(visited_paths))

        if depth >= max_depth:
            logger.info("   ⏹️ 已达到最大深度，停止探索")
            return ExplorationPlan(
                next_actions=[],
                reason="depth limit reached",
                is_done=True,
            )

        # 统一转换为 ActionCandidate 对象
        nav_actions = self._normalize_actions(
            analysis.navigable_actions or [],
            source="navigable_actions"
        )
        nav_source = "navigable_actions" if nav_actions else None

        # 如果 navigable_actions 为空，尝试用 main_actions 补充
        main_actions = analysis.main_actions or []
        if not nav_actions and main_actions:
            nav_actions = [
                ActionCandidate(
                    label=a,
                    description=f"点击{a}",
                    priority=self._estimate_priority(a)
                )
                for a in main_actions
            ]
            nav_source = "main_actions"

        # 如果仍然为空，尝试从 actionable_elements 中提取可导航元素（link 类型或常见导航词汇）
        if not nav_actions and analysis.actionable_elements:
            nav_actions = self._extract_navigable_from_elements(analysis.actionable_elements)
            nav_source = "actionable_elements"

        # #region agent log
        _debug_log("A", "nav_actions source and element_index", {
            "nav_source": nav_source,
            "nav_count": len(nav_actions),
            "with_element_index": sum(
                1
                for a in nav_actions
                if a.element_index is not None
            ),
            "without_element_index": sum(
                1
                for a in nav_actions
                if a.element_index is None
            ),
            "nav_labels": [a.label for a in nav_actions[:8]],
            "nav_element_indexes": [a.element_index for a in nav_actions[:8]],
        })
        _debug_log("B", "actionable_elements at plan time", {
            "count": len(analysis.actionable_elements or []),
            "labels": [e.get("label") for e in (analysis.actionable_elements or [])[:10]],
            "indexes": [e.get("index") or e.get("element_index") for e in (analysis.actionable_elements or [])[:10]],
        })
        # #endregion

        # 为缺少 element_index 的 nav_actions 尝试从 actionable_elements 中按 label 匹配
        nav_actions = self._fill_element_index_from_actionable_elements(
            nav_actions, analysis.actionable_elements or []
        )

        # #region agent log
        _debug_log("C", "after fill_element_index", {
            "with_element_index": sum(
                1
                for a in nav_actions
                if a.element_index is not None
            ),
            "without_element_index": sum(
                1
                for a in nav_actions
                if a.element_index is None
            ),
        })
        # #endregion

        if not nav_actions:
            logger.info("   ⏹️ 未发现可导航操作，停止探索")
            return ExplorationPlan(
                next_actions=[],
                reason="no navigable actions",
                is_done=True,
            )

        budget_remaining = exploration_budget - len(visited_paths)
        if budget_remaining <= 0:
            logger.info("   ⏹️ 探索预算已耗尽，停止探索")
            return ExplorationPlan(
                next_actions=[],
                reason="exploration budget exhausted",
                is_done=True,
            )

        # 按 priority 排序，高优先级在前
        nav_actions.sort(key=lambda x: x.priority, reverse=True)

        logger.info("   🔗 发现 %d 个可导航操作", len(nav_actions))
        logger.info("   💰 剩余探索预算: %d", budget_remaining)
        logger.info("   📊 优先级分布: %s", self._format_priority_summary(nav_actions))
        logger.info("   🤖 调用 LLM 规划探索策略...")

        try:
            from browser_use.case_generator.prompts import ExplorationPlanPrompt

            # 将 ActionCandidate 转换为 dict 以便 JSON 序列化
            nav_actions_dicts = [a.to_dict() for a in nav_actions]

            messages = [
                ExplorationPlanPrompt.get_system_message(),
                ExplorationPlanPrompt.get_user_message(
                    analysis=analysis,
                    depth=depth,
                    max_depth=max_depth,
                    visited_paths=list(visited_paths),
                    nav_actions=nav_actions_dicts,
                    path_chain=path_chain,
                ),
            ]

            # 调试日志：打印模型输入
            logger.debug("=" * 60)
            logger.debug("[ExplorationPlanner] 模型输入:")
            logger.debug("  Page: %s (type: %s)", analysis.page_title, analysis.page_type)
            logger.debug("  Depth: %d/%d", depth, max_depth)
            logger.debug("  Visited: %s", list(visited_paths))
            logger.debug("  Navigable Actions (%d):", len(nav_actions_dicts))
            for i, action in enumerate(nav_actions_dicts[:10], 1):  # 最多打印10个
                logger.debug("    %d. [%s] %s - %s",
                    i,
                    action.get('priority', 'N/A'),
                    action.get('label', 'N/A'),
                    action.get('description', 'N/A')[:50]
                )
            if len(nav_actions_dicts) > 10:
                logger.debug("    ... and %d more", len(nav_actions_dicts) - 10)
            logger.debug("=" * 60)

            # 使用带重试的 LLM 调用（参考 agent/service.py 模式）
            parsed = await ainvoke_with_retry(
                self.llm,
                messages,
                parsing_func=self._parse_and_validate,
                max_retry=3,
            )

            # 调试日志：打印模型输出
            logger.debug("=" * 60)
            logger.debug("[ExplorationPlanner] 模型输出:")
            logger.debug("  is_done: %s", parsed.get('is_done', False))
            logger.debug("  reason: %s", parsed.get('reason', 'N/A'))
            logger.debug("  next_actions (%d):", len(parsed.get('next_actions', [])))
            for i, action in enumerate(parsed.get('next_actions', []), 1):
                logger.debug("    %d. %s - %s",
                    i,
                    action.get('label', 'N/A'),
                    action.get('description', 'N/A')[:50]
                )
            logger.debug("=" * 60)

            next_actions = self._normalize_actions(
                parsed.get("next_actions", []),
                source="llm_output"
            )[:3]
            reason = parsed.get("reason", "")
            is_done = bool(parsed.get("is_done", False))

            if is_done:
                logger.info("   ⏹️ 探索完成: %s", reason)
                return ExplorationPlan(
                    next_actions=[],
                    reason=reason,
                    is_done=True,
                )

            # 转换为字典列表返回
            next_actions_dicts = [a.to_dict() for a in next_actions]
            logger.info("   ✅ 规划完成，选择 %d 个探索动作", len(next_actions))
            for i, action in enumerate(next_actions, 1):
                idx_info = f"[idx:{action.element_index}]" if action.element_index else ""
                logger.info("      %d. [%dp] %s %s - %s", i, action.priority, action.label, idx_info, action.description)

            return ExplorationPlan(
                next_actions=next_actions_dicts,
                reason=reason,
                is_done=False,
            )
        except Exception as e:
            logger.warning("   ⚠️ 探索规划失败，使用回退策略: %s", e)
            # 回退策略：按优先级排序后选择
            selected = nav_actions[: min(3, budget_remaining)]
            actions_dicts = [a.to_dict() for a in selected]
            logger.info("   ✅ 使用回退策略，选择 %d 个探索动作", len(selected))
            for i, action in enumerate(selected, 1):
                idx_info = f"[idx:{action.element_index}]" if action.element_index else ""
                logger.info("      %d. [%dp] %s %s", i, action.priority, action.label, idx_info)
            return ExplorationPlan(
                next_actions=actions_dicts,
                reason=f"fallback due to: {str(e)[:50]}",
                is_done=False,
            )

    def _parse_and_validate(self, content: str) -> dict:
        """Extract and validate JSON from LLM response.

        扩展 _parse_json，增加字段验证和默认值填充。
        复用 browser_use.agent.message_manager.utils.extract_json_from_model_output
        """
        parsed = extract_json_from_model_output(content)

        if not isinstance(parsed, dict):
            logger.warning("LLM response is not a dict, wrapping: %s", type(parsed))
            parsed = {"next_actions": [], "reason": "invalid format", "is_done": True}

        # 验证 next_actions 字段
        next_actions = parsed.get("next_actions", [])
        if not isinstance(next_actions, list):
            logger.warning("next_actions is not a list: %s", type(next_actions))
            next_actions = []
            parsed["next_actions"] = next_actions

        # 验证每个 action 的基本字段
        validated_actions = []
        for i, action in enumerate(next_actions):
            if not isinstance(action, dict):
                logger.warning("Action %d is not a dict: %s", i, type(action))
                continue

            # 确保必需的 label 字段存在
            label = action.get("label") or action.get("element")
            if not label:
                logger.warning("Action %d missing label, skipping", i)
                continue

            # 规范化字段
            validated = {
                "label": str(label),
                "description": str(action.get("description", f"点击{label}")),
                "element_index": action.get("element_index") or action.get("index"),
                "priority": action.get("priority", 5),
            }
            validated_actions.append(validated)

        parsed["next_actions"] = validated_actions

        # 验证 reason 字段
        if not isinstance(parsed.get("reason"), str):
            parsed["reason"] = str(parsed.get("reason", ""))

        # 验证 is_done 字段
        is_done = parsed.get("is_done")
        if not isinstance(is_done, bool):
            parsed["is_done"] = str(is_done).lower() in ("true", "yes", "1", "done")

        return parsed

    def _normalize_actions(self, actions: List[Any], source: str = "unknown") -> List[ActionCandidate]:
        """统一将各种格式的 action 转换为 ActionCandidate 列表。

        Args:
            actions: 可能包含 dict、str 或 ActionCandidate 的列表
            source: 数据来源标识（用于日志）

        Returns:
            List[ActionCandidate]: 标准化的 ActionCandidate 列表
        """
        if not actions:
            return []

        candidates = []
        for i, action in enumerate(actions):
            try:
                if isinstance(action, ActionCandidate):
                    candidates.append(action)
                elif isinstance(action, dict):
                    candidates.append(ActionCandidate.from_dict(action))
                elif isinstance(action, str):
                    candidates.append(ActionCandidate(
                        label=action,
                        description=f"点击{action}",
                        priority=self._estimate_priority(action)
                    ))
                else:
                    logger.warning("[%s] Unknown action type at %d: %s", source, i, type(action))
            except Exception as e:
                logger.warning("[%s] Failed to parse action %d: %s", source, i, e)

        if candidates:
            logger.debug("[%s] Normalized %d actions from %d inputs", source, len(candidates), len(actions))

        return candidates

    def _estimate_priority(self, label: str) -> int:
        """根据 label 估算优先级（用于 main_actions 转换和 fallback）。

        基于关键词匹配，返回 1-10 的优先级值（越大越优先）。
        """
        label_lower = str(label).lower()

        for keyword in self.HIGH_PRIORITY_KEYWORDS:
            if keyword.lower() in label_lower:
                return 8  # 高优先级

        # 其他情况默认中等优先级
        return 5

    def _format_priority_summary(self, actions: List[ActionCandidate]) -> str:
        """格式化优先级分布摘要。"""
        if not actions:
            return "N/A"

        # 按优先级分档统计
        high = sum(
            1
            for a in actions
            if a.priority >= 7
        )
        medium = sum(
            1
            for a in actions
            if 4 <= a.priority < 7
        )
        low = sum(
            1
            for a in actions
            if a.priority < 4
        )

        parts = []
        if high:
            parts.append(f"高:{high}")
        if medium:
            parts.append(f"中:{medium}")
        if low:
            parts.append(f"低:{low}")

        return ", ".join(parts) if parts else "N/A"

    def _extract_navigable_from_elements(self, elements: List[Dict]) -> List[ActionCandidate]:
        """
        从 actionable_elements 中提取可导航元素。

        当 navigable_actions 为空时，根据 HTML tag name 推断可导航元素。
        - <a> 标签（链接）通常是可导航的
        """
        nav_candidates = []

        logger.debug("   🔍 从 %d 个 actionable_elements 中提取可导航元素", len(elements))

        for elem in elements:
            if not isinstance(elem, dict):
                logger.debug("      ⚠️ 跳过非字典元素: %s", type(elem))
                continue

            # element_type 是 HTML tag name（如 "a", "button", "input"）
            elem_type = elem.get("element_type", "").lower()
            label = elem.get("label", "") or elem.get("text", "")
            index = elem.get("index") or elem.get("element_index")

            logger.debug("      📎 检查元素: type=%s, label=%s, index=%s", elem_type, label, index)

            # 判断是否是可导航元素
            is_navigable = False

            # HTML <a> 标签（链接）是可导航的
            if elem_type == "a":
                is_navigable = True

            # 旧版兼容：如果 element_type 是 "link" 也认为是可导航的
            if elem_type == "link":
                is_navigable = True

            # button、span 等可能为侧边栏/菜单项，有 index 时也视为可导航（便于 label 匹配执行点击）
            if elem_type in ("button", "span", "div") and index is not None and label:
                is_navigable = True

            # 如果没有 index，记录警告
            if is_navigable and index is None:
                logger.warning("      ⚠️ 可导航元素缺少 index: %s (type=%s)", label, elem_type)

            if is_navigable and label:
                desc = elem.get("description") or f"点击{label}"
                candidate = ActionCandidate(
                    label=label,
                    description=desc,
                    element_index=index,
                    priority=self._estimate_priority(label)
                )
                nav_candidates.append(candidate)
                logger.debug("      ✅ 添加可导航元素: %s [idx:%s]", label, index)

        if nav_candidates:
            logger.info("   🔍 从 actionable_elements 中提取 %d 个可导航元素", len(nav_candidates))
            # 记录提取的可导航元素详情
            for i, nav in enumerate(nav_candidates[:5], 1):
                logger.debug("      %d. %s [idx:%s]", i, nav.label, nav.element_index)
        else:
            logger.warning("   ⚠️ 未从 actionable_elements 中提取到可导航元素")

        return nav_candidates

    def _fill_element_index_from_actionable_elements(
        self,
        nav_actions: List[ActionCandidate],
        actionable_elements: List[Dict],
    ) -> List[ActionCandidate]:
        """
        为缺少 element_index 的 nav_actions 从 actionable_elements 中按 label 匹配 index。
        解决 navigable_actions/main_actions 仅有 label 无 index 时无法执行点击的问题。
        """
        if not actionable_elements:
            return nav_actions

        # 构建 label -> index 映射（支持模糊匹配：去除空格、忽略大小写）
        label_to_index: Dict[str, int] = {}
        for elem in actionable_elements:
            idx = elem.get("index") or elem.get("element_index")
            if idx is None:
                continue
            try:
                idx = int(idx)
            except (ValueError, TypeError):
                continue
            label = (elem.get("label") or elem.get("text") or "").strip()
            if label:
                label_to_index[label] = idx
                # 也存储去除空格后的版本
                label_norm = "".join(label.split())
                if label_norm and label_norm != label:
                    label_to_index.setdefault(label_norm, idx)

        filled = 0
        for action in nav_actions:
            if action.element_index is not None:
                continue
            label = (action.label or "").strip()
            if not label:
                continue
            idx = label_to_index.get(label) or label_to_index.get("".join(label.split()))
            if idx is not None:
                action.element_index = idx
                filled += 1
                logger.debug("   📎 按 label 匹配 element_index: %s -> %d", label, idx)

        if filled:
            logger.info("   📎 从 actionable_elements 为 %d 个可导航操作补充了 element_index", filled)

        return nav_actions
