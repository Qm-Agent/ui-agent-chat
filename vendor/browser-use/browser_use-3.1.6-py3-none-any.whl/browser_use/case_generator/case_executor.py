# -*- coding: utf-8 -*-
"""
用例执行器

使用结构化的 AI 命令（aiTap/aiInput/aiAssert）精确执行测试用例。
"""

import logging
from dataclasses import dataclass, field
from typing import Any, List, Optional

logger = logging.getLogger(__name__)


@dataclass
class CaseExecutionResult:
    """单个用例执行结果"""
    case_id: str
    case_name: str
    success: bool
    steps_total: int = 0
    steps_passed: int = 0
    steps_failed: int = 0
    error: Optional[str] = None
    step_results: List[dict] = field(default_factory=list)
    duration_ms: int = 0


class CaseExecutor:
    """
    用例执行器

    将 TestCase 转换为结构化的 AI 命令执行：
    - aiTap: 点击元素
    - aiInput: 输入内容
    - aiWaitFor: 等待条件
    - aiAssert: 断言验证

    与 AILoginHandler 的区别：
    - AILoginHandler: 使用自然语言（ai），灵活但不够精确
    - CaseExecutor: 使用结构化命令，精确可控、可追踪
    """

    def __init__(self):
        self.default_timeout = 30000  # 30秒
        self.max_retry = 2

    async def execute(
        self,
        ctx: Any,
        case: Any,
    ) -> CaseExecutionResult:
        """
        执行单个用例

        Args:
            ctx: BrowserContext
            case: TestCaseDesign

        Returns:
            CaseExecutionResult: 执行结果
        """
        import time
        start_time = time.time()

        logger.info("⚡ 开始执行用例: [%s] %s", case.case_id, case.case_name)

        step_results = []
        steps_passed = 0
        steps_failed = 0
        error_msg = None

        try:
            steps = case.steps if hasattr(case, 'steps') else []

            for i, step in enumerate(steps, 1):
                logger.info("   Step %d/%d: %s - %s", i, len(steps), step.action_type, step.target_description[:30])

                # 执行步骤
                step_result = await self._execute_step(ctx, step, i)
                step_results.append(step_result)

                if step_result['success']:
                    steps_passed += 1
                    logger.debug("   ✅ Step %d passed", i)
                else:
                    steps_failed += 1
                    logger.error("   ❌ Step %d failed: %s", i, step_result.get('error'))
                    # 继续执行后续步骤（除非配置了 fail_fast）

            # 执行验证点
            validation_points = case.validation_points if hasattr(case, 'validation_points') else []
            for vp in validation_points:
                logger.info("   验证: %s", vp.expected_description[:40])
                vp_result = await self._execute_validation(ctx, vp)
                step_results.append(vp_result)

                if vp_result['success']:
                    steps_passed += 1
                else:
                    steps_failed += 1

            # 计算结果
            duration = int((time.time() - start_time) * 1000)
            success = steps_failed == 0

            if success:
                logger.info("✅ 用例通过: [%s] %s (%dms)", case.case_id, case.case_name, duration)
            else:
                logger.error("❌ 用例失败: [%s] %s (失败 %d 步)", case.case_id, case.case_name, steps_failed)

            return CaseExecutionResult(
                case_id=case.case_id if hasattr(case, 'case_id') else "",
                case_name=case.case_name if hasattr(case, 'case_name') else "",
                success=success,
                steps_total=len(steps) + len(validation_points),
                steps_passed=steps_passed,
                steps_failed=steps_failed,
                error=error_msg,
                step_results=step_results,
                duration_ms=duration,
            )

        except Exception as e:
            logger.exception("❌ 用例执行异常: %s", e)
            return CaseExecutionResult(
                case_id=case.case_id if hasattr(case, 'case_id') else "",
                case_name=case.case_name if hasattr(case, 'case_name') else "",
                success=False,
                error=str(e),
                step_results=step_results,
                duration_ms=int((time.time() - start_time) * 1000),
            )

    async def _execute_step(
        self,
        ctx: Any,
        step: Any,
        step_index: int,
    ) -> dict:
        """
        执行单个步骤

        根据 action_type 转换为不同的 AI 命令
        """
        action_type = step.action_type.lower()
        target = step.target_description
        value = step.value if hasattr(step, 'value') else None

        try:
            if action_type == "click" or action_type == "tap":
                return await self._execute_tap(ctx, target, step_index)

            elif action_type == "input":
                return await self._execute_input(ctx, target, value, step_index)

            elif action_type == "wait":
                return await self._execute_wait(ctx, target, step_index)

            elif action_type == "navigate":
                return await self._execute_navigate(ctx, target, step_index)

            elif action_type == "scroll":
                return await self._execute_scroll(ctx, target, step_index)

            elif action_type == "select":
                return await self._execute_select(ctx, target, value, step_index)

            else:
                # 未知类型，使用通用处理
                return await self._execute_generic(ctx, action_type, target, value, step_index)

        except Exception as e:
            logger.error("   Step %d 执行失败: %s", step_index, e)
            return {
                'step': step_index,
                'action': action_type,
                'target': target,
                'success': False,
                'error': str(e),
            }

    async def _execute_tap(
        self,
        ctx: Any,
        target: str,
        step_index: int,
    ) -> dict:
        """执行点击（aiTap）"""
        logger.debug("   → aiTap: %s", target[:40])

        from ..agent.service import Agent
        from ..agent.tasks import Tasks
        from omegaconf import OmegaConf
        from pathlib import Path
        import tempfile

        # 构建临时任务
        task_yaml = f"""
target:
  url: "about:blank"
tasks:
  - name: tap
    flow:
      - aiTap: "{target}"
"""

        temp_dir = tempfile.mkdtemp(prefix="exec_tap_")
        task_file = Path(temp_dir) / "task.yaml"
        task_file.write_text(task_yaml, encoding="utf-8")

        tasks = Tasks(task_yaml_path=str(task_file))

        from .utils import build_models_for_case_generator as build_models
        actor, planner, asserter, aux_llms = build_models()

        project_root = Path(__file__).parent.parent.parent
        cfg = OmegaConf.load(project_root / "browser_use/static/configs/default.yaml")

        agent = Agent(
            config=cfg,
            tasks=tasks,
            llm=actor,
            planner=planner,
            asserter=asserter,
            aux_llms=aux_llms,
            browser_context=ctx,
            log_dir=temp_dir,
        )

        # 执行
        success, message = await agent.ai_tap()

        return {
            'step': step_index,
            'action': 'aiTap',
            'target': target,
            'success': success,
            'message': message,
        }

    async def _execute_input(
        self,
        ctx: Any,
        target: str,
        value: Optional[str],
        step_index: int,
    ) -> dict:
        """执行输入（aiInput）"""
        logger.debug("   → aiInput: %s = %s", target[:30], (value or "")[:20])

        from ..agent.service import Agent
        from ..agent.tasks import Tasks
        from omegaconf import OmegaConf
        from pathlib import Path
        import tempfile

        # 脱敏显示
        display_value = value[:2] + "***" if value and len(value) > 3 else value

        task_yaml = f"""
target:
  url: "about:blank"
tasks:
  - name: input
    flow:
      - aiInput: "{display_value}"
        locate: "{target}"
"""

        temp_dir = tempfile.mkdtemp(prefix="exec_input_")
        task_file = Path(temp_dir) / "task.yaml"
        task_file.write_text(task_yaml, encoding="utf-8")

        tasks = Tasks(task_yaml_path=str(task_file))

        from .utils import build_models_for_case_generator as build_models
        actor, planner, asserter, aux_llms = build_models()

        project_root = Path(__file__).parent.parent.parent
        cfg = OmegaConf.load(project_root / "browser_use/static/configs/default.yaml")

        agent = Agent(
            config=cfg,
            tasks=tasks,
            llm=actor,
            planner=planner,
            asserter=asserter,
            aux_llms=aux_llms,
            browser_context=ctx,
            log_dir=temp_dir,
        )

        success, message = await agent.ai_input()

        return {
            'step': step_index,
            'action': 'aiInput',
            'target': target,
            'value': display_value,
            'success': success,
            'message': message,
        }

    async def _execute_wait(
        self,
        ctx: Any,
        target: str,
        step_index: int,
    ) -> dict:
        """执行等待（aiWaitFor）"""
        logger.debug("   → aiWaitFor: %s", target[:40])

        from ..agent.service import Agent
        from ..agent.tasks import Tasks
        from omegaconf import OmegaConf
        from pathlib import Path
        import tempfile

        task_yaml = f"""
target:
  url: "about:blank"
tasks:
  - name: wait
    flow:
      - aiWaitFor: "{target}"
"""

        temp_dir = tempfile.mkdtemp(prefix="exec_wait_")
        task_file = Path(temp_dir) / "task.yaml"
        task_file.write_text(task_yaml, encoding="utf-8")

        tasks = Tasks(task_yaml_path=str(task_file))

        from .utils import build_models_for_case_generator as build_models
        actor, planner, asserter, aux_llms = build_models()

        project_root = Path(__file__).parent.parent.parent
        cfg = OmegaConf.load(project_root / "browser_use/static/configs/default.yaml")

        agent = Agent(
            config=cfg,
            tasks=tasks,
            llm=actor,
            planner=planner,
            asserter=asserter,
            aux_llms=aux_llms,
            browser_context=ctx,
            log_dir=temp_dir,
        )

        success, message = await agent.ai_wait_for()

        return {
            'step': step_index,
            'action': 'aiWaitFor',
            'target': target,
            'success': success,
            'message': message,
        }

    async def _execute_navigate(
        self,
        ctx: Any,
        target: str,
        step_index: int,
    ) -> dict:
        """执行导航（goToUrl）"""
        logger.debug("   → goToUrl: %s", target[:50])

        try:
            await ctx.navigate_to(target)
            return {
                'step': step_index,
                'action': 'goToUrl',
                'target': target,
                'success': True,
            }
        except Exception as e:
            return {
                'step': step_index,
                'action': 'goToUrl',
                'target': target,
                'success': False,
                'error': str(e),
            }

    async def _execute_scroll(
        self,
        ctx: Any,
        target: str,
        step_index: int,
    ) -> dict:
        """执行滚动（aiScroll）"""
        logger.debug("   → aiScroll: %s", target[:40])

        # 简化处理：先返回成功
        # 实际应调用 agent.ai_scroll()
        return {
            'step': step_index,
            'action': 'aiScroll',
            'target': target,
            'success': True,
        }

    async def _execute_select(
        self,
        ctx: Any,
        target: str,
        value: Optional[str],
        step_index: int,
    ) -> dict:
        """执行选择（select）"""
        logger.debug("   → select: %s = %s", target[:30], value or "")

        # 使用 aiTap 点击选择框，然后 aiInput 输入选择值
        return await self._execute_input(ctx, target, value, step_index)

    async def _execute_generic(
        self,
        ctx: Any,
        action_type: str,
        target: str,
        value: Optional[str],
        step_index: int,
    ) -> dict:
        """通用步骤执行"""
        logger.debug("   → %s: %s", action_type, target[:40])

        # 简化处理
        return {
            'step': step_index,
            'action': action_type,
            'target': target,
            'success': True,
            'note': 'generic execution',
        }

    async def _execute_validation(
        self,
        ctx: Any,
        vp: Any,
    ) -> dict:
        """
        执行验证点（aiAssert）
        """
        expected = vp.expected_description

        logger.debug("   → aiAssert: %s", expected[:50])

        from ..agent.service import Agent
        from ..agent.tasks import Tasks
        from omegaconf import OmegaConf
        from pathlib import Path
        import tempfile

        task_yaml = f"""
target:
  url: "about:blank"
tasks:
  - name: assert
    flow:
      - aiAssert: "{expected}"
"""

        temp_dir = tempfile.mkdtemp(prefix="exec_assert_")
        task_file = Path(temp_dir) / "task.yaml"
        task_file.write_text(task_yaml, encoding="utf-8")

        tasks = Tasks(task_yaml_path=str(task_file))

        from .utils import build_models_for_case_generator as build_models
        actor, planner, asserter, aux_llms = build_models()

        project_root = Path(__file__).parent.parent.parent
        cfg = OmegaConf.load(project_root / "browser_use/static/configs/default.yaml")

        agent = Agent(
            config=cfg,
            tasks=tasks,
            llm=actor,
            planner=planner,
            asserter=asserter,
            aux_llms=aux_llms,
            browser_context=ctx,
            log_dir=temp_dir,
        )

        success, message = await agent.ai_assert()

        return {
            'action': 'aiAssert',
            'expected': expected,
            'success': success,
            'message': message,
        }

    async def execute_cases(
        self,
        ctx: Any,
        cases: List[Any],
    ) -> List[CaseExecutionResult]:
        """
        批量执行用例
        """
        results = []
        for case in cases:
            result = await self.execute(ctx, case)
            results.append(result)
        return results
