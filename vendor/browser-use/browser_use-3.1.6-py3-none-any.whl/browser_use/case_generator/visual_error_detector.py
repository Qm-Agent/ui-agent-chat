# -*- coding: utf-8 -*-
"""
视觉错误检测器：分析页面截图，识别系统级报错（404/500、错误提示、异常弹窗等）。

职责：使用 LLM 视觉能力分析截图，判断是否存在系统/网络/服务端相关错误，
将发现的错误记录为 ExplorationIssue 供汇总报告使用。
"""

import json
import logging
import re
from typing import List, Optional

from langchain_core.language_models import BaseChatModel

from browser_use.case_generator.error_collector import ExplorationIssue
from browser_use.case_generator.prompts import VisualErrorPrompt

logger = logging.getLogger(__name__)


class VisualErrorDetector:
    """分析截图，识别系统级报错。"""

    def __init__(self, llm: BaseChatModel):
        self.llm = llm

    async def detect(
        self,
        screenshot_base64: str,
        url: str = "",
        path: str = "",
    ) -> List[ExplorationIssue]:
        """
        分析截图，识别系统级报错。
        返回发现的错误列表，若无则返回空列表。
        """
        logger.info("👁️ [VisualErrorDetector] 开始视觉错误检测...")

        if not screenshot_base64:
            logger.debug("   ⏭️ 截图为空，跳过检测")
            return []

        logger.info("   📸 分析截图 (base64 长度: %d)", len(screenshot_base64[:50]))
        logger.info("   🔗 URL: %s", url[:80] if url else "unknown")

        messages = [
            VisualErrorPrompt.get_system_message(),
            VisualErrorPrompt.get_user_message(url=url, screenshot_base64=screenshot_base64),
        ]

        try:
            logger.info("   🤖 调用 LLM 进行视觉分析...")
            response = await self.llm.ainvoke(messages)
            content = response.content if hasattr(response, "content") else str(response)
            if isinstance(content, list):
                content = "".join(
                    c.get("text", "") if isinstance(c, dict) else str(c) for c in content
                )
            parsed = self._parse_json(content)
            has_error = parsed.get("has_error", False)
            errors = parsed.get("errors", [])

            if not has_error or not errors:
                logger.info("   ✅ 未检测到视觉错误")
                return []

            issues: List[ExplorationIssue] = []
            for e in errors:
                msg = e.get("message", "") if isinstance(e, dict) else str(e)
                etype = e.get("type", "visual_error") if isinstance(e, dict) else "visual_error"
                issues.append(
                    ExplorationIssue(
                        type="visual_error",
                        message=msg[:500],
                        url=url,
                        path=path,
                        detail="etype=%s" % etype,
                    )
                )

            logger.warning("   🐛 检测到 %d 个视觉问题!", len(issues))
            for i, issue in enumerate(issues, 1):
                logger.warning("      %d. [%s] %s", i, issue.type, issue.message[:100])

            return issues

        except Exception as e:
            logger.warning("   ⚠️ 视觉错误检测失败: %s", e)
            return []

    def _parse_json(self, content: str) -> dict:
        content = content.strip()
        match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", content)
        if match:
            content = match.group(1).strip()
        try:
            return json.loads(content)
        except json.JSONDecodeError as e:
            logger.warning("Failed to parse visual error JSON: %s. Raw: %s", e, content[:300])
            return {"has_error": False, "errors": []}
