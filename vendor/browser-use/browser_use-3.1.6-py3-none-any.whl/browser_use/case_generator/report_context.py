# -*- coding: utf-8 -*-
"""
报告数据上下文：探索过程中采集的页面分析、用例、探索任务等，供 HTML 报告生成使用。
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class LoginRecord:
    """登录步骤记录：登录前后截图，供报告展示。"""

    url: str = ""
    before_screenshot: Optional[str] = None  # base64，登录前页面
    after_screenshot: Optional[str] = None  # base64，登录后页面
    success: bool = False
    steps: List[str] = field(default_factory=list)  # 登录步骤描述，如 ["打开登录页", "输入账号密码", "点击登录"]


@dataclass
class ExploreTaskRecord:
    """单条探索任务记录（执行前后截图）。"""

    label: str
    before_screenshot: Optional[str] = None  # base64
    after_screenshot: Optional[str] = None  # base64
    status: str = ""  # success | captcha_page | no_new_url | error
    new_url: Optional[str] = None
    child_node: Optional["PageReportNode"] = None  # 探索成功时对应的子页面节点


@dataclass
class PageReportNode:
    """单页报告节点：截图、分析、用例、探索任务。"""

    depth: int
    path: str
    url: str
    screenshot: Optional[str] = None  # base64
    analysis: Optional[Any] = None  # PageAnalysisResult
    cases: List[Any] = field(default_factory=list)  # List[TestCaseDesign]
    exploration_tasks: List[ExploreTaskRecord] = field(default_factory=list)
    children: List["PageReportNode"] = field(default_factory=list)


@dataclass
class ReportContext:
    """报告上下文：探索过程完整数据。"""

    target_url: str = ""
    nodes: List[PageReportNode] = field(default_factory=list)
    login_record: Optional[LoginRecord] = None  # 若有登录，记录登录前后截图
