# -*- coding: utf-8 -*-
"""
页面分析角色：UI 测试用例生成 Agent 的页面分析子角色。
职责：进入被测页面后，分析页面结构，识别并分类可操作元素与不可操作元素。

支持两种模式：
- use_vision_only=True（默认）：仅截图输入，LLM 输出可操作元素及含位置描述的 description，避免 DOM 导致超时。
- use_vision_only=False：传统 DOM+截图输入（兼容旧逻辑）。
"""

import json
import logging
import re
from typing import TYPE_CHECKING, List, Optional

from langchain_core.language_models import BaseChatModel

from browser_use.case_generator.models import PageAnalysisResult
from browser_use.case_generator.prompts import PageAnalysisPrompt, PageAnalysisVisionPrompt
from browser_use.case_generator.utils import ainvoke_with_retry
from browser_use.agent.message_manager.utils import extract_json_from_model_output

if TYPE_CHECKING:
    from browser_use.browser.context import BrowserContext

logger = logging.getLogger(__name__)

# 可选 DOM 匹配：最小 IoU 阈值，低于则不计入 index
DOM_MATCH_IOU_THRESHOLD = 0.2

# DOM 精简：不传属性，仅保留 index+tag+text+box_2d，减少 token（参考 Midscene）
# 可选：["aria-label"] 保留关键无障碍属性
DEFAULT_INCLUDE_ATTRIBUTES: List[str] = []

# 元素文本最大长度，超出截断以减少 LLM 输入
MAX_ELEMENT_TEXT_LEN = 80


def _truncate_page_description(desc: str, max_len: int = MAX_ELEMENT_TEXT_LEN) -> str:
    """截断 page_description 中过长的元素文本，减少 token。"""
    # 匹配 >text</ 中 text 超过 max_len 的部分
    def _repl(m: re.Match) -> str:
        text = m.group(1)
        return f">{text[:max_len]}...<"

    return re.sub(rf">([^<]{{{max_len + 1},}})<", _repl, desc)


class PageAnalyzer:
    """
    分析浏览器页面，识别可操作与不可操作元素，并按元素类型分类。
    输出包含 actionable_elements（可操作）和 non_actionable_elements（不可操作）。
    默认使用仅截图（vision-only）模式，避免 DOM 输入导致超时；description 含位置描述供执行 Agent 定位。
    """

    def __init__(
        self,
        llm: BaseChatModel,
        include_attributes: Optional[List[str]] = None,
        use_vision_only: bool = True,
        use_dom_match: bool = False,
    ):
        self.llm = llm
        self.include_attributes = include_attributes or DEFAULT_INCLUDE_ATTRIBUTES
        self.use_vision_only = use_vision_only
        self.use_dom_match = use_dom_match  # 仅在 use_vision_only 时有效：用 vision box_2d 与 DOM 匹配填 index

    async def analyze(self, browser_context: "BrowserContext") -> PageAnalysisResult:
        """
        分析当前页面，识别并分类元素。
        返回 PageAnalysisResult，含 actionable_elements 与 non_actionable_elements。
        """
        logger.info("🔍 [PageAnalyzer] 开始页面分析... (use_vision_only=%s)", self.use_vision_only)

        session = await browser_context.get_session()
        state = await browser_context.get_state()
        session.cached_state = state

        if state is None:
            raise RuntimeError("Browser state is None. Ensure page is loaded before analysis.")
        logger.info("   📄 URL: %s", state.url or "unknown")

        screenshot_base64 = state.screenshot
        if not screenshot_base64:
            raise RuntimeError("Screenshot is empty. Cannot analyze page.")

        if self.use_vision_only:
            return await self._analyze_vision_only(state, browser_context)
        return await self._analyze_with_dom(state)

    async def _analyze_vision_only(self, state, browser_context: "BrowserContext") -> PageAnalysisResult:
        """仅截图输入，无 DOM，减少 token 与超时；description 须含位置描述。"""
        logger.info("   📷 使用 vision-only 模式（仅截图）...")
        page_width = getattr(state, "page_width", None) or 0
        page_height = getattr(state, "page_height", None) or 0

        messages = [
            PageAnalysisVisionPrompt.get_system_message(),
            PageAnalysisVisionPrompt.get_user_message(
                url=state.url or "",
                screenshot_base64=state.screenshot,
                page_width=page_width or None,
                page_height=page_height or None,
            ),
        ]

        logger.info("   🤖 调用 LLM（仅图片）进行元素识别...")
        logger.debug("[PageAnalyzer] Vision-only 输入: url=%s, image size=%dx%d", state.url, page_width, page_height)

        parsed = await ainvoke_with_retry(
            self.llm,
            messages,
            parsing_func=self._parse_json,
            max_retry=3,
        )

        # 可选：用 vision 的 box_2d 与 DOM 匹配填 index
        if self.use_dom_match and parsed.get("actionable_elements"):
            parsed = self._fill_index_from_dom(parsed, state)

        result = PageAnalysisResult.from_dict(parsed)
        n_actionable = len(result.actionable_elements)
        n_non_actionable = len(result.non_actionable_elements)

        logger.info("   ✅ 页面分析完成（vision-only）")
        logger.info("      - 可操作元素: %d 个", n_actionable)
        logger.info("      - 不可操作元素: %d 个", n_non_actionable)
        if result.actionable_elements:
            type_counts = {}
            for elem in result.actionable_elements:
                elem_type = elem.get("element_type", "unknown") if isinstance(elem, dict) else getattr(elem, "element_type", "unknown")
                type_counts[elem_type] = type_counts.get(elem_type, 0) + 1
            logger.info("      - 元素类型分布: %s", ", ".join(f"{k}:{v}" for k, v in sorted(type_counts.items())))

        return result

    def _fill_index_from_dom(self, parsed: dict, state) -> dict:
        """用 vision 返回的 box_2d 与 DOM 做 IoU 匹配，为 actionable_elements 填 index。"""
        try:
            from browser_use.dom.views import DOMElementNode
            from browser_use.controller.utils import match_element_with_box_2d
        except ImportError as e:
            logger.debug("   ⏭️ 跳过 DOM 匹配（依赖不可用）: %s", e)
            return parsed

        element_tree = getattr(state, "element_tree", None)
        if not element_tree:
            logger.debug("   ⏭️ 无 element_tree，跳过 DOM 匹配")
            return parsed

        def _keep_clickable(node):
            return isinstance(node, DOMElementNode) and node.highlight_index is not None and node.rectangle is not None

        dom_elements = element_tree.recursively_get_all_children(filter_func=_keep_clickable)
        if not dom_elements:
            logger.debug("   ⏭️ 无可匹配的 DOM 元素，跳过")
            return parsed

        actionables = list(parsed.get("actionable_elements", []))
        filled = 0
        for elem in actionables:
            if not isinstance(elem, dict):
                continue
            if elem.get("index") is not None or elem.get("element_index") is not None:
                continue
            box_2d = elem.get("box_2d")
            if not box_2d or len(box_2d) != 4:
                continue
            try:
                top, left, bottom, right = box_2d[0], box_2d[1], box_2d[2], box_2d[3]
                matched, iou = match_element_with_box_2d((top, left, bottom, right), dom_elements)
                if iou >= DOM_MATCH_IOU_THRESHOLD and matched.highlight_index is not None:
                    elem["index"] = matched.highlight_index
                    elem["element_index"] = matched.highlight_index
                    filled += 1
            except Exception:
                pass
        if filled:
            logger.info("   📎 DOM 匹配为 %d 个可操作元素填入了 index", filled)
        parsed["actionable_elements"] = actionables
        return parsed

    async def _analyze_with_dom(self, state) -> PageAnalysisResult:
        """传统模式：DOM + 截图，兼容旧逻辑。"""
        page_description = state.build_page_description(
            include_attributes=self.include_attributes,
            include_offscreen_elements=False,
            box_format="tlbr",
        )
        page_description = _truncate_page_description(page_description)

        logger.info("   📝 构建页面描述完成 (长度: %d 字符)", len(page_description))
        logger.info("   🤖 调用 LLM 进行元素识别（DOM+截图）...")

        messages = [
            PageAnalysisPrompt.get_system_message(),
            PageAnalysisPrompt.get_user_message(
                page_description=page_description,
                url=state.url or "",
                screenshot_base64=state.screenshot,
            ),
        ]

        logger.debug("[PageAnalyzer] LLM 输入: page_description length=%d", len(page_description))

        parsed = await ainvoke_with_retry(
            self.llm,
            messages,
            parsing_func=self._parse_json,
            max_retry=3,
        )

        result = PageAnalysisResult.from_dict(parsed)
        n_actionable = len(result.actionable_elements)
        n_non_actionable = len(result.non_actionable_elements)

        logger.info("   ✅ 页面分析完成")
        logger.info("      - 可操作元素: %d 个", n_actionable)
        logger.info("      - 不可操作元素: %d 个", n_non_actionable)
        if result.actionable_elements:
            type_counts = {}
            for elem in result.actionable_elements:
                elem_type = elem.get("element_type", "unknown") if isinstance(elem, dict) else getattr(elem, "element_type", "unknown")
                type_counts[elem_type] = type_counts.get(elem_type, 0) + 1
            logger.info("      - 元素类型分布: %s", ", ".join(f"{k}:{v}" for k, v in sorted(type_counts.items())))

        return result

    def _parse_json(self, content: str) -> dict:
        """Extract JSON from LLM response (may be wrapped in markdown).

        复用 browser_use.agent.message_manager.utils.extract_json_from_model_output
        """
        try:
            return extract_json_from_model_output(content)
        except ValueError as e:
            logger.warning("Failed to parse page analysis JSON: %s. Raw: %s", e, content[:500])
            raise ValueError(f"Invalid JSON from page analysis: {e}") from e
