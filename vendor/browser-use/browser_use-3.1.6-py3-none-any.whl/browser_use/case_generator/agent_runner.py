# -*- coding: utf-8 -*-
"""
前置步骤 Agent 统一执行入口

抽取「临时 YAML → Agent 创建 → run()」为 run_ai_task，供登录、模块导航、前置多步骤共用。
"""

import logging
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


def _resolve_env_in_string(s: str) -> str:
    """解析字符串中的 ${VAR}，从 os.environ 取值；未定义则保留原样。"""
    import re
    pattern = r'\$\{\s*([a-zA-Z0-9_]+)\s*\}'
    def repl(match):
        key = match.group(1)
        return os.environ.get(key, match.group(0))
    return re.sub(pattern, repl, s)


def _inject_credentials_to_env(credentials: Optional[Dict[str, str]]) -> Dict[str, Optional[str]]:
    """
    将用户提供的 credentials 临时写入 os.environ，使 controller 的
    replace_variable_placeholders_in_string 能解析 ${USERNAME}/${PASSWORD}。
    若 credentials 值为 ${TEST_USERNAME}/${TEST_PASSWORD}，会先从环境解析再注入。
    返回被覆盖的旧值，便于恢复。
    """
    saved: Dict[str, Optional[str]] = {}
    if not credentials:
        return saved
    username = (credentials.get("username") or credentials.get("user") or "").strip()
    password = (credentials.get("password") or "").strip()
    username = _resolve_env_in_string(username)
    password = _resolve_env_in_string(password)
    if username:
        saved["USERNAME"] = os.environ.get("USERNAME")
        os.environ["USERNAME"] = username
        saved["TEST_USERNAME"] = os.environ.get("TEST_USERNAME")
        os.environ["TEST_USERNAME"] = username
    if password:
        saved["PASSWORD"] = os.environ.get("PASSWORD")
        os.environ["PASSWORD"] = password
        saved["TEST_PASSWORD"] = os.environ.get("TEST_PASSWORD")
        os.environ["TEST_PASSWORD"] = password
    return saved


def _restore_env(saved: Dict[str, Optional[str]]) -> None:
    """恢复 _inject_credentials_to_env 覆盖前的环境变量。"""
    for key, value in saved.items():
        if value is None:
            os.environ.pop(key, None)
        else:
            os.environ[key] = value


@dataclass
class PreStepResult:
    """单步前置执行结果，供 assistant 判断是否继续或进入探索。"""

    success: bool
    final_url: Optional[str] = None
    error: Optional[str] = None
    steps_count: int = 0


def _escape_instruction(instruction: str) -> str:
    """对指令中的特殊字符转义，避免 YAML 解析错误。"""
    return (instruction or "").replace("\\", "\\\\").replace('"', '\\"').replace("\n", " ")


def _escape_url_for_yaml(url: str) -> str:
    """对 URL 中可能破坏 YAML 双引号字符串的字符转义。"""
    return (url or "").replace("\\", "\\\\").replace('"', '\\"')


async def run_ai_task(
    ctx: Any,
    instruction: str,
    target_url: Optional[str] = None,
    max_steps: int = 30,
    task_name: str = "pre_step",
    credentials: Optional[Dict[str, str]] = None,
    go_to_after_instruction: bool = False,
) -> PreStepResult:
    """
    执行单条 AI 任务（临时 YAML + Agent.run），供登录、导航、前置多步共用。

    Args:
        ctx: BrowserContext
        instruction: 自然语言指令（如「打开登录页并输入账号密码登录」）
        target_url: 目标 URL，与本步 goTo 对应；为 None 时使用当前页 URL
        max_steps: 最大执行步数
        task_name: 任务名称，用于 YAML 中 task name
        credentials: 用户已提供的账号/密码；若提供则临时注入到 os.environ（USERNAME/PASSWORD），
            以便 controller 对 input_text 做 ${VAR} 替换时能解析，执行完毕后恢复环境。
        go_to_after_instruction: False 时 flow 为 [goTo, ai]（先跳转再执行指令）；True 时为 [ai, goTo]（先执行指令再跳转）。

    Returns:
        PreStepResult: success, final_url, error, steps_count
    """
    if not instruction or not instruction.strip():
        return PreStepResult(success=False, error="instruction is empty")

    saved_env = _inject_credentials_to_env(credentials)
    try:
        from omegaconf import OmegaConf

        from browser_use.agent.service import Agent
        from browser_use.agent.tasks import Tasks
        from browser_use.agent.views import AgentSettings

        from .utils import build_models_for_case_generator as build_models

        # 若未指定 target_url，使用当前页 URL
        if not target_url or not target_url.strip():
            state = await ctx.get_state()
            target_url = (state.url if state and getattr(state, "url", None) else None) or "about:blank"

        instruction_escaped = _escape_instruction(instruction.strip())
        url_escaped = _escape_url_for_yaml(target_url)
        # goTo 与 ai 顺序：go_to_after_instruction=False 则先 goTo 再 ai；True 则先 ai 再 goTo
        if go_to_after_instruction:
            flow_lines = [
                f'- ai: "{instruction_escaped}"',
                f'- goTo: "{url_escaped}"',
            ]
        else:
            flow_lines = [
                f'- goTo: "{url_escaped}"',
                f'- ai: "{instruction_escaped}"',
            ]
        flow_body = "\n      ".join(flow_lines)
        task_yaml = f"""
target:
  url: "{url_escaped}"
tasks:
  - name: {task_name}
    flow:
      {flow_body}
"""

        temp_dir = tempfile.mkdtemp(prefix="agent_run_")
        task_file = Path(temp_dir) / f"{task_name}.yaml"
        task_file.write_text(task_yaml, encoding="utf-8")

        tasks = Tasks(task_yaml_path=str(task_file))
        actor, planner, asserter, aux_llms = build_models()

        project_root = Path(__file__).parent.parent.parent
        cfg = OmegaConf.load(project_root / "browser_use/static/configs/default.yaml")
        OmegaConf.update(cfg, "task_file", str(task_file))
        OmegaConf.update(cfg, "log_dir", temp_dir)

        # 先导航到 target_url，再执行 flow（与 CLI 一致）；否则 Agent 不会打开目标页，
        # 第一个 ai 指令「打开目标 URL…」可能被模型误判为 example.com 等默认页
        initial_actions = [{"go_to_url": {"url": target_url}}]

        agent = Agent(
            config=cfg,
            tasks=tasks,
            llm=actor,
            planner=planner,
            asserter=asserter,
            aux_llms=aux_llms,
            browser_context=ctx,
            initial_actions=initial_actions,
            log_dir=temp_dir,
        )
        agent.settings = AgentSettings(
            planner=planner,
            max_steps=max_steps,
            max_failures=3,
        )

        await agent.run()

        # 获取执行后当前页 URL
        try:
            state = await ctx.get_state()
            final_url = state.url if state and getattr(state, "url", None) else None
            if not final_url:
                page = await ctx.get_current_page()
                final_url = page.url if page else None
        except Exception:
            final_url = None

        return PreStepResult(success=True, final_url=final_url, error=None, steps_count=0)

    except Exception as e:
        logger.warning("run_ai_task 执行失败: %s", e)
        try:
            state = await ctx.get_state()
            final_url = state.url if state and getattr(state, "url", None) else None
        except Exception:
            final_url = None
        return PreStepResult(success=False, final_url=final_url, error=str(e), steps_count=0)
    finally:
        _restore_env(saved_env)
