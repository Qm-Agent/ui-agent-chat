# -*- coding: utf-8 -*-
"""
汇总报告生成器：聚合页面分析、用例生成、探索路径及缺陷，输出 summary_report.md 和 summary_report.html。

职责：接收探索过程中收集的 analysis_records、case_records、exploration_records，
生成包含 4.1 页面分析+用例生成、4.2 探索路径+缺陷 的 Markdown 与 HTML 汇总报告。
"""

import html
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, TYPE_CHECKING

from browser_use.case_generator.error_collector import ExplorationIssue

if TYPE_CHECKING:
    from browser_use.case_generator.models import TestCaseDesign

logger = logging.getLogger(__name__)


@dataclass
class AnalysisRecord:
    """单页分析记录。"""

    path: str
    url: str
    page_type: str
    page_title: str
    actionable_count: int
    actionable_elements: List[Dict[str, Any]] = field(default_factory=list)
    non_actionable_elements: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class CaseRecord:
    """单页用例生成记录。"""

    path: str
    case_count: int
    case_names: List[str] = field(default_factory=list)
    cases: List[Any] = field(default_factory=list)  # List[TestCaseDesign]


@dataclass
class ExplorationRecord:
    """单条探索路径及对应缺陷。"""

    path: str
    url: str
    issues: List[ExplorationIssue] = field(default_factory=list)


@dataclass
class SummaryData:
    """汇总数据。"""

    target_url: str = ""  # 被测网站
    analysis_records: List[AnalysisRecord] = field(default_factory=list)
    case_records: List[CaseRecord] = field(default_factory=list)
    exploration_records: List[ExplorationRecord] = field(default_factory=list)


def _escape_html(s: str) -> str:
    return html.escape(s) if s else ""


class SummaryReporter:
    """生成 summary_report.md 和 summary_report.html。"""

    def generate(self, data: SummaryData, output_path: Path) -> None:
        """
        生成汇总报告。输出 Markdown 和 HTML 两种格式。
        output_path 通常为 output_dir/logs/summary_report.md，HTML 输出到同目录 summary_report.html。
        """
        md_path = Path(str(output_path))
        html_path = md_path.parent / "summary_report.html"
        self._generate_md(data, md_path)
        self._generate_html(data, html_path)
        logger.info("Summary report written: %s, %s", md_path, html_path)

    def _generate_md(self, data: SummaryData, output_path: Path) -> None:
        lines: List[str] = []
        lines.append("# 页面探索与用例生成汇总\n")
        if data.target_url:
            lines.append("## 被测网站\n")
            lines.append(data.target_url)
            lines.append("\n")
        lines.append("## 一、页面分析过程\n")
        lines.append("| 页面路径 | URL | 页面类型 | 页面标题 | 可操作元素数 |")
        lines.append("|---------|-----|---------|---------|-------------|")
        for r in data.analysis_records:
            url_short = r.url[:60] + "..." if len(r.url) > 60 else r.url
            lines.append(
                "| %s | %s | %s | %s | %d |"
                % (r.path, url_short, r.page_type, r.page_title[:30], r.actionable_count)
            )

        lines.append("\n## 二、测试用例生成结果\n")
        lines.append("| 页面路径 | 生成用例数 | 用例列表 |")
        lines.append("|---------|-----------|---------|")
        for r in data.case_records:
            names_str = ", ".join(r.case_names[:5])
            if len(r.case_names) > 5:
                names_str += ", ..."
            lines.append("| %s | %d | %s |" % (r.path, r.case_count, names_str))

        lines.append("\n## 三、探索路径与缺陷\n")
        lines.append("| 探索路径 | 到达URL | 缺陷数量 | 缺陷列表 |")
        lines.append("|---------|---------|---------|---------|")
        for r in data.exploration_records:
            url_short = r.url[:50] + "..." if len(r.url) > 50 else r.url
            issue_summary = "; ".join(
                "%s: %s" % (i.type, i.message[:40]) for i in r.issues[:3]
            )
            if len(r.issues) > 3:
                issue_summary += " ..."
            lines.append(
                "| %s | %s | %d | %s |"
                % (r.path, url_short, len(r.issues), issue_summary or "-")
            )

        lines.append("\n### 缺陷明细\n")
        lines.append("| 路径 | 类型 | 描述 | 详情 |")
        lines.append("|-----|------|------|------|")
        for r in data.exploration_records:
            for i in r.issues:
                msg_esc = i.message.replace("|", "\\|")[:80]
                lines.append("| %s | %s | %s | %s |" % (r.path, i.type, msg_esc, i.detail or ""))

        output_path.write_text("\n".join(lines), encoding="utf-8")

    def _generate_html(self, data: SummaryData, output_path: Path) -> None:
        html_content = self._build_html(data)
        output_path.write_text(html_content, encoding="utf-8")

    def _build_html(self, data: SummaryData) -> str:
        sidebar_items, content_panels = self._build_sidebar_and_panels(data)
        return self._html_template(sidebar_items, content_panels)

    def _build_sidebar_and_panels(
        self, data: SummaryData
    ) -> tuple[str, str]:
        """构建左侧导航项与右侧内容面板。"""
        sidebar_parts: List[str] = []
        panel_parts: List[str] = []

        # 1. 被测网站
        first_active = "panel-target" if data.target_url else "panel-analysis"
        if data.target_url:
            sidebar_parts.append(
                f'<li class="nav-item {"active" if first_active == "panel-target" else ""}" data-panel="panel-target">被测网站</li>'
            )
            panel_parts.append(
                f'<div id="panel-target" class="content-panel {"active" if first_active == "panel-target" else ""}">'
                f'{self._section_target_url(data.target_url)}</div>'
            )
        else:
            panel_parts.append('<div id="panel-target" class="content-panel"></div>')

        # 2. 页面分析
        sidebar_parts.append(
            f'<li class="nav-item {"active" if first_active == "panel-analysis" else ""}" data-panel="panel-analysis">页面分析</li>'
        )
        panel_parts.append(
            f'<div id="panel-analysis" class="content-panel {"active" if first_active == "panel-analysis" else ""}">'
            f'{self._section_page_analysis(data.analysis_records)}</div>'
        )

        # 3. 测试用例：主菜单 + 子菜单（按页面路径）
        sidebar_parts.append('<li class="nav-group"><span class="nav-group-title">测试用例</span><ul class="nav-sub">')
        if data.case_records:
            for i, r in enumerate(data.case_records):
                safe_id = f"panel-cases-{i}"
                label = f"{_escape_html(r.path)} ({r.case_count})"
                sidebar_parts.append(
                    f'<li class="nav-sub-item" data-panel="{safe_id}">{label}</li>'
                )
            for i, r in enumerate(data.case_records):
                safe_id = f"panel-cases-{i}"
                panel_content = self._section_test_cases_single(r)
                panel_parts.append(
                    f'<div id="{safe_id}" class="content-panel">{panel_content}</div>'
                )
        else:
            sidebar_parts.append(
                '<li class="nav-sub-item" data-panel="panel-cases-empty">（暂无用例）</li>'
            )
            panel_parts.append(
                '<div id="panel-cases-empty" class="content-panel"><p>暂无生成的测试用例。</p></div>'
            )
        sidebar_parts.append("</ul></li>")

        # 4. 探索路径与缺陷
        sidebar_parts.append(
            '<li class="nav-item" data-panel="panel-exploration">探索路径与缺陷</li>'
        )
        panel_parts.append(
            f'<div id="panel-exploration" class="content-panel">'
            f'{self._section_exploration(data.exploration_records)}</div>'
        )

        sidebar_html = "\n".join(sidebar_parts)
        panels_html = "\n".join(panel_parts)
        return sidebar_html, panels_html

    def _html_template(self, sidebar_items: str, content_panels: str) -> str:
        return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>测试用例生成汇总报告</title>
    <style>
        :root {{
            --border: #e5e5e5;
            --bg: #f8f8f8;
            --text: #333;
            --muted: #666;
            --primary: #06b1ab;
            --error: #e74c3c;
        }}
        * {{ box-sizing: border-box; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; font-size: 14px; color: var(--text); line-height: 1.6; margin: 0; display: flex; min-height: 100vh; background: var(--bg); }}
        .layout {{ display: flex; width: 100%; min-height: 100vh; }}
        #sidebar {{ width: 240px; flex-shrink: 0; background: #fff; border-right: 1px solid var(--border); overflow-y: auto; }}
        .sidebar-header {{ padding: 16px; font-weight: bold; color: var(--primary); border-bottom: 1px solid var(--border); }}
        .nav-item, .nav-sub-item {{ padding: 10px 16px; cursor: pointer; transition: background 0.15s; }}
        .nav-item:hover, .nav-sub-item:hover {{ background: var(--bg); }}
        .nav-item.active, .nav-sub-item.active {{ background: rgba(6,177,171,0.12); color: var(--primary); border-left: 3px solid var(--primary); margin-left: -1px; }}
        .nav-group {{ list-style: none; padding: 0; margin: 0; }}
        .nav-group-title {{ display: block; padding: 10px 16px; font-weight: 600; color: var(--text); }}
        .nav-sub {{ list-style: none; padding: 0 0 8px 0; margin: 0; }}
        .nav-sub-item {{ padding-left: 28px; font-size: 13px; }}
        #main {{ flex: 1; padding: 24px; overflow-y: auto; }}
        .content-panel {{ display: none; }}
        .content-panel.active {{ display: block; }}
        h1 {{ font-size: 1.5rem; margin: 0 0 24px; color: var(--primary); }}
        h2 {{ font-size: 1.2rem; margin: 24px 0 12px; padding-bottom: 8px; border-bottom: 1px solid var(--border); }}
        h3 {{ font-size: 1rem; margin: 16px 0 8px; }}
        table {{ border-collapse: collapse; width: 100%; background: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 3px rgba(0,0,0,0.06); }}
        th, td {{ padding: 10px 12px; text-align: left; border-bottom: 1px solid var(--border); }}
        th {{ background: var(--bg); font-weight: 600; color: var(--text); }}
        tr:hover {{ background: #fafafa; }}
        .url {{ word-break: break-all; max-width: 400px; }}
        .issue-card {{ background: #fff; border: 1px solid var(--border); border-radius: 8px; margin: 8px 0; padding: 12px; }}
        .issue-card.error {{ border-left: 4px solid var(--error); }}
        .issue-type {{ display: inline-block; padding: 2px 8px; border-radius: 4px; font-size: 12px; background: #f0f0f0; margin-right: 8px; }}
        .issue-type.visual_error {{ background: #ffe0e0; color: #c00; }}
        .issue-type.console_error {{ background: #fff3cd; color: #856404; }}
        .issue-type.network_error {{ background: #f8d7da; color: #721c24; }}
        .issue-screenshot {{ max-width: 100%; max-height: 400px; border-radius: 4px; margin-top: 8px; cursor: pointer; }}
        .issue-log {{ font-family: monospace; font-size: 12px; background: #f5f5f5; padding: 8px; border-radius: 4px; margin-top: 8px; overflow-x: auto; white-space: pre-wrap; word-break: break-all; }}
        .case-steps {{ margin: 8px 0; padding-left: 16px; }}
        .case-step {{ margin: 4px 0; }}
        .validation-list {{ margin: 8px 0; padding-left: 16px; list-style: disc; }}
        .element-list {{ margin: 4px 0; padding-left: 16px; }}
        .element-item {{ margin: 2px 0; }}
    </style>
</head>
<body>
    <div class="layout">
        <aside id="sidebar">
            <div class="sidebar-header">汇总报告</div>
            <ul class="nav-list">
                {sidebar_items}
            </ul>
        </aside>
        <main id="main">
            <h1>页面探索与用例生成汇总</h1>
            {content_panels}
        </main>
    </div>
    <script>
        (function() {{
            var items = document.querySelectorAll('.nav-item[data-panel], .nav-sub-item[data-panel]');
            var panels = document.querySelectorAll('.content-panel');
            function show(panelId) {{
                panels.forEach(function(p) {{ p.classList.remove('active'); }});
                items.forEach(function(i) {{ i.classList.remove('active'); }});
                var p = document.getElementById(panelId);
                var item = document.querySelector('[data-panel="' + panelId + '"]');
                if (p) p.classList.add('active');
                if (item) item.classList.add('active');
            }}
            items.forEach(function(item) {{
                item.addEventListener('click', function() {{
                    var id = this.getAttribute('data-panel');
                    if (id) show(id);
                }});
            }});
            var first = document.querySelector('.content-panel.active');
            if (!first && panels.length) show(panels[0].id);
        }})();
    </script>
</body>
</html>"""

    def _section_target_url(self, target_url: str) -> str:
        if not target_url:
            return ""
        return f"""
    <h2>一、被测网站</h2>
    <p><a href="{_escape_html(target_url)}" target="_blank" rel="noopener">{_escape_html(target_url)}</a></p>"""

    def _section_page_analysis(self, records: List[AnalysisRecord]) -> str:
        if not records:
            return ""
        rows: List[str] = []
        for r in records:
            url_short = r.url[:80] + "..." if len(r.url) > 80 else r.url
            rows.append(
                f"<tr><td>{_escape_html(r.path)}</td><td class='url'>{_escape_html(url_short)}</td>"
                f"<td>{_escape_html(r.page_type)}</td><td>{_escape_html(r.page_title[:40])}</td><td>{r.actionable_count}</td></tr>"
            )
        table = (
            "<table><thead><tr><th>页面路径</th><th>URL</th><th>页面类型</th><th>页面标题</th><th>可操作元素数</th></tr></thead><tbody>"
            + "".join(rows)
            + "</tbody></table>"
        )
        details: List[str] = []
        for r in records:
            if r.actionable_elements or r.non_actionable_elements:
                detail = f"<h3>{_escape_html(r.path)} - {_escape_html(r.page_title[:30])}</h3>"
                if r.actionable_elements:
                    detail += "<p><strong>可操作元素：</strong></p><ul class='element-list'>"
                    for el in r.actionable_elements[:50]:
                        label = el.get("label") or el.get("description") or str(el)
                        etype = el.get("element_type", "")
                        detail += f"<li class='element-item'>{_escape_html(etype)}: {_escape_html(str(label)[:80])}</li>"
                    detail += "</ul>"
                if r.non_actionable_elements:
                    detail += "<p><strong>不可操作元素：</strong></p><ul class='element-list'>"
                    for el in r.non_actionable_elements[:30]:
                        text = el.get("text") or str(el)
                        detail += f"<li class='element-item'>{_escape_html(str(text)[:80])}</li>"
                    detail += "</ul>"
                details.append(detail)
        details_html = "\n".join(details) if details else ""
        return f"""
    <h2>二、页面分析</h2>
    {table}
    {details_html}"""

    def _section_test_cases(self, records: List[CaseRecord]) -> str:
        """保留供 MD 或兼容使用。"""
        if not records:
            return ""
        rows: List[str] = []
        for r in records:
            names_str = ", ".join(r.case_names[:5])
            if len(r.case_names) > 5:
                names_str += ", ..."
            rows.append(
                f"<tr><td>{_escape_html(r.path)}</td><td>{r.case_count}</td><td>{_escape_html(names_str)}</td></tr>"
            )
        table = (
            "<table><thead><tr><th>页面路径</th><th>生成用例数</th><th>用例列表</th></tr></thead><tbody>"
            + "".join(rows)
            + "</tbody></table>"
        )
        details = "\n".join(self._render_case_details(records))
        return f"<h2>三、生成测试用例</h2>{table}<h3>用例详情</h3>{details}"

    def _section_test_cases_single(self, record: CaseRecord) -> str:
        """单个页面路径下的用例列表与详情。"""
        names_str = ", ".join(record.case_names)
        table = (
            f"<h2>测试用例 - {_escape_html(record.path)}</h2>"
            f"<p>共 {record.case_count} 个用例：{_escape_html(names_str)}</p>"
        )
        details = "\n".join(self._render_case_details([record]))
        return f"{table}<h3>用例详情</h3>{details}"

    def _render_case_details(self, records: List[CaseRecord]) -> List[str]:
        case_details: List[str] = []
        for r in records:
            for c in r.cases:
                name = getattr(c, "case_name", "") or ""
                desc = getattr(c, "description", "") or ""
                steps = getattr(c, "steps", []) or []
                validations = getattr(c, "validation_points", []) or []
                steps_html = "<ol class='case-steps'>"
                for s in sorted(steps, key=lambda x: getattr(x, "order", 0)):
                    action = getattr(s, "action_type", "")
                    target = getattr(s, "target_description", "")
                    val = getattr(s, "value", "") or ""
                    steps_html += f"<li class='case-step'>{_escape_html(action)}: {_escape_html(target)}"
                    if val:
                        steps_html += f" (值: {_escape_html(str(val)[:50])})"
                    steps_html += "</li>"
                steps_html += "</ol>"
                valid_html = "<ul class='validation-list'>"
                for v in validations:
                    vtype = getattr(v, "validation_type", "")
                    expected = getattr(v, "expected_description", "")
                    valid_html += f"<li>{_escape_html(vtype)}: {_escape_html(expected)}</li>"
                valid_html += "</ul>"
                reason = getattr(c, "generation_reason", "") or ""
                reason_block = f"<p><strong>生成原因：</strong>{_escape_html(reason)}</p>" if reason else ""
                case_details.append(
                    f"<div class='issue-card'><h3>{_escape_html(name)}</h3>"
                    f"<p>{_escape_html(desc)}</p>{reason_block}<p><strong>操作步骤：</strong></p>{steps_html}"
                    f"<p><strong>校验点：</strong></p>{valid_html}</div>"
                )
        return case_details

    def _section_exploration(self, records: List[ExplorationRecord]) -> str:
        if not records:
            return ""
        rows: List[str] = []
        for r in records:
            url_short = r.url[:60] + "..." if len(r.url) > 60 else r.url
            issue_sum = "; ".join(f"{i.type}: {i.message[:30]}" for i in r.issues[:3])
            if len(r.issues) > 3:
                issue_sum += " ..."
            rows.append(
                f"<tr><td>{_escape_html(r.path)}</td><td class='url'>{_escape_html(url_short)}</td>"
                f"<td>{len(r.issues)}</td><td>{_escape_html(issue_sum or '-')}</td></tr>"
            )
        table = (
            "<table><thead><tr><th>探索路径</th><th>到达URL</th><th>缺陷数量</th><th>缺陷列表</th></tr></thead><tbody>"
            + "".join(rows)
            + "</tbody></table>"
        )
        issue_cards: List[str] = []
        for r in records:
            for i in r.issues:
                cls = "error" if i.type in ("visual_error", "network_error", "page_error") else ""
                card = (
                    f"<div class='issue-card {cls}'><span class='issue-type {i.type}'>{_escape_html(i.type)}</span>"
                    f"<strong>{_escape_html(r.path)}</strong><br>{_escape_html(i.message)}"
                )
                if i.detail:
                    card += f"<br><span style='color:var(--muted);'>{_escape_html(i.detail)}</span>"
                if i.screenshot_base64:
                    src = i.screenshot_base64
                    if not src.startswith("data:"):
                        src = f"data:image/png;base64,{src}"
                    card += f"<br><img class='issue-screenshot' src='{src}' alt='screenshot' />"
                if i.log_snippet:
                    card += f"<pre class='issue-log'>{_escape_html(i.log_snippet)}</pre>"
                card += "</div>"
                issue_cards.append(card)
        issues_block = "\n".join(issue_cards) if issue_cards else "<p>无缺陷</p>"
        return f"""
    <h2>四、探索路径与缺陷</h2>
    <h3>探索路径概览</h3>
    {table}
    <h3>缺陷明细（含截图/日志）</h3>
    {issues_block}"""
