# -*- coding: utf-8 -*-
"""
探索模式测试助手 - TestAssistant

当用户未给定具体测试步骤时，由智能体自动遍历被测页面、分析页面结构、
自主规划探索路径并生成测试用例。
"""

import asyncio
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from browser_use.logging_config import setup_logging

logger = logging.getLogger(__name__)

# 生成 YAML 时登录步一律使用占位符，实际值由执行时从环境变量解析（.env 配置）
CREDENTIALS_PLACEHOLDER_FOR_YAML: Dict[str, str] = {
    "username": "${TEST_USERNAME}",
    "password": "${TEST_PASSWORD}",
}


class ExecutionMode(Enum):
    """执行模式"""
    GENERATE_ONLY = "generate_only"      # 默认：只生成 YAML
    EXECUTE_SINGLE = "execute_single"    # 单条执行
    EXECUTE_BATCH = "execute_batch"      # 批量执行
    EXECUTE_ALL = "execute_all"          # 全部执行


@dataclass
class ExecutionResult:
    """执行结果"""
    status: str                          # completed / cancelled / failed
    cases_executed: List[Any] = field(default_factory=list)
    total: int = 0
    passed: int = 0
    failed: int = 0


@dataclass
class TestAssistantResult:
    """测试结果"""
    status: str                          # success / failed
    cases: List[Any] = field(default_factory=list)
    yaml_paths: List[Path] = field(default_factory=list)
    execution_result: Optional[ExecutionResult] = None
    defects: List[Any] = field(default_factory=list)
    report_paths: List[Path] = field(default_factory=list)
    run_dir: Optional[Path] = None
    error: Optional[str] = None


class TestAssistant:
    """
    探索模式测试助手

    核心职责：
    1. AI 自然语言登录
    2. 智能模块导航
    3. 多层级页面探索 + 用例生成
    4. 全流程缺陷采集
    5. 安全的执行控制（默认不执行，需用户确认）
    6. 完整报告输出

    探索模式：未给定具体测试步骤时，由智能体自主遍历被测页面并生成用例。
    """

    def __init__(
        self,
        output_dir: str = "./test_reports",
    ):
        self.output_dir = Path(output_dir).expanduser().resolve()
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # 初始化各模块（延迟加载）
        self._login_handler = None
        self._module_navigator = None
        self._page_analyzer = None
        self._case_designer = None
        self._yaml_generator = None
        self._case_executor = None
        self._exploration_planner = None
        self._error_collector = None
        self._visual_detector = None
        self._report_generator = None
        self._intent_parser = None

        # Exploration Agent 使用的共享资源
        self._exploration_llm_bundle = None  # 缓存 LLM 避免重复创建
        self._exploration_agent = None       # 缓存 Agent 避免重复创建
        self._exploration_agent_ctx = None   # 记录 Agent 绑定的 context
        self._exploration_stats = {  # 性能统计
            "total_count": 0,
            "success_count": 0,
            "fail_count": 0,
            "timeout_count": 0,
            "captcha_skip_count": 0,  # 验证码跳过计数
            "failed_actions": [],      # 记录失败的探索任务
            "total_exec_time": 0.0,
        }

        logger.info("【探索模式测试助手】初始化完成")
        logger.info("【探索模式测试助手】输出目录: %s", self.output_dir)

    # ============ 属性延迟加载 ============

    @property
    def login_handler(self):
        if self._login_handler is None:
            from .ai_login import AILoginHandler
            self._login_handler = AILoginHandler()
        return self._login_handler

    @property
    def module_navigator(self):
        if self._module_navigator is None:
            from .module_navigator import ModuleNavigator
            self._module_navigator = ModuleNavigator()
        return self._module_navigator

    @property
    def page_analyzer(self):
        if self._page_analyzer is None:
            from .page_analyzer import PageAnalyzer

            # 复用 agent 中的 build_models 获取 LLM
            from .utils import build_models_for_case_generator
            models = build_models_for_case_generator()
            self._page_analyzer = PageAnalyzer(llm=models[0])  # actor
        return self._page_analyzer

    @property
    def case_designer(self):
        if self._case_designer is None:
            from .case_designer import CaseDesigner
            from .utils import build_models_for_case_generator
            models = build_models_for_case_generator()
            self._case_designer = CaseDesigner(llm=models[0])
        return self._case_designer

    @property
    def yaml_generator(self):
        if self._yaml_generator is None:
            from .utils import build_models_for_case_generator
            from .yaml_generator import YamlGenerator
            models = build_models_for_case_generator()
            self._yaml_generator = YamlGenerator(llm=models[0])
        return self._yaml_generator

    @property
    def case_executor(self):
        if self._case_executor is None:
            from .case_executor import CaseExecutor
            self._case_executor = CaseExecutor()
        return self._case_executor

    @property
    def exploration_planner(self):
        if self._exploration_planner is None:
            from .exploration_planner import ExplorationPlanner
            from .utils import build_models_for_case_generator
            models = build_models_for_case_generator()
            self._exploration_planner = ExplorationPlanner(llm=models[0])
        return self._exploration_planner

    @property
    def error_collector(self):
        if self._error_collector is None:
            from .error_collector import ErrorCollector
            self._error_collector = ErrorCollector()
        return self._error_collector

    @property
    def visual_detector(self):
        if self._visual_detector is None:
            from .utils import build_models_for_case_generator
            from .visual_error_detector import VisualErrorDetector
            models = build_models_for_case_generator()
            self._visual_detector = VisualErrorDetector(llm=models[0])
        return self._visual_detector

    @property
    def intent_parser(self):
        if self._intent_parser is None:
            from .intent_parser import IntentParser
            from .utils import build_models_for_case_generator
            models = build_models_for_case_generator()
            self._intent_parser = IntentParser(llm=models[0])
        return self._intent_parser

    # ============ 主入口 ============

    async def run(
        self,
        # 输入方式
        user_input: Optional[str] = None,
        url: Optional[str] = None,

        # 测试范围
        target_module: Optional[str] = None,
        exploration_depth: int = 1,

        # 执行控制
        execution_mode: ExecutionMode = ExecutionMode.GENERATE_ONLY,
        interactive: bool = False,

        # 执行指定
        case_id: Optional[str] = None,
        case_ids: Optional[List[str]] = None,

        # 浏览器配置
        headless: bool = True,

        # 用例生成配置
        max_cases_per_page: int = 5,
        visual_error_check: bool = False,  # 探索过程是否进行视觉缺陷检测（暂默认关闭以省 token）
        realtime_output: bool = True,  # 每页用例生成后立即保存到本地（默认开启，可关闭改为最后统一输出）

    ) -> TestAssistantResult:
        """
        主入口

        使用示例：
            # 凭据通过 .env 配置 USERNAME、PASSWORD，不传 credentials
            # 默认生成用例（realtime_output=True，每页用例生成后立即保存）
            result = await assistant.run(
                url="https://admin.example.com",
                target_module="投放管理",
                exploration_depth=2,
            )

            # 关闭实时输出，改为探索结束后统一写入
            result = await assistant.run(
                url="https://admin.example.com",
                exploration_depth=2,
                realtime_output=False,
            )

            # 交互式执行
            result = await assistant.run(
                url="https://admin.example.com",
                target_module="投放管理",
                interactive=True,
            )
        """
        run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_dir = self.output_dir / run_id
        run_dir.mkdir(exist_ok=True)

        # 创建 reports 目录并配置日志输出到文件
        reports_dir = run_dir / "reports"
        reports_dir.mkdir(exist_ok=True)
        log_path = reports_dir / "execution.log"

        # 创建 symlink latest
        latest_link = self.output_dir / "latest"
        if latest_link.exists() or latest_link.is_symlink():
            latest_link.unlink()
        latest_link.symlink_to(run_dir, target_is_directory=True)

        # 配置日志：控制台 + reports/execution.log
        setup_logging(log_path=log_path)
        logger.info("📁 执行日志: %s", log_path)

        try:
            # Step 1: 解析输入（用户指令 → 测试目标 + 可执行步骤；仅 url 时合成最小指令，登录与否由指令决定）
            use_pre_steps = False
            steps_from_ai: List[Any] = []
            effective_input: Optional[str] = None
            if user_input and str(user_input).strip():
                effective_input = user_input.strip()
            elif url and str(url).strip():
                # 仅传 url（或 url + target_module）时合成最小指令，走同一管道，不强制登录
                if target_module and str(target_module).strip():
                    effective_input = f"打开 {url}，进入 {target_module} 模块并探索"
                else:
                    effective_input = f"打开 {url} 并探索该页面"
                logger.info("未提供 user_input，按 url/target_module 合成指令并解析步骤")

            if effective_input:
                from browser_use.case_generator.pre_step_generator import user_input_to_steps
                target_url_ai, steps_from_ai = await user_input_to_steps(
                    self.intent_parser.llm, effective_input, url or ""
                )
                if target_url_ai:
                    url = target_url_ai
                use_pre_steps = True
                from browser_use.case_generator.pre_step_generator import PreStepSpec
                steps_with_go = sum(
                    1
                    for s in steps_from_ai
                    if isinstance(s, PreStepSpec) and s.target_url
                )
                logger.info(
                    "【解析完成】target_url=%s, 前置步骤数=%d, 其中含 go_to_url 步数=%d",
                    url or "(empty)", len(steps_from_ai), steps_with_go,
                )

            # 用于 YAML 前序步骤：将 PreStepSpec 转为 dict 列表供 YamlGenerator 使用
            pre_steps_for_yaml: Optional[List[dict]] = None
            if use_pre_steps and steps_from_ai:
                from browser_use.case_generator.pre_step_generator import PreStepSpec as _PSS
                pre_steps_for_yaml = []
                for s in steps_from_ai:
                    if isinstance(s, _PSS) and getattr(s, "instruction", None):
                        pre_steps_for_yaml.append({
                            "instruction": (s.instruction or "").strip(),
                            "target_url": getattr(s, "target_url", None),
                            "go_after_instruction": getattr(s, "go_after_instruction", False),
                        })
                if not pre_steps_for_yaml:
                    pre_steps_for_yaml = None

            if not url:
                raise ValueError("必须提供 url 或 user_input")

            logger.info("="*60)
            logger.info("【探索模式测试助手】启动")
            logger.info("📍 URL: %s", url)
            logger.info("📋 目标模块: %s", target_module or "未指定")
            logger.info("🔍 探索深度: %d", exploration_depth)
            logger.info("="*60)

            # Step 2: 创建浏览器上下文
            from ..browser.browser import Browser, BrowserConfig
            from ..browser.context import BrowserContext

            browser_config = BrowserConfig(headless=headless)
            browser = Browser(config=browser_config)
            ctx = BrowserContext(browser=browser)

            try:
                login_record = None

                if use_pre_steps:
                    # 用户指令（或合成指令）→ AI 可执行步骤 + 测试目标，按序执行；登录与否由指令决定
                    if steps_from_ai:
                        pre_error = await self._run_pre_steps(
                            ctx, steps_from_ai, url
                        )
                        if pre_error:
                            logger.error("【探索模式测试助手】前置步骤失败: %s", pre_error)
                            return TestAssistantResult(
                                status="failed",
                                error=pre_error,
                                run_dir=run_dir,
                            )
                    else:
                        # 无步骤时仅打开 URL
                        await ctx.navigate_to(url)
                    # 兜底：若指定了目标模块，在步骤执行或打开 URL 后进入模块（与是否登录无关）
                    if target_module:
                        await self._do_navigate(ctx, target_module)

                # Step 5: 探索 + 生成用例（YAML 中登录步使用占位符，由 CREDENTIALS_PLACEHOLDER_FOR_YAML 提供）
                all_cases, all_defects, report_ctx = await self._explore_and_generate(
                    ctx, exploration_depth, run_dir,
                    target_url=url,
                    target_module=target_module,
                    login_record=login_record,
                    max_cases=max_cases_per_page,
                    visual_error_check=visual_error_check,
                    realtime_output=realtime_output,
                    pre_steps=pre_steps_for_yaml,
                )

                # 写入登录记录到报告上下文（若有）
                if login_record is not None:
                    report_ctx.login_record = login_record

                # Step 6: 保存 YAML（realtime_output 时用例已增量写入，此处仅生成 index；登录步用占位符）
                yaml_paths = await self._save_yaml_files(
                    all_cases, run_dir, url,
                    realtime_output=realtime_output,
                    login_record=login_record,
                    target_module=target_module,
                    credentials=CREDENTIALS_PLACEHOLDER_FOR_YAML,
                    pre_steps=pre_steps_for_yaml,
                )

                # 生成预览报告
                preview_path = self._generate_preview_report(
                    all_cases, all_defects, run_dir
                )

                # 生成用例生成过程 HTML 报告
                from browser_use.case_generator.generation_report import (
                    GenerationReportGenerator,
                )
                gen_report_path = GenerationReportGenerator().generate(
                    report_ctx, run_dir
                )

                logger.info("="*60)
                logger.info("【探索模式测试助手】用例生成完成")
                logger.info("📝 共 %d 个用例", len(all_cases))
                logger.info("📁 输出目录: %s", run_dir)

                # Step 7: 执行控制（默认不执行）
                execution_result = None

                if interactive:
                    execution_result = await self._interactive_execute(
                        ctx, all_cases, run_dir
                    )
                elif execution_mode == ExecutionMode.EXECUTE_SINGLE:
                    execution_result = await self._execute_single(
                        ctx, case_id, all_cases, run_dir
                    )
                elif execution_mode == ExecutionMode.EXECUTE_BATCH:
                    execution_result = await self._execute_batch(
                        ctx, case_ids, all_cases, run_dir
                    )
                elif execution_mode == ExecutionMode.EXECUTE_ALL:
                    execution_result = await self._execute_all(
                        ctx, all_cases, run_dir
                    )

                # 生成执行报告（如执行了）
                execution_report_path = None
                if execution_result:
                    execution_report_path = self._generate_execution_report(
                        execution_result, run_dir
                    )

                report_paths = [preview_path, gen_report_path]
                if execution_report_path:
                    report_paths.append(execution_report_path)

                return TestAssistantResult(
                    status="success",
                    cases=all_cases,
                    yaml_paths=yaml_paths,
                    execution_result=execution_result,
                    defects=all_defects,
                    report_paths=report_paths,
                    run_dir=run_dir,
                )

            finally:
                await ctx.close()
                await browser.close()

        except RuntimeError as e:
            # 浏览器关闭等用户主动中断的情况
            if "浏览器已关闭" in str(e) or "任务终止" in str(e):
                logger.warning("【探索模式测试助手】用户关闭浏览器，任务终止: %s", e)
                return TestAssistantResult(
                    status="cancelled",
                    error="用户关闭浏览器，任务已终止",
                    run_dir=run_dir,
                )
            # 其他 RuntimeError 作为普通异常处理
            logger.exception("【探索模式测试助手】执行失败: %s", e)
            return TestAssistantResult(
                status="failed",
                error=str(e),
                run_dir=run_dir,
            )
        except Exception as e:
            logger.exception("【探索模式测试助手】执行失败: %s", e)
            return TestAssistantResult(
                status="failed",
                error=str(e),
                run_dir=run_dir,
            )

    # ============ 私有方法 ============

    async def _parse_user_input(self, user_input: str) -> Any:
        """解析自然语言输入"""
        logger.info("📝 解析用户输入...")
        return await self.intent_parser.parse(user_input)

    async def _do_login(self, ctx: Any, url: str) -> Optional[Any]:
        """登录 + 缺陷采集。凭据从环境变量 USERNAME、PASSWORD 读取（.env 配置）。"""
        import os

        from browser_use.case_generator.report_context import LoginRecord

        logger.info("【探索模式测试助手】开始登录...")

        page = await self._get_playwright_page(ctx)
        self.error_collector.attach(page, url, "login")

        login_record: Optional[LoginRecord] = None
        username = (os.environ.get("TEST_USERNAME") or os.environ.get("USERNAME") or "").strip()
        password = (os.environ.get("TEST_PASSWORD") or os.environ.get("PASSWORD") or "").strip()

        try:
            if username or password:
                resolved = {"username": username, "password": password}
                # 先导航到登录页，采集登录前截图
                await ctx.navigate_to(url)
                await asyncio.sleep(1.0)
                state_before = await ctx.get_state()
                before_screenshot = state_before.screenshot if state_before else None

                success = await self.login_handler.login(
                    ctx, url, resolved
                )
                if not success:
                    logger.warning("⚠️  登录可能失败，继续执行...")

                state_after = await ctx.get_state()
                after_screenshot = state_after.screenshot if state_after else None

                login_record = LoginRecord(
                    url=url,
                    before_screenshot=before_screenshot,
                    after_screenshot=after_screenshot,
                    success=success,
                    steps=["打开登录页", "输入账号密码", "点击登录"],
                )
            else:
                await ctx.navigate_to(url)

            # 采集登录阶段缺陷
            self.error_collector.collect(url, "login")

        finally:
            self.error_collector.detach()

        logger.info("【探索模式测试助手】登录完成")
        return login_record

    async def _do_navigate(self, ctx: Any, target_module: str) -> None:
        """模块导航"""
        logger.info("📍 导航到模块: %s", target_module)

        page = await self._get_playwright_page(ctx)
        current_url = await self._get_current_url(ctx)
        self.error_collector.attach(page, current_url, "navigation")

        try:
            success = await self.module_navigator.navigate(ctx, target_module)
            if not success:
                logger.warning("⚠️  导航到模块 '%s' 失败，将在当前页面继续", target_module)

            # 采集导航缺陷
            current_url = await self._get_current_url(ctx)
            self.error_collector.collect(current_url, "navigation")

        finally:
            self.error_collector.detach()

    async def _run_pre_steps(
        self,
        ctx: Any,
        steps: List[Any],
        initial_url: str,
    ) -> Optional[str]:
        """
        按序执行前置步骤（user_input 解析出的 steps 原样传递）。每步 instruction 直接传 run_ai_task，
        不做用户名/密码的额外处理；占位符 ${TEST_USERNAME}/${TEST_PASSWORD} 由 browser-use/agent 执行时从 os.environ 解析。
        """
        from browser_use.case_generator.agent_runner import run_ai_task
        from browser_use.case_generator.pre_step_generator import PreStepSpec

        current_url = initial_url
        for i, spec in enumerate(steps):
            if not isinstance(spec, PreStepSpec):
                continue
            instr_preview = spec.instruction[:60] + ("..." if len(spec.instruction) > 60 else "")
            logger.info("【前置步骤 %d/%d】%s", i + 1, len(steps), instr_preview)

            result = await run_ai_task(
                ctx,
                instruction=spec.instruction,
                target_url=spec.target_url or current_url,
                max_steps=30,
                task_name="pre_step_%d" % (i + 1),
                credentials=None,
                go_to_after_instruction=getattr(spec, "go_after_instruction", False),
            )
            if not result.success:
                return result.error or "前置步骤执行失败"
            if result.final_url:
                current_url = result.final_url

        return None

    async def _explore_and_generate(
        self,
        ctx: Any,
        max_depth: int,
        run_dir: Path,
        target_url: str = "",
        target_module: Optional[str] = None,
        login_record: Optional[Any] = None,
        max_cases: int = 5,
        visual_error_check: bool = False,
        realtime_output: bool = True,
        pre_steps: Optional[List[dict]] = None,
    ) -> Tuple[List[Any], List[Any], Any]:
        """多层级探索 + 用例生成 + 缺陷采集。返回 (all_cases, all_defects, report_context)。
        pre_steps: 用户前序步骤（PreStepSpec 转 dict 列表），用于生成 YAML 时写入 flow 前序。
        """
        from collections import deque

        from browser_use.case_generator.report_context import (
            ExploreTaskRecord,
            PageReportNode,
            ReportContext,
        )

        logger.info("【探索模式测试助手】开始页面探索 (depth=%d)...", max_depth)

        all_cases = []
        all_defects = []

        current_url = await self._get_current_url(ctx)
        report_ctx = ReportContext(target_url=current_url)
        node_by_key: Dict[Tuple[str, str], PageReportNode] = {}
        # 队列: (depth, url, path, parent_key, path_chain)，path_chain 为从根到当前页的路径链
        queue = deque([(0, current_url, "首页", None, ["首页"])])
        visited: Set[str] = set()

        while queue:
            depth, url, path, parent_key, path_chain = queue.popleft()

            if depth > max_depth or url in visited:
                continue
            visited.add(url)

            # 检测浏览器是否已关闭
            if await self._is_browser_closed(ctx):
                logger.warning("⚠️ 浏览器已关闭，终止探索任务")
                break

            # 深度 > 0 时需导航到目标页面
            if depth > 0:
                current = await self._get_current_url(ctx)
                if current != url:
                    try:
                        page = await self._get_playwright_page(ctx)
                        await page.goto(url)
                        await asyncio.sleep(0.5)
                    except Exception as e:
                        logger.warning("导航到 %s 失败: %s", url[:60], e)
                        continue

            logger.info("-"*60)
            logger.info("📄 层级 L%d: %s", depth, path)
            logger.info("   URL: %s", url[:80])

            # 获取或创建报告节点
            key = (url, path)
            if key in node_by_key:
                current_node = node_by_key[key]
            else:
                current_node = PageReportNode(depth=depth, path=path, url=url)
                node_by_key[key] = current_node
                if parent_key is None:
                    report_ctx.nodes.append(current_node)
                else:
                    parent_node = node_by_key.get(parent_key)
                    if parent_node:
                        parent_node.children.append(current_node)

            # 绑定缺陷采集器
            page = await self._get_playwright_page(ctx)
            self.error_collector.attach(page, url, path)

            try:
                # 若该页已在「立即分析新页面」中分析过（从队列弹出时），复用已有 analysis，避免重复分析及重复用例
                if getattr(current_node, "analysis", None) is not None and getattr(current_node, "cases", None):
                    logger.info("   ♻️ 复用已分析页面 (L%d)，继续规划下一层", depth)
                    analysis = current_node.analysis
                    page_cases = list(current_node.cases)
                    page_defects = []
                else:
                    # 分析当前页面并生成用例
                    page_cases, page_defects, analysis = await self._analyze_single_page(
                        ctx=ctx,
                        url=url,
                        depth=depth,
                        path=path,
                        path_chain=path_chain,
                        max_cases=max_cases,
                        visual_error_check=visual_error_check,
                    )
                    all_cases.extend(page_cases)
                    all_defects.extend(page_defects)

                    # 实时输出：每页用例生成后立即写入
                    if realtime_output and page_cases:
                        await self._save_page_cases_immediately(
                            page_cases, run_dir, target_url,
                            login_record=login_record,
                            target_module=target_module,
                            credentials=CREDENTIALS_PLACEHOLDER_FOR_YAML,
                            pre_steps=pre_steps,
                        )

                    # 采集报告数据：截图、分析、用例
                    state = await ctx.get_state()
                    current_node.screenshot = state.screenshot if state else None
                    current_node.analysis = analysis
                    current_node.cases = list(page_cases)

                # 如果当前页面是登录页或无可用内容，跳过探索规划
                if analysis is None or analysis.is_login_page:
                    logger.info("   ⏭️ 当前页面是登录页或无可用内容，跳过探索规划")
                    continue

                # 方案 1：若页面分析检测到弹窗，探索前统一关闭
                if analysis.has_popup:
                    logger.info("   🪟 检测到弹窗，探索前先关闭: %s", analysis.popup_close_hint or "尝试常见关闭按钮")
                    await self._dismiss_popup(ctx, analysis.popup_close_hint)
                    await asyncio.sleep(0.5)  # 等待主内容渲染
                    # 关闭弹窗后重新分析页面，以获取主内容中的可操作元素（如侧边栏导航）
                    logger.info("   🔄 弹窗已关闭，重新分析页面以获取最新可操作元素...")
                    try:
                        analysis = await self.page_analyzer.analyze(ctx)
                        logger.info("   ✅ 重新分析完成: %d 个可操作元素", len(analysis.actionable_elements or []))
                    except Exception as e:
                        logger.warning("   ⚠️ 重新分析失败，使用原分析结果: %s", e)

                # 规划下一层级
                if depth < max_depth:
                    plan = await self.exploration_planner.plan(
                        analysis, depth, max_depth, visited,
                        exploration_budget=10,
                        path_chain=path_chain,
                    )

                    if not plan.is_done and plan.next_actions:
                        logger.info("   🧭 规划下一层: %d 个动作", len(plan.next_actions))
                        logger.info("   📍 当前分析页面 URL: %s", url[:80])
                        logger.debug("   📋 ExplorationPlanner 输出 -> 准备执行 %d 个动作", len(plan.next_actions[:3]))

                        for i, action in enumerate(plan.next_actions[:3], 1):  # 最多3个
                            label = action.get("label", "unknown")
                            description = action.get("description", f"点击{label}")
                            element_index = action.get("element_index")
                            priority = action.get("priority", "N/A")

                            logger.info("   → [%d/%d] 探索: %s", i, len(plan.next_actions[:3]), label)
                            logger.debug("      📋 Action 详情: label=%s, priority=%s, element_index=%s",
                                       label, priority, element_index)
                            logger.debug("      📋 Action 描述: %s", description[:80])

                            # 关键：在每个 exploration 前重置回当前分析页面
                            # 因为上一个 exploration 可能已经跳转到其他页面
                            current_before_nav = await self._get_current_url(ctx)
                            if current_before_nav != url:
                                logger.info("      🔄 重置页面状态: %s → %s", current_before_nav[:60], url[:60])
                                try:
                                    page = await self._get_playwright_page(ctx)
                                    await page.goto(url)
                                    await asyncio.sleep(0.5)  # 等待页面加载
                                    logger.info("      ✅ 页面重置完成")
                                except Exception as e:
                                    logger.warning("      ⚠️ 页面重置失败: %s", e)
                                    continue

                            # 真正执行探索：点击链接并获取新 URL
                            logger.debug("      🔄 调用 _explore_navigation() 执行具体操作")

                            # 采集探索前截图
                            state_before = await ctx.get_state()
                            before_screenshot = state_before.screenshot if state_before else None

                            # 初始化该次探索结果
                            self._exploration_stats["total_count"] += 1
                            is_captcha_skip = False
                            new_url = None
                            task_status = "no_new_url"

                            try:
                                # 预检测：检查目标 URL 是否包含通用验证码关键词
                                if self._is_captcha_url(action.get("href", "")):
                                    logger.warning("      ❌ 探索失败 [%s]: 目标页面可能触发验证码，自动跳过", label)
                                    is_captcha_skip = True
                                    task_status = "captcha_skip"
                                    self._exploration_stats["captcha_skip_count"] += 1
                                    self._exploration_stats["failed_actions"].append({
                                        "label": label,
                                        "reason": "captcha_skip",
                                        "url": url,
                                    })

                                if not is_captcha_skip:
                                    new_url, skip_reason = await self._explore_navigation(ctx, action, url)
                                    url_preview = new_url[:80] if new_url else "None"
                                    logger.debug(
                                        "      📍 _explore_navigation() 返回: %s, skip_reason=%s",
                                        url_preview,
                                        skip_reason,
                                    )

                                    # 方案 3：探索失败且存在弹窗时，尝试关闭弹窗后重试一次
                                    if new_url is None and analysis.has_popup:
                                        logger.info("      🔄 探索失败，尝试关闭弹窗后重试...")
                                        await self._dismiss_popup(ctx, analysis.popup_close_hint)
                                        await asyncio.sleep(0.5)
                                        new_url, skip_reason = await self._explore_navigation(ctx, action, url)
                                        if new_url:
                                            logger.info("      ✅ 重试成功: %s", new_url[:60])

                                    if skip_reason == "captcha":
                                        task_status = "captcha_page"
                                        self._exploration_stats["captcha_skip_count"] += 1
                                        self._exploration_stats["fail_count"] += 1
                                        self._exploration_stats["failed_actions"].append({
                                            "label": label,
                                            "reason": "captcha_page",
                                            "url": url,
                                        })
                                    elif skip_reason == "no_url_change":
                                        task_status = "no_url_change"
                                        logger.info("      ⏸️ 同页操作（如展开菜单），无新 URL，跳过: %s", label)
                                    elif new_url and new_url not in visited:
                                        # 获取新页面后再次检查是否是验证码页面
                                        if self._is_captcha_url(new_url):
                                            task_status = "captcha_page"
                                            logger.warning("      ❌ 探索失败 [%s]: 进入验证码页面 %s", label, new_url[:60])
                                            self._exploration_stats["captcha_skip_count"] += 1
                                            self._exploration_stats["fail_count"] += 1
                                            self._exploration_stats["failed_actions"].append({
                                                "label": label,
                                                "reason": "captcha_page",
                                                "url": new_url,
                                            })
                                            new_url = None  # 标记为失败
                                        else:
                                            # 成功探索到新页面
                                            task_status = "success"
                                            self._exploration_stats["success_count"] += 1
                                            logger.info("      ✅ 探索成功，进入新页面: %s", new_url[:60])

                                            # 检查深度限制：如果新页面深度在限制内，立即分析并生成用例
                                            new_depth = depth + 1
                                            if new_depth <= max_depth:
                                                logger.info("   📄 立即分析新页面 (L%d): %s", new_depth, new_url[:60])

                                                # 不在此处 visited.add(new_url)，否则该页从队列弹出时
                                                # 会因 url in visited 被 continue 跳过，导致无法从
                                                # L1 继续规划到 L2/L3；visited 在 popleft 后统一添加。

                                                # 立即分析新页面并生成用例（path_chain 含完整导航链）
                                                child_path_chain = path_chain + [label]
                                                child_cases, child_defects, child_analysis = await self._analyze_single_page(
                                                    ctx=ctx,
                                                    url=new_url,
                                                    depth=new_depth,
                                                    path=label,
                                                    path_chain=child_path_chain,
                                                    max_cases=max_cases,
                                                    visual_error_check=visual_error_check,
                                                )

                                                all_cases.extend(child_cases)
                                                all_defects.extend(child_defects)

                                                # 实时输出：子页面用例生成后立即写入
                                                # （传入 pre_steps 使 L1+ 用例含完整探索前路径，可独立运行）
                                                if realtime_output and child_cases:
                                                    await self._save_page_cases_immediately(
                                                        child_cases, run_dir, target_url,
                                                        login_record=login_record,
                                                        target_module=target_module,
                                                        credentials=CREDENTIALS_PLACEHOLDER_FOR_YAML,
                                                        pre_steps=pre_steps,
                                                    )

                                                # 采集探索后截图
                                                state_after = await ctx.get_state()
                                                after_screenshot = state_after.screenshot if state_after else None

                                                # 创建子节点并采集报告数据
                                                child_node = PageReportNode(depth=new_depth, path=label, url=new_url)
                                                child_node.screenshot = after_screenshot
                                                child_node.analysis = child_analysis
                                                child_node.cases = list(child_cases)
                                                child_node_key = (new_url, label)
                                                node_by_key[child_node_key] = child_node
                                                current_node.children.append(child_node)

                                                # 添加探索任务记录（含子节点引用，供报告展示子页面摘要）
                                                current_node.exploration_tasks.append(
                                                    ExploreTaskRecord(
                                                        label=label,
                                                        before_screenshot=before_screenshot,
                                                        after_screenshot=after_screenshot,
                                                        status=task_status,
                                                        new_url=new_url,
                                                        child_node=child_node,
                                                    )
                                                )

                                                # 如果新页面的深度还能继续探索，将其加入队列
                                                if new_depth < max_depth:
                                                    logger.debug("      ➕ 将 L%d 页面加入待探索队列", new_depth)
                                                    queue.append((new_depth, new_url, label, key, child_path_chain))
                                                else:
                                                    logger.debug(
                                                        "      ➕ 该 L%d 页面已达深度上限，不加入下一层探索队列",
                                                        new_depth,
                                                    )
                                            else:
                                                logger.info("      ⏹️ 超过最大深度 %d，跳过分析与用例生成", max_depth)
                                    elif new_url in visited:
                                        logger.info("      ⏭️ 已访问，跳过: %s", new_url[:60])
                                    elif skip_reason not in ("captcha", "no_url_change"):
                                        # 探索失败（未获取到新URL），排除 captcha 与同页操作
                                        task_status = "no_new_url"
                                        logger.warning("      ❌ 探索失败 [%s]: 未获取到新 URL", label)
                                        self._exploration_stats["fail_count"] += 1
                                        self._exploration_stats["failed_actions"].append({
                                            "label": label,
                                            "reason": "no_new_url",
                                            "url": url,
                                        })
                            except RuntimeError as e:
                                # 浏览器关闭等致命错误，终止整个探索
                                if "浏览器已关闭" in str(e) or "任务终止" in str(e):
                                    logger.error("      ❌ %s", e)
                                    raise  # 向上抛出，终止整个探索流程
                                task_status = "error"
                                logger.warning("      ❌ 探索失败 [%s]: %s", label, e)
                                self._exploration_stats["fail_count"] += 1
                                self._exploration_stats["failed_actions"].append({
                                    "label": label,
                                    "reason": str(e),
                                    "url": url,
                                })
                            except Exception as e:
                                # TimeoutError 和其他异常统一处理
                                task_status = "error"
                                logger.warning("      ❌ 探索失败 [%s]: %s", label, e)
                                self._exploration_stats["fail_count"] += 1
                                self._exploration_stats["failed_actions"].append({
                                    "label": label,
                                    "reason": str(e),
                                    "url": url,
                                })

                            # 对未成功的探索添加任务记录（成功分支已在内部添加）
                            if task_status != "success":
                                state_after = await ctx.get_state()
                                after_screenshot = state_after.screenshot if state_after else None
                                current_node.exploration_tasks.append(
                                    ExploreTaskRecord(
                                        label=label,
                                        before_screenshot=before_screenshot,
                                        after_screenshot=after_screenshot,
                                        status=task_status,
                                        new_url=new_url,
                                    )
                                )

                        # 本轮探索任务全部执行完成后，再判断并输出是否达到最大深度
                        if depth + 1 >= max_depth and plan.next_actions:
                            logger.info("   ⏹️ 本轮 %d 个探索任务已执行完成，已达到最大深度 %d，不再深入探索",
                                        min(3, len(plan.next_actions)), max_depth)

            finally:
                self.error_collector.detach()

        logger.info("-"*60)
        logger.info("【探索模式测试助手】探索完成: %d 个用例", len(all_cases))

        # 输出探索统计
        stats = self._exploration_stats
        if stats["total_count"] > 0:
            logger.info("📊 探索任务统计:")
            logger.info("   总任务数: %d", stats["total_count"])
            logger.info("   成功: %d (%.1f%%)", stats["success_count"], stats["success_count"] / stats["total_count"] * 100)
            logger.info("   失败: %d (%.1f%%)", stats["fail_count"], stats["fail_count"] / stats["total_count"] * 100)
            logger.info("   验证码跳过: %d", stats["captcha_skip_count"])

            # 输出失败的探索任务详情
            if stats["failed_actions"]:
                logger.info("   失败任务列表:")
                for i, failed in enumerate(stats["failed_actions"][:10], 1):  # 最多显示10个
                    logger.info("      %d. [%s] %s - %s", i, failed["reason"], failed["label"], failed["url"][:40])
                if len(stats["failed_actions"]) > 10:
                    logger.info("      ... 还有 %d 个", len(stats["failed_actions"]) - 10)

        return all_cases, all_defects, report_ctx

    async def _analyze_single_page(
        self,
        ctx: Any,
        url: str,
        depth: int,
        path: str,
        path_chain: Optional[List[str]] = None,
        max_cases: int = 5,
        visual_error_check: bool = False,
    ) -> Tuple[List[Any], List[Any], Optional[Any]]:
        """
        分析单个页面并生成用例

        Args:
            ctx: BrowserContext
            url: 页面URL
            depth: 当前深度
            path: 页面路径描述
            max_cases: 最大用例数

        Returns:
            (cases, defects, analysis) 该页面生成的用例列表、缺陷列表和分析结果
        """
        cases = []
        defects = []
        analysis = None

        try:
            # 获取页面状态（强制刷新，确保获取最新页面）
            state = await ctx.get_state()
            actual_url = state.url if state else url

            # 页面分析
            logger.debug("   🔍 开始页面分析: %s (expected: %s)", actual_url[:60], url[:60])
            analysis = await self.page_analyzer.analyze(ctx)

            # 统计元素类型分布
            type_counts = {}
            unknown_elements = []
            for elem in analysis.actionable_elements:
                elem_type = (
                    elem.get("element_type", "unknown")
                    if isinstance(elem, dict)
                    else getattr(elem, 'element_type', 'unknown')
                )
                type_counts[elem_type] = type_counts.get(elem_type, 0) + 1
                if elem_type in ("unknown", "", None):
                    unknown_elements.append(elem)

            logger.info("   📊 页面分析完成: %d 个可操作元素", len(analysis.actionable_elements))
            logger.info("   📈 元素类型分布: %s", ", ".join(f"{k}:{v}" for k, v in sorted(type_counts.items())))

            # 如果有很多 unknown 类型，发出警告
            unknown_count = len(unknown_elements)
            if unknown_count > 0:
                logger.warning("   ⚠️ 发现 %d 个 unknown 类型元素", unknown_count)
                for i, elem in enumerate(unknown_elements[:3], 1):
                    logger.warning("      %d. %s", i, elem)

            # 检测登录页
            if analysis.is_login_page:
                logger.warning("   ⚠️ 检测到登录页，跳过: %s", path)
                return cases, defects, analysis

            # 视觉缺陷检测（可关闭以省 token）
            if visual_error_check:
                screenshot_base64 = None
                if hasattr(state, 'screenshot') and state.screenshot:
                    screenshot_base64 = state.screenshot
                if screenshot_base64:
                    visual_defects = await self.visual_detector.detect(
                        screenshot_base64, actual_url, path
                    )
                    if visual_defects:
                        defects.extend(visual_defects)

            # 用例设计（限制数量）；传入 path 供兜底用例与 path 关联；有截图时传入供设计参考
            page_cases = await self.case_designer.design(
                analysis,
                max_cases=max_cases,
                path=path,
                screenshot_base64=(
                    state.screenshot if state and getattr(state, "screenshot", None) else None
                ),
            )
            logger.info("   📝 设计 %d 个用例（限制: %d）", len(page_cases), max_cases)

            # 为用例添加层级信息（path_chain 用于 YAML 前序导航步骤）
            path_chain = path_chain if path_chain is not None else ([path] if path and path != "root" else [])
            for case in page_cases:
                case.metadata = {"depth": depth, "path": path, "path_chain": path_chain}

            cases.extend(page_cases)

            # 采集本页缺陷
            page_defects = self.error_collector.collect(actual_url, path)
            if page_defects:
                defects.extend(page_defects)

        except Exception as e:
            logger.warning("   ⚠️ 页面分析失败 [%s]: %s", actual_url[:60] if 'actual_url' in locals() else url[:60], e)

        return cases, defects, analysis

    async def _save_page_cases_immediately(
        self,
        cases: List[Any],
        run_dir: Path,
        target_url: str,
        login_record: Optional[Any] = None,
        target_module: Optional[str] = None,
        credentials: Optional[Dict[str, str]] = None,
        pre_steps: Optional[List[dict]] = None,
    ) -> List[Path]:
        """每页用例生成后立即写入 YAML 文件（用于 realtime_output 模式）"""
        if not cases:
            return []
        cases_dir = run_dir / "cases"
        cases_dir.mkdir(exist_ok=True)
        yaml_contents = await self.yaml_generator.generate(
            cases, target_url,
            login_record=login_record,
            target_module=target_module,
            credentials_for_yaml=credentials,
            pre_steps=pre_steps,
        )
        written = []
        for i, (case, content) in enumerate(zip(cases, yaml_contents)):
            case_id = case.case_id if hasattr(case, 'case_id') else f"{i+1:02d}"
            safe_name = self._sanitize_filename(case.case_name if hasattr(case, 'case_name') else f"case_{i}")
            depth = case.metadata.get("depth", 0) if hasattr(case, 'metadata') else 0
            path = case.metadata.get("path", "root") if hasattr(case, 'metadata') else "root"
            depth_dir = cases_dir / f"L{depth}_{self._sanitize_filename(path)}"
            depth_dir.mkdir(exist_ok=True)
            fpath = depth_dir / f"{case_id}_{safe_name}.yaml"
            fpath.write_text(content, encoding="utf-8")
            written.append(fpath)
            logger.info("   ✓ %s", fpath.relative_to(run_dir))
        return written

    async def _save_yaml_files(
        self,
        cases: List[Any],
        run_dir: Path,
        target_url: str,
        realtime_output: bool = False,
        login_record: Optional[Any] = None,
        target_module: Optional[str] = None,
        credentials: Optional[Dict[str, str]] = None,
        pre_steps: Optional[List[dict]] = None,
    ) -> List[Path]:
        """保存 YAML 用例文件。realtime_output=True 时用例已增量写入，此处仅生成 index.yaml。
        策略：多个 case 不合并为可执行 YAML，每个 case 单独一个文件；
        执行时应对每个 .yaml 单独 --task-file，不要用 index 作为 task-file。"""
        cases_dir = run_dir / "cases"
        cases_dir.mkdir(exist_ok=True)

        if realtime_output:
            # 用例已由 _save_page_cases_immediately 增量写入，仅生成索引
            logger.info("💾 生成用例索引 (realtime_output 模式，用例已增量写入)...")
            yaml_paths = self._build_yaml_paths_from_cases(cases, cases_dir)
        else:
            logger.info("💾 保存 YAML 文件...")
            yaml_contents = await self.yaml_generator.generate(
                cases, target_url,
                login_record=login_record,
                target_module=target_module,
                credentials_for_yaml=credentials,
                pre_steps=pre_steps,
            )
            yaml_paths = []
            for i, (case, content) in enumerate(zip(cases, yaml_contents)):
                case_id = case.case_id if hasattr(case, 'case_id') else f"{i+1:02d}"
                safe_name = self._sanitize_filename(case.case_name if hasattr(case, 'case_name') else f"case_{i}")
                depth = case.metadata.get("depth", 0) if hasattr(case, 'metadata') else 0
                path = case.metadata.get("path", "root") if hasattr(case, 'metadata') else "root"
                depth_dir = cases_dir / f"L{depth}_{self._sanitize_filename(path)}"
                depth_dir.mkdir(exist_ok=True)
                fpath = depth_dir / f"{case_id}_{safe_name}.yaml"
                fpath.write_text(content, encoding="utf-8")
                yaml_paths.append(fpath)
                logger.info("   ✓ %s", fpath.relative_to(run_dir))

        index_path = cases_dir / "index.yaml"
        index_content = self._generate_index(cases, yaml_paths)
        index_path.write_text(index_content, encoding="utf-8")

        return yaml_paths

    def _build_yaml_paths_from_cases(self, cases: List[Any], cases_dir: Path) -> List[Path]:
        """根据用例元数据构建 YAML 文件路径（用于 realtime_output 模式下的索引生成）"""
        paths = []
        for i, case in enumerate(cases):
            case_id = case.case_id if hasattr(case, 'case_id') else f"{i+1:02d}"
            safe_name = self._sanitize_filename(case.case_name if hasattr(case, 'case_name') else f"case_{i}")
            depth = case.metadata.get("depth", 0) if hasattr(case, 'metadata') else 0
            path = case.metadata.get("path", "root") if hasattr(case, 'metadata') else "root"
            depth_dir = cases_dir / f"L{depth}_{self._sanitize_filename(path)}"
            fpath = depth_dir / f"{case_id}_{safe_name}.yaml"
            paths.append(fpath)
        return paths

    def _generate_index(self, cases: List[Any], yaml_paths: List[Path]) -> str:
        """生成用例索引（仅元数据，不可作为 task-file 执行）。执行时应对每个 case 的 .yaml 单独 --task-file。"""
        import yaml

        index = {
            "total": len(cases),
            "generated_at": datetime.now().isoformat(),
            "execution_note": (
                "Execute each case file individually (one --task-file per .yaml). "
                "Do not use this index as task-file."
            ),
            "cases": [],
        }

        for case, path in zip(cases, yaml_paths):
            index["cases"].append({
                "id": case.case_id if hasattr(case, 'case_id') else "",
                "name": case.case_name if hasattr(case, 'case_name') else "",
                "description": case.description if hasattr(case, 'description') else "",
                "path": str(path.name),
                "depth": case.metadata.get("depth", 0) if hasattr(case, 'metadata') else 0,
            })

        return yaml.dump(index, allow_unicode=True, sort_keys=False)

    def _generate_preview_report(
        self,
        cases: List[Any],
        defects: List[Any],
        run_dir: Path,
    ) -> Path:
        """生成预览报告"""
        reports_dir = run_dir / "reports"
        reports_dir.mkdir(exist_ok=True)

        preview_path = reports_dir / "preview_report.md"

        lines = ["# 测试用例预览报告\n"]
        lines.append(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        lines.append(f"用例总数: {len(cases)}\n")
        lines.append(f"缺陷数量: {len(defects)}\n\n")

        # 按层级分组
        from collections import defaultdict
        by_depth = defaultdict(list)
        for case in cases:
            depth = case.metadata.get("depth", 0) if hasattr(case, 'metadata') else 0
            by_depth[depth].append(case)

        for depth in sorted(by_depth.keys()):
            lines.append(f"## L{depth} 层级\n\n")
            for case in by_depth[depth]:
                lines.append(f"### [{case.case_id}] {case.case_name}\n\n")
                lines.append(f"- 描述: {case.description}\n")
                lines.append(f"- 步骤数: {len(case.steps)}\n")
                lines.append(f"- 验证点: {len(case.validation_points)}\n\n")

        # 缺陷汇总
        if defects:
            lines.append("## 发现的缺陷\n\n")
            for d in defects[:20]:  # 最多显示20个
                lines.append(f"- [{d.type}] {d.message[:100]}\n")

        preview_path.write_text("".join(lines), encoding="utf-8")
        logger.info("📄 预览报告: %s", preview_path.name)

        return preview_path

    def _generate_execution_report(
        self,
        result: ExecutionResult,
        run_dir: Path,
    ) -> Path:
        """生成执行报告"""
        reports_dir = run_dir / "reports"
        reports_dir.mkdir(exist_ok=True)

        exec_path = reports_dir / "execution_report.md"

        lines = ["# 测试执行报告\n\n"]
        lines.append(f"执行时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        lines.append(f"执行状态: {result.status}\n\n")
        lines.append(f"- 总计: {result.total}\n")
        lines.append(f"- 通过: {result.passed}\n")
        lines.append(f"- 失败: {result.failed}\n\n")

        if result.cases_executed:
            lines.append("## 执行详情\n\n")
            for case_result in result.cases_executed:
                status = "✅" if case_result.success else "❌"
                lines.append(f"{status} [{case_result.case_id}] {case_result.case_name}\n")
                if not case_result.success and case_result.error:
                    lines.append(f"   Error: {case_result.error}\n")

        exec_path.write_text("".join(lines), encoding="utf-8")
        logger.info("📄 执行报告: %s", exec_path.name)

        return exec_path

    # ============ 执行控制 ============

    async def _interactive_execute(
        self,
        ctx: Any,
        cases: List[Any],
        run_dir: Path,
    ) -> Optional[ExecutionResult]:
        """交互式执行选择"""
        while True:
            print("\n" + "="*60)
            print(f"📝 已生成 {len(cases)} 个测试用例")
            print("="*60)
            print("[1] 单条执行 → 选择具体用例执行")
            print("[2] 批量执行 → 选择多个用例执行")
            print("[3] 全部执行 → 执行所有用例")
            print("[4] 跳过执行 → 仅保存 YAML")
            print("[q] 退出")
            print()

            choice = input("> 请选择 [1-4/q]: ").strip().lower()

            if choice == "1":
                return await self._menu_single_execute(ctx, cases, run_dir)
            elif choice == "2":
                return await self._menu_batch_execute(ctx, cases, run_dir)
            elif choice == "3":
                return await self._execute_all(ctx, cases, run_dir)
            elif choice in ("4", "q"):
                print("跳过执行，用例已保存")
                return None
            else:
                print("无效选项，请重新选择")

    async def _menu_single_execute(
        self,
        ctx: Any,
        cases: List[Any],
        run_dir: Path,
    ) -> Optional[ExecutionResult]:
        """菜单选择单条执行"""
        print("\n可用用例：")
        for i, case in enumerate(cases, 1):
            print(f"  [{i:02d}] {case.case_id}: {case.case_name}")

        choice = input("\n> 请输入用例编号（或 'b' 返回）: ").strip()
        if choice == 'b':
            return None

        try:
            idx = int(choice) - 1
            case = cases[idx]
        except (ValueError, IndexError):
            print("无效编号")
            return None

        return await self._execute_single(ctx, case.case_id, cases, run_dir)

    async def _menu_batch_execute(
        self,
        ctx: Any,
        cases: List[Any],
        run_dir: Path,
    ) -> Optional[ExecutionResult]:
        """菜单选择批量执行"""
        print("\n可用用例：")
        for i, case in enumerate(cases, 1):
            print(f"  [{i:02d}] {case.case_id}: {case.case_name}")

        choice = input("\n> 请输入用例编号（逗号分隔，如 1,3,5，或 'b' 返回）: ").strip()
        if choice == 'b':
            return None

        try:
            indices = [int(x.strip()) - 1 for x in choice.split(",")]
            selected_ids = [cases[i].case_id for i in indices if 0 <= i < len(cases)]
        except (ValueError, IndexError):
            print("无效编号")
            return None

        return await self._execute_batch(ctx, selected_ids, cases, run_dir)

    async def _execute_single(
        self,
        ctx: Any,
        case_id: Optional[str],
        cases: List[Any],
        run_dir: Path,
    ) -> Optional[ExecutionResult]:
        """单条执行"""
        if not case_id:
            raise ValueError("单条执行需要提供 case_id")

        case = next(
            (
                c
                for c in cases
                if c.case_id == case_id
            ),
            None,
        )
        if not case:
            logger.error("❌ 未找到用例: %s", case_id)
            return None

        print("\n📋 用例详情：")
        print(f"  编号: {case.case_id}")
        print(f"  名称: {case.case_name}")
        print(f"  描述: {case.description}")
        print(f"  步骤数: {len(case.steps)}")

        confirm = input("\n确认执行? [y/N]: ").strip().lower()
        if confirm != 'y':
            print("已取消")
            return ExecutionResult(status="cancelled")

        logger.info("⚡ 执行用例: [%s] %s", case.case_id, case.case_name)
        result = await self.case_executor.execute(ctx, case)

        status = "✅ 通过" if result.success else "❌ 失败"
        logger.info("%s: [%s] %s", status, case.case_id, case.case_name)

        return ExecutionResult(
            status="completed" if result.success else "failed",
            cases_executed=[result],
            total=1,
            passed=1 if result.success else 0,
            failed=0 if result.success else 1,
        )

    async def _execute_batch(
        self,
        ctx: Any,
        case_ids: Optional[List[str]],
        cases: List[Any],
        run_dir: Path,
    ) -> Optional[ExecutionResult]:
        """批量执行"""
        if not case_ids:
            raise ValueError("批量执行需要提供 case_ids")

        selected = [c for c in cases if c.case_id in case_ids]

        print(f"\n⚡ 批量执行 - 已选择 {len(selected)} 个用例")
        for c in selected:
            print(f"  - [{c.case_id}] {c.case_name}")

        confirm = input("\n确认执行? [y/N]: ").strip().lower()
        if confirm != 'y':
            print("已取消")
            return ExecutionResult(status="cancelled")

        logger.info("⚡ 批量执行 %d 个用例", len(selected))

        results = []
        passed = 0
        failed = 0

        for case in selected:
            result = await self.case_executor.execute(ctx, case)
            results.append(result)

            if result.success:
                passed += 1
                logger.info("✅ [%s] %s", case.case_id, case.case_name)
            else:
                failed += 1
                logger.error("❌ [%s] %s - %s", case.case_id, case.case_name, result.error)

        return ExecutionResult(
            status="completed",
            cases_executed=results,
            total=len(selected),
            passed=passed,
            failed=failed,
        )

    async def _execute_all(
        self,
        ctx: Any,
        cases: List[Any],
        run_dir: Path,
    ) -> ExecutionResult:
        """全部执行"""
        print(f"\n⚡ 全部执行 - 共 {len(cases)} 个用例")

        confirm = input("确认执行所有用例? [y/N]: ").strip().lower()
        if confirm != 'y':
            print("已取消")
            return ExecutionResult(status="cancelled")

        logger.info("⚡ 执行全部 %d 个用例", len(cases))

        results = []
        passed = 0
        failed = 0

        for case in cases:
            result = await self.case_executor.execute(ctx, case)
            results.append(result)

            if result.success:
                passed += 1
                logger.info("✅ [%s] %s", case.case_id, case.case_name)
            else:
                failed += 1
                logger.error("❌ [%s] %s - %s", case.case_id, case.case_name, result.error)

        return ExecutionResult(
            status="completed",
            cases_executed=results,
            total=len(cases),
            passed=passed,
            failed=failed,
        )

    # ============ 工具方法 ============

    async def _dismiss_popup(self, ctx: Any, hint: Optional[str] = None) -> bool:
        """
        尝试关闭页面上可能存在的弹窗。
        优先按 hint 点击（如 "点击知道了" 提取 "知道了"），无 hint 时尝试常见关闭文案。
        返回是否执行了关闭操作。
        """
        try:
            page = await self._get_playwright_page(ctx)
            closed = False
            # 若有 hint，从中提取可点击文案（如 "点击知道了" -> "知道了"）
            if hint:
                for prefix in ("点击", "点", "按"):
                    if hint.startswith(prefix):
                        text = hint[len(prefix):].strip().strip("""'"''""")
                        if text and len(text) <= 20:
                            try:
                                loc = page.get_by_text(text).first
                                await loc.click(timeout=2000)
                                logger.info("   🪟 已关闭弹窗: %s", hint)
                                closed = True
                                await asyncio.sleep(0.5)
                                return True
                            except Exception:
                                pass
                        break
            if not closed:
                for text in ["知道了", "关闭", "确定", "×", "x"]:
                    try:
                        loc = page.get_by_text(text).first
                        await loc.click(timeout=1500)
                        logger.info("   🪟 已关闭弹窗: 点击了 '%s'", text)
                        closed = True
                        await asyncio.sleep(0.5)
                        return True
                    except Exception:
                        continue
            if not closed:
                try:
                    close_btn = page.locator(
                        ".ant-modal-close, [class*='modal-close'], [aria-label='Close']"
                    ).first
                    await close_btn.click(timeout=1000)
                    logger.info("   🪟 已关闭弹窗: 点击了关闭图标")
                    await asyncio.sleep(0.5)
                    return True
                except Exception:
                    pass
            return closed
        except Exception as e:
            logger.debug("   弹窗关闭尝试: %s", e)
            return False

    async def _get_playwright_page(self, ctx: Any) -> Any:
        """获取 Playwright page 对象"""
        # 从 BrowserContext 获取底层的 playwright page
        if hasattr(ctx, 'get_current_page'):
            return await ctx.get_current_page()
        elif hasattr(ctx, '_page'):
            return ctx._page
        elif hasattr(ctx, 'page'):
            return ctx.page
        else:
            raise RuntimeError("无法获取 Playwright page 对象")

    async def _get_current_url(self, ctx: Any) -> str:
        """获取当前页面 URL"""
        page = await self._get_playwright_page(ctx)
        return page.url

    async def _is_browser_closed(self, ctx: Any) -> bool:
        """检测浏览器是否已被用户关闭"""
        try:
            page = await self._get_playwright_page(ctx)
            # 检查 page 是否已关闭
            if hasattr(page, 'is_closed') and callable(page.is_closed):
                return page.is_closed()
            # 尝试访问 page 的属性，如果浏览器已关闭会抛出异常
            _ = page.url
            return False
        except Exception:
            # 任何异常都表示浏览器连接已断开或页面已关闭
            return True

    # 验证码/安全验证页面关键词（仅保留通用规则，不针对特定被测站点）
    # 仅保留明确与验证码页相关的关键词，避免误判（如 URL/页面中含 verify、verification 的业务页）
    CAPTCHA_KEYWORDS = [
        'captcha', '验证码', '安全验证',
        '请输入验证码', '点击验证', '拖动滑块', '滑块验证',
    ]

    def _is_captcha_url(self, url: str) -> bool:
        """检测 URL 是否是已知的验证码页面"""
        url_lower = url.lower()
        for keyword in self.CAPTCHA_KEYWORDS:
            if keyword.lower() in url_lower:
                return True
        return False

    async def _is_captcha_page(self, ctx: Any) -> bool:
        """检测当前页面内容是否包含验证码元素"""
        try:
            page = await ctx.get_current_page()
            # 获取页面文本内容
            content = await page.content()
            content_lower = content.lower()

            # 检测验证码相关关键词
            # 不含单独 'verify'，避免命中业务文案/脚本中的 verify、verified、verification 等
            captcha_indicators = [
                '验证码', '安全验证', 'captcha',
                '请输入验证码', '点击验证', '拖动滑块',
                'security-verify', 'captcha-image', 'verify-code'
            ]

            for indicator in captcha_indicators:
                if indicator.lower() in content_lower:
                    return True

            # 检测是否有验证码输入框
            captcha_inputs = await page.query_selector_all(
                'input[name*="captcha"], input[name*="verify"], '
                '.captcha-input, #captcha, [class*="captcha"], [id*="captcha"]'
            )
            if captcha_inputs:
                return True

            return False
        except Exception:
            return False

    async def _explore_navigation(
        self,
        ctx: Any,
        action: Dict[str, Any],
        original_url: str
    ) -> Optional[str]:
        """
        执行导航探索：使用 Agent 智能点击链接并获取新页面 URL

        Args:
            ctx: BrowserContext
            action: 探索动作，包含 label, description 等
            original_url: 当前页面 URL（用于返回）

        Returns:
            新页面 URL，如果失败返回 None
        """
        import shutil
        import tempfile
        import time

        # 检测浏览器是否已关闭
        if await self._is_browser_closed(ctx):
            logger.warning("      ⚠️ 浏览器已关闭，终止探索任务")
            raise RuntimeError("浏览器已关闭，任务终止")

        label = action.get("label", "")
        description = action.get("description", f"点击{label}")
        element_index = action.get("element_index")

        # 如果存在 element_index，在描述中明确指定
        if element_index is not None:
            description = f"使用索引为 {element_index} 的元素: {description}"

        # 预先检测目标 URL 是否包含通用验证码关键词
        target_url_hint = action.get("href", "") or action.get("url", "")
        if self._is_captcha_url(target_url_hint):
            logger.warning("      ⚠️ [%s] 目标页面可能触发验证码，自动跳过", label)
            return None, "captcha"

        logger.info("      🤖 使用 Agent 执行: %s", description[:50])
        logger.debug("         📍 原始 URL: %s", original_url[:80])

        # 获取或复用 LLM（避免重复创建）
        llm_bundle = self._get_or_create_llm_bundle()

        temp_dir = tempfile.mkdtemp(prefix="explore_")
        start_time = time.time()

        try:
            # 不再在此处加探索总超时，agent.ai_action() 内部已有超时控制
            url, reason = await self._do_explore_navigation_internal(
                ctx, action, original_url, label, description,
                element_index, llm_bundle, temp_dir, start_time
            )
            return url, reason
        except Exception as e:
            total_time = time.time() - start_time
            logger.exception("      ❌ Agent 探索异常 [%.2fs]: %s", total_time, e)
            return None, None
        finally:
            # 清理临时文件
            try:
                shutil.rmtree(temp_dir, ignore_errors=True)
                logger.debug("        🧹 临时目录清理: %s", temp_dir)
            except Exception as cleanup_err:
                logger.warning("        ⚠️ 临时目录清理失败: %s", cleanup_err)

    async def _do_explore_navigation_internal(
        self,
        ctx: Any,
        action: Dict[str, Any],
        original_url: str,
        label: str,
        description: str,
        element_index: Optional[int],
        llm_bundle: Tuple,
        temp_dir: str,
        start_time: float
    ) -> Optional[str]:
        """内部探索执行逻辑（可被超时控制包装）"""

        # 方案 B：复用 Agent + 手动清理状态
        logger.debug("         🔧 步骤1: 获取或创建 Agent")
        agent = await self._get_or_create_exploration_agent(ctx, llm_bundle, temp_dir)
        logger.debug("         ✅ Agent 就绪 (复用: %s)", "是" if self._exploration_agent is agent else "否")

        logger.debug("         🔧 步骤2: 重置 Agent 状态")
        self._reset_agent_state(agent)

        logger.debug("         🔧 步骤3: 设置 Agent 命令状态")
        from ..agent.tasks import AiConfig
        command = AiConfig(ai=description)
        agent.state.update_current_cmd_state(
            task_index=0,
            cmd_index=0,
            command=command,
        )
        agent.update_action_space('ai')
        logger.debug("         ✅ 命令状态设置完成: type='ai', description='%s'", description[:50])

        # 记录执行前的 URL
        url_before_exec = await self._get_current_url(ctx)
        logger.debug("         📍 执行前 URL: %s", url_before_exec[:80])

        # 5. 执行探索（使用 ai_action 单步执行）
        logger.debug("         🚀 步骤4: 调用 agent.ai_action() 执行探索")
        exec_start = time.time()
        success, msg = await agent.ai_action()
        exec_time = time.time() - exec_start
        logger.debug("         ✅ ai_action() 执行完成: success=%s, time=%.2fs", success, exec_time)

        # 执行后检测是否是验证码页面
        if await self._is_captcha_page(ctx):
            logger.warning("      ⚠️ 检测到验证码页面，自动跳过")
            return None, "captcha"

        # 6. 如果执行成功，使用 aiWaitFor 等待页面加载完成
        if success:
            logger.debug("         🚀 步骤4b: 调用 agent.ai_wait_for() 等待页面加载")
            wait_start = time.time()

            # 在等待期间定期检查是否是验证码页面
            try:
                await asyncio.wait_for(
                    self._wait_for_page_load_with_captcha_check(agent, ctx),
                    timeout=15.0
                )
                wait_time = time.time() - wait_start
                logger.debug("         ✅ 页面加载完成，time=%.2fs", wait_time)
            except asyncio.TimeoutError:
                logger.warning("      ⚠️ 等待页面加载超时，检查是否为验证码页面")
                if await self._is_captcha_page(ctx):
                    logger.warning("      ⚠️ 检测到验证码页面，自动跳过")
                    return None, "captcha"

        # 7. 获取新 URL
        logger.debug("         🔧 步骤5: 获取执行后页面 URL")
        await asyncio.sleep(0.3)
        new_url = await self._get_current_url(ctx)
        logger.debug("         📍 执行后 URL: %s", new_url[:80])

        # 再次检测目标页面是否是验证码页面
        if self._is_captcha_url(new_url) or await self._is_captcha_page(ctx):
            logger.warning("      ⚠️ 目标页面是验证码页面，自动跳过: %s", new_url[:60])
            return None, "captcha"

        total_time = time.time() - start_time

        # 详细日志：URL 变化追踪
        if new_url != url_before_exec:
            logger.debug("         🔄 URL 变化: %s → %s", url_before_exec[:60], new_url[:60])
        else:
            logger.debug("         ⏸️ URL 未变化: %s", new_url[:60])

        # 记录详细监控日志
        self._log_exploration_result(
            description=description,
            original_url=original_url,
            new_url=new_url,
            success=success,
            exec_time=exec_time,
            total_time=total_time,
            temp_dir=temp_dir,
        )

        if success and new_url != original_url:
            logger.info("      ✅ Agent 探索成功 [%.2fs]: %s", total_time, new_url[:60])
            return new_url, None
        elif success:
            logger.info("      ⏸️ Agent 执行成功但 URL 未变化（同页操作，如展开菜单）[%.2fs]", total_time)
            return None, "no_url_change"
        else:
            logger.warning("      ❌ Agent 探索失败 [%.2fs]: %s", total_time, msg)
            return None, None

    async def _wait_for_page_load_with_captcha_check(self, agent, ctx: Any) -> None:
        """等待页面加载，同时监控是否是验证码页面"""
        from ..agent.tasks import AiWaitForConfig

        wait_command = AiWaitForConfig(aiWaitFor="等待页面加载完成，确保所有元素都已渲染")
        agent.state.update_current_cmd_state(
            task_index=0,
            cmd_index=1,
            command=wait_command,
        )
        agent.update_action_space('aiWaitFor')

        # 使用较短的超时执行 ai_wait_for
        try:
            await asyncio.wait_for(agent.ai_wait_for(), timeout=10.0)
        except asyncio.TimeoutError:
            # 超时后检查是否是验证码
            if await self._is_captcha_page(ctx):
                raise asyncio.TimeoutError("检测到验证码页面")

    def _get_or_create_llm_bundle(self):
        """
        获取或创建 LLM Bundle（复用优化）

        避免每次 exploration 都重新创建 LLM 实例，提升性能。
        返回: (actor, planner, asserter, aux_llms) 元组
        """
        if self._exploration_llm_bundle is None:
            logger.debug("🔄 初始化 Exploration LLM Bundle...")
            from .utils import build_models_for_case_generator
            self._exploration_llm_bundle = build_models_for_case_generator()
            logger.debug("✅ LLM Bundle 初始化完成")
        return self._exploration_llm_bundle

    async def _get_or_create_exploration_agent(self, ctx, llm_bundle, temp_dir: str):
        """
        获取或创建 Exploration Agent（复用优化）

        方案 B：复用 Agent + 手动清理状态
        - 如果 Agent 已存在且绑定的是同一个 context，直接复用
        - 否则创建新的 Agent

        Args:
            ctx: BrowserContext
            llm_bundle: LLM 资源元组
            temp_dir: 临时目录路径

        Returns:
            Agent: 可复用的 Agent 实例
        """
        # 检查是否可以复用现有 Agent
        if self._exploration_agent is not None and self._exploration_agent_ctx is ctx:
            logger.debug("        ♻️ 复用现有 Exploration Agent")
            return self._exploration_agent

        # 需要创建新的 Agent
        logger.debug("        🆕 创建新的 Exploration Agent")

        # 清理旧的 Agent（如果存在且 context 不同）
        if self._exploration_agent is not None:
            logger.debug("        🧹 清理旧的 Agent（context 已变更）")
            # 注意：不要关闭 agent，因为 context 是注入的，不会被 agent 关闭
            self._exploration_agent = None
            self._exploration_agent_ctx = None

        # 构建配置
        from omegaconf import OmegaConf
        project_root = Path(__file__).parent.parent.parent
        cfg = OmegaConf.load(project_root / "browser_use/static/configs/default.yaml")
        OmegaConf.update(cfg, "agent.max_steps", 5)
        OmegaConf.update(cfg, "agent.max_failures", 2)

        # 创建 Agent
        from ..agent.service import Agent
        from ..agent.tasks import Tasks

        # 创建占位任务 YAML（Tasks 类需要有效的 task 或 task_yaml_path）
        placeholder_task = """
target:
  url: "about:blank"
tasks:
  - name: exploration_placeholder
    flow: []
"""

        # 使用占位任务创建 Agent（实际指令通过 ai_react 动态设置）
        agent = Agent(
            config=cfg,
            tasks=Tasks(task=placeholder_task),
            llm=llm_bundle[0],
            planner=llm_bundle[1],
            asserter=llm_bundle[2],
            aux_llms=llm_bundle[3],
            browser_context=ctx,
            log_dir=temp_dir,
        )

        # 缓存 Agent
        self._exploration_agent = agent
        self._exploration_agent_ctx = ctx

        logger.debug("        ✅ Exploration Agent 创建完成")
        return agent

    def _reset_agent_state(self, agent):
        """
        重置 Agent 状态，准备执行新的 exploration 任务。

        方案 B 关键：手动清理状态，避免污染。
        """
        logger.debug("        🔄 重置 Agent 状态")

        # 重置失败计数
        agent.state.consecutive_failures = 0

        # 重置 step 计数（关键！避免 step 累积）
        if hasattr(agent.state, 'n_steps'):
            agent.state.n_steps = 0
            logger.debug("        🔄 n_steps 已重置为 0")

        # 重置 history（关键！避免历史干扰新任务）
        if hasattr(agent.state, 'history'):
            # 清空 history 列表，而不是创建新实例
            if hasattr(agent.state.history, 'clear'):
                agent.state.history.clear()
            elif hasattr(agent.state.history, 'history') and isinstance(agent.state.history.history, list):
                agent.state.history.history.clear()
            logger.debug("        🔄 history 已重置")

        # 重置当前命令相关状态
        agent.state.current_cmd_report_paths = []

        # 重置已执行动作列表
        if hasattr(agent.state, 'executed_actions'):
            agent.state.executed_actions = []
            logger.debug("        🔄 executed_actions 已重置")

    def _log_exploration_result(
        self,
        description: str,
        original_url: str,
        new_url: str,
        success: bool,
        exec_time: float,
        total_time: float,
        temp_dir: str,
    ):
        """
        记录 Exploration 执行结果（用于监控和调试）

        包含性能指标、成功/失败统计、URL 变化等信息。
        """
        # 更新统计数据
        self._exploration_stats["total_count"] += 1
        self._exploration_stats["total_exec_time"] += exec_time

        if success and new_url != original_url:
            self._exploration_stats["success_count"] += 1
            status = "SUCCESS"
        elif success:
            self._exploration_stats["timeout_count"] += 1
            status = "NO_NAVIGATION"
        else:
            self._exploration_stats["fail_count"] += 1
            status = "FAILED"

        # 详细日志（debug 级别，避免过多输出）
        logger.debug(
            "📊 Exploration Stats: "
            "total=%d, success=%d, fail=%d, timeout=%d, "
            "avg_exec_time=%.2fs",
            self._exploration_stats["total_count"],
            self._exploration_stats["success_count"],
            self._exploration_stats["fail_count"],
            self._exploration_stats["timeout_count"],
            self._exploration_stats["total_exec_time"] / max(self._exploration_stats["total_count"], 1),
        )

        # 详细记录到文件（便于后续分析）
        try:
            _ = {
                "timestamp": datetime.now().isoformat(),
                "description": description,
                "original_url": original_url,
                "new_url": new_url,
                "url_changed": new_url != original_url,
                "success": success,
                "status": status,
                "exec_time_sec": round(exec_time, 2),
                "total_time_sec": round(total_time, 2),
                "temp_dir": temp_dir,
            }
            # 可以写入专门的探索日志文件
            # with open(self.output_dir / "exploration_log.jsonl", "a") as f:
            #     f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")
        except Exception as e:
            logger.debug("记录 exploration 日志失败: %s", e)

    def get_exploration_stats(self) -> Dict[str, Any]:
        """
        获取 Exploration 统计信息

        Returns:
            包含成功/失败率、平均执行时间等统计数据的字典
        """
        total = self._exploration_stats["total_count"]
        if total == 0:
            return {"message": "暂无 exploration 数据"}

        return {
            "total_explorations": total,
            "success_rate": f"{self._exploration_stats['success_count'] / total * 100:.1f}%",
            "failure_rate": f"{self._exploration_stats['fail_count'] / total * 100:.1f}%",
            "no_navigation_rate": f"{self._exploration_stats['timeout_count'] / total * 100:.1f}%",
            "avg_exec_time": f"{self._exploration_stats['total_exec_time'] / total:.2f}s",
        }

    def _sanitize_filename(self, name: str) -> str:
        """清理文件名"""
        import re
        invalid = '<>:"/\\|?*'
        for c in invalid:
            name = name.replace(c, '_')
        return re.sub(r'\s+', '_', name)[:50]
