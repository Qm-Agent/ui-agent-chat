# -*- coding: utf-8 -*-
"""
模块导航器

参考 ai_login.py 实现：使用 AI 自然语言指令（ai）查找并点击模块入口，
自适应不同页面布局（左侧菜单、顶部导航、卡片等）。
"""

import logging
from typing import Any, Optional

logger = logging.getLogger(__name__)


class ModuleNavigator:
    """
    智能模块导航器

    参考 AILoginHandler 实现逻辑：
    1. 构建自然语言导航指令（类似 _build_login_instruction）
    2. 使用 ai 流执行，由 Agent Planner + Actor 理解并执行
    3. 验证是否成功进入目标模块
    """

    def __init__(self):
        self.max_retries = 3

    async def navigate(
        self,
        ctx: Any,
        module_name: str,
        max_steps: int = 5,
    ) -> bool:
        """
        导航到指定模块

        Args:
            ctx: BrowserContext
            module_name: 模块名称（如"投放管理"、"模型体验"）
            max_steps: 最大尝试步数

        Returns:
            bool: 导航是否成功
        """
        logger.info("📍 导航到模块: %s", module_name)

        try:
            # Step 1: 使用 AI 执行导航（参考 ai_login：ai 指令 + Agent.run）
            success = await self._navigate_with_ai(ctx, module_name, max_steps)
            if not success:
                logger.warning("⚠️  AI 导航执行失败")
                return False

            # Step 2: 验证是否进入成功
            verified = await self._verify_module_entry(ctx, module_name)
            if verified:
                logger.info("✅ 成功进入模块: %s", module_name)
                return True
            else:
                logger.warning("⚠️  可能未正确进入模块")
                return False

        except Exception as e:
            logger.exception("❌ 导航失败: %s", e)
            return False

    def _build_navigate_instruction(self, module_name: str) -> str:
        """
        构建导航指令（参考 ai_login._build_login_instruction）

        描述模块入口可能位置，供 Agent 理解并执行查找+点击。
        """
        instructions = [
            f"在页面上找到【{module_name}】模块的入口",
            "入口可能位于：左侧菜单、顶部导航栏、卡片列表、页签或侧边栏",
            "点击该入口进入模块",
            "等待页面跳转完成",
        ]
        return "，".join(instructions)

    async def _navigate_with_ai(
        self,
        ctx: Any,
        module_name: str,
        max_steps: int = 5,
    ) -> bool:
        """
        使用 AI 执行模块导航，通过 agent_runner.run_ai_task 统一执行。
        target_url=None 表示在当前页执行（run_ai_task 内会取当前 URL）。
        """
        try:
            from .agent_runner import run_ai_task

            instruction = self._build_navigate_instruction(module_name)
            result = await run_ai_task(
                ctx,
                instruction=instruction,
                target_url=None,  # 当前页
                max_steps=max_steps,
                task_name="导航",
            )
            return result.success
        except Exception as e:
            logger.warning("⚠️  AI 导航执行失败: %s", e)
            return False

    async def _verify_module_entry(
        self,
        ctx: Any,
        module_name: str,
    ) -> bool:
        """
        验证是否成功进入模块

        检查：URL 变化、页面标题包含模块名；不确定时默认通过（参考 ai_login 避免阻塞）。
        """
        try:
            state = await ctx.get_state()
            if not state:
                logger.warning("⚠️  验证失败: 无法获取页面状态")
                return False

            current_url = getattr(state, "url", "") or ""
            title = getattr(state, "title", "") or ""

            # 简单验证：URL 或标题包含模块名（去除常见后缀）
            module_core = module_name.replace("管理", "").replace("模块", "").strip()
            url_match = (
                module_core
                and module_core.lower() in (current_url or "").lower()
            )
            title_match = module_name in title or (
                module_core and module_core in title
            )

            if url_match or title_match:
                return True

            # 不确定时默认认为成功（参考 ai_login 避免阻塞）
            logger.debug("🔍 模块验证不确定，默认通过: %s", module_name[:30])
            return True

        except Exception as e:
            logger.warning("⚠️  验证失败: %s", e)
            return True
