# -*- coding: utf-8 -*-
"""
前置步骤生成器：将用户自然语言输入转为「测试目标 + 有序可执行步骤」，由 AI 生成，不写死分类。

用于「用户输入不可控 → AI 可执行步骤和测试目标」方案。
"""

import importlib.resources
import json
import logging
import re
from dataclasses import dataclass
from typing import List, Optional, Tuple

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import HumanMessage, SystemMessage

logger = logging.getLogger(__name__)


@dataclass
class PreStepSpec:
    """单步前置规格：自然语言指令 + 可选目标 URL（无 step_type 分类）。"""

    instruction: str
    target_url: Optional[str] = None  # 为 None 表示在当前页执行
    go_after_instruction: bool = False  # True 表示先执行 ai 指令，再 goTo 到 target_url；默认 False 表示先 goTo 再 ai


async def user_input_to_steps(
    llm: BaseChatModel,
    user_input: str,
    url_hint: str = "",
) -> Tuple[str, List[PreStepSpec]]:
    """
    将用户原话通过 AI 转为测试目标 URL 与有序可执行步骤，不写死分类。

    Args:
        llm: 用于生成的 LLM
        user_input: 用户自然语言输入（不可控）
        url_hint: 调用方提供的默认 URL，供 LLM 参考

    Returns:
        (target_url, steps)：测试目标 URL 与 PreStepSpec 列表
    """
    if not user_input or not user_input.strip():
        return (url_hint or "", [])

    try:
        logger.info("【寻找测试目标】根据用户输入解析测试目标与前置步骤...")
        system_content = _load_prompt()
        user_content = (
            "用户输入：{input}\n\n"
            "若用户未提供 URL，可使用以下默认 URL：{hint}\n\n"
            "请输出合法 JSON：target_url 与 steps 数组（每步可含 instruction、可选 go_to_url、可选 go_after_instruction）。"
        ).format(input=user_input.strip(), hint=url_hint or "（无）")
        messages = [
            SystemMessage(content=system_content),
            HumanMessage(content=user_content),
        ]
        response = await llm.ainvoke(messages)
        content = response.content if hasattr(response, "content") else str(response)
        if isinstance(content, list):
            content = "".join(
                c.get("text", "") if isinstance(c, dict) else str(c) for c in content
            )
        if not isinstance(content, str):
            content = str(content)
        # 打印模型原始输出便于排查（过长则截断）
        raw_preview = content.strip()[:500] + ("..." if len(content.strip()) > 500 else "")
        logger.info("【寻找测试目标】模型输出: %s", raw_preview)
        logger.debug("【寻找测试目标】模型完整输出: %s", content)

        parsed = _parse_json(content)
        target_url = (parsed.get("target_url") or "").strip()
        if not target_url:
            target_url = url_hint or ""
        raw_steps = parsed.get("steps")
        if not isinstance(raw_steps, list):
            raw_steps = []
        steps = _steps_to_specs(raw_steps)
        steps_with_go = sum(
            1
            for s in steps
            if s.target_url
        )
        logger.info(
            "Pre-step AI: target_url=%s, steps_count=%d, 其中含 go_to_url 步数=%d",
            target_url or "(empty)",
            len(steps),
            steps_with_go,
        )
        return (target_url, steps)
    except Exception as e:
        logger.warning("Pre-step generation failed: %s. Returning url_hint and no steps.", e)
        return (url_hint or "", [])


def _steps_to_specs(raw_steps: list) -> List[PreStepSpec]:
    """将 steps 数组（元素可为字符串或 {instruction, go_to_url?, go_after_instruction?} 对象）转为 PreStepSpec 列表。"""
    specs: List[PreStepSpec] = []
    for s in raw_steps:
        if isinstance(s, str):
            instruction = s.strip()
            if instruction:
                specs.append(PreStepSpec(instruction=instruction, target_url=None))
        elif isinstance(s, dict):
            instruction = (s.get("instruction") or "").strip()
            if not instruction:
                continue
            go_to_url = s.get("go_to_url")
            if go_to_url is not None and not isinstance(go_to_url, str):
                go_to_url = str(go_to_url).strip() or None
            else:
                go_to_url = (go_to_url or "").strip() or None
            go_after = s.get("go_after_instruction", False)
            if isinstance(go_after, str):
                go_after = str(go_after).strip().lower() in ("true", "1", "yes")
            else:
                go_after = bool(go_after)
            specs.append(
                PreStepSpec(instruction=instruction, target_url=go_to_url, go_after_instruction=go_after)
            )
    return specs


def _load_prompt() -> str:
    with importlib.resources.files("browser_use.case_generator.prompts").joinpath(
        "pre_step_prompt.md"
    ).open("r", encoding="utf-8") as f:
        return f.read()


def _parse_json(content: str) -> dict:
    content = content.strip()
    match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", content)
    if match:
        content = match.group(1).strip()
    return json.loads(content)
