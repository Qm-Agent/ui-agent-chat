# -*- coding: utf-8 -*-
"""
自然语言意图解析：从用户输入中提取被测 URL 和模块名称。
用于「帮我测试某个模块」场景，支持 Planner + Actor 定位模块后再进行用例设计。
"""

import json
import logging
import re
from dataclasses import dataclass
from typing import Optional

from langchain_core.language_models import BaseChatModel
from langchain_core.messages import HumanMessage, SystemMessage

logger = logging.getLogger(__name__)


@dataclass
class ParsedIntent:
    """Parsed user intent from natural language. 用于多步骤前置：意图识别 → 步骤序列。"""

    url: str
    module_name: Optional[str] = None
    need_login: bool = False
    tenant: Optional[str] = None
    workspace: Optional[str] = None

    @property
    def has_module(self) -> bool:
        return bool(self.module_name and self.module_name.strip())

    @property
    def has_url(self) -> bool:
        return bool(self.url and self.url.strip())

    @property
    def has_tenant_or_workspace(self) -> bool:
        return bool(
            (self.tenant and self.tenant.strip())
            or (self.workspace and self.workspace.strip())
        )


class IntentParser:
    """Parse user natural language to extract url and module_name."""

    def __init__(self, llm: BaseChatModel):
        self.llm = llm

    async def parse(self, user_input: str) -> ParsedIntent:
        """
        Parse user input to extract url and module_name.
        Returns ParsedIntent. Empty strings if not found.
        """
        if not user_input or not user_input.strip():
            return ParsedIntent(url="", module_name=None)

        try:
            messages = [
                self._get_system_message(),
                HumanMessage(
                    content="用户输入：{input}\n\n输出 JSON，包含 url、module_name、need_login、tenant、workspace。".format(
                        input=user_input.strip()
                    )
                ),
            ]
            response = await self.llm.ainvoke(messages)
            content = response.content if hasattr(response, "content") else str(response)
            if isinstance(content, list):
                content = "".join(
                    c.get("text", "") if isinstance(c, dict) else str(c) for c in content
                )
            parsed = self._parse_json(content)
            url = (parsed.get("url") or "").strip()
            module_name = (parsed.get("module_name") or "").strip() or None
            need_login = bool(parsed.get("need_login", False))
            tenant = (parsed.get("tenant") or "").strip() or None
            workspace = (parsed.get("workspace") or "").strip() or None
            logger.info(
                "Parsed intent: url=%s, module_name=%s, need_login=%s, tenant=%s, workspace=%s",
                url or "(empty)",
                module_name or "(empty)",
                need_login,
                tenant or "(empty)",
                workspace or "(empty)",
            )
            return ParsedIntent(
                url=url,
                module_name=module_name,
                need_login=need_login,
                tenant=tenant,
                workspace=workspace,
            )
        except Exception as e:
            logger.warning("Intent parse failed: %s. Returning empty intent.", e)
            return ParsedIntent(url="", module_name=None)

    def _get_system_message(self) -> SystemMessage:
        try:
            import importlib.resources

            with importlib.resources.files("browser_use.case_generator.prompts").joinpath(
                "intent_parse_prompt.md"
            ).open("r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            raise RuntimeError(f"Failed to load intent_parse_prompt: {e}") from e
        return SystemMessage(content=content)

    def _parse_json(self, content: str) -> dict:
        content = content.strip()
        match = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", content)
        if match:
            content = match.group(1).strip()
        return json.loads(content)
