# -*- coding: utf-8 -*-
"""YAML generator for case generator."""

import logging
import re
from typing import Any, List, Optional

import yaml

from langchain_core.language_models import BaseChatModel

from browser_use.case_generator.models import StepDesign, TestCaseDesign
from browser_use.case_generator.prompts import YamlGenerationPrompt
logger = logging.getLogger(__name__)

def _is_variable_placeholder(value: str) -> bool:
    """判断是否为 ${VAR_NAME} 形式的占位符（与执行时替换逻辑一致）。"""
    if not value or not isinstance(value, str):
        return False
    return bool(re.match(r"^\s*\$\{\s*[a-zA-Z0-9_]+\s*\}\s*$", value.strip()))


def _pre_steps_to_flow(pre_steps: List[dict]) -> List[dict]:
    """
    将用户前序步骤（PreStepSpec 的 dict 形式）转为 flow 项列表。
    每步含 instruction、可选 target_url、可选 go_after_instruction。
    与 agent_runner.run_ai_task 中临时 YAML 的 goTo/ai 顺序一致。
    """
    flow: List[dict] = []
    for spec in pre_steps or []:
        if not isinstance(spec, dict):
            continue
        instruction = (spec.get("instruction") or "").strip()
        target_url = spec.get("target_url") or spec.get("go_to_url")
        if isinstance(target_url, str):
            target_url = target_url.strip() or None
        go_after = bool(spec.get("go_after_instruction", False))
        if go_after:
            if instruction:
                flow.append({"ai": instruction})
                flow.append({"aiWaitFor": "步骤完成"})
            if target_url:
                flow.append({"goTo": target_url})
                flow.append({"aiWaitFor": "页面加载成功"})
        else:
            if target_url:
                flow.append({"goTo": target_url})
                flow.append({"aiWaitFor": "页面加载成功"})
            if instruction:
                flow.append({"ai": instruction})
                flow.append({"aiWaitFor": "步骤完成"})
    return flow


class YamlGenerator:
    """Generates browser-use YAML from test case designs."""

    def __init__(self, llm: BaseChatModel):
        self.llm = llm

    def _build_pre_steps(
        self,
        login_record: Optional[Any] = None,
        target_module: Optional[str] = None,
        path_chain: Optional[List[str]] = None,
        credentials_for_yaml: Optional[dict] = None,
        pre_steps: Optional[List[dict]] = None,
    ) -> List[dict]:
        """构建前序步骤：用户前序步骤（pre_steps）或 登录 → 模块导航，再追加探索路径。
        若提供 pre_steps（user_input 解析出的步骤），优先用其生成 flow，再追加 path_chain；
        否则使用 login_record/target_module + path_chain。
        若提供 credentials_for_yaml：配置变量模式（${VAR}）则在 YAML 中写占位符，写死则写实际账号密码。
        """
        pre: List[dict] = []
        if pre_steps:
            pre.extend(_pre_steps_to_flow(pre_steps))
        else:
            if login_record:
                if credentials_for_yaml:
                    username = credentials_for_yaml.get("username", "")
                    password = credentials_for_yaml.get("password", "")
                    u = username if (username and _is_variable_placeholder(username)) else (username or "")
                    p = password if (password and _is_variable_placeholder(password)) else (password or "")
                    if u or p:
                        login_ai = f"打开登录页面，输入账号 {u} 密码 {p}，点击登录"
                    else:
                        login_ai = "打开登录页面，输入账号密码，点击登录"
                else:
                    login_ai = "打开登录页面，输入账号密码，点击登录"
                pre.append({"ai": login_ai})
                pre.append({"aiWaitFor": "登录完成，进入主页面"})
            if target_module:
                pre.append({"ai": f"找到并点击进入 {target_module}"})
                pre.append({"aiWaitFor": "进入模块页面"})
        path_chain = path_chain or []
        for seg in path_chain[1:]:
            if seg and seg != "root":
                pre.append({"aiTap": seg})
                pre.append({"aiWaitFor": "页面加载成功"})
        return pre

    async def generate(
        self,
        cases: List[TestCaseDesign],
        target_url: str,
        login_record: Optional[Any] = None,
        target_module: Optional[str] = None,
        credentials_for_yaml: Optional[dict] = None,
        pre_steps: Optional[List[dict]] = None,
    ) -> List[str]:
        """
        Generate YAML content for each case. Returns list of YAML strings.
        Falls back to programmatic generation if LLM output is invalid.
        credentials_for_yaml: 登录账号密码，用于在 YAML 中写入登录步骤。
        若为配置变量（如 {"username": "${LOGIN_USERNAME}", "password": "${LOGIN_PASSWORD}"}）则写占位符；
        若为写死则写实际值。与执行时 replace_variable_placeholders 一致。
        pre_steps: 用户前序步骤（如 user_input 解析出的 PreStepSpec 转 dict 列表），
        每项含 instruction、可选 target_url、可选 go_after_instruction；有则优先于 login_record 生成前序。
        """
        if not cases:
            return []

        logger.info("📄 [YamlGenerator] 开始生成 YAML...")
        logger.info("   📝 共 %d 个用例需要生成", len(cases))
        logger.info("   🔗 目标 URL: %s", target_url)

        messages = [
            YamlGenerationPrompt.get_system_message(),
            YamlGenerationPrompt.get_user_message(cases=cases, target_url=target_url),
        ]

        try:
            logger.info("   🤖 调用 LLM 生成 YAML...")
            response = await self.llm.ainvoke(messages)
            content = response.content if hasattr(response, "content") else str(response)
            if isinstance(content, list):
                content = "".join(
                    c.get("text", "") if isinstance(c, dict) else str(c) for c in content
                )

            docs = self._split_yaml_docs(content)
            logger.info("   ✅ LLM 生成 %d 个 YAML 文档", len(docs))

            if len(docs) >= len(cases):
                result = []
                for i, doc_str in enumerate(docs[: len(cases)]):
                    result.append(self._inject_pre_steps(
                        doc_str, cases[i],
                        login_record=login_record,
                        target_module=target_module,
                        credentials_for_yaml=credentials_for_yaml,
                        pre_steps=pre_steps,
                    ))
                return result

            # LLM 返回文档数少于用例数时：前 len(docs) 个注入前序步骤，其余用程序按 case 生成
            logger.info("   📎 LLM 返回 %d 个文档，不足 %d 个用例，已用程序生成补充 %d 个", len(docs), len(cases), len(cases) - len(docs))
            result = []
            for i in range(len(docs)):
                result.append(self._inject_pre_steps(
                    docs[i], cases[i],
                    login_record=login_record,
                    target_module=target_module,
                    credentials_for_yaml=credentials_for_yaml,
                    pre_steps=pre_steps,
                ))
            for i in range(len(docs), len(cases)):
                meta = getattr(cases[i], "metadata", None) or {}
                pc = meta.get("path_chain")
                if pc is None and meta.get("path") and meta.get("path") != "root":
                    pc = ["首页", meta.get("path")]
                result.append(self._design_to_yaml(
                    cases[i], target_url,
                    login_record=login_record,
                    target_module=target_module,
                    path_chain=pc,
                    credentials_for_yaml=credentials_for_yaml,
                    pre_steps=pre_steps,
                ))

            logger.info("   ✅ YAML 生成完成，共 %d 个文件", len(result))
            return result

        except Exception as e:
            logger.warning("   ⚠️ LLM YAML 生成失败，使用程序生成回退: %s", e)
            result = []
            for c in cases:
                meta = getattr(c, "metadata", None) or {}
                pc = meta.get("path_chain")
                if pc is None and meta.get("path") and meta.get("path") != "root":
                    pc = ["首页", meta.get("path")]
                result.append(self._design_to_yaml(
                    c, target_url,
                    login_record=login_record,
                    target_module=target_module,
                    path_chain=pc,
                    credentials_for_yaml=credentials_for_yaml,
                    pre_steps=pre_steps,
                ))
            logger.info("   ✅ 程序生成完成，共 %d 个 YAML 文件", len(result))
            return result

    def _inject_pre_steps(
        self,
        yaml_str: str,
        case: TestCaseDesign,
        login_record: Optional[Any] = None,
        target_module: Optional[str] = None,
        credentials_for_yaml: Optional[dict] = None,
        pre_steps: Optional[List[dict]] = None,
    ) -> str:
        """在 flow 开头注入前序步骤：用户前序步骤或 登录 → 模块导航 → 探索路径。"""
        meta = getattr(case, "metadata", None) or {}
        path_chain = meta.get("path_chain")
        if path_chain is None and meta.get("path") and meta.get("path") != "root":
            path_chain = ["首页", meta.get("path")]
        prefix = self._build_pre_steps(
            login_record=login_record,
            target_module=target_module,
            path_chain=path_chain,
            credentials_for_yaml=credentials_for_yaml,
            pre_steps=pre_steps,
        )
        if not prefix:
            return yaml_str
        try:
            # 只解析第一个 YAML 文档，避免 LLM 返回的多文档导致 safe_load 报错
            doc_to_parse = yaml_str
            if "\n---" in (yaml_str or ""):
                parts = re.split(r"\n---\s*\n", yaml_str, maxsplit=1)
                doc_to_parse = (parts[0] or "").strip()
                if not doc_to_parse:
                    return yaml_str
            data = yaml.safe_load(doc_to_parse)
            if not data or not isinstance(data, dict):
                return yaml_str
            # 兼容 LLM 返回 task 单数或 tasks 复数
            tasks_list = data.get("tasks")
            if not tasks_list and "task" in data:
                single = data.get("task")
                if isinstance(single, dict):
                    tasks_list = [single]
                elif isinstance(single, list):
                    tasks_list = single
            if not tasks_list:
                # 尝试顶层 flow（非标准但可注入后写回标准结构）
                top_flow = data.get("flow")
                if isinstance(top_flow, list):
                    data["tasks"] = [{"name": "task", "description": "", "flow": prefix + top_flow}]
                    if "target" not in data and "url" in data:
                        data["target"] = {"url": data.pop("url", "")}
                    return yaml.dump(data, allow_unicode=True, default_flow_style=False, sort_keys=False)
                logger.warning("   ⚠️ YAML 无 tasks/task/flow，无法注入前序步骤，用例可能无法直接执行")
                return yaml_str
            task = tasks_list[0] if isinstance(tasks_list[0], dict) else {}
            flow = task.get("flow", [])
            if not isinstance(flow, list):
                flow = []
            task["flow"] = prefix + flow
            if not data.get("tasks"):
                data["tasks"] = [task]
            return yaml.dump(data, allow_unicode=True, default_flow_style=False, sort_keys=False)
        except Exception as e:
            logger.warning("   ⚠️ 注入前序步骤失败，返回原 YAML: %s", e)
            return yaml_str

    def _split_yaml_docs(self, content: str) -> List[str]:
        """Split content by '---' into YAML documents. Extracts all ```yaml code blocks first if present."""
        content = content.strip()
        # 提取所有 markdown 代码块并合并（LLM 可能输出多个 ```yaml ... ``` 块，只取第一个会丢文档）
        code_blocks = re.findall(r"```(?:yaml|yml)?\s*([\s\S]*?)\s*```", content)
        if code_blocks:
            content = "\n---\n".join(
                b.strip()
                for b in code_blocks
                if b.strip()
            )
        elif "```" in content:
            match = re.search(r"```(?:yaml|yml)?\s*([\s\S]*?)\s*```", content)
            if match:
                content = match.group(1).strip()
        parts = re.split(r"\n---\s*\n", content)
        result = [
            p.strip()
            for p in parts
            if p.strip()
        ]
        # 若按 --- 只得到 1 个文档且 LLM 可能返回了「一个 target + 多个 tasks」的单个 YAML，再按 tasks 拆成多文档
        if len(result) == 1 and result[0]:
            expanded = self._split_single_doc_multi_tasks(result[0])
            if expanded:
                logger.info("   📎 检测到单文档多 tasks，已拆分为 %d 个 YAML 文档", len(expanded))
                result = expanded
        return result

    def _split_single_doc_multi_tasks(self, single_doc: str) -> Optional[List[str]]:
        """当 LLM 返回一个 YAML 但内含多个 tasks 时，拆成多个单 task 的 YAML 文档。若解析失败或非多 task 则返回 None。"""
        try:
            data = yaml.safe_load(single_doc)
            if not data or not isinstance(data, dict):
                return None
            tasks = data.get("tasks")
            if not tasks and "task" in data:
                t = data.get("task")
                tasks = [t] if isinstance(t, dict) else (t if isinstance(t, list) else None)
            if not tasks or not isinstance(tasks, list) or len(tasks) <= 1:
                return None
            target = data.get("target") or {}
            out = []
            for task in tasks:
                if not isinstance(task, dict):
                    continue
                doc = {"target": target, "tasks": [task]}
                out.append(yaml.dump(doc, allow_unicode=True, default_flow_style=False, sort_keys=False))
            return out if len(out) > 1 else None
        except Exception:
            return None

    def _design_to_yaml(
        self,
        case: TestCaseDesign,
        target_url: str,
        login_record: Optional[Any] = None,
        target_module: Optional[str] = None,
        path_chain: Optional[List[str]] = None,
        credentials_for_yaml: Optional[dict] = None,
        pre_steps: Optional[List[dict]] = None,
    ) -> str:
        """Convert a single TestCaseDesign to YAML programmatically."""
        flow: List[dict] = []

        # 前序步骤：用户前序或 登录 → 模块导航 → 探索路径
        pre = self._build_pre_steps(
            login_record=login_record,
            target_module=target_module,
            path_chain=path_chain,
            credentials_for_yaml=credentials_for_yaml,
            pre_steps=pre_steps,
        )
        flow.extend(pre)

        for step in sorted(case.steps, key=lambda s: s.order):
            flow.extend(self._step_to_flow(step))

        # Add validation points as aiAssert
        for vp in case.validation_points:
            flow.append({"aiAssert": vp.expected_description})

        # Ensure flow starts with aiWaitFor, not navigate（仅当尚未注入前置步骤时）
        if flow and self._is_navigate_step(flow[0]):
            flow.insert(0, {"aiWaitFor": "页面加载完成"})

        task = {
            "name": case.case_name,
            "description": case.description,
            "flow": flow,
        }

        doc = {
            "target": {"url": target_url},
            "tasks": [task],
        }
        return yaml.dump(doc, allow_unicode=True, default_flow_style=False, sort_keys=False)

    def _step_to_flow(self, step: StepDesign) -> List[dict]:
        """Convert a step design to flow items."""
        flow: List[dict] = []
        action = step.action_type.lower()
        target = step.target_description
        value = step.value

        if action == "wait":
            flow.append({"aiWaitFor": target or "页面加载完成"})
        elif action == "input":
            item: dict = {"aiInput": value or ""}
            if target:
                item["locate"] = target
            flow.append(item)
        elif action == "click":
            flow.append({"aiTap": target})
        elif action == "assert":
            flow.append({"aiAssert": target})
        elif action == "navigate":
            flow.append({"aiTap": target})
        elif action == "select":
            if value:
                flow.append({"aiInput": value, "locate": target})
            else:
                flow.append({"aiTap": target})
        elif action == "scroll":
            flow.append({"aiWaitFor": target or "滚动完成"})
        else:
            flow.append({"aiWaitFor": target or "操作完成"})
        return flow

    def _is_navigate_step(self, item: dict) -> bool:
        """Check if flow item is a navigate (goto) step."""
        if "go_to_url" in item or "goto" in str(item).lower():
            return True
        return False
