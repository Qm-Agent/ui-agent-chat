# -*- coding: utf-8 -*-
"""
用例设计角色：Web UI 测试工程师。
职责：理解页面含义，针对 Web 页面控件进行针对性测试，输出测试用例（前置执行步骤、操作步骤、测试数据、校验点），
并以表格 Markdown 形式存储到用户生成用例的本地目录。
"""

import json
import logging
import re
from pathlib import Path
from typing import List, Optional

from langchain_core.language_models import BaseChatModel

from browser_use.case_generator.models import PageAnalysisResult, StepDesign, TestCaseDesign
from browser_use.case_generator.prompts import CaseDesignPrompt
from browser_use.case_generator.utils import ainvoke_with_retry
from browser_use.agent.message_manager.utils import extract_json_from_model_output

logger = logging.getLogger(__name__)

# 角色定义：Web UI 测试工程师
CASE_DESIGNER_ROLE = (
    "你是 Web UI 测试工程师。理解页面含义，针对 Web 页面控件进行针对性测试，"
    "输出测试用例的前置执行步骤、操作步骤、测试数据、校验点。"
)


class CaseDesigner:
    """
    Web UI 测试工程师：设计测试用例。
    输出包含前置执行步骤、操作步骤、测试数据、校验点，支持 Markdown 表格导出。
    """

    def __init__(self, llm: BaseChatModel):
        self.llm = llm

    async def design(
        self,
        page_analysis: PageAnalysisResult,
        max_cases: int = 5,
        path: str = "",
        screenshot_base64: Optional[str] = None,
    ) -> List[TestCaseDesign]:
        """Design test cases from page analysis. Returns list of TestCaseDesign."""
        page_title = page_analysis.page_title if hasattr(page_analysis, 'page_title') else "Unknown"
        n_elements = len(page_analysis.actionable_elements) if hasattr(page_analysis, 'actionable_elements') else 0

        logger.info("🎨 [CaseDesigner] 开始用例设计...")
        logger.info("   📄 页面: %s", page_title)
        logger.info("   🔍 基于 %d 个可操作元素设计用例", n_elements)
        logger.info("   📝 最大用例数限制: %d", max_cases)
        logger.info("   🤖 调用 LLM 进行用例生成...")

        messages = [
            CaseDesignPrompt.get_system_message(),
            CaseDesignPrompt.get_user_message(page_analysis, max_cases=max_cases, screenshot_base64=screenshot_base64),
        ]

        logger.debug("   📝 CaseDesigner messages prepared, calling LLM...")

        try:
            # 使用带重试的 LLM 调用（参考 agent/service.py 模式）
            parsed = await ainvoke_with_retry(
                self.llm,
                messages,
                parsing_func=self._parse_json,
                max_retry=3,
            )
            logger.debug("   ✅ LLM response received, parsing cases...")
        except Exception as e:
            logger.error("   ❌ LLM call failed: %s", e)
            raise

        overall_design_reason = (
            (parsed.get("overall_design_reason") or parsed.get("总体用例设计原因") or "").strip()
            or "未返回总体设计原因"
        )
        logger.info("   📌 总体用例设计原因: %s", overall_design_reason)

        cases_data = parsed.get("cases", [])
        logger.debug("   📋 Raw cases data count: %d", len(cases_data))

        try:
            cases = [TestCaseDesign.from_dict(c) for c in cases_data]
            logger.debug("   ✅ Parsed %d TestCaseDesign objects", len(cases))
        except Exception as e:
            logger.error("   ❌ Failed to parse cases: %s", e)
            logger.debug("   📄 Raw data: %s", json.dumps(cases_data, ensure_ascii=False)[:500])
            raise

        case_names = [c.case_name for c in cases] if cases else []
        if case_names:
            logger.info("   📋 测试用例 list: %s", case_names)
        else:
            logger.info("   📋 测试用例 list: (空)")
            logger.info("   📌 未设计出用例，理由: %s", overall_design_reason)

        # 探索页面至少 1 个 case：若 LLM 返回 0 个，生成兜底用例（aiWaitFor 页面加载成功）
        if not cases:
            desc = f"验证页面加载成功（{path}）" if path else "验证页面加载成功"
            fallback_reason = f"总体: {overall_design_reason}; 程序兜底: 页面加载验证"
            fallback = TestCaseDesign(
                case_id="01",
                case_name="页面加载验证",
                description=desc,
                ui_type="page_load",
                preconditions=[],
                steps=[StepDesign(order=1, action_type="wait", target_description="页面加载成功", value=None)],
                test_data={},
                validation_points=[],
                generation_reason=fallback_reason,
            )
            cases = [fallback]
            logger.info("   📌 LLM 返回 0 个用例，已生成兜底用例: 页面加载验证 (aiWaitFor: 页面加载成功)")

        logger.info("   ✅ 用例设计完成，生成 %d 个用例", len(cases))

        # 记录用例摘要
        if cases:
            for case in cases:
                steps_count = len(case.steps) if hasattr(case, 'steps') else 0
                validation_count = len(case.validation_points) if hasattr(case, 'validation_points') else 0
                priority = case.priority if hasattr(case, 'priority') else '?'
                reason = getattr(case, "generation_reason", "") or ""
                logger.info("      [%s] %s (P%s, %d步, %d验证点)%s",
                    case.case_id, case.case_name, priority, steps_count, validation_count,
                    f" | 生成原因: {reason}" if reason else "")

        return cases

    def _parse_json(self, content: str) -> dict:
        """Extract JSON from LLM response (may be wrapped in markdown).

        复用 browser_use.agent.message_manager.utils.extract_json_from_model_output
        处理可能的 JSON 截断情况。
        """
        try:
            # 复用 Agent 模块的 JSON 提取函数
            return extract_json_from_model_output(content)
        except ValueError as e:
            logger.warning("Failed to parse case design JSON: %s. Raw: %s", e, content[:500])
            raise ValueError(f"Invalid JSON from case design: {e}") from e

    def _sanitize_json(self, content: str) -> str:
        """Fix common LLM JSON errors (e.g. JavaScript .repeat() in value)."""
        # Replace "x".repeat(N) with actual repeated string (max 200 chars for safety)
        def _replace_repeat(m):
            s, n = m.group(1), min(int(m.group(2)), 200)
            return json.dumps((s * n)[:n])

        content = re.sub(r'"([^"]*)"\.repeat\((\d+)\)', _replace_repeat, content)
        return content

    def _case_to_table_row(self, case: TestCaseDesign) -> tuple:
        """Convert a case to table row cells (preconditions, steps, test_data, validation)."""
        preconditions_str = "\n".join(f"{i+1}. {p}" for i, p in enumerate(case.preconditions)) if case.preconditions else "-"
        steps_str = "\n".join(
            f"{s.order}. {s.action_type}: {s.target_description}" + (f" = {s.value}" if s.value else "")
            for s in sorted(case.steps, key=lambda x: x.order)
        ) if case.steps else "-"
        test_data_str = "\n".join(f"{k}={v}" for k, v in case.test_data.items()) if case.test_data else "-"
        validation_str = "\n".join(
            f"{v.step_order}. {v.expected_description}"
            for v in sorted(case.validation_points, key=lambda x: x.step_order)
        ) if case.validation_points else "-"
        return preconditions_str, steps_str, test_data_str, validation_str

    def export_to_markdown_table(
        self,
        cases: List[TestCaseDesign],
        output_path: Path,
        page_title: str = "",
    ) -> Path:
        """
        将测试用例以 Markdown 表格形式导出到本地文件。
        表格列：用例ID、用例名称、前置执行步骤、操作步骤、测试数据、校验点、生成原因。
        """
        lines = [
            "# 测试用例设计表",
            "",
            f"**页面**: {page_title or '未知'}",
            "",
            "| 用例ID | 用例名称 | 前置执行步骤 | 操作步骤 | 测试数据 | 校验点 | 生成原因 |",
            "|--------|----------|--------------|----------|----------|--------|----------|",
        ]
        for case in cases:
            pre, steps, data, val = self._case_to_table_row(case)
            reason = getattr(case, "generation_reason", "") or "-"
            # Escape pipe and newline in cell content for markdown table
            def esc(s: str) -> str:
                return str(s).replace("|", "\\|").replace("\n", "<br>")
            pre_esc = esc(pre)
            steps_esc = esc(steps)
            data_esc = esc(data)
            val_esc = esc(val)
            reason_esc = esc(reason)
            lines.append(f"| {case.case_id} | {case.case_name} | {pre_esc} | {steps_esc} | {data_esc} | {val_esc} | {reason_esc} |")

        content = "\n".join(lines).strip()
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(content, encoding="utf-8")
        logger.info("Wrote markdown table: %s", output_path)
        return output_path
