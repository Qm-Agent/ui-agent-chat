# -*- coding: utf-8 -*-
"""
测试用例生成过程 HTML 报告：左侧平铺探索路径，右侧展示当前路径的探索前后截图、成功/失败、页面分析、生成用例。
"""

import html
import logging
from pathlib import Path
from typing import Any, List, Optional, Tuple

from browser_use.case_generator.report_context import (
    ExploreTaskRecord,
    LoginRecord,
    PageReportNode,
    ReportContext,
)

logger = logging.getLogger(__name__)

# 探索状态中文映射
STATUS_LABELS = {
    "success": "成功",
    "captcha_page": "验证码页面",
    "captcha_skip": "验证码跳过",
    "no_new_url": "未获取新 URL",
    "no_url_change": "同页操作（无新 URL）",
    "error": "异常",
}


def _escape(s: str) -> str:
    return html.escape(s) if s else ""


def _img_src(b64: Optional[str]) -> str:
    if not b64:
        return ""
    if b64.startswith("data:"):
        return b64
    return f"data:image/png;base64,{b64}"


class GenerationReportGenerator:
    """生成测试用例生成过程的 HTML 报告。"""

    def generate(self, ctx: ReportContext, run_dir: Path) -> Path:
        """
        生成 generation_report.html。
        输出路径：run_dir/reports/generation_report.html
        """
        reports_dir = run_dir / "reports"
        reports_dir.mkdir(parents=True, exist_ok=True)
        output_path = reports_dir / "generation_report.html"
        html_content = self._build_html(ctx)
        output_path.write_text(html_content, encoding="utf-8")
        logger.info("Generation report written: %s", output_path)
        return output_path

    def _build_html(self, ctx: ReportContext) -> str:
        sidebar_html = self._build_sidebar(ctx)
        panels_html = self._build_detail_panels(ctx)
        login_html = self._build_login_section(ctx.login_record)
        return self._html_template(sidebar_html, panels_html, login_html)

    def _collect_flat_paths(
        self, ctx: ReportContext
    ) -> List[Tuple[str, str, PageReportNode, Optional[ExploreTaskRecord]]]:
        """
        收集平铺的探索路径列表。
        Returns: [(path_display, panel_id, node, task), ...]
        - path_display: "首页" 或 "首页 → 新闻"
        - panel_id: 用于 DOM 切换
        - node: 页面节点（根页面或探索目标页）
        - task: 探索任务，根页面时为 None
        """
        flat: List[Tuple[str, str, PageReportNode, Optional[ExploreTaskRecord]]] = []
        panel_idx = [0]

        def collect(node: PageReportNode, parent_path: str = "") -> None:
            path_display = node.path if not parent_path else f"{parent_path} → {node.path}"
            # 根页面：添加入口页
            if not parent_path:
                pid = f"path-{panel_idx[0]}"
                panel_idx[0] += 1
                flat.append((path_display, pid, node, None))
            # 探索任务：从当前节点的 exploration_tasks 展开
            for t in node.exploration_tasks:
                task_path = f"{path_display} → {t.label}"
                pid = f"path-{panel_idx[0]}"
                panel_idx[0] += 1
                target_node = t.child_node if t.status == "success" and t.child_node else node
                flat.append((task_path, pid, target_node, t))
            # 递归子节点（处理子页面的探索任务）
            for c in node.children:
                collect(c, path_display)

        for root in ctx.nodes:
            collect(root, "")
        return flat

    def _build_sidebar(self, ctx: ReportContext) -> str:
        """构建左侧平铺探索路径列表。"""
        flat_paths = self._collect_flat_paths(ctx)
        parts: List[str] = []
        for path_display, pid, node, task in flat_paths:
            status_class = "path-ok"
            status_icon = "📄"
            if task:
                if task.status == "success":
                    status_class = "path-success"
                    status_icon = "✅"
                else:
                    status_class = "path-fail"
                    status_icon = "❌"
            else:
                if node.cases:
                    status_icon = "📋"
            badge = ""
            if node.cases and (not task or task.status == "success"):
                badge = f" <span class='path-badge'>({len(node.cases)} 用例)</span>"
            parts.append(
                f'<li class="path-item {status_class}" data-node-id="{pid}">'
                f'<span class="path-icon">{status_icon}</span>'
                f'<span class="path-label">{_escape(path_display)}{badge}</span></li>'
            )
        return "\n".join(parts)

    def _build_login_section(self, login_record: Optional[LoginRecord]) -> str:
        """构建登录区块：步骤 + 前后截图。"""
        if not login_record:
            return ""
        parts: List[str] = []
        parts.append("<section class='detail-section login-section'>")
        parts.append("<h3>🔐 登录步骤</h3>")
        parts.append(f"<p class='muted'>目标 URL: {_escape(login_record.url[:80])}{'...' if len(login_record.url) > 80 else ''}</p>")
        if login_record.steps:
            steps_li = "".join(f"<li>{_escape(s)}</li>" for s in login_record.steps)
            parts.append(f"<ol class='login-steps'>{steps_li}</ol>")
        status_cls = "success" if login_record.success else "fail"
        status_text = "成功" if login_record.success else "可能失败"
        parts.append(f"<p><span class='status-badge {status_cls}'>{status_text}</span></p>")
        parts.append("<div class='before-after'>")
        before_img = f'<img src="{_img_src(login_record.before_screenshot)}" alt="登录前" />' if login_record.before_screenshot else "<span class='muted'>无截图</span>"
        after_img = f'<img src="{_img_src(login_record.after_screenshot)}" alt="登录后" />' if login_record.after_screenshot else "<span class='muted'>无截图</span>"
        parts.append(f"<div class='ba-col'><p>登录前</p>{before_img}</div>")
        parts.append(f"<div class='ba-col'><p>登录后</p>{after_img}</div>")
        parts.append("</div>")
        parts.append("</section>")
        return "\n".join(parts)

    def _build_detail_panels(self, ctx: ReportContext) -> str:
        """按平铺路径顺序构建详情面板。"""
        flat_paths = self._collect_flat_paths(ctx)
        panels: List[str] = []
        for i, (path_display, pid, node, task) in enumerate(flat_paths):
            active = "active" if i == 0 else ""
            content = self._panel_content_for_path(path_display, node, task)
            panels.append(
                f'<div id="detail-{pid}" class="detail-panel {active}" data-node-id="{pid}">'
                f"{content}</div>"
            )
        return "\n".join(panels)

    def _panel_content_for_path(
        self,
        path_display: str,
        node: PageReportNode,
        task: Optional[ExploreTaskRecord],
    ) -> str:
        """为单个探索路径生成详情内容：当前路径、前后截图、成功/失败、页面分析、生成用例。"""
        sections: List[str] = []

        # 1. 当前探索路径 + 状态
        sections.append(
            f"<section class='detail-section path-header'>"
            f"<h2 class='path-title'>{_escape(path_display)}</h2>"
        )
        if task:
            status_cls = "success" if task.status == "success" else "fail"
            status_text = STATUS_LABELS.get(task.status, task.status)
            sections.append(
                f"<p><span class='status-badge {status_cls}'>{status_text}</span></p>"
            )
        else:
            sections.append("<p><span class='status-badge path-entry'>入口</span></p>")
        sections.append("</section>")

        # 2. 探索前后截图（探索任务有 before/after，根页面仅当前截图）
        if task:
            before_img = (
                f'<img src="{_img_src(task.before_screenshot)}" alt="探索前" />'
                if task.before_screenshot
                else "<span class='muted'>无</span>"
            )
            after_img = (
                f'<img src="{_img_src(task.after_screenshot)}" alt="探索后" />'
                if task.after_screenshot
                else "<span class='muted'>无</span>"
            )
            sections.append(
                "<section class='detail-section'><h3>探索前后截图</h3>"
                "<div class='before-after'>"
                f"<div class='ba-col'><p>探索前</p>{before_img}</div>"
                f"<div class='ba-col'><p>探索后</p>{after_img}</div>"
                "</div></section>"
            )
        else:
            if node.screenshot:
                src = _img_src(node.screenshot)
                sections.append(
                    f"<section class='detail-section'><h3>当前页面截图</h3>"
                    f"<div class='screenshot-wrap'>"
                    f"<img class='screenshot-img' src='{src}' alt='screenshot' /></div></section>"
                )
            else:
                sections.append(
                    "<section class='detail-section'><h3>当前页面截图</h3>"
                    "<p class='muted'>暂无截图</p></section>"
                )

        # 3. 页面分析结果
        analysis_node = node
        if analysis_node.analysis:
            a = analysis_node.analysis
            rows = [
                f"<tr><td>页面类型</td><td>{_escape(a.page_type)}</td></tr>",
                f"<tr><td>页面标题</td><td>{_escape(a.page_title)}</td></tr>",
                f"<tr><td>可操作元素数</td><td>{len(getattr(a, 'actionable_elements', []) or [])}</td></tr>",
                f"<tr><td>URL</td><td class='url'>{_escape(analysis_node.url[:120])}{'...' if len(analysis_node.url) > 120 else ''}</td></tr>",
            ]
            sections.append(
                "<section class='detail-section'><h3>页面分析结果</h3>"
                f"<table class='detail-table'><tbody>{''.join(rows)}</tbody></table></section>"
            )
        else:
            sections.append(
                "<section class='detail-section'><h3>页面分析结果</h3>"
                "<p class='muted'>暂无分析</p></section>"
            )

        # 4. 生成用例
        # 探索失败（验证码跳过、未获取新 URL 等）时，不展示父节点用例，应明确说明未生成
        if task and task.status != "success":
            skip_msg = STATUS_LABELS.get(task.status, task.status)
            sections.append(
                "<section class='detail-section'><h3>生成用例</h3>"
                f"<p class='muted'>探索因「{_escape(skip_msg)}」跳过，未进入目标页面，未生成用例。</p></section>"
            )
        elif node.cases:
            case_html_parts: List[str] = []
            for c in node.cases:
                name = getattr(c, "case_name", "") or ""
                desc = getattr(c, "description", "") or ""
                steps = getattr(c, "steps", []) or []
                validations = getattr(c, "validation_points", []) or []
                steps_li = "".join(
                    f"<li>{_escape(getattr(s, 'action_type', ''))}: {_escape(getattr(s, 'target_description', ''))}</li>"
                    for s in sorted(steps, key=lambda x: getattr(x, "order", 0))
                )
                valid_li = "".join(
                    f"<li>{_escape(getattr(v, 'validation_type', ''))}: {_escape(getattr(v, 'expected_description', ''))}</li>"
                    for v in validations
                )
                reason = getattr(c, "generation_reason", "") or ""
                reason_p = f"<p><strong>生成原因：</strong>{_escape(reason) if reason else '-'}</p>"
                case_html_parts.append(
                    f"<div class='case-card'><h4>{_escape(name)}</h4>"
                    f"<p>{_escape(desc)}</p>"
                    f"{reason_p}"
                    f"<p><strong>步骤：</strong></p><ol>{steps_li}</ol>"
                    f"<p><strong>验证点：</strong></p><ul>{valid_li}</ul></div>"
                )
            sections.append(
                "<section class='detail-section'><h3>生成用例</h3>"
                f"<div class='case-list'>{''.join(case_html_parts)}</div></section>"
            )
        else:
            sections.append(
                "<section class='detail-section'><h3>生成用例</h3>"
                "<p class='muted'>暂无用例</p></section>"
            )

        return "\n".join(sections)

    def _html_template(self, sidebar_items: str, detail_panels: str, login_html: str = "") -> str:
        return f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>测试用例生成过程报告</title>
    <style>
        :root {{
            --border: #e5e5e5;
            --bg: #f8f8f8;
            --text: #333;
            --muted: #666;
            --primary: #06b1ab;
            --success: #27ae60;
            --fail: #e74c3c;
            --warn: #f39c12;
        }}
        * {{ box-sizing: border-box; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif; font-size: 14px; color: var(--text); line-height: 1.6; margin: 0; min-height: 100vh; background: var(--bg); }}
        .layout {{ display: flex; width: 100%; min-height: 100vh; }}
        #sidebar {{ width: 240px; flex-shrink: 0; background: #fff; border-right: 1px solid var(--border); overflow-y: auto; }}
        .sidebar-header {{ padding: 16px; font-weight: bold; color: var(--primary); border-bottom: 1px solid var(--border); }}
        .path-item {{ padding: 10px 16px; cursor: pointer; list-style: none; display: flex; align-items: center; gap: 8px; border-bottom: 1px solid var(--border); }}
        .path-item:hover {{ background: var(--bg); }}
        .path-item.active {{ background: rgba(6,177,171,0.12); color: var(--primary); border-left: 3px solid var(--primary); margin-left: -1px; }}
        .path-icon {{ font-size: 14px; }}
        .path-label {{ flex: 1; word-break: break-word; }}
        .path-item.path-success .path-label {{ color: var(--success); }}
        .path-item.path-fail .path-label {{ color: var(--fail); }}
        .path-badge {{ font-size: 11px; color: var(--muted); margin-left: 4px; }}
        .path-title {{ font-size: 1.25rem; margin: 0 0 8px; }}
        .path-header {{ margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid var(--border); }}
        .status-badge.path-entry {{ background: #e8f4f8; color: var(--primary); }}
        #main {{ flex: 1; padding: 24px; overflow-y: auto; }}
        .detail-panel {{ display: none; }}
        .detail-panel.active {{ display: block; }}
        .detail-section {{ margin-bottom: 24px; }}
        .detail-section h3 {{ font-size: 1rem; margin: 16px 0 8px; padding-bottom: 6px; border-bottom: 1px solid var(--border); }}
        .screenshot-wrap {{ max-width: 100%; }}
        .screenshot-img {{ max-width: 100%; max-height: 400px; border-radius: 8px; cursor: pointer; border: 1px solid var(--border); }}
        .detail-table {{ border-collapse: collapse; width: 100%; background: #fff; border-radius: 8px; overflow: hidden; }}
        .detail-table th, .detail-table td {{ padding: 10px 12px; text-align: left; border-bottom: 1px solid var(--border); }}
        .detail-table th {{ background: var(--bg); font-weight: 600; }}
        .url {{ word-break: break-all; max-width: 500px; }}
        .case-card {{ background: #fff; border: 1px solid var(--border); border-radius: 8px; padding: 12px; margin: 8px 0; }}
        .case-list {{ display: flex; flex-direction: column; gap: 12px; }}
        .explore-task {{ background: #fff; border: 1px solid var(--border); border-radius: 8px; padding: 12px; margin: 12px 0; }}
        .explore-task.success {{ border-left: 4px solid var(--success); }}
        .explore-task.fail {{ border-left: 4px solid var(--fail); }}
        .status-badge {{ font-size: 12px; padding: 2px 8px; border-radius: 4px; margin-left: 8px; }}
        .status-badge.success {{ background: #d4edda; color: var(--success); }}
        .status-badge.fail {{ background: #f8d7da; color: var(--fail); }}
        .before-after {{ display: flex; gap: 24px; flex-wrap: wrap; }}
        .ba-col {{ flex: 1; min-width: 200px; }}
        .ba-col img {{ max-width: 100%; max-height: 300px; border-radius: 4px; border: 1px solid var(--border); cursor: pointer; }}
        .ba-col p {{ margin: 0 0 8px; font-weight: 600; color: var(--muted); }}
        .login-section {{ background: #fff; border: 1px solid var(--border); border-radius: 8px; padding: 16px; margin-bottom: 24px; }}
        .login-steps {{ margin: 8px 0; padding-left: 24px; }}
        .child-summary {{ margin-top: 12px; padding: 8px 12px; background: var(--bg); border-radius: 6px; font-size: 13px; }}
        .muted {{ color: var(--muted); font-style: italic; }}
    </style>
</head>
<body>
    <div class="layout">
        <aside id="sidebar">
            <div class="sidebar-header">探索路径</div>
            <ul class="path-list" style="list-style:none;padding:0;margin:0;">
                {sidebar_items}
            </ul>
        </aside>
        <main id="main">
            <h1>测试用例生成过程报告</h1>
            {login_html}
            {detail_panels}
        </main>
    </div>
    <script>
        (function() {{
            var items = document.querySelectorAll('.path-item[data-node-id]');
            var panels = document.querySelectorAll('.detail-panel');
            function show(nodeId) {{
                panels.forEach(function(p) {{ p.classList.remove('active'); }});
                items.forEach(function(i) {{ i.classList.remove('active'); }});
                var p = document.getElementById('detail-' + nodeId);
                var item = document.querySelector('.path-item[data-node-id="' + nodeId + '"]');
                if (p) p.classList.add('active');
                if (item) item.classList.add('active');
            }}
            items.forEach(function(item) {{
                item.addEventListener('click', function() {{
                    var id = this.getAttribute('data-node-id');
                    if (id) show(id);
                }});
            }});
            if (panels.length > 0) {{ var first = panels[0].getAttribute('data-node-id'); if (first) show(first); }}
        }})();
    </script>
</body>
</html>"""
