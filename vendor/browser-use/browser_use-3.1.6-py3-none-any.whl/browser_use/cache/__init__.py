"""Cache module for browser-use agent execution pipeline.

Provides two-level caching:
- L1 (RuntimeCache): In-memory state deduplication within a step
- L2 (ActionCacheManager): File-based command cache for replay across runs
"""

from browser_use.cache.action_cache import ActionCacheConfig, ActionCacheManager
from browser_use.cache.manager import CacheConfig, CacheManager, CacheStats
from browser_use.cache.runtime_cache import RuntimeCache, RuntimeCacheConfig

__all__ = [
    'CacheManager',
    'CacheConfig',
    'CacheStats',
    'RuntimeCache',
    'RuntimeCacheConfig',
    'ActionCacheManager',
    'ActionCacheConfig',
]
