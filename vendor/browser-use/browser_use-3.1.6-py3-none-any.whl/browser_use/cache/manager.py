"""CacheManager — unified L1+L2 cache coordinator."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

DEFAULT_CACHE_BLACKLIST = [
    'if',
    'jsCode',
    'upload',
    'aiAssert',
    'aiAssertText',
    'assertText',
    'aiQuery',
    'aiWaitFor',
    'waitForText',
    'toolCall',
    'pyCode',
    'sleep',
]


class RuntimeCacheConfig(BaseModel):
    """L1 runtime cache configuration."""
    dom_cache: bool = True
    screenshot_cache: bool = True
    smart_wait: bool = True
    ttl_seconds: float = 3.0


class ActionCacheConfig(BaseModel):
    """L2 command cache configuration."""
    auto_save: bool = True
    auto_lookup: bool = True
    ttl_days: int = 7


class CacheConfig(BaseModel):
    """Global cache configuration."""
    enabled: bool = False
    global_dir: str = '~/.browser-use/cache'
    blacklist: List[str] = Field(default_factory=lambda: list(DEFAULT_CACHE_BLACKLIST))
    runtime: RuntimeCacheConfig = RuntimeCacheConfig()
    action: ActionCacheConfig = ActionCacheConfig()


@dataclass
class CacheStats:
    """Cache hit/miss counters."""
    l1_hits: int = 0
    l1_misses: int = 0
    l2_hits: int = 0
    l2_misses: int = 0
    l2_saves: int = 0
    l2_evictions: int = 0
    smart_wait_skips: int = 0

    def to_dict(self) -> Dict[str, int]:
        return {
            'l1_hits': self.l1_hits,
            'l1_misses': self.l1_misses,
            'l2_hits': self.l2_hits,
            'l2_misses': self.l2_misses,
            'l2_saves': self.l2_saves,
            'l2_evictions': self.l2_evictions,
            'smart_wait_skips': self.smart_wait_skips,
        }


class CacheManager:
    """Unified coordinator for L1 (RuntimeCache) and L2 (ActionCacheManager)."""

    def __init__(self, config: CacheConfig) -> None:
        self.config = config
        self.stats = CacheStats()
        self.runtime: Optional[Any] = None  # RuntimeCache, set in initialize()
        self.actions: Optional[Any] = None  # ActionCacheManager, set in initialize()

    def initialize(self) -> None:
        """Create cache layers based on configuration."""
        if not self.config.enabled:
            logger.info('[Cache] Cache disabled by configuration')
            return

        try:
            from browser_use.cache.runtime_cache import RuntimeCache
            self.runtime = RuntimeCache(self.config.runtime)
            logger.info('[Cache] L1 runtime cache initialized')
        except Exception as e:
            logger.warning(f'[Cache] Failed to initialize L1 runtime cache: {e}')

        try:
            from browser_use.cache.action_cache import ActionCacheManager
            self.actions = ActionCacheManager(self.config.action, self.config.global_dir)
            self.actions.load_index()
            self.stats.l2_evictions += self.actions.last_cleanup_evicted
            logger.info('[Cache] L2 action cache initialized')
        except Exception as e:
            logger.warning(f'[Cache] Failed to initialize L2 action cache: {e}')

    def on_action_executed(self) -> None:
        """Mark L1 cache dirty after a browser action."""
        if self.runtime is not None:
            try:
                self.runtime.mark_dirty()
            except Exception as e:
                logger.warning(f'[Cache] Failed to mark dirty: {e}')

    def on_command_start(self, url: str, command_type: str, command_arg: str) -> Optional[List[Dict]]:
        """L2 lookup before command execution. Returns cached history items or None."""
        if self.actions is None or not self.config.enabled:
            return None
        if not self.config.action.auto_lookup:
            return None
        if command_type in self.config.blacklist:
            return None

        try:
            result = self.actions.lookup(url, command_type, command_arg)
            if result is not None:
                self.stats.l2_hits += 1
                logger.info(f'[L2 cache hit] {command_type}:{command_arg[:50]}')
                return result
            else:
                self.stats.l2_misses += 1
                return None
        except Exception as e:
            logger.warning(f'[Cache] L2 lookup failed: {e}')
            self.stats.l2_misses += 1
            return None

    def on_command_success(self, url: str, command_type: str, command_arg: str, history_items: List[Dict]) -> None:
        """L2 save after successful command execution."""
        if self.actions is None or not self.config.enabled:
            return
        if not self.config.action.auto_save:
            return
        if command_type in self.config.blacklist:
            return

        try:
            self.actions.save(url, command_type, command_arg, history_items)
            self.stats.l2_saves += 1
            logger.info(f'[L2 cache saved] {command_type}:{command_arg[:50]}')
        except Exception as e:
            logger.warning(f'[Cache] L2 save failed: {e}')

    def get_stats(self) -> Dict[str, int]:
        """Return all cache statistics."""
        return self.stats.to_dict()
