"""ActionCacheManager (L2) — file-based command cache for replay across runs."""

from __future__ import annotations

import hashlib
import json
import logging
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse

from pydantic import BaseModel

logger = logging.getLogger(__name__)


class ActionCacheConfig(BaseModel):
    """L2 command cache configuration."""
    auto_save: bool = True
    auto_lookup: bool = True
    ttl_days: int = 7


class ActionCacheManager:
    """File-based persistent cache for command-level operations."""

    def __init__(self, config: ActionCacheConfig, global_dir: str) -> None:
        self.config = config
        self.cache_dir = Path(os.path.expanduser(global_dir)) / 'actions'
        self._index: Dict[str, Dict[str, Any]] = {}
        self.last_cleanup_evicted: int = 0

    def load_index(self) -> None:
        """Load index from disk. Creates directories if needed. Runs proactive cleanup."""
        try:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
            index_path = self.cache_dir / 'index.json'
            if index_path.exists():
                with open(index_path, 'r', encoding='utf-8') as f:
                    self._index = json.load(f)
                logger.debug(f'[L2] Loaded index with {len(self._index)} entries')
            else:
                self._index = {}
            self.last_cleanup_evicted = self.cleanup_expired()
            self.cleanup_orphaned_files()
        except Exception as e:
            logger.warning(f'[L2] Failed to load index: {e}')
            self._index = {}

    def _save_index(self) -> None:
        """Persist index to disk."""
        try:
            index_path = self.cache_dir / 'index.json'
            with open(index_path, 'w', encoding='utf-8') as f:
                json.dump(self._index, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.warning(f'[L2] Failed to save index: {e}')

    @staticmethod
    def _cache_key(domain: str, path: str, command_type: str, command_arg: str) -> str:
        """Generate cache key: SHA-256(domain:path:type:arg)[:16]."""
        raw = f'{domain}:{path}:{command_type}:{command_arg}'
        return hashlib.sha256(raw.encode('utf-8')).hexdigest()[:16]

    def _parse_url(self, url: str) -> tuple:
        """Extract domain and path from URL."""
        parsed = urlparse(url)
        domain = parsed.netloc or parsed.hostname or ''
        path = parsed.path or '/'
        return domain, path

    def _is_expired(self, saved_at: str) -> bool:
        """Check if an entry has expired based on TTL."""
        try:
            saved_time = datetime.fromisoformat(saved_at)
            return datetime.now() - saved_time > timedelta(days=self.config.ttl_days)
        except (ValueError, TypeError):
            return True

    def lookup(self, url: str, command_type: str, command_arg: str) -> Optional[List[Dict]]:
        """Find cached actions for a command. Returns None on miss or TTL expiry."""
        try:
            domain, path = self._parse_url(url)
            key = self._cache_key(domain, path, command_type, command_arg)

            if key not in self._index:
                return None

            entry_meta = self._index[key]

            # Check TTL
            if self._is_expired(entry_meta.get('saved_at', '')):
                logger.debug(f'[L2] Cache entry expired for {command_type}:{command_arg[:50]}')
                # Evict expired entry
                self._evict(key)
                return None

            # Load cache file
            cache_file = self.cache_dir / f'{key}.json'
            if not cache_file.exists():
                # Index has entry but file is missing — clean up
                del self._index[key]
                self._save_index()
                return None

            with open(cache_file, 'r', encoding='utf-8') as f:
                cache_entry = json.load(f)

            # Update hit count
            cache_entry['hit_count'] = cache_entry.get('hit_count', 0) + 1
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache_entry, f, indent=2, ensure_ascii=False)

            history = cache_entry.get('history', [])
            if not history:
                return None

            hit_count = cache_entry['hit_count']
            logger.info(f'[L2 cache hit] {command_type}:{command_arg[:50]} (hits: {hit_count})')
            return history

        except Exception as e:
            logger.warning(f'[L2] Lookup failed for {command_type}:{command_arg[:50]}: {e}')
            return None

    def save(self, url: str, command_type: str, command_arg: str, history_items: List[Dict]) -> None:
        """Save successful command actions to cache.

        history_items format (matches execute_actions_in_cache input):
        [{"metadata": {...}, "result": [{"codified": {...}}]}]
        """
        try:
            # Only save items with valid codified data in result
            valid_items = [
                item for item in history_items
                if (item.get('result') and any(r.get('codified') for r in item['result']))
                or item.get('codified')
            ]
            if not valid_items:
                logger.debug(f'[L2] No codified data to save for {command_type}:{command_arg[:50]}')
                return

            domain, path = self._parse_url(url)
            key = self._cache_key(domain, path, command_type, command_arg)
            now = datetime.now().isoformat()

            cache_entry = {
                'domain': domain,
                'path': path,
                'url': url,
                'command_type': command_type,
                'command_arg': command_arg,
                'history': valid_items,
                'saved_at': now,
                'hit_count': 0,
            }

            # Write cache file
            cache_file = self.cache_dir / f'{key}.json'
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache_entry, f, indent=2, ensure_ascii=False)

            # Update index
            self._index[key] = {
                'domain': domain,
                'path': path,
                'command_type': command_type,
                'command_arg': command_arg[:80],
                'saved_at': now,
            }
            self._save_index()

        except Exception as e:
            logger.warning(f'[L2] Save failed for {command_type}:{command_arg[:50]}: {e}')

    def _evict(self, key: str) -> None:
        """Remove a cache entry by key."""
        try:
            cache_file = self.cache_dir / f'{key}.json'
            if cache_file.exists():
                cache_file.unlink()
            if key in self._index:
                del self._index[key]
            self._save_index()
        except Exception as e:
            logger.warning(f'[L2] Eviction failed for key {key}: {e}')

    def cleanup_expired(self) -> int:
        """Scan all index entries and evict expired ones. Returns count of evicted entries."""
        evicted = 0
        expired_keys = [
            key for key, meta in self._index.items()
            if self._is_expired(meta.get('saved_at', ''))
        ]
        for key in expired_keys:
            try:
                cache_file = self.cache_dir / f'{key}.json'
                if cache_file.exists():
                    cache_file.unlink()
                del self._index[key]
                evicted += 1
            except Exception as e:
                logger.warning(f'[L2] Failed to clean up expired entry {key}: {e}')
        if evicted > 0:
            self._save_index()
            logger.info(f'[L2] Cleaned up {evicted} expired cache entries')
        return evicted

    def cleanup_orphaned_files(self) -> int:
        """Remove .json files in cache dir that are not tracked in index. Returns count removed."""
        removed = 0
        try:
            for f in self.cache_dir.glob('*.json'):
                if f.name == 'index.json':
                    continue
                key = f.stem
                if key not in self._index:
                    try:
                        f.unlink()
                        removed += 1
                        logger.debug(f'[L2] Removed orphaned cache file: {f.name}')
                    except Exception as e:
                        logger.warning(f'[L2] Failed to remove orphaned file {f.name}: {e}')
            if removed > 0:
                logger.info(f'[L2] Removed {removed} orphaned cache files')
        except Exception as e:
            logger.warning(f'[L2] Orphan cleanup failed: {e}')
        return removed
