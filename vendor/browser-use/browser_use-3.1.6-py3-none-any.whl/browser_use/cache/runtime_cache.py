"""RuntimeCache (L1) — in-memory state cache for get_state() deduplication."""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from typing import TYPE_CHECKING, Dict, Optional

from browser_use.cache.manager import RuntimeCacheConfig

if TYPE_CHECKING:
    from browser_use.browser.views import BrowserState

logger = logging.getLogger(__name__)


@dataclass
class CachedState:
    """Cached browser state entry."""
    state: BrowserState
    timestamp: float
    url: str
    scroll_y: int


class RuntimeCache:
    """L1 in-memory cache for get_state() result deduplication and smart page-load wait."""

    def __init__(self, config: RuntimeCacheConfig) -> None:
        self.config = config
        self._state_cache: Dict[str, CachedState] = {}
        self._dirty: bool = True  # Start dirty — first call always fetches
        self._last_url: Optional[str] = None

    def _make_key(self, url: str, scroll_y: int) -> str:
        return f'{url}#{scroll_y}'

    def get_state(self, url: str, scroll_y: int) -> Optional[BrowserState]:
        """Return cached state if clean, key matches, and within TTL. Otherwise None."""
        if not self.config.dom_cache:
            return None

        if self._dirty:
            return None

        key = self._make_key(url, scroll_y)
        cached = self._state_cache.get(key)
        if cached is None:
            return None

        elapsed = time.time() - cached.timestamp
        if elapsed > self.config.ttl_seconds:
            del self._state_cache[key]
            return None

        logger.info(f'[L1 cache hit] state for {key}')
        return cached.state

    def put_state(self, url: str, scroll_y: int, state: BrowserState) -> None:
        """Store state in cache, clear dirty flag, update _last_url."""
        if not self.config.dom_cache:
            return

        key = self._make_key(url, scroll_y)
        self._state_cache[key] = CachedState(
            state=state,
            timestamp=time.time(),
            url=url,
            scroll_y=scroll_y,
        )
        self._dirty = False
        self._last_url = url

    def mark_dirty(self) -> None:
        """Mark cache dirty. Must be called after every browser action."""
        self._dirty = True

    def should_skip_page_wait(self, current_url: str) -> bool:
        """Return True if dirty=False and URL unchanged since last put_state().

        Note: _last_url is NOT updated here — only in put_state().
        """
        if not self.config.smart_wait:
            return False

        if self._dirty:
            return False

        if self._last_url is None:
            return False

        return self._last_url == current_url
