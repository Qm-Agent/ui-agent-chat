# -*- coding: utf-8 -*-
# Author: Yichen Lu
# Time: 2025/2/19

import argparse
import asyncio
import base64
import datetime as dt
import json
import logging
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any, Optional, Union

from langchain_core.messages import HumanMessage, SystemMessage
from omegaconf import DictConfig, ListConfig, OmegaConf
import yaml

from browser_use import Agent, Browser, BrowserConfig, project_root
from browser_use.agent.chat_models import build_models
from browser_use.agent.quick import (
    build_quick_sensitive_data as _build_quick_sensitive_data,
    extract_first_url as _extract_first_url,
    extract_inline_credentials as _extract_inline_credentials,
    prepare_quick_task,
    resolve_quick_url as _resolve_quick_url,
)
from browser_use.agent.tasks import Tasks
from browser_use.browser.context import (
    BrowserContext,
    BrowserContextConfig,
    BrowserContextWindowSize,
)
from browser_use.browser.profiles import get_browser_profile
from browser_use.logging_config import setup_logging


def get_args_parser(
    description: Optional[str] = None,
    add_help: bool = True,
) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=description,
        add_help=add_help,
    )
    parser.add_argument(
        "--task-file", required=True, metavar="FILE", help="任务配置文件的地址"
    )
    parser.add_argument(
        "--config-file",
        default=project_root / "static/configs/default.yaml",
        metavar="FILE",
        help="agent配置文件的地址，默认使用预设的default.yaml",
    )
    parser.add_argument(
        "--log-dir",
        default=f"logs/{dt.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}",
        type=str,
        help="日志目录，如果不存在会自动新建，新建的默认地址为当前目录下 logs/<当前系统时间>",
    )
    parser.add_argument(
        "--cache-path",
        default=None,
        type=str,
        metavar="FILE",
        help="缓存文件的地址，默认无缓存",
    )
    parser.add_argument(
        "opts",
        help="""
        Modify config options at the end of the command. For Yacs configs, use
        space-separated "PATH.KEY VALUE" pairs.
        For python-based LazyConfig, use "path.key=value".
        """.strip(),
        default=None,
        nargs=argparse.REMAINDER,
    )

    return parser


def before_launch() -> Union[DictConfig, ListConfig]:
    description = "Launch browser agent."

    args_parser = get_args_parser(description=description)
    args = args_parser.parse_args()

    Path(args.log_dir).mkdir(parents=True, exist_ok=True)

    args.opts = args.opts or []
    # Normalize "browser.headless false" -> "browser.headless=false" so OmegaConf sets boolean
    normalized = []
    i = 0
    while i < len(args.opts):
        o = args.opts[i]
        if (
            o == "browser.headless"
            and i + 1 < len(args.opts)
            and args.opts[i + 1] in ("true", "false")
        ):
            normalized.append(f"browser.headless={args.opts[i + 1]}")
            i += 2
            continue
        normalized.append(o)
        i += 1
    args.opts = normalized + [f"task_file={args.task_file}", f"log_dir={args.log_dir}"]
    if args.cache_path:
        args.opts += [f"cache_path={args.cache_path}"]
    default_cfg = OmegaConf.load(project_root / "static/configs/default.yaml")
    cfg = OmegaConf.load(args.config_file)
    cfg = OmegaConf.merge(default_cfg, cfg, OmegaConf.from_cli(args.opts))

    # 环境变量覆盖模型配置
    _env_overrides = [
        ("BU_ACTOR_MODEL", "models.actor"),
        ("BU_PLANNER_MODEL", "models.planner"),
        ("BU_ASSERTER_MODEL", "models.asserter"),
        ("BU_PAGE_EXTRACTION_LLM", "models.aux_llms.page_extraction_llm"),
        ("BU_LOCATING_LLM", "models.aux_llms.locating_llm"),
        ("BU_CODING_LLM", "models.aux_llms.coding_llm"),
    ]
    for env_key, cfg_path in _env_overrides:
        val = os.getenv(env_key) or os.getenv("BU_LLM_MODEL")
        if val:
            OmegaConf.update(cfg, cfg_path, val)

    with open(f"{args.log_dir}/agent_config.yaml", "w", encoding="utf-8") as file:
        OmegaConf.save(cfg, file)

    setup_logging()
    return cfg


def _parse_headless(value) -> bool:
    if isinstance(value, str):
        return value.lower() not in ("false", "0", "no")
    return bool(value)


def _load_agent_config(config_file: str, log_dir: str, opts: Optional[list[str]] = None):
    opts = opts or []
    default_cfg = OmegaConf.load(project_root / "static/configs/default.yaml")
    cfg = OmegaConf.load(config_file)
    cfg = OmegaConf.merge(default_cfg, cfg, OmegaConf.from_cli(opts))
    OmegaConf.update(cfg, "log_dir", log_dir)

    _env_overrides = [
        ("BU_ACTOR_MODEL", "models.actor"),
        ("BU_PLANNER_MODEL", "models.planner"),
        ("BU_ASSERTER_MODEL", "models.asserter"),
        ("BU_PAGE_EXTRACTION_LLM", "models.aux_llms.page_extraction_llm"),
        ("BU_LOCATING_LLM", "models.aux_llms.locating_llm"),
        ("BU_CODING_LLM", "models.aux_llms.coding_llm"),
    ]
    for env_key, cfg_path in _env_overrides:
        val = os.getenv(env_key) or os.getenv("BU_LLM_MODEL")
        if val:
            OmegaConf.update(cfg, cfg_path, val)

    return cfg


def _infer_headless_from_quick_text(text: str) -> Optional[bool]:
    if "有头模式" in text or "非无头" in text:
        return False
    if "无头模式" in text:
        return True
    return None


def _print_cdp_start_help(cdp_url: str, error: Optional[str] = None) -> None:
    if error:
        print(f"CDP browser is not available: {error}")
    else:
        print("CDP browser is not available.")
    print("")
    print("Start Google Chrome with remote debugging, then rerun the quick command:")
    print("")
    print('"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \\')
    print("  --remote-debugging-port=9222 \\")
    print("  '--remote-allow-origins=*' \\")
    print('  --user-data-dir="$HOME/.browser-use/cdp-chrome"')
    print("")
    print(f'export BU_LOCAL_BROWSER_CDP_URL="{cdp_url}"')
    print(f"curl {cdp_url.rstrip('/')}/json/version")
    print("")
    print("Log in manually in that Chrome window once; later quick runs will reuse it.")


def get_quick_args_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="browser-use quick task CLI")
    parser.add_argument("text", help="Natural language quick task text")
    parser.add_argument(
        "--config-file",
        default=str(project_root / "static/configs/default.yaml"),
        metavar="FILE",
        help="agent配置文件的地址",
    )
    parser.add_argument(
        "--log-dir",
        default=f"logs/{dt.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}",
        type=str,
        help="日志目录",
    )
    parser.add_argument("--cache-path", default=None, type=str, help="缓存文件地址")
    parser.add_argument(
        "--headless",
        default=None,
        choices=("true", "false"),
        help="Run browser headless. If omitted, quick infers from text or config.",
    )
    parser.add_argument(
        "--cdp-url",
        default=None,
        help="CDP URL. Defaults to BU_LOCAL_BROWSER_CDP_URL or http://127.0.0.1:9222",
    )
    cdp_group = parser.add_mutually_exclusive_group()
    cdp_group.add_argument(
        "--cdp",
        dest="use_cdp",
        action="store_true",
        help="Use an existing CDP browser. This is the default for quick tasks.",
    )
    cdp_group.add_argument(
        "--no-cdp",
        dest="use_cdp",
        action="store_false",
        help="Launch a fresh browser instead of attaching to an existing CDP browser.",
    )
    parser.set_defaults(use_cdp=True)
    parser.add_argument(
        "--react-mode",
        default="enhanced",
        choices=("enhanced", "legacy"),
        help="ReAct mode for quick tasks. Defaults to enhanced; legacy preserves the original prompt behavior.",
    )
    parser.add_argument(
        "--max-steps",
        type=int,
        default=None,
        help="Max aiReAct steps for quick tasks. If omitted, enhanced mode uses at least 16 steps.",
    )
    parser.add_argument(
        "--resume",
        action="store_true",
        help="Continue quick task on the current page instead of navigating to the resolved URL first.",
    )
    return parser


def get_observe_args_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="browser-use current page observe CLI")
    parser.add_argument(
        "--url",
        default=None,
        help="Optional URL to open before observing. Only supported in CDP mode.",
    )
    parser.add_argument(
        "--config-file",
        default=str(project_root / "static/configs/default.yaml"),
        metavar="FILE",
        help="agent配置文件的地址",
    )
    parser.add_argument(
        "--log-dir",
        default=f"logs/{dt.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}",
        type=str,
        help="日志目录",
    )
    parser.add_argument(
        "--cdp-url",
        default=None,
        help="CDP URL. Defaults to BU_LOCAL_BROWSER_CDP_URL or http://127.0.0.1:9222",
    )
    cdp_group = parser.add_mutually_exclusive_group()
    cdp_group.add_argument(
        "--cdp",
        dest="use_cdp",
        action="store_true",
        help="Observe the current page by attaching to an existing CDP browser. This is the default.",
    )
    cdp_group.add_argument(
        "--no-cdp",
        dest="use_cdp",
        action="store_false",
        help="Observe the last screenshot saved in the quick log dir instead of attaching to CDP.",
    )
    parser.set_defaults(use_cdp=True)
    parser.add_argument(
        "--output",
        default=None,
        help="Write observe JSON to this file. JSON is also printed to stdout.",
    )
    parser.add_argument(
        "--vision",
        default="true",
        choices=("true", "false"),
        help="Use page_extraction_llm to enrich control descriptions from screenshot.",
    )
    parser.add_argument(
        "--include-screenshot-base64",
        action="store_true",
        help="Include screenshot base64 in JSON output. By default only file paths are included.",
    )
    parser.add_argument(
        "--max-controls",
        type=int,
        default=80,
        help="Maximum interactive controls returned in the JSON output.",
    )
    return parser


def _apply_quick_react_mode_config(
    cfg: Union[DictConfig, ListConfig],
    react_mode: str,
    max_steps: Optional[int] = None,
) -> int:
    if max_steps is not None:
        effective_max_steps = max_steps
    elif react_mode == "enhanced":
        effective_max_steps = max(int(cfg.agent.max_steps), 16)
    else:
        effective_max_steps = int(cfg.agent.max_steps)

    OmegaConf.update(cfg, "agent.max_steps", effective_max_steps)
    return effective_max_steps


def _check_cdp_available(cdp_url: str) -> tuple[bool, Optional[str]]:
    version_url = f"{cdp_url.rstrip('/')}/json/version"
    try:
        with urllib.request.urlopen(version_url, timeout=2) as response:
            if response.status != 200:
                return False, f"{version_url} returned HTTP {response.status}"
            return True, None
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        return False, str(exc)


def _ensure_local_cdp_no_proxy(cdp_url: str) -> None:
    hostname = urllib.parse.urlparse(cdp_url).hostname
    if hostname not in {"127.0.0.1", "localhost", "::1"}:
        return

    required = ["127.0.0.1", "localhost", "::1"]
    for env_key in ("NO_PROXY", "no_proxy"):
        existing = os.environ.get(env_key, "")
        values = [v.strip() for v in existing.split(",") if v.strip()]
        changed = False
        for item in required:
            if item not in values:
                values.append(item)
                changed = True
        if changed or not existing:
            os.environ[env_key] = ",".join(values)


def _element_text(element: Any, max_len: int = 160) -> str:
    try:
        text = element.get_all_text_till_next_clickable_element()
    except Exception:
        text = ""
    text = re.sub(r"\s+", " ", text or "").strip()
    return text[:max_len]


def _element_label(element: Any) -> str:
    attrs = getattr(element, "attributes", {}) or {}
    candidates = [
        attrs.get("aria-label"),
        attrs.get("title"),
        attrs.get("placeholder"),
        attrs.get("name"),
        attrs.get("value"),
        _element_text(element),
    ]
    for item in candidates:
        if item:
            return str(item).strip()
    return ""


def _infer_control_role(element: Any) -> str:
    attrs = getattr(element, "attributes", {}) or {}
    tag = (getattr(element, "tag_name", "") or "").lower()
    role = (attrs.get("role") or "").lower()
    input_type = (attrs.get("type") or "").lower()

    if role:
        return role
    if tag == "a":
        return "link"
    if tag == "button" or input_type in {"button", "submit", "reset"}:
        return "button"
    if input_type in {"checkbox", "radio"}:
        return input_type
    if tag in {"input", "textarea"}:
        return "textbox"
    if tag == "select":
        return "combobox"
    return tag or "control"


def _normalize_observe_box(rectangle: Optional[dict], height: int, width: int) -> Optional[list[int]]:
    if not rectangle or not height or not width:
        return None
    try:
        top = int(round(float(rectangle["top"]) / height * 1000))
        left = int(round(float(rectangle["left"]) / width * 1000))
        bottom = int(round(float(rectangle["bottom"]) / height * 1000))
        right = int(round(float(rectangle["right"]) / width * 1000))
    except (KeyError, TypeError, ValueError):
        return None
    return [top, left, bottom, right]


def _position_hint(rectangle: Optional[dict], height: int, width: int) -> str:
    box = _normalize_observe_box(rectangle, height, width)
    if not box:
        return "unknown"
    top, left, bottom, right = box
    center_y = (top + bottom) / 2
    center_x = (left + right) / 2
    vertical = "top" if center_y < 333 else "bottom" if center_y > 667 else "middle"
    horizontal = "left" if center_x < 333 else "right" if center_x > 667 else "center"
    return f"{vertical}-{horizontal}"


def _observe_control_name(control: dict[str, Any]) -> str:
    label = str(control.get("label") or "").strip()
    if label:
        return label
    text = str(control.get("text") or "").strip()
    if text:
        return text
    attrs = control.get("attributes") or {}
    for key in ("aria-label", "title", "placeholder", "name", "value"):
        value = str(attrs.get(key) or "").strip()
        if value:
            return value
    return ""


def _infer_observe_purpose(control: dict[str, Any]) -> tuple[str, list[str], str]:
    name = _observe_control_name(control)
    name_lower = name.lower()
    role = str(control.get("role") or "").lower()
    tag = str(control.get("tag") or "").lower()
    attrs = control.get("attributes") or {}
    input_type = str(attrs.get("type") or "").lower()
    action_like = role in {"button", "link", "img"} or tag in {"button", "a"} or input_type in {"button", "submit"}

    if role == "textbox" or tag in {"input", "textarea"}:
        if any(token in name_lower for token in ("搜索", "search")):
            return (
                "输入搜索关键词或筛选条件。",
                [f"输入目标关键词后提交或等待列表过滤"],
                "文本输入控件，可用于搜索或筛选。",
            )
        if any(token in name_lower for token in ("密码", "password")) or input_type == "password":
            return (
                "输入密码等敏感凭据。",
                ["使用 ${PASSWORD} 等标准敏感占位符输入"],
                "密码输入控件，页面可能会以掩码显示真实值。",
            )
        if any(token in name_lower for token in ("url", "链接", "网址")):
            return (
                "输入 URL 或链接地址。",
                ["输入目标 URL 后点击完成、确定或提交按钮"],
                "URL 输入控件，通常需要配合提交按钮生效。",
            )
        return (
            "输入文本内容。",
            [f"在该输入框中填写 {name}" if name else "在该输入框中填写任务所需文本"],
            "文本输入控件。",
        )

    if role in {"checkbox", "switch"} or input_type == "checkbox":
        return (
            "切换开关或勾选状态。",
            ["点击切换选中状态"],
            "二态配置控件，点击后通常改变后续行为。",
        )
    if role == "radio" or input_type == "radio":
        return (
            "选择互斥选项。",
            ["点击选择该选项"],
            "单选控件，同组选项通常只能选择一个。",
        )
    if role == "combobox" or tag == "select":
        return (
            "展开并选择下拉选项。",
            ["点击打开下拉菜单并选择目标项"],
            "下拉选择控件。",
        )
    if role == "link" or tag == "a":
        return (
            "跳转到相关页面或资源。",
            ["点击打开链接"],
            "链接控件，点击后通常发生页面跳转。",
        )

    primary_action_tokens = ("新建", "新增", "添加", "导入", "上传", "完成", "确定", "提交", "发送")
    destructive_tokens = ("取消", "关闭", "返回", "删除")
    if action_like and (any(token in name for token in primary_action_tokens) or any(
        token in name_lower for token in ("new", "create", "add", "import", "upload", "submit", "send", "ok")
    )):
        return (
            f"执行“{name}”操作。",
            [f"点击“{name}”推进任务"],
            "任务相关主操作控件，通常用于创建、提交、导入或发送。",
        )
    if action_like and (any(token in name for token in destructive_tokens) or any(
        token in name_lower for token in ("cancel", "close", "back", "delete", "remove")
    )):
        return (
            f"执行“{name}”操作。",
            [f"仅在需要退出、关闭或删除时点击“{name}”"],
            "可能会取消、关闭或删除内容，执行前需要确认任务意图。",
        )
    if any(token in name_lower for token in ("ellipsis", "more", "menu")) or "更多" in name:
        return (
            "打开更多操作菜单。",
            ["点击展开更多操作，再选择具体命令"],
            "更多菜单入口，通常包含编辑、删除、配置等二级操作。",
        )
    if any(token in name_lower for token in ("plus", "+")):
        return (
            "新增或展开创建入口。",
            ["点击打开新增流程"],
            "加号入口，通常用于新建内容。",
        )

    if name and role in {"div", "span"}:
        return (
            f"查看或选择“{name}”对应的页面条目。",
            [f"如果任务目标是该条目，可点击或检查“{name}”"],
            "列表、卡片或文本区域中的可交互条目。",
        )

    return (
        f"与“{name}”相关的页面控件。" if name else "页面可交互控件。",
        [f"根据任务需要点击或检查“{name}”"] if name else ["根据任务需要点击或检查该控件"],
        "可交互控件，具体效果需结合页面上下文判断。",
    )


def _add_observe_baseline_enrichment(control: dict[str, Any]) -> dict[str, Any]:
    name = _observe_control_name(control)
    role = control.get("role") or "control"
    position = control.get("position_hint") or "unknown"
    box = control.get("box_2d_tlbr")
    purpose, suggested_actions, state_hint = _infer_observe_purpose(control)

    control_type = role if role and role != "span" else control.get("tag") or "control"
    description = f"{position} 区域的 {control_type} 控件"
    if name:
        description += f"，文本/标签为“{name}”"
    if box:
        description += f"，归一化坐标 {box}"
    control["visual_description"] = description + "。"
    control["purpose"] = purpose
    control["state_hint"] = state_hint
    control["suggested_actions"] = suggested_actions
    control["confidence"] = 0.55 if name else 0.35
    control["enrichment_source"] = "dom_heuristic"
    return control


def _build_observe_page_understanding(
    *,
    url: str,
    title: str,
    controls: list[dict[str, Any]],
    viewport: dict[str, Any],
) -> dict[str, Any]:
    visible_controls = [c for c in controls if c.get("is_in_viewport")]
    source_controls = visible_controls or controls
    position_counts: dict[str, int] = {}
    role_counts: dict[str, int] = {}
    action_names: list[str] = []
    input_names: list[str] = []
    nav_names: list[str] = []
    key_visible_texts: list[str] = []

    for control in source_controls:
        position = str(control.get("position_hint") or "unknown")
        role = str(control.get("role") or "control")
        name = _observe_control_name(control)
        compact_name = re.sub(r"\s+", "", name)
        looks_like_action_text = (
            len(compact_name) <= 16
            and (
                compact_name.startswith(("新建", "新增", "创建", "导入", "上传", "发送", "提交", "确定", "保存"))
                or compact_name in {"完成", "取消", "关闭", "返回"}
            )
        )
        position_counts[position] = position_counts.get(position, 0) + 1
        role_counts[role] = role_counts.get(role, 0) + 1
        if role in {"textbox", "combobox"} and name:
            input_names.append(name)
        elif (role in {"button", "checkbox", "switch"} or looks_like_action_text) and name:
            action_names.append(name)
        elif (
            role == "link"
            or any(token in name for token in ("知识问答", "原始数据", "知识加工", "数据看板", "知识管理", "系统设置"))
        ) and name:
            nav_names.append(name)
        if name:
            key_visible_texts.append(name)

    def _unique_limited(items: list[str], limit: int = 8) -> list[str]:
        seen: set[str] = set()
        result: list[str] = []
        for item in items:
            cleaned = re.sub(r"\s+", " ", item).strip()
            if not cleaned or cleaned in seen:
                continue
            seen.add(cleaned)
            result.append(cleaned)
            if len(result) >= limit:
                break
        return result

    action_names = _unique_limited(action_names)
    input_names = _unique_limited(input_names)
    nav_names = _unique_limited(nav_names)
    key_visible_texts = _unique_limited(key_visible_texts, 12)
    dominant_positions = [
        item[0]
        for item in sorted(position_counts.items(), key=lambda item: item[1], reverse=True)
        if item[0] != "unknown"
    ][:4]
    dominant_roles = [
        f"{role}:{count}"
        for role, count in sorted(role_counts.items(), key=lambda item: item[1], reverse=True)[:5]
    ]

    page_name = title or urllib.parse.urlparse(url).netloc or "当前页面"
    page_title_text = f"{title} {' '.join(key_visible_texts)}"
    if any(token in page_title_text for token in ("原始数据", "文件库", "知识库", "导入")):
        page_function_guess = "这是知识工程的原始数据/知识库管理页面，核心目标通常是查看、新建、导入或管理文件库与数据源。"
    elif any(token in page_title_text for token in ("知识问答", "问答", "对话")):
        page_function_guess = "这是知识问答或对话测试页面，核心目标通常是输入问题、发送请求并校验模型回答。"
    elif any(token in page_title_text for token in ("知识加工", "加工")):
        page_function_guess = "这是知识加工页面，核心目标通常是处理、转换或配置知识内容。"
    elif any(token in page_title_text for token in ("数据看板", "看板")):
        page_function_guess = "这是数据看板页面，核心目标通常是查看指标、任务状态或统计结果。"
    else:
        page_function_guess = "这是一个业务 Web 页面，核心功能需要结合当前可见控件和任务目标判断。"
    primary_regions: list[str] = []
    if any(position.startswith("top") for position in position_counts):
        primary_regions.append("顶部区域包含页面导航、筛选或主要入口。")
    if any("left" in position for position in position_counts):
        primary_regions.append("左侧区域包含导航菜单、分类或列表入口。")
    if any("center" in position or "middle" in position for position in position_counts):
        primary_regions.append("中部区域是主要内容与任务操作区。")
    if any("right" in position for position in position_counts):
        primary_regions.append("右侧区域包含辅助操作、详情或工具入口。")
    if any(position.startswith("bottom") for position in position_counts):
        primary_regions.append("底部区域可能包含提交、确认、分页或固定操作栏。")
    if not primary_regions:
        primary_regions.append("页面当前可见区域存在少量可交互控件，布局需要结合截图进一步判断。")

    functionality_parts = []
    if nav_names:
        functionality_parts.append(f"可通过链接/导航进入：{'、'.join(nav_names[:5])}")
    if action_names:
        functionality_parts.append(f"主要可执行操作包括：{'、'.join(action_names[:6])}")
    if input_names:
        functionality_parts.append(f"可填写或筛选的输入项包括：{'、'.join(input_names[:5])}")
    functionality = page_function_guess
    if functionality_parts:
        functionality += " " + "；".join(functionality_parts) + "。"

    suggested_next_steps = []
    if input_names:
        suggested_next_steps.append(f"如任务需要输入信息，优先定位并填写“{input_names[0]}”。")
    if action_names:
        suggested_next_steps.append(f"如任务需要推进流程，优先确认“{action_names[0]}”是否是当前主操作。")
    if nav_names:
        suggested_next_steps.append(f"如当前页面不是目标功能页，可从“{nav_names[0]}”等导航入口切换。")
    if not suggested_next_steps:
        suggested_next_steps.append("结合任务目标选择页面中最相关的可交互控件继续操作。")

    return {
        "page_description": f"当前页面为“{page_name}”，URL 为 {url or 'unknown'}。",
        "functionality": functionality,
        "layout": (
            f"视口大小 {viewport.get('width')}x{viewport.get('height')}，"
            f"当前返回 {len(controls)} 个控件，主要分布在 {', '.join(dominant_positions) or 'unknown'} 区域，"
            f"控件类型分布为 {', '.join(dominant_roles) or 'unknown'}。"
        ),
        "key_visible_texts": key_visible_texts,
        "primary_regions": primary_regions,
        "suggested_next_steps": suggested_next_steps,
        "confidence": 0.55 if controls else 0.25,
        "enrichment_source": "dom_heuristic",
    }


def _build_observe_dom_controls(state: Any, max_controls: int = 80) -> list[dict[str, Any]]:
    controls: list[dict[str, Any]] = []
    selector_items = sorted((state.selector_map or {}).items(), key=lambda item: item[0])
    page_height = int(getattr(state, "page_height", 0) or 0)
    page_width = int(getattr(state, "page_width", 0) or 0)

    for index, element in selector_items[:max_controls]:
        attrs = getattr(element, "attributes", {}) or {}
        rectangle = getattr(element, "rectangle", None)
        label = _element_label(element)
        role = _infer_control_role(element)
        control = {
            "id": index,
            "tag": getattr(element, "tag_name", "") or "",
            "role": role,
            "label": label,
            "text": _element_text(element),
            "attributes": {
                key: attrs.get(key)
                for key in ("aria-label", "title", "placeholder", "name", "type", "value", "role")
                if attrs.get(key)
            },
            "is_interactive": bool(getattr(element, "is_interactive", False)),
            "is_in_viewport": bool(getattr(element, "is_in_viewport", False)),
            "position_hint": _position_hint(rectangle, page_height, page_width),
            "box_2d_tlbr": _normalize_observe_box(rectangle, page_height, page_width),
            "rectangle": rectangle,
            "dom_description": (
                f"{role} {label}".strip()
                or f"{getattr(element, 'tag_name', '')} control".strip()
            ),
        }
        _add_observe_baseline_enrichment(control)
        controls.append(control)

    return controls


def _message_content_to_text(response: Any) -> str:
    content = response.content if hasattr(response, "content") else response
    if isinstance(content, list):
        return "".join(
            item.get("text", "") if isinstance(item, dict) else str(item)
            for item in content
        )
    return str(content)


def _parse_json_object(content: str) -> dict[str, Any]:
    text = content.strip()
    fenced = re.search(r"```(?:json)?\s*([\s\S]*?)\s*```", text)
    if fenced:
        text = fenced.group(1).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start = text.find("{")
        end = text.rfind("}")
        if start >= 0 and end > start:
            return json.loads(text[start : end + 1])
        raise


async def _enrich_observe_controls_with_vision(
    llm: Any,
    controls: list[dict[str, Any]],
    screenshot_base64: Optional[str],
    url: str,
    title: str,
    max_controls: int,
) -> dict[str, Any]:
    if not llm or not screenshot_base64:
        return {"controls": {}, "page_understanding": {}}

    compact_controls = [
        {
            "id": c["id"],
            "tag": c["tag"],
            "role": c["role"],
            "label": c["label"],
            "text": c["text"],
            "position_hint": c["position_hint"],
            "box_2d_tlbr": c["box_2d_tlbr"],
        }
        for c in controls[:max_controls]
    ]
    system = SystemMessage(
        content=(
            "You are a UI test page observer. Analyze the screenshot and DOM control list. "
            "Return JSON only. First summarize the whole page: its overall function, layout, "
            "major regions, and useful next-step hints for a test agent. Then, for each "
            "visible/actionable control, describe what it visually is, what action it likely "
            "performs, and any state hint useful for a test agent. "
            "Prefer concise Chinese descriptions when the page text is Chinese. "
            "If many controls are similar, enrich the most task-relevant controls and omit low-value duplicates."
        )
    )
    user = HumanMessage(
        content=[
            {
                "type": "text",
                "text": (
                    f"URL: {url}\nTitle: {title}\n"
                    "DOM controls JSON:\n"
                    f"{json.dumps(compact_controls, ensure_ascii=False)}\n\n"
                    "Return schema: {\"page_understanding\":{"
                    "\"page_description\":string,\"functionality\":string,"
                    "\"layout\":string,\"key_visible_texts\":[string],\"primary_regions\":[string],"
                    "\"suggested_next_steps\":[string],\"confidence\":0-1},"
                    "\"controls\":[{\"id\":number,"
                    "\"visual_description\":string,\"purpose\":string,"
                    "\"state_hint\":string,\"suggested_actions\":[string],"
                    "\"confidence\":0-1}]}"
                ),
            },
            {
                "type": "image_url",
                "image_url": {"url": f"data:image/png;base64,{screenshot_base64}"},
            },
        ]
    )
    response = await llm.ainvoke([system, user])
    parsed = _parse_json_object(_message_content_to_text(response))
    enriched: dict[int, dict[str, Any]] = {}
    for item in parsed.get("controls", []):
        if not isinstance(item, dict):
            continue
        try:
            control_id = int(item.get("id"))
        except (TypeError, ValueError):
            continue
        values = {
            key: item.get(key)
            for key in (
                "visual_description",
                "purpose",
                "state_hint",
                "suggested_actions",
                "confidence",
            )
            if key in item and item.get(key) not in (None, "", [])
        }
        if values:
            values["enrichment_source"] = "vision_llm"
        enriched[control_id] = values
    page_values: dict[str, Any] = {}
    page_understanding = parsed.get("page_understanding")
    if isinstance(page_understanding, dict):
        page_values = {
            key: page_understanding.get(key)
            for key in (
                "page_description",
                "functionality",
                "layout",
                "key_visible_texts",
                "primary_regions",
                "suggested_next_steps",
                "confidence",
            )
            if key in page_understanding and page_understanding.get(key) not in (None, "", [])
        }
        if page_values:
            page_values["enrichment_source"] = "vision_llm"
    return {"controls": enriched, "page_understanding": page_values}


def _write_screenshot(path: Path, screenshot_base64: Optional[str]) -> Optional[str]:
    if not screenshot_base64:
        return None
    path.write_bytes(base64.b64decode(screenshot_base64))
    return str(path)


def _default_observe_result_path(log_dir: str) -> Path:
    return Path(log_dir) / "quick_task_result.json"


def _load_last_observe_history_state(result_path: Union[str, Path]) -> dict[str, Any]:
    path = Path(result_path)
    if not path.exists():
        raise ValueError(f"Observe history result file not found: {path}")

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ValueError(f"Observe history result file is not valid JSON: {path}") from exc

    history = data.get("history")
    if not isinstance(history, list) or not history:
        raise ValueError(f"Observe history result has no history items: {path}")

    for item in reversed(history):
        if not isinstance(item, dict):
            continue
        state = item.get("state")
        if isinstance(state, dict) and state.get("screenshot"):
            return state

    raise ValueError(f"Observe history result has no state screenshot: {path}")


def _build_history_screenshot_page_understanding(
    *,
    url: str,
    title: str,
) -> dict[str, Any]:
    page_name = title or urllib.parse.urlparse(url).netloc or "当前页面"
    return {
        "page_description": f"当前页面为“{page_name}”，URL 为 {url or 'unknown'}。",
        "functionality": "这是从非 CDP quick 执行历史中恢复的最后页面截图；可用于判断页面当前视觉状态，但不包含实时 DOM 控件映射。",
        "layout": "非 CDP history 截图不包含视口尺寸、滚动位置或 DOM 控件分布。",
        "key_visible_texts": [],
        "primary_regions": ["请结合截图判断页面主要区域和下一步操作。"],
        "suggested_next_steps": ["根据截图改写后续 quick 任务；如需要控件 id 和 DOM 坐标，请使用 CDP 模式 observe。"],
        "confidence": 0.35,
        "enrichment_source": "history_screenshot",
    }


def _build_history_screenshot_observe_result(
    *,
    state: dict[str, Any],
    result_path: Union[str, Path],
    log_dir: str,
    include_screenshot_base64: bool = False,
) -> dict[str, Any]:
    url = str(state.get("url") or "")
    title = str(state.get("title") or "")
    screenshot = state.get("screenshot")
    screenshot_dir = Path(log_dir)
    raw_screenshot_path = _write_screenshot(
        screenshot_dir / "observe_screenshot.png",
        screenshot,
    )
    result: dict[str, Any] = {
        "schema_version": "browser-use.observe.v1",
        "timestamp": dt.datetime.now().isoformat(),
        "observe_mode": "history_screenshot",
        "cdp_url": None,
        "source_result_path": str(Path(result_path)),
        "url": url,
        "title": title,
        "viewport": {
            "width": None,
            "height": None,
            "pixels_above": None,
            "pixels_below": None,
        },
        "screenshots": {
            "raw_path": raw_screenshot_path,
            "highlighted_path": None,
        },
        "page_understanding": _build_history_screenshot_page_understanding(
            url=url,
            title=title,
        ),
        "controls": [],
        "browser_errors": [],
    }
    if include_screenshot_base64:
        result["screenshots"]["raw_base64"] = screenshot
        result["screenshots"]["highlighted_base64"] = None
    return result


def _emit_observe_result(result: dict[str, Any], output: Optional[str]) -> None:
    if output:
        output_path = Path(output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            json.dumps(result, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    print(json.dumps(result, ensure_ascii=False, indent=2))


def _write_quick_task_yaml(log_dir: str, task_text: str, url: Optional[str]) -> Path:
    timestamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    output_path = Path(log_dir) / f"quick_task_{timestamp}.yaml"
    task_yaml = {
        "target": {
            "url": url or os.getenv("QUICK_URL") or "about:blank",
        },
        "tasks": [
            {
                "name": "quick",
                "flow": [
                    {
                        "aiQuick": task_text,
                    }
                ],
            }
        ],
    }
    output_path.write_text(
        yaml.safe_dump(task_yaml, allow_unicode=True, sort_keys=False),
        encoding="utf-8",
    )
    return output_path


async def _run_with_browser_type(
    cfg,
    browser_type: str,
    log_dir: str,
    logger: logging.Logger,
) -> dict:
    """Run tasks with a specific browser type. Returns result dict."""
    profile = get_browser_profile(browser_type)
    logger.info(
        "=== Running with browser: %s (key=%s) ===", profile.display_name, profile.key
    )

    tasks = Tasks(
        task_yaml_path=cfg.task_file,
        dump_config_dir=log_dir,
        cache_path=cfg.get("cache_path", None),
    )
    initial_actions = [
        {"go_to_url": {"url": tasks.tasks_config.target.url}},
    ]

    actor, planner, asserter, aux_llms = build_models(
        actor=cfg.models.actor,
        planner=cfg.models.planner,
        asserter=cfg.models.asserter,
        page_extraction_llm=cfg.models.aux_llms.page_extraction_llm,
        locating_llm=cfg.models.aux_llms.locating_llm,
        coding_llm=cfg.models.aux_llms.coding_llm,
    )

    headless = _parse_headless(cfg.browser.headless)
    logger.info("Browser headless=%s", headless)

    # Task YAML viewportWidth/viewportHeight 优先于 default config
    target = tasks.tasks_config.target
    vw = int(target.viewportWidth)
    vh = int(target.viewportHeight)
    logger.info("Viewport: %dx%d", vw, vh)

    browser = Browser(
        config=BrowserConfig(
            headless=headless,
            browser_type=browser_type,
            new_context_config=BrowserContextConfig(
                cookies_file=target.cookie or None,
                browser_window_size=BrowserContextWindowSize(
                    width=vw,
                    height=vh,
                ),
                device_scale_factor=cfg.browser.device_scale_factor,
                click_mode=cfg.controller.click_mode,
            ),
        )
    )

    agent = Agent(
        config=cfg,
        tasks=tasks,
        llm=actor,
        planner=planner,
        asserter=asserter,
        aux_llms=aux_llms,
        browser=browser,
        initial_actions=initial_actions,
        log_dir=log_dir,
    )
    logger.info("Agent created, starting run (browser will start on first action)...")
    await agent.run()
    return {"browser": profile.display_name, "key": profile.key, "status": "success"}


async def run_quick(args: argparse.Namespace) -> int:
    Path(args.log_dir).mkdir(parents=True, exist_ok=True)
    setup_logging()
    logger = logging.getLogger("browser_use")

    try:
        quick_spec = prepare_quick_task(
            args.text,
            require_url=not args.resume,
            include_url_context=args.resume,
        )
    except ValueError as exc:
        logger.error(str(exc))
        return 1
    url = quick_spec.url

    use_cdp = bool(args.use_cdp)
    cdp_url = None
    if use_cdp:
        cdp_url = (
            args.cdp_url
            or os.getenv("BU_LOCAL_BROWSER_CDP_URL")
            or "http://127.0.0.1:9222"
        )
        _ensure_local_cdp_no_proxy(cdp_url)
        ok, error = _check_cdp_available(cdp_url)
        if not ok:
            _print_cdp_start_help(cdp_url, error)
            return 2
    elif args.cdp_url:
        logger.warning("--cdp-url is ignored when --no-cdp is used.")
    if args.resume and not use_cdp:
        logger.warning("--resume with --no-cdp starts a fresh browser page; it can only continue after the browser opens.")

    cfg = _load_agent_config(args.config_file, args.log_dir, args.opts)
    OmegaConf.update(cfg, "task_file", "quick_task")
    OmegaConf.update(cfg, "quick_display_query", args.text)
    if args.cache_path:
        OmegaConf.update(cfg, "cache_path", args.cache_path)
    max_steps = _apply_quick_react_mode_config(
        cfg,
        args.react_mode,
        args.max_steps,
    )

    inferred_headless = _infer_headless_from_quick_text(args.text)
    if args.headless is not None:
        headless = _parse_headless(args.headless)
    elif inferred_headless is not None:
        headless = inferred_headless
    else:
        headless = _parse_headless(cfg.browser.headless)

    task_text = quick_spec.task_text
    sensitive_data = quick_spec.sensitive_data

    with open(f"{args.log_dir}/agent_config.yaml", "w", encoding="utf-8") as file:
        OmegaConf.save(cfg, file)
    quick_yaml_path = _write_quick_task_yaml(args.log_dir, args.text, url)

    logger.info("Quick browser mode: %s", "cdp" if use_cdp else "fresh")
    if use_cdp:
        logger.info("Starting quick task with CDP: %s", cdp_url)
    logger.info("Initial URL: %s", url or "(current page)")
    logger.info("Quick resume: %s", args.resume)
    if use_cdp:
        logger.info(
            "Browser headless=%s (ignored when attaching to an existing CDP browser)",
            headless,
        )
    else:
        logger.info("Browser headless=%s", headless)
    logger.info("Quick ReAct mode: %s", args.react_mode)
    logger.info("Quick max steps: %s", max_steps)
    logger.info("Quick YAML artifact: %s", quick_yaml_path)

    tasks = Tasks(
        task=task_text,
        dump_config_dir=args.log_dir,
        cache_path=cfg.get("cache_path", None),
    )
    initial_actions = None if args.resume else [{"go_to_url": {"url": url}}]

    actor, planner, asserter, aux_llms = build_models(
        actor=cfg.models.actor,
        planner=cfg.models.planner,
        asserter=cfg.models.asserter,
        page_extraction_llm=cfg.models.aux_llms.page_extraction_llm,
        locating_llm=cfg.models.aux_llms.locating_llm,
        coding_llm=cfg.models.aux_llms.coding_llm,
    )

    vw = int(getattr(cfg.browser, "viewport_width", 1496))
    vh = int(getattr(cfg.browser, "viewport_height", 818))
    context_config = BrowserContextConfig(
        browser_window_size=BrowserContextWindowSize(width=vw, height=vh),
        device_scale_factor=cfg.browser.device_scale_factor,
        click_mode=cfg.controller.click_mode,
        _force_keep_context_alive=use_cdp,
    )
    browser_config_kwargs = {
        "headless": headless,
        "new_context_config": context_config,
        "_force_keep_browser_alive": use_cdp,
    }
    if use_cdp:
        browser_config_kwargs["cdp_url"] = cdp_url

    browser = Browser(config=BrowserConfig(**browser_config_kwargs))

    agent = Agent(
        config=cfg,
        tasks=tasks,
        llm=actor,
        planner=planner,
        asserter=asserter,
        aux_llms=aux_llms,
        browser=browser,
        initial_actions=initial_actions,
        log_dir=args.log_dir,
        sensitive_data=sensitive_data or None,
        react_mode=args.react_mode,
    )
    await agent.run()
    return 0


async def run_observe(args: argparse.Namespace) -> int:
    Path(args.log_dir).mkdir(parents=True, exist_ok=True)
    setup_logging()
    logger = logging.getLogger("browser_use")
    use_vision = _parse_headless(args.vision)
    use_cdp = bool(args.use_cdp)

    if not use_cdp:
        if args.url:
            logger.error("--url is only supported in CDP observe mode.")
            return 1
        result_path = _default_observe_result_path(args.log_dir)
        try:
            state = _load_last_observe_history_state(result_path)
            result = _build_history_screenshot_observe_result(
                state=state,
                result_path=result_path,
                log_dir=args.log_dir,
                include_screenshot_base64=args.include_screenshot_base64,
            )
        except ValueError as exc:
            logger.error(str(exc))
            return 1

        vision_error = None
        if use_vision:
            try:
                cfg = _load_agent_config(args.config_file, args.log_dir, [])
                _, _, _, aux_llms = build_models(
                    actor=cfg.models.actor,
                    planner=cfg.models.planner,
                    asserter=cfg.models.asserter,
                    page_extraction_llm=cfg.models.aux_llms.page_extraction_llm,
                    locating_llm=cfg.models.aux_llms.locating_llm,
                    coding_llm=cfg.models.aux_llms.coding_llm,
                )
                page_extraction_llm = aux_llms.get("page_extraction_llm")
                enrichment = await _enrich_observe_controls_with_vision(
                    page_extraction_llm,
                    [],
                    state.get("screenshot"),
                    result["url"],
                    result["title"],
                    args.max_controls,
                )
                result["page_understanding"].update(
                    enrichment.get("page_understanding", {})
                )
            except Exception as exc:
                vision_error = str(exc)
                logger.warning("Observe history screenshot vision enrichment failed: %s", exc)
        if vision_error:
            result["vision_error"] = vision_error
        _emit_observe_result(result, args.output)
        return 0

    cdp_url = (
        args.cdp_url
        or os.getenv("BU_LOCAL_BROWSER_CDP_URL")
        or "http://127.0.0.1:9222"
    )
    _ensure_local_cdp_no_proxy(cdp_url)
    ok, error = _check_cdp_available(cdp_url)
    if not ok:
        _print_cdp_start_help(cdp_url, error)
        return 2

    cfg = _load_agent_config(args.config_file, args.log_dir, [])
    vw = int(getattr(cfg.browser, "viewport_width", 1496))
    vh = int(getattr(cfg.browser, "viewport_height", 818))
    context_config = BrowserContextConfig(
        browser_window_size=BrowserContextWindowSize(width=vw, height=vh),
        device_scale_factor=cfg.browser.device_scale_factor,
        click_mode=cfg.controller.click_mode,
        _force_keep_context_alive=True,
    )
    browser = Browser(
        config=BrowserConfig(
            headless=True,
            cdp_url=cdp_url,
            new_context_config=context_config,
            _force_keep_browser_alive=True,
        )
    )
    browser_context = BrowserContext(
        browser=browser,
        config=context_config,
    )

    try:
        page = await browser_context.get_current_page()
        if args.url:
            await page.goto(args.url)
        state = await browser_context.get_state()
        controls = _build_observe_dom_controls(state, args.max_controls)
        viewport = {
            "width": state.page_width,
            "height": state.page_height,
            "pixels_above": state.pixels_above,
            "pixels_below": state.pixels_below,
        }
        page_understanding = _build_observe_page_understanding(
            url=state.url,
            title=state.title,
            controls=controls,
            viewport=viewport,
        )

        screenshot_dir = Path(args.log_dir)
        raw_screenshot_path = _write_screenshot(
            screenshot_dir / "observe_screenshot.png",
            state.screenshot,
        )
        highlighted_screenshot_path = _write_screenshot(
            screenshot_dir / "observe_highlighted.png",
            state.dom_tree_screenshot,
        )

        vision_error = None
        if use_vision:
            try:
                _, _, _, aux_llms = build_models(
                    actor=cfg.models.actor,
                    planner=cfg.models.planner,
                    asserter=cfg.models.asserter,
                    page_extraction_llm=cfg.models.aux_llms.page_extraction_llm,
                    locating_llm=cfg.models.aux_llms.locating_llm,
                    coding_llm=cfg.models.aux_llms.coding_llm,
                )
                page_extraction_llm = aux_llms.get("page_extraction_llm")
                enrichment = await _enrich_observe_controls_with_vision(
                    page_extraction_llm,
                    controls,
                    state.dom_tree_screenshot or state.screenshot,
                    state.url,
                    state.title,
                    args.max_controls,
                )
                enriched = enrichment.get("controls", {})
                for control in controls:
                    control.update(enriched.get(control["id"], {}))
                page_understanding.update(enrichment.get("page_understanding", {}))
            except Exception as exc:
                vision_error = str(exc)
                logger.warning("Observe vision enrichment failed: %s", exc)

        result: dict[str, Any] = {
            "schema_version": "browser-use.observe.v1",
            "timestamp": dt.datetime.now().isoformat(),
            "observe_mode": "cdp",
            "cdp_url": cdp_url,
            "url": state.url,
            "title": state.title,
            "viewport": viewport,
            "screenshots": {
                "raw_path": raw_screenshot_path,
                "highlighted_path": highlighted_screenshot_path,
            },
            "page_understanding": page_understanding,
            "controls": controls,
            "browser_errors": state.browser_errors,
        }
        if vision_error:
            result["vision_error"] = vision_error
        if args.include_screenshot_base64:
            result["screenshots"]["raw_base64"] = state.screenshot
            result["screenshots"]["highlighted_base64"] = state.dom_tree_screenshot
        _emit_observe_result(result, args.output)
        return 0
    finally:
        await browser_context.close()


async def launch():
    logger = logging.getLogger("browser_use")
    cfg = before_launch()

    # Determine browser types to run
    # Priority: .env (BU_BROWSER_TYPES > BU_BROWSER_TYPE) > config yaml > default
    browser_types: list[str] = []
    env_types = os.environ.get("BU_BROWSER_TYPES", "").strip()
    env_type = os.environ.get("BU_BROWSER_TYPE", "").strip()
    if env_types:
        browser_types = [t.strip() for t in env_types.split(",") if t.strip()]
        logger.info("Multi-browser mode (from .env BU_BROWSER_TYPES): %s", browser_types)
    elif env_type:
        browser_types = [env_type]
        logger.info("Browser type (from .env BU_BROWSER_TYPE): %s", env_type)
    elif hasattr(cfg.browser, "types") and cfg.browser.types:
        browser_types = list(cfg.browser.types)
        logger.info("Multi-browser mode (from config): %s", browser_types)
    else:
        browser_type = getattr(cfg.browser, "type", "chrome") or "chrome"
        browser_types = [str(browser_type)]

    base_log_dir = cfg.log_dir
    results: list[dict] = []

    for bt in browser_types:
        # Isolate log dir per browser in multi-browser mode
        if len(browser_types) > 1:
            safe_key = bt.replace(":", "_")
            log_dir = str(Path(base_log_dir) / safe_key)
            Path(log_dir).mkdir(parents=True, exist_ok=True)
        else:
            log_dir = base_log_dir

        try:
            result = await _run_with_browser_type(cfg, bt, log_dir, logger)
            results.append(result)
        except Exception as e:
            logger.error("Browser %s failed: %s", bt, e, exc_info=True)
            profile = get_browser_profile(bt)
            results.append({
                "browser": profile.display_name,
                "key": profile.key,
                "status": "failed",
                "error": str(e),
            })
            if len(browser_types) == 1:
                raise

    # Summary
    if len(browser_types) > 1:
        logger.info("=== Multi-browser execution summary ===")
        for r in results:
            status_icon = "OK" if r["status"] == "success" else "FAILED"
            logger.info("  [%s] %s (%s)", status_icon, r["browser"], r["key"])
            if r.get("error"):
                logger.info("       Error: %s", r["error"])


async def run_generate_cases(args: argparse.Namespace) -> int:
    from browser_use.case_generator.agent import CaseGeneratorAgent

    setup_logging()
    logger = logging.getLogger("browser_use")

    # URL: --url takes precedence; if only --user-input, agent.run() will parse
    url = args.url or ""
    if not url and args.user_input:
        logger.info("Starting case generator with user_input (url will be parsed)")
    else:
        logger.info("Starting case generator for %s", url)

    if not url and not args.user_input:
        logger.error("Either --url or --user-input is required for generate-cases mode")
        return 1

    login_config = None
    if args.login_config and Path(args.login_config).exists():
        login_config = {"task_file": args.login_config}

    agent = CaseGeneratorAgent()
    headless = str(getattr(args, "headless", "true")).lower() not in (
        "false",
        "0",
        "no",
    )
    max_depth = int(getattr(args, "max_depth", 1))
    collect_errors = str(
        getattr(args, "collect_exploration_errors", "true")
    ).lower() not in ("false", "0", "no")
    visual_check = str(getattr(args, "visual_error_check", "true")).lower() not in (
        "false",
        "0",
        "no",
    )
    written = await agent.run(
        url=url,
        output_dir=args.output_dir,
        project_name=args.project_name,
        max_depth=max_depth,
        login_config=login_config,
        headless=headless,
        user_input=getattr(args, "user_input", None),
        collect_exploration_errors=collect_errors,
        visual_error_check=visual_check,
    )
    logger.info("Generated %d files: %s", len(written), written)
    return 0


def main():
    if os.name == "nt":
        os.environ["PYTHONUTF8"] = "1"
        os.environ["PYTHONIOENCODING"] = "utf-8"
        for stream in (sys.stdout, sys.stderr):
            if hasattr(stream, "reconfigure"):
                stream.reconfigure(encoding="utf-8", errors="backslashreplace")
    if len(sys.argv) > 1 and sys.argv[1] == "quick":
        parser = get_quick_args_parser()
        args, unknown = parser.parse_known_args(sys.argv[2:])
        args.opts = unknown
        exit_code = asyncio.run(run_quick(args))
        sys.exit(exit_code)

    if len(sys.argv) > 1 and sys.argv[1] == "observe":
        parser = get_observe_args_parser()
        args = parser.parse_args(sys.argv[2:])
        exit_code = asyncio.run(run_observe(args))
        sys.exit(exit_code)

    # Two modes: --url triggers generate-cases, otherwise run (requires --task-file)
    parser = argparse.ArgumentParser(description="browser-use CLI")
    parser.add_argument(
        "--url", default=None, help="Target URL (triggers generate-cases mode)"
    )
    parser.add_argument(
        "--task-file", default=None, metavar="FILE", help="任务配置文件的地址"
    )
    parser.add_argument(
        "--config-file",
        default=str(project_root / "static/configs/default.yaml"),
        metavar="FILE",
        help="agent配置文件的地址",
    )
    parser.add_argument(
        "--log-dir",
        default=f"logs/{dt.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}",
        type=str,
        help="日志目录",
    )
    parser.add_argument("--cache-path", default=None, type=str, help="缓存文件地址")
    parser.add_argument(
        "--output-dir", default=None, help="Output dir (generate-cases)"
    )
    parser.add_argument(
        "--project-name", default="uiTest", help="Project name (generate-cases)"
    )
    parser.add_argument(
        "--max-depth",
        type=int,
        default=1,
        help="Case gen depth: 1=single page (default), >=2=multi-level exploration",
    )
    parser.add_argument(
        "--login-config", default=None, help="Login task YAML (generate-cases)"
    )
    parser.add_argument(
        "--user-input",
        default=None,
        help="Natural language input for module test, e.g. '帮我测试投放管理模块'. Parsed for url and module_name.",
    )
    parser.add_argument(
        "--headless",
        default="true",
        choices=("true", "false"),
        help="Run browser headless (default: true)",
    )
    parser.add_argument(
        "--collect-exploration-errors",
        default="true",
        choices=("true", "false"),
        help="Collect console/network/exploration errors during exploration (default: true)",
    )
    parser.add_argument(
        "--visual-error-check",
        default="true",
        choices=("true", "false"),
        help="Use LLM to detect system-level errors in screenshots (default: true)",
    )
    parser.add_argument(
        "opts", nargs=argparse.REMAINDER, default=[], help="Extra options"
    )

    args, unknown = parser.parse_known_args()

    if args.url or args.user_input:
        exit_code = asyncio.run(run_generate_cases(args))
        sys.exit(exit_code)

    if not args.task_file:
        parser.error(
            "--task-file is required for run mode (or use --url for generate-cases)"
        )

    # run mode: build argv for before_launch
    sys.argv = [sys.argv[0], "--task-file", args.task_file]
    if args.config_file:
        sys.argv += ["--config-file", args.config_file]
    sys.argv += ["--log-dir", args.log_dir]
    if args.cache_path:
        sys.argv += ["--cache-path", args.cache_path]
    opts = getattr(args, "opts", []) or unknown
    sys.argv += opts

    exit_code = 0
    try:
        asyncio.run(launch())
    except Exception as e:
        print(f"Error running agent: {e}")
        exit_code = 1
    finally:
        sys.exit(exit_code)


if __name__ == "__main__":
    main()
