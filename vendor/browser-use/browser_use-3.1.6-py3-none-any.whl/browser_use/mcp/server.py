from __future__ import annotations

import json
import logging
from typing import Any, Dict, List

from mcp.server.fastmcp import FastMCP
from mcp.types import TextContent, ImageContent

from browser_use.mcp.session import BrowserSessionManager

logger = logging.getLogger(__name__)

mcp = FastMCP("browser-use", instructions="AI-powered browser automation via browser-use")
session_manager = BrowserSessionManager()


def _text(data: Dict[str, Any]) -> TextContent:
    return TextContent(type="text", text=json.dumps(data, ensure_ascii=False))


def _result_with_screenshot(result: Dict[str, Any]) -> list:
    """Build MCP content list from execution result."""
    screenshot = result.pop("screenshot", None)
    contents: list = [_text(result)]
    if screenshot:
        contents.append(ImageContent(type="image", data=screenshot, mimeType="image/png"))
    return contents


def _error(msg: str) -> list:
    return [_text({"success": False, "error": msg})]


# ---------------------------------------------------------------------------
# Session Management Tools (3)
# ---------------------------------------------------------------------------


@mcp.tool()
async def browser_create_session(
    cdp_url: str = "",
    chrome_instance_path: str = "",
    wss_url: str = "",
    cookies_file: str = "",
    headless: bool = True,
    start_url: str = "",
    viewport_width: int = 1496,
    viewport_height: int = 818,
) -> list:
    """Create a new browser session. Supports connecting to a local Chrome browser via CDP to reuse login state.

    Use cdp_url='http://localhost:9222' to connect to Chrome started with --remote-debugging-port=9222.
    Use chrome_instance_path to auto-start and connect to a local Chrome installation.
    Use cookies_file to persist cookies across sessions.
    """
    try:
        session_id = await session_manager.create_session(
            cdp_url=cdp_url,
            chrome_instance_path=chrome_instance_path,
            wss_url=wss_url,
            cookies_file=cookies_file,
            headless=headless,
            start_url=start_url,
            viewport_width=viewport_width,
            viewport_height=viewport_height,
        )
        return [_text({"session_id": session_id, "message": f"Session {session_id} created."})]
    except Exception as e:
        return _error(str(e))


@mcp.tool()
async def browser_close_session(session_id: str = "") -> list:
    """Close a browser session. Saves cookies if cookies_file was configured during creation."""
    try:
        msg = await session_manager.close_session(session_id or None)
        return [_text({"success": True, "message": msg})]
    except Exception as e:
        return _error(str(e))


@mcp.tool()
async def browser_screenshot(session_id: str = "", full_page: bool = False) -> list:
    """Take a screenshot of the current page. Returns the image for visual inspection."""
    try:
        b64 = await session_manager.take_screenshot(session_id or None, full_page=full_page)
        return [
            _text({"success": True, "message": "Screenshot captured."}),
            ImageContent(type="image", data=b64, mimeType="image/png"),
        ]
    except Exception as e:
        return _error(str(e))


# ---------------------------------------------------------------------------
# AI Task Tools (2)
# ---------------------------------------------------------------------------


@mcp.tool()
async def browser_ai_task(task: str, max_steps: int = 10, session_id: str = "") -> list:
    """Execute a complete AI-driven browser task described in natural language.

    The AI agent will plan, act, and observe in a loop until the task is done or max_steps is reached.
    Example: browser_ai_task(task="search for 'hello world' on Google and click the first result")
    """
    try:
        from browser_use.agent.tasks import AiConfig
        cmd = AiConfig(ai=task)
        result = await session_manager.execute_command(cmd, session_id=session_id or None, max_steps=max_steps)
        return _result_with_screenshot(result)
    except Exception as e:
        return _error(str(e))


@mcp.tool()
async def browser_ai_action(action: str, session_id: str = "") -> list:
    """Execute a single AI step (one plan-act cycle) described in natural language.

    Unlike browser_ai_task, this performs only one step without looping.
    Example: browser_ai_action(action="click the login button")
    """
    try:
        from browser_use.agent.tasks import AiActionConfig
        cmd = AiActionConfig(aiAction=action)
        result = await session_manager.execute_command(cmd, session_id=session_id or None)
        return _result_with_screenshot(result)
    except Exception as e:
        return _error(str(e))


# ---------------------------------------------------------------------------
# Precise Interaction Tools (6)
# ---------------------------------------------------------------------------


@mcp.tool()
async def browser_navigate(url: str, session_id: str = "") -> list:
    """Navigate the browser to the specified URL.

    Example: browser_navigate(url="https://example.com")
    """
    try:
        from browser_use.agent.tasks import GoToConfig
        cmd = GoToConfig(goTo=url)
        result = await session_manager.execute_command(cmd, session_id=session_id or None)
        return _result_with_screenshot(result)
    except Exception as e:
        return _error(str(e))


@mcp.tool()
async def browser_click(target: str, locate: str = "", session_id: str = "") -> list:
    """AI-powered click on a page element described in natural language.

    Args:
        target: Element description, e.g. "Submit button", "Login link"
        locate: Optional hint to narrow down location, e.g. "in the navigation bar"
    """
    try:
        from browser_use.agent.tasks import AiTapConfig
        cmd = AiTapConfig(aiTap=target, locate=locate or None)
        result = await session_manager.execute_command(cmd, session_id=session_id or None)
        return _result_with_screenshot(result)
    except Exception as e:
        return _error(str(e))


@mcp.tool()
async def browser_type(text: str, locate: str = "", session_id: str = "") -> list:
    """AI-powered text input into a form field.

    Args:
        text: Text to type into the field
        locate: Optional hint for which field, e.g. "search box", "email input"
    """
    try:
        from browser_use.agent.tasks import AiInputConfig
        cmd = AiInputConfig(aiInput=text, locate=locate or None)
        result = await session_manager.execute_command(cmd, session_id=session_id or None)
        return _result_with_screenshot(result)
    except Exception as e:
        return _error(str(e))


@mcp.tool()
async def browser_hover(target: str, locate: str = "", session_id: str = "") -> list:
    """AI-powered hover over a page element described in natural language.

    Args:
        target: Element description, e.g. "user menu", "dropdown trigger"
        locate: Optional hint to narrow down location
    """
    try:
        from browser_use.agent.tasks import AiHoverConfig
        cmd = AiHoverConfig(aiHover=target, locate=locate or None)
        result = await session_manager.execute_command(cmd, session_id=session_id or None)
        return _result_with_screenshot(result)
    except Exception as e:
        return _error(str(e))


@mcp.tool()
async def browser_scroll(direction: str, session_id: str = "") -> list:
    """AI-powered scroll action on the page.

    Args:
        direction: Scroll description, e.g. "scroll down", "scroll to bottom", "scroll up"
    """
    try:
        from browser_use.agent.tasks import AiScrollConfig
        cmd = AiScrollConfig(aiScroll=direction)
        result = await session_manager.execute_command(cmd, session_id=session_id or None)
        return _result_with_screenshot(result)
    except Exception as e:
        return _error(str(e))


@mcp.tool()
async def browser_send_keys(keys: str, session_id: str = "") -> list:
    """Send keyboard keys to the page.

    Args:
        keys: Keys to send, e.g. "Enter", "Ctrl+A", "Escape"
    """
    try:
        from browser_use.agent.tasks import AiSendKeysConfig
        cmd = AiSendKeysConfig(aiSendKeys=keys)
        result = await session_manager.execute_command(cmd, session_id=session_id or None)
        return _result_with_screenshot(result)
    except Exception as e:
        return _error(str(e))


# ---------------------------------------------------------------------------
# Query & Assertion Tools (4)
# ---------------------------------------------------------------------------


@mcp.tool()
async def browser_query(query: str, session_id: str = "") -> list:
    """Extract page content based on a natural language query.

    The AI analyzes the current page and extracts the requested information.
    Example: browser_query(query="list all product names and prices")
    """
    try:
        from browser_use.agent.tasks import AiQueryConfig
        cmd = AiQueryConfig(aiQuery=query)
        result = await session_manager.execute_command(cmd, session_id=session_id or None)
        return _result_with_screenshot(result)
    except Exception as e:
        return _error(str(e))


@mcp.tool()
async def browser_assert(assertion: str, session_id: str = "") -> list:
    """Assert a condition about the current page state using AI.

    Returns whether the assertion is true or false, with reasoning.
    Example: browser_assert(assertion="the page shows a success message")
    """
    try:
        from browser_use.agent.tasks import AiAssertConfig
        cmd = AiAssertConfig(aiAssert=assertion)
        result = await session_manager.execute_command(cmd, session_id=session_id or None)
        return _result_with_screenshot(result)
    except Exception as e:
        return _error(str(e))


@mcp.tool()
async def browser_wait_for(condition: str, timeout_ms: int = 90000, session_id: str = "") -> list:
    """Wait for a page condition to be met, evaluated by AI.

    Polls the page state until the condition is true or timeout is reached.
    Example: browser_wait_for(condition="loading spinner disappears", timeout_ms=30000)
    """
    try:
        from browser_use.agent.tasks import AiWaitForConfig
        cmd = AiWaitForConfig(aiWaitFor=condition, timeout=timeout_ms)
        result = await session_manager.execute_command(cmd, session_id=session_id or None)
        return _result_with_screenshot(result)
    except Exception as e:
        return _error(str(e))


@mcp.tool()
async def browser_run_javascript(code: str, session_id: str = "") -> list:
    """Execute JavaScript code in the browser context.

    Example: browser_run_javascript(code="document.title")
    """
    try:
        from browser_use.agent.tasks import JsCodeConfig
        cmd = JsCodeConfig(jsCode=code)
        result = await session_manager.execute_command(cmd, session_id=session_id or None)
        return [_text(result)]
    except Exception as e:
        return _error(str(e))
