from __future__ import annotations

import asyncio
import json
import logging
import tempfile
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from omegaconf import OmegaConf, DictConfig

from browser_use.agent.tasks import (
    BaseCommandConfig,
    Tasks,
    TasksConfig,
    TaskConfig,
    TargetConfig,
)
from browser_use.browser.browser import Browser, BrowserConfig
from browser_use.browser.context import BrowserContext, BrowserContextConfig

logger = logging.getLogger(__name__)


def _build_tasks_for_command(command_config: BaseCommandConfig) -> Tasks:
    """Construct an in-memory Tasks object containing a single command.

    Bypasses Tasks.__init__() which requires a YAML file or plain-text task string.
    """
    tasks = Tasks.__new__(Tasks)
    tasks.task = None
    tasks.task_yaml_path = None
    tasks.dump_config_dir = None
    tasks.cache_path = None
    tasks.cache = None
    tasks.extra_sensitive_variables = []
    tasks.modules = {}
    tasks.imported_command_indices = set()

    # Convert config to dict so TaskConfig's _convert_flow validator can process it
    cmd_dict = command_config.model_dump(exclude_none=True)
    cmd_dict.pop("cache", None)
    tasks.tasks_config = TasksConfig(
        tasks=[TaskConfig(name="mcp_cmd", flow=[cmd_dict])]
    )
    return tasks


def _load_default_config(
    log_dir: str,
    max_steps: int = 10,
) -> DictConfig:
    """Load default.yaml and add runtime fields the Agent expects."""
    config_path = Path(__file__).parent.parent / "static" / "configs" / "default.yaml"
    cfg = OmegaConf.load(str(config_path))
    cfg.task_file = "mcp_session"
    cfg.log_dir = log_dir
    cfg.agent.max_steps = max_steps
    return cfg


@dataclass
class BrowserSession:
    session_id: str
    browser: Browser
    browser_context: BrowserContext
    config: DictConfig
    llm_models: tuple  # (actor, planner, asserter, aux_llms)
    log_dir: Path
    cookies_file: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    last_used_at: datetime = field(default_factory=datetime.now)


class BrowserSessionManager:
    """Manages browser session lifecycle for MCP tools."""

    def __init__(self):
        self._sessions: Dict[str, BrowserSession] = {}
        self._default_session_id: Optional[str] = None
        self._lock = asyncio.Lock()

    async def create_session(
        self,
        cdp_url: str = "",
        chrome_instance_path: str = "",
        wss_url: str = "",
        cookies_file: str = "",
        headless: bool = True,
        start_url: str = "",
        viewport_width: int = 1496,
        viewport_height: int = 818,
    ) -> str:
        """Create a new browser session with the given configuration."""
        session_id = uuid.uuid4().hex[:12]
        log_dir = Path(tempfile.mkdtemp(prefix=f"browser-use-mcp-{session_id}-"))

        # Build browser config
        browser_config = BrowserConfig(
            headless=headless,
            cdp_url=cdp_url or None,
            chrome_instance_path=chrome_instance_path or None,
            wss_url=wss_url or None,
            new_context_config=BrowserContextConfig(
                cookies_file=cookies_file or None,
                browser_window_size={
                    "width": viewport_width,
                    "height": viewport_height,
                },
            ),
        )

        browser = Browser(config=browser_config)
        browser_context = BrowserContext(
            browser=browser,
            config=browser_config.new_context_config,
        )

        # Initialize LLM models
        from browser_use.agent.chat_models import build_models

        cfg = _load_default_config(str(log_dir))
        actor, planner, asserter, aux_llms = build_models(
            actor=cfg.models.actor,
            planner=cfg.models.planner,
            asserter=cfg.models.asserter,
            page_extraction_llm=cfg.models.aux_llms.page_extraction_llm,
            locating_llm=cfg.models.aux_llms.locating_llm,
            coding_llm=cfg.models.aux_llms.coding_llm,
        )

        # Navigate to start_url if provided
        if start_url:
            page = await browser_context.get_current_page()
            await page.goto(start_url)

        session = BrowserSession(
            session_id=session_id,
            browser=browser,
            browser_context=browser_context,
            config=cfg,
            llm_models=(actor, planner, asserter, aux_llms),
            log_dir=log_dir,
            cookies_file=cookies_file or None,
        )
        self._sessions[session_id] = session

        if self._default_session_id is None:
            self._default_session_id = session_id

        return session_id

    async def get_or_create_default(self) -> BrowserSession:
        """Get default session, creating one if none exists."""
        if self._default_session_id and self._default_session_id in self._sessions:
            return self._sessions[self._default_session_id]
        session_id = await self.create_session()
        return self._sessions[session_id]

    def get_session(self, session_id: Optional[str] = None) -> Optional[BrowserSession]:
        """Get session by ID or return default."""
        if session_id and session_id in self._sessions:
            return self._sessions[session_id]
        if not session_id and self._default_session_id:
            return self._sessions.get(self._default_session_id)
        return None

    async def close_session(self, session_id: Optional[str] = None) -> str:
        """Close a session and clean up resources."""
        sid = session_id or self._default_session_id
        if not sid or sid not in self._sessions:
            return "No active session to close."

        session = self._sessions[sid]

        # Save cookies if configured
        if session.cookies_file:
            try:
                await session.browser_context.save_cookies()
            except Exception as e:
                logger.warning(f"Failed to save cookies: {e}")

        # Close browser resources
        try:
            await session.browser_context.close()
        except Exception:
            pass
        try:
            await session.browser.close()
        except Exception:
            pass

        del self._sessions[sid]
        if self._default_session_id == sid:
            self._default_session_id = next(iter(self._sessions), None)

        return f"Session {sid} closed."

    async def close_all(self) -> None:
        """Close all sessions."""
        for sid in list(self._sessions.keys()):
            await self.close_session(sid)

    async def take_screenshot(self, session_id: Optional[str] = None, full_page: bool = False) -> str:
        """Take a screenshot, return base64-encoded PNG."""
        session = self.get_session(session_id)
        if not session:
            session = await self.get_or_create_default()

        page = await session.browser_context.get_current_page()
        screenshot_bytes = await page.screenshot(full_page=full_page)

        import base64
        return base64.b64encode(screenshot_bytes).decode("utf-8")

    async def execute_command(
        self,
        command_config: BaseCommandConfig,
        session_id: Optional[str] = None,
        max_steps: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Execute a single command via a temporary Agent.

        Creates an Agent with the session's browser injected, runs the command,
        and extracts results from the execution history.
        """
        async with self._lock:
            session = self.get_session(session_id)
            if not session:
                session = await self.get_or_create_default()

            session.last_used_at = datetime.now()

            # Build config with optional max_steps override
            cfg = session.config.copy()
            if max_steps is not None:
                cfg.agent.max_steps = max_steps

            # Update log_dir for this execution
            exec_log_dir = session.log_dir / f"exec_{datetime.now().strftime('%H%M%S')}"
            exec_log_dir.mkdir(parents=True, exist_ok=True)
            cfg.log_dir = str(exec_log_dir)

            tasks = _build_tasks_for_command(command_config)

            # Lazy import to avoid circular dependencies
            from browser_use.agent.service import Agent

            actor, planner, asserter, aux_llms = session.llm_models

            agent = Agent(
                config=cfg,
                tasks=tasks,
                llm=actor,
                planner=planner,
                asserter=asserter,
                aux_llms=aux_llms,
                browser=session.browser,
                browser_context=session.browser_context,
                log_dir=str(exec_log_dir),
            )

            try:
                history = await agent.run()
                return self._extract_result(history)
            except Exception as e:
                logger.exception(f"Command execution failed: {e}")
                # Try to capture screenshot on error
                screenshot = None
                try:
                    screenshot = await self.take_screenshot(session.session_id)
                except Exception:
                    pass
                return {
                    "success": False,
                    "message": str(e),
                    "screenshot": screenshot,
                }

    def _extract_result(self, history: Any) -> Dict[str, Any]:
        """Extract structured result from AgentHistoryList."""
        result: Dict[str, Any] = {
            "success": True,
            "message": "",
            "screenshot": None,
        }

        if not history or not hasattr(history, "history") or not history.history:
            result["message"] = "No execution history available."
            return result

        # Check last history entry for results
        last_entry = history.history[-1]

        # Collect messages from action results
        messages = []
        extracted_content = []
        for action_result in (last_entry.result or []):
            if action_result.error:
                result["success"] = False
                messages.append(f"Error: {action_result.error}")
            elif action_result.extracted_content:
                extracted_content.append(action_result.extracted_content)
            if action_result.is_done:
                if action_result.extracted_content:
                    extracted_content.append(action_result.extracted_content)

        # Check all history entries for any errors
        for entry in history.history:
            for action_result in (entry.result or []):
                if action_result.error:
                    result["success"] = False

        if extracted_content:
            result["content"] = "\n".join(extracted_content)

        if messages:
            result["message"] = "; ".join(messages)
        elif extracted_content:
            result["message"] = "Content extracted successfully."
        else:
            result["message"] = "Command completed."

        # Get screenshot from last entry if available
        if last_entry.state and last_entry.state.screenshot:
            result["screenshot"] = last_entry.state.screenshot

        return result
