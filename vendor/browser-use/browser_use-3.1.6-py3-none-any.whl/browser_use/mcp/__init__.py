def main():
    from browser_use.mcp.server import mcp
    mcp.run()
