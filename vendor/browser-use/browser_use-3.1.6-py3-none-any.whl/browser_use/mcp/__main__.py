from browser_use.mcp import main

main()
