(
  args = {
    doHighlightElements: true,
    viewportExpansion: 0,
  }
) => {
  const { doHighlightElements, viewportExpansion } = args;

  let scrollableIndex = 0;
  var scrollableElements = [];

  // Add timing stack to handle recursion
  const TIMING_STACK = {
    nodeProcessing: [],
    treeTraversal: [],
    highlighting: [],
    current: null
  };

  function popTiming(type) {
    const start = TIMING_STACK[type].pop();
    return performance.now() - start;
  }

  // Add caching mechanisms at the top level
  const DOM_CACHE = {
    boundingRects: new WeakMap(),
    computedStyles: new WeakMap(),
    clearCache: () => {
      DOM_CACHE.boundingRects = new WeakMap();
      DOM_CACHE.computedStyles = new WeakMap();
    }
  };

  // Cache helper functions
  function getCachedBoundingRect(element) {
    if (!element) return null;

    if (DOM_CACHE.boundingRects.has(element)) {
      return DOM_CACHE.boundingRects.get(element);
    }

    let rect;
    rect = element.getBoundingClientRect();

    if (rect) {
      DOM_CACHE.boundingRects.set(element, rect);
    }
    return rect;
  }

  function getCachedComputedStyle(element) {
    if (!element) return null;

    if (DOM_CACHE.computedStyles.has(element)) {
      return DOM_CACHE.computedStyles.get(element);
    }


    let style;
    style = window.getComputedStyle(element);


    if (style) {
      DOM_CACHE.computedStyles.set(element, style);
    }
    return style;
  }

  const ID = { current: 0 };

  const HIGHLIGHT_CONTAINER_ID = "playwright-highlight-container";

  /**
   * Highlights an element in the DOM and returns the index of the next element.
   */
  function highlightElement(element, index, parentIframe = null) {
    padding = 2;
    if (!element) return index;

    try {
      // Create or get highlight container
      let container = document.getElementById(HIGHLIGHT_CONTAINER_ID);
      if (!container) {
        container = document.createElement("div");
        container.id = HIGHLIGHT_CONTAINER_ID;
        container.style.position = "fixed";
        container.style.pointerEvents = "none";
        container.style.top = "0";
        container.style.left = "0";
        container.style.width = "100%";
        container.style.height = "100%";
        container.style.zIndex = "2147483647";
        document.body.appendChild(container);
      }

      // Get element position
      const rect = getEffectiveVisibleRect(element)

      if (!rect) return index;

      // Generate a color based on the index
      const colors = [
        "#FF0000",
        "#00FF00",
        "#0000FF",
        "#FFA500",
        "#800080",
        "#008080",
        "#FF69B4",
        "#4B0082",
        "#FF4500",
        "#2E8B57",
        "#DC143C",
        "#4682B4",
      ];
      const colorIndex = index % colors.length;
      const baseColor = colors[colorIndex];
      const backgroundColor = baseColor + "06"; // 3% opacity version of the color

      // Create highlight overlay
      const overlay = document.createElement("div");
      overlay.style.position = "fixed";
      overlay.style.border = `3px solid ${baseColor}`;
      overlay.style.backgroundColor = backgroundColor;
      overlay.style.pointerEvents = "none";
      overlay.style.boxSizing = "border-box";

      // Get element position
      let iframeOffset = { x: 0, y: 0 };

      // If element is in an iframe, calculate iframe offset
      if (parentIframe) {
        const iframeRect = getEffectiveVisibleRect(parentIframe);
        iframeOffset.x = iframeRect.left;
        iframeOffset.y = iframeRect.top;
      }

      // Calculate position
      const top = rect.top + iframeOffset.y;
      const left = rect.left + iframeOffset.x;

      overlay.style.top = `${top - padding}px`;
      overlay.style.left = `${left - padding}px`;
      overlay.style.width = `${rect.width + 2 * padding}px`;
      overlay.style.height = `${rect.height + 2 * padding}px`;

      // Create and position label
      const label = document.createElement("div");
      label.className = "playwright-highlight-label";
      label.style.position = "fixed";
      label.style.background = baseColor;
      label.style.color = "white";
      label.style.padding = "1px 4px";
      label.style.borderRadius = "4px";
      // label.style.fontSize = `${Math.min(12, Math.max(8, rect.height / 2))}px`;
      label.style.fontSize = `16px`;
      label.textContent = index;

      const labelWidth = 20;
      const labelHeight = 16;

      let labelTop = top + 2;
      let labelLeft = left + 2;

      if (rect.width < labelWidth + 4 || rect.height < labelHeight + 4) {
        labelTop = top - labelHeight - 2;
        labelLeft = left;
      }

      label.style.top = `${labelTop - padding}px`;
      label.style.left = `${labelLeft - padding}px`;

      // Add to container
      container.appendChild(overlay);
      container.appendChild(label);

      // Update positions on scroll
      const updatePositions = () => {
        const newRect = getEffectiveVisibleRect(element);
        let newIframeOffset = { x: 0, y: 0 };

        if (parentIframe) {
          const iframeRect = getEffectiveVisibleRect(parentIframe);
          newIframeOffset.x = iframeRect.left;
          newIframeOffset.y = iframeRect.top;
        }

        const newTop = newRect.top + newIframeOffset.y;
        const newLeft = newRect.left + newIframeOffset.x;

        overlay.style.top = `${newTop - padding}px`;
        overlay.style.left = `${newLeft - padding}px`;
        overlay.style.width = `${newRect.width + 2 * padding}px`;
        overlay.style.height = `${newRect.height + 2 * padding}px`;

        let newLabelTop = newTop + 2;
        let newLabelLeft = newLeft + 2;

        if (newRect.width < labelWidth + 4 || newRect.height < labelHeight + 4) {
          newLabelTop = newTop - labelHeight - 2;
          newLabelLeft = newLeft;
        }

        label.style.top = `${newLabelTop - padding}px`;
        label.style.left = `${newLabelLeft - padding}px`;
      };

      window.addEventListener('scroll', updatePositions);
      window.addEventListener('resize', updatePositions);

      return index + 1;
    } finally {
      popTiming('highlighting');
    }
  }

  function getIntersection(rect1, rect2) {
    const top = Math.max(rect1.top, rect2.top);
    const left = Math.max(rect1.left, rect2.left);
    const bottom = Math.min(rect1.bottom, rect2.bottom);
    const right = Math.min(rect1.right, rect2.right);

    const width = Math.max(0, right - left);
    const height = Math.max(0, bottom - top);

    return { top, left, bottom, right, width, height };
  }

  /**
   * Calculates the effective scroll height of an element.
   */
  function getEffectiveVisibleRect(element) {
    const rect = element.getBoundingClientRect();

    // 初始可见区域是浏览器视口
    let intersection = {
      top: 0,
      left: 0,
      bottom: window.innerHeight,
      right: window.innerWidth,
      width: window.innerWidth,
      height: window.innerHeight
    };

    // 如果是 html 或 body，其可见高度直接就是视口高度（不需要查父级）
    if (element === document.documentElement || element === document.body) {
      return getIntersection(rect, intersection);
    }

    // 向上遍历父元素，如果父元素会裁剪子元素（overflow不是visible），就取交集
    let parent = element.parentElement;
    while (parent && parent !== document.documentElement) {
      const isScrollable = isElementScrollable(parent);
      if (isScrollable.vertical || isScrollable.horizontal) {
        const parentRect = parent.getBoundingClientRect();
        intersection = getIntersection(intersection, parentRect);
      }
      parent = parent.parentElement;
    }

    return getIntersection(rect, intersection);
  }

  /**
   * Returns an XPath tree string for an element.
   */
  function getXPathTree(element, stopAtBoundary = true) {
    const segments = [];
    let currentElement = element;

    while (currentElement && currentElement.nodeType === Node.ELEMENT_NODE) {
      // Stop if we hit a shadow root or iframe
      if (
        stopAtBoundary &&
        (currentElement.parentNode instanceof ShadowRoot ||
          currentElement.parentNode instanceof HTMLIFrameElement)
      ) {
        break;
      }

      let index = 0;
      let sibling = currentElement.previousSibling;
      while (sibling) {
        if (
          sibling.nodeType === Node.ELEMENT_NODE &&
          sibling.nodeName === currentElement.nodeName
        ) {
          index++;
        }
        sibling = sibling.previousSibling;
      }

      const tagName = currentElement.nodeName.toLowerCase();
      // const xpathIndex = index > 0 ? `[${index + 1}]` : "";
      const xpathIndex = `[${index + 1}]`;
      segments.unshift(`${tagName}${xpathIndex}`);

      currentElement = currentElement.parentNode;
    }

    return segments.join("/");
  }

  // Helper function to check if element is accepted
  function isElementAccepted(element) {
    if (!element || !element.tagName) return false;

    // Always accept body and common container elements
    const alwaysAccept = new Set([
      "body", "div", "main", "article", "section", "nav", "header", "footer"
    ]);
    const tagName = element.tagName.toLowerCase();

    if (alwaysAccept.has(tagName)) return true;

    const leafElementDenyList = new Set([
      "svg",
      "script",
      "style",
      "link",
      "meta",
      "noscript",
      "template",
    ]);

    return !leafElementDenyList.has(tagName);
  }

  /**
   * Checks if an element is visible.
   */
  function isElementVisible(element) {
    const style = getCachedComputedStyle(element);
    return (
      element.offsetWidth > 0 &&
      element.offsetHeight > 0 &&
      style.visibility !== "hidden" &&
      style.display !== "none"
    );
  }

  /**
   * Checks if an element is the topmost element at its position.
   */
  function isTopElement(element) {
    const rect = getCachedBoundingRect(element);

    // If element is not in viewport, consider it top
    const isInViewport = (
      rect.left < window.innerWidth &&
      rect.right > 0 &&
      rect.top < window.innerHeight &&
      rect.bottom > 0
    );

    if (!isInViewport) {
      return true;
    }

    // Find the correct document context and root element
    let doc = element.ownerDocument;

    // If we're in an iframe, elements are considered top by default
    if (doc !== window.document) {
      return true;
    }

    // For shadow DOM, we need to check within its own root context
    const shadowRoot = element.getRootNode();
    if (shadowRoot instanceof ShadowRoot) {
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;

      try {
        const topEl = shadowRoot.elementFromPoint(centerX, centerY);
        if (!topEl) return false;

        let current = topEl;
        while (current && current !== shadowRoot) {
          if (current === element) return true;
          current = current.parentElement;
        }
        return false;
      } catch (e) {
        return true;
      }
    }

    // For elements in viewport, check if they're topmost
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    try {
      const topEl = document.elementFromPoint(centerX, centerY);
      if (!topEl) return false;

      let current = topEl;
      while (current && current !== document.documentElement) {
        if (current === element) return true;
        current = current.parentElement;
      }
      return false;
    } catch (e) {
      return true;
    }
  }

  // Add these helper functions at the top level
  function isInteractiveCandidate(element) {
    if (!element || element.nodeType !== Node.ELEMENT_NODE) return false;

    const tagName = element.tagName.toLowerCase();

    // Fast-path for common interactive elements
    const interactiveElements = new Set([
      "a", "button", "input", "select", "textarea", "details", "summary"
    ]);

    if (interactiveElements.has(tagName)) return true;

    // Quick attribute checks without getting full lists
    return element.hasAttribute("onclick") ||
        element.hasAttribute("role") ||
        element.hasAttribute("tabindex") ||
        element.hasAttribute("aria-") ||
        element.hasAttribute("data-action");
  }

  /**
   * Creates a node data object for a given node and its descendants.
   */
  function buildDomTree(node, parentIframe = null) {
    var highlighs = [];

    if (!node || node.id === HIGHLIGHT_CONTAINER_ID) {
      return null;
    }

    // Special handling for root node (body)
    if (node === document.body) {
      const nodeData = {
        tagName: 'body',
        attributes: {},
        xpath: '/body',
        children: [],
      };

      // Process children of body
      for (const child of node.childNodes) {
        const domElement = buildDomTree(child, parentIframe);
        if (domElement) nodeData.children.push(domElement);
      }

      const scrollStatus = isElementScrollable(node);
      if (scrollStatus.horizontal || scrollStatus.vertical) {
        nodeData.isScrollable = true;
        nodeData.isVerticalScrollable = scrollStatus.vertical;
        nodeData.isHorizontalScrollable = scrollStatus.horizontal;
        nodeData.isVisible = isElementVisible(node);
        nodeData.isTopElement = isTopElement(node);
        nodeData.scrollableIndex = scrollableIndex++;
        nodeData.rectangle = node.getBoundingClientRect();
        nodeData.className = node.className.trim();
        nodeData.scrollHeight = node.scrollHeight;
        nodeData.scrollWidth = node.scrollWidth;
        nodeData.scrollTop = node.scrollTop;
        nodeData.scrollLeft = node.scrollLeft;
        nodeData.clientHeight = node.clientHeight;
        nodeData.clientWidth = node.clientWidth;
        nodeData.visibleRect = getEffectiveVisibleRect(node);
        scrollableElements.push(nodeData)

        if (doHighlightElements) {
          highlightElement(node, nodeData.scrollableIndex, parentIframe);
        }
      }
      return `${ID.current++}`;
    }

    // Early bailout for non-element nodes except text
    if (node.nodeType !== Node.ELEMENT_NODE && node.nodeType !== Node.TEXT_NODE) {
      return null;
    }

    // Process text nodes
    if (node.nodeType === Node.TEXT_NODE) {
      const textContent = node.textContent.trim();
      if (!textContent) {
        return null;
      }

      // Only check visibility for text nodes that might be visible
      const parentElement = node.parentElement;
      if (!parentElement || parentElement.tagName.toLowerCase() === 'script') {
        return null;
      }

      return `${ID.current++}`;
    }

    // Quick checks for element nodes
    if (node.nodeType === Node.ELEMENT_NODE && !isElementAccepted(node)) {
      return null;
    }

    // Early viewport check - only filter out elements clearly outside viewport
    if (viewportExpansion !== -1) {
      const rect = getCachedBoundingRect(node);
      const style = getCachedComputedStyle(node);

      // Skip viewport check for fixed/sticky elements as they may appear anywhere
      const isFixedOrSticky = style && (style.position === 'fixed' || style.position === 'sticky');

      // Check if element has actual dimensions
      const hasSize = node.offsetWidth > 0 || node.offsetHeight > 0;

      if (!rect || (!isFixedOrSticky && !hasSize && (
        rect.bottom < -viewportExpansion ||
        rect.top > window.innerHeight + viewportExpansion ||
        rect.right < -viewportExpansion ||
        rect.left > window.innerWidth + viewportExpansion
      ))) {
        return null;
      }
    }

    // Process element node
    const nodeData = {
      tagName: node.tagName.toLowerCase(),
      attributes: {},
      xpath: getXPathTree(node, true),
      children: [],
    };

    // Get attributes for interactive elements or potential text containers
    if (isInteractiveCandidate(node) || node.tagName.toLowerCase() === 'iframe' || node.tagName.toLowerCase() === 'body') {
      const attributeNames = node.getAttributeNames?.() || [];
      for (const name of attributeNames) {
        nodeData.attributes[name] = node.getAttribute(name);
      }
    }

    // Check Scrollability
    if (node.nodeType === Node.ELEMENT_NODE) {
      nodeData.isVisible = isElementVisible(node);
      if (nodeData.isVisible) {
        nodeData.isTopElement = isTopElement(node);
        if (nodeData.isTopElement) {
          // check if it is scrollable
          const scrollStatus = isElementScrollable(node);
          if (scrollStatus.horizontal || scrollStatus.vertical) {
            nodeData.isScrollable = true;
            nodeData.isVerticalScrollable = scrollStatus.vertical;
            nodeData.isHorizontalScrollable = scrollStatus.horizontal;
            nodeData.scrollableIndex = scrollableIndex++;
            nodeData.rectangle = node.getBoundingClientRect();
            nodeData.className = node.className.trim();
            nodeData.scrollHeight = node.scrollHeight;
            nodeData.scrollWidth = node.scrollWidth;
            nodeData.scrollTop = node.scrollTop;
            nodeData.scrollLeft = node.scrollLeft;
            nodeData.clientHeight = node.clientHeight;
            nodeData.clientWidth = node.clientWidth;
            nodeData.visibleRect = getEffectiveVisibleRect(node);
            scrollableElements.push(nodeData)

            if (doHighlightElements) {
              highlightElement(node, nodeData.scrollableIndex, parentIframe);
            }
          } else {
            nodeData.isScrollable = false;
          }
        }
      }
    }

    // Process children, with special handling for iframes and rich text editors
    if (node.tagName) {
      const tagName = node.tagName.toLowerCase();

      // Handle iframes
      if (tagName === "iframe") {
        try {
          const iframeDoc = node.contentDocument || node.contentWindow?.document;
          if (iframeDoc) {
            for (const child of iframeDoc.childNodes) {
              const domElement = buildDomTree(child, node);
              if (domElement) nodeData.children.push(domElement);
            }
          }
        } catch (e) {
          console.warn("Unable to access iframe:", e);
        }
      }
      // Handle rich text editors and contenteditable elements
      else if (
        node.isContentEditable ||
        node.getAttribute("contenteditable") === "true" ||
        node.id === "tinymce" ||
        node.classList.contains("mce-content-body") ||
        (tagName === "body" && node.getAttribute("data-id")?.startsWith("mce_"))
      ) {
        // Process all child nodes to capture formatted text
        for (const child of node.childNodes) {
          const domElement = buildDomTree(child, parentIframe);
          if (domElement) nodeData.children.push(domElement);
        }
      }
      // Handle shadow DOM
      else if (node.shadowRoot) {
        nodeData.shadowRoot = true;
        for (const child of node.shadowRoot.childNodes) {
          const domElement = buildDomTree(child, parentIframe);
          if (domElement) nodeData.children.push(domElement);
        }
      }
      // Handle regular elements
      else {
        for (const child of node.childNodes) {
          const domElement = buildDomTree(child, parentIframe);
          if (domElement) nodeData.children.push(domElement);
        }
      }
    }

    // Skip empty anchor tags
    if (nodeData.tagName === 'a' && nodeData.children.length === 0 && !nodeData.attributes.href) {
      return null;
    }

    return `${ID.current++}`;
  }

  function isElementActuallyScrollable(ele) {
    let vertical = false;
    let horizontal = false;

    if (ele.scrollHeight > ele.clientHeight) {
      if (ele.scrollTop > 0) {
        vertical = true;
      } else {
        ele.scrollTop++;
        // 元素不能滚动的话，scrollTop 设置不会生效，还会置为 0
        const top = ele.scrollTop;
        // 重置滚动位置
        top && (ele.scrollTop = 0);
        vertical = top > 0;
      }
    }

    if (ele.scrollWidth > ele.clientWidth) {
      if (ele.scrollLeft > 0) {
        horizontal = true;
      } else {
        ele.scrollLeft++;
        // 元素不能滚动的话，scrollLeft 设置不会生效，还会置为 0
        const left = ele.scrollLeft;
        // 重置滚动位置
        left && (ele.scrollLeft = 0);
        horizontal = left > 0;
      }
    }

    return { vertical, horizontal };
  }

  function isElementScrollable(ele) {
    // 如果可以竖向滚动
    let vertical = false;
    let horizontal = false;

    const isRoot = ele === document.documentElement || ele === document.body;
    const style = window.getComputedStyle(ele);
    const overflowY = style.overflowY;
    const overflowX = style.overflowX;

    const scrollStatus = isElementActuallyScrollable(ele);

    if (isRoot) {
      return scrollStatus;
    } else {
      // 样式检查
      const verticalInStyle = overflowY === 'auto' || overflowY === 'scroll';
      const horizontalInStyle = overflowX === 'auto' || overflowX === 'scroll';

      vertical = verticalInStyle && scrollStatus.vertical;
      horizontal = horizontalInStyle && scrollStatus.horizontal;
    }

    return { vertical, horizontal };
  }

  // Special handling for document
  const scrollStatus = isElementScrollable(document.documentElement);
  if (scrollStatus.horizontal || scrollStatus.vertical) {
    const nodeData = {
      tagName: 'documentElement',
      attributes: {},
      xpath: 'html',
      children: [],
      isScrollable: true,
      isVerticalScrollable: scrollStatus.vertical,
      isHorizontalScrollable: scrollStatus.horizontal,
      scrollableIndex: scrollableIndex++,
      isVisible: isElementVisible(document.documentElement),
      isTopElement: isTopElement(document.documentElement),
      rectangle: document.documentElement.getBoundingClientRect(),
      // Copy the full HTML for the element
      // fullHTML: document.documentElement.outerHTML,
      className: document.documentElement.className.trim(),
      scrollHeight: document.documentElement.scrollHeight,
      scrollWidth: document.documentElement.scrollWidth,
      scrollTop: document.documentElement.scrollTop,
      scrollLeft: document.documentElement.scrollLeft,
      clientHeight: document.documentElement.clientHeight,
      clientWidth: document.documentElement.clientWidth,
      visibleRect: getEffectiveVisibleRect(document.documentElement),
    };
    scrollableElements.push(nodeData)

    if (doHighlightElements) {
      highlightElement(document.documentElement, nodeData.scrollableIndex, null);
    }
  }

  buildDomTree(document.body);
  // Clear the cache before starting
  DOM_CACHE.clearCache();

  return scrollableElements;
};
