from dataclasses import dataclass
from functools import cached_property
from typing import TYPE_CHECKING, Dict, List, Optional, Callable

from bs4 import BeautifulSoup

from browser_use.dom.history_tree_processor.view import CoordinateSet, HashedDomElement, ViewportInfo
from browser_use.utils import normalize_box_2d, box_2d_to_box_prompt


# Avoid circular import issues
if TYPE_CHECKING:
    from .views import DOMElementNode


@dataclass(frozen=False)
class DOMBaseNode:
    is_visible: bool
    # Use None as default and set parent later to avoid circular reference issues
    parent: Optional['DOMElementNode']


@dataclass(frozen=False)
class DOMTextNode(DOMBaseNode):
    text: str
    type: str = 'TEXT_NODE'

    def has_parent_with_highlight_index(self) -> bool:
        current = self.parent
        while current is not None:
            # stop if the element has a highlight index (will be handled separately)
            if current.highlight_index is not None:
                return True

            current = current.parent
        return False

    def is_parent_in_viewport(self) -> bool:
        if self.parent is None:
            return False
        return self.parent.is_in_viewport

    def is_parent_top_element(self) -> bool:
        if self.parent is None:
            return False
        return self.parent.is_top_element


@dataclass(frozen=False)
class DOMElementNode(DOMBaseNode):
    """
    xpath: the xpath of the element from the last root node (shadow root or iframe OR document if no shadow root or iframe).
    To properly reference the element we need to recursively switch the root node until we find the element (work you way up the tree with `.parent`)
    """

    tag_name: str
    xpath: str
    attributes: Dict[str, str]
    children: List[DOMBaseNode]
    is_interactive: bool = False
    is_top_element: bool = False
    is_in_viewport: bool = False
    shadow_root: bool = False
    highlight_index: Optional[int] = None
    viewport_coordinates: Optional[CoordinateSet] = None
    page_coordinates: Optional[CoordinateSet] = None
    viewport_info: Optional[ViewportInfo] = None
    rectangle: Optional[Dict] = None
    full_html: Optional[str] = None
    class_name: Optional[str] = None

    is_scrollable: bool = False
    is_vertical_scrollable: bool = False
    is_horizontal_scrollable: bool = False
    scrollable_index: Optional[int] = None
    scroll_height: Optional[int] = None
    scroll_width: Optional[int] = None
    scroll_top: Optional[int] = None
    scroll_left: Optional[int] = None
    client_height: Optional[int] = None
    client_width: Optional[int] = None
    visible_rect: Optional[Dict] = None

    def __repr__(self) -> str:
        tag_str = f'<{self.tag_name}'

        # Add attributes
        for key, value in self.attributes.items():
            tag_str += f' {key}="{value}"'
        tag_str += '>'

        # Add extra info
        extras = []
        if self.is_interactive:
            extras.append('interactive')
        if self.is_top_element:
            extras.append('top')
        if self.shadow_root:
            extras.append('shadow-root')
        if self.highlight_index is not None:
            extras.append(f'highlight:{self.highlight_index}')
        if self.is_in_viewport:
            extras.append('in-viewport')
        if self.is_scrollable:
            extras.append(f'scrollable: {self.scrollable_index}')

        if extras:
            tag_str += f' [{", ".join(extras)}]'

        return tag_str

    @cached_property
    def hash(self) -> HashedDomElement:
        from browser_use.dom.history_tree_processor.service import (
            HistoryTreeProcessor,
        )

        return HistoryTreeProcessor._hash_dom_element(self)

    def get_all_text_till_next_clickable_element(self, max_depth: int = -1) -> str:
        text_parts = []

        def collect_text(node: DOMBaseNode, current_depth: int) -> None:
            if max_depth != -1 and current_depth > max_depth:
                return

            # Skip this branch if we hit a highlighted element (except for the current node)
            if isinstance(node, DOMElementNode) and node != self and node.highlight_index is not None:
                return

            if isinstance(node, DOMTextNode):
                text_parts.append(node.text)
            elif isinstance(node, DOMElementNode):
                for child in node.children:
                    collect_text(child, current_depth + 1)

        collect_text(self, 0)
        return '\n'.join(text_parts).strip()

    def clickable_elements_to_string(
            self,
            include_attributes: Optional[List[str]] = None,
            include_offscreen_elements: bool = True,
            height: int = None,
            width: int = None,
            box_format: str = 'tlbr'
    ) -> str:
        """Convert the processed DOM content to HTML."""
        on_screen_formatted_text = []
        off_screen_formatted_text = []

        def process_node(node: DOMBaseNode, depth: int) -> None:
            if isinstance(node, DOMElementNode):
                # Add element with highlight_index
                if node.highlight_index is not None:
                    attributes_str = ''
                    text = node.get_all_text_till_next_clickable_element()
                    if include_attributes:
                        attributes = list(
                            set(
                                [
                                    str(value)
                                    for key, value in node.attributes.items()
                                    if key in include_attributes and value != node.tag_name
                                ]
                            )
                        )
                        if text in attributes:
                            attributes.remove(text)
                        attributes_str = ';'.join(attributes)
                    line = f'[{node.highlight_index}]<{node.tag_name} '
                    if attributes_str:
                        line += f'{attributes_str}'
                    line += f'>'
                    if text:
                        line += f'{text}'
                    line += f'</{node.tag_name}>'
                    if (
                            height is not None
                            and width is not None
                            and hasattr(node, "rectangle")
                            and node.rectangle is not None
                    ):
                        top, left, bottom, right = (
                            node.rectangle["top"], node.rectangle["left"],
                            node.rectangle["bottom"], node.rectangle["right"]
                        )
                        top, left, bottom, right = normalize_box_2d([top, left, bottom, right], height, width)

                        center_x = (left + right) / 2
                        center_y = (top + bottom) / 2
                        if 0 <= center_x <= 1000 and 0 <= center_y <= 1000:
                            box_prompt = box_2d_to_box_prompt(box_format, [top, left, bottom, right])
                            line += f'   {{"box_2d": {box_prompt}}}'
                            on_screen_formatted_text.append(line)
                        else:
                            off_screen_formatted_text.append(line)
                    else:
                        off_screen_formatted_text.append(line)

                # Process children regardless
                for child in node.children:
                    process_node(child, depth + 1)

            elif isinstance(node, DOMTextNode):
                # Add text only if it doesn't have a highlighted parent
                if not node.has_parent_with_highlight_index():
                    if node.is_parent_top_element():
                        on_screen_formatted_text.append(f'{node.text}')
                    else:
                        off_screen_formatted_text.append(f'{node.text}')

        process_node(self, 0)
        # return '\n'.join(visible_formatted_text)
        on_screen_formatted_text = '\n'.join(on_screen_formatted_text)
        off_screen_formatted_text = '\n'.join(off_screen_formatted_text)
        description = f"""
[On-screen elements start]
{on_screen_formatted_text}
[On-screen elements end]
"""
        if include_offscreen_elements:
            description += f"""
[Off-screen or obscured elements start]
{off_screen_formatted_text}
[Off-screen or obscured elements end]
"""
        return description

    def get_file_upload_element(self, check_siblings: bool = True) -> Optional['DOMElementNode']:
        # Check if current element is a file input
        if self.tag_name == 'input' and self.attributes.get('type') == 'file':
            return self

        # Check children
        for child in self.children:
            if isinstance(child, DOMElementNode):
                result = child.get_file_upload_element(check_siblings=False)
                if result:
                    return result

        # Check siblings only for the initial call
        if check_siblings and self.parent:
            for sibling in self.parent.children:
                if sibling is not self and isinstance(sibling, DOMElementNode):
                    result = sibling.get_file_upload_element(check_siblings=False)
                    if result:
                        return result

        return None

    def generate_xpath(self, contain_class: bool = False) -> str:
        xpath_str = f'//{self.xpath}'
        if contain_class:
            classes = self.class_name.split(' ')
            if classes:
                classes_str = " and ".join([f"contains(@class, '{cls}')" for cls in classes])
                xpath_str += f"[{classes_str}]"
        return xpath_str

    def recursively_get_all_children(self, filter_func: Callable = None) -> List[DOMBaseNode]:
        children = []
        if filter_func is None or filter_func(self):
            children.append(self)
        for child in self.children:
            if isinstance(child, DOMElementNode):
                children.extend(child.recursively_get_all_children(filter_func))
            elif isinstance(child, DOMTextNode) and (filter_func is None or filter_func(child)):
                children.append(child)
        return children


SelectorMap = dict[int, DOMElementNode]


@dataclass
class DOMState:
    element_tree: DOMElementNode
    selector_map: SelectorMap


class ScrollableElements(dict):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        assert all(
            isinstance(index, int) and isinstance(element, DOMElementNode)
            for index, element in self.items()
        ), "All keys must be integers and all values must be DOMElementNode."

    def scrollable_elements_to_string(self, height: int = None, width: int = None, box_format: str = "tlbr"):
        kvs = sorted(self.items(), key=lambda x: x[0])
        lines = []
        for index, element in kvs:
            if (
                    height is not None
                    and width is not None
                    and hasattr(element, "visible_rect")
                    and element.visible_rect is not None
            ):
                line = f'[{index}]<{element.tag_name}> </{element.tag_name}>'
                box_2d = (
                    element.visible_rect["top"], element.visible_rect["left"],
                    element.visible_rect["bottom"], element.visible_rect["right"],
                )
                box_2d = normalize_box_2d(box_2d, height, width)
                box_prompt = box_2d_to_box_prompt(box_format, box_2d)
                line += f'   {{' \
                        f'"box_2d": {box_prompt}, ' \
                        f'"visible_height": {element.visible_rect["height"]}, ' \
                        f'"visible_width": {element.visible_rect["width"]}, ' \
                        f'"vertical_scrollable": {element.is_vertical_scrollable}, ' \
                        f'"horizontal_scrollable": {element.is_horizontal_scrollable}' \
                        f'}}\n'
                lines.append(line)

        if lines:
            return "\n".join(lines) + '\n'
        else:
            return "No scrollable elements."
