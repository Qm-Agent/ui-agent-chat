import os
from pathlib import Path
from dotenv import load_dotenv

project_root = Path(__file__).parent.resolve()

cwd = Path.cwd()
if os.getenv("BU_ENV_ISOLATED") == "1":
    # Skill entrypoint already resolved its explicit config; ignore ambient .env.
    pass
elif (cwd / ".env").exists():
    print("⚠️ .env file found in current working directory.")
    load_dotenv(cwd / ".env")
elif (Path(__file__).parent / ".env").exists():
    print("⚠️ .env file found in script directory.")
    load_dotenv(Path(__file__).parent / ".env")
elif os.getenv("DOTENV_PATH") and Path(os.getenv("DOTENV_PATH")).exists():
    print(f"⚠️ .env file found at {os.getenv('DOTENV_PATH')}.")
    load_dotenv(os.getenv("DOTENV_PATH"))
else:
    print("⚠️ .env file not found, using environment variables.")

from browser_use.agent.prompts import SystemPrompt as SystemPrompt
from browser_use.agent.service import Agent
from browser_use.agent.views import ActionModel as ActionModel
from browser_use.agent.views import ActionResult as ActionResult
from browser_use.agent.views import AgentHistoryList as AgentHistoryList
from browser_use.browser.browser import Browser as Browser
from browser_use.browser.browser import BrowserConfig as BrowserConfig
from browser_use.browser.context import BrowserContextConfig
from browser_use.controller.service import Controller as Controller
from browser_use.dom.service import DomService as DomService

__all__ = [
    'project_root',
    'Agent',
    'Browser',
    'BrowserConfig',
    'Controller',
    'DomService',
    'SystemPrompt',
    'ActionResult',
    'ActionModel',
    'AgentHistoryList',
    'BrowserContextConfig',
]
