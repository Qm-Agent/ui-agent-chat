from typing import Optional

from pydantic import BaseModel, model_validator, Field, conlist, ValidationError, ConfigDict


# Action Input Models
class SearchGoogleAction(BaseModel):
    query: str


class GoToUrlAction(BaseModel):
    url: str


class ScrollToTextAction(BaseModel):
    text: str


class WaitAction(BaseModel):
    seconds: float = 8.


class ClickElementAction(BaseModel):
    box_2d: conlist(int, min_length=4, max_length=4)
    # str 类型 description为详细介绍
    detailed_element_description: str = Field(
        ...,
        description="MUST includes the visual description of the element (shape of element, "
                    "what it looks like and text within the element if any), the element's position on the page, "
                    "its relative position to other elements."
    )
    hover: bool = True


class InputTextAction(BaseModel):
    box_2d: conlist(int, min_length=4, max_length=4)
    text: str
    detailed_input_field_description: str = Field(
        ...,
        description="MUST includes the visual description of the input field "
                    "(what it looks like and default text within the element if any), "
                    "the position of input field on the page, its relative position to other elements."
    )


class ClearInputTextAction(BaseModel):
    box_2d: conlist(int, min_length=4, max_length=4)
    detailed_input_field_description: str = Field(
        ...,
        description="MUST includes the visual description of the input field "
                    "(what it looks like and default text within the element if any), "
                    "the position of input field on the page, its relative position to other elements."
    )


class DoneAction(BaseModel):
    text: str
    success: bool


class SwitchTabAction(BaseModel):
    page_id: int


class OpenTabAction(BaseModel):
    url: str


class ScrollAction(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True, extra="allow")

    point_2d: conlist(int, min_length=2, max_length=2) = Field(
        ...,
        description="The cursor coordinate to scroll, or the center of the scrolling area. Expected format: [x, y]"
    )
    amount: Optional[int] = None  # The number of pixels to scroll. If None, scroll down/up one page


class SendKeysAction(BaseModel):
    keys: str


class UploadFileAction(BaseModel):
    path: str = Field(
        ...,
        description=(
            "Absolute or relative local file path to upload. Use the exact path from the task when provided."
        ),
    )
    locate: Optional[str] = Field(
        default=None,
        description=(
            "Optional Playwright selector for a file input or a scoped upload container. "
            "Prefer leaving this empty unless you know the exact selector; the uploader will fall back to "
            "all input[type=file] elements. Do not invent pseudo selectors."
        ),
    )
    upload_index: Optional[int] = Field(
        default=None,
        description=(
            "Optional zero-based index when multiple matching file inputs exist. "
            "Leave empty to automatically pick the best candidate."
        ),
    )


class ExtractPageContentAction(BaseModel):
    query: str


class HoverAction(BaseModel):
    box_2d: conlist(int, min_length=4, max_length=4)
    detailed_element_description: str


class NoParamsAction(BaseModel):
    """
    Accepts absolutely anything in the incoming data
    and discards it, so the final parsed model is empty.
    """

    @model_validator(mode='before')
    def ignore_all_inputs(cls, values):
        # No matter what the user sends, discard it and return empty.
        return {}

    class Config:
        # If you want to silently allow unknown fields at top-level,
        # set extra = 'allow' as well:
        extra = 'allow'


if __name__ == '__main__':
    try:
        SearchGoogleAction(query=1)
    except ValidationError as e:
        print(e)
