import asyncio
import json
import logging
import re
import time
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, Generic, List, Optional, TypeVar

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import HumanMessage
from playwright.async_api import BrowserContext as PlaywrightBrowserContext
from playwright.async_api import Locator
from playwright.async_api import Page

from browser_use.agent.code_generation import (
    convert_clear_input_text_action,
    convert_click_action,
    convert_done_action,
    convert_go_back_action,
    convert_go_to_url_action,
    convert_hover_action,
    convert_input_text_action,
    convert_open_tab_action,
    convert_scroll_down_action,
    convert_scroll_left_action,
    convert_scroll_right_action,
    convert_scroll_to_text_action,
    convert_scroll_up_action,
    convert_search_google_action,
    convert_send_keys_action,
    convert_switch_tab_action,
    convert_wait_action,
)
from browser_use.agent.message_manager.utils import parse_response
from browser_use.agent.prompts import LocatingLLMPrompt
from browser_use.agent.views import ActionModel, ActionResult
from browser_use.browser.context import BrowserContext  # noqa: E125
from browser_use.controller.registry.service import Registry
from browser_use.controller.utils import (
    calculate_iou_tolerance,
    find_semantic_interactive_ancestor,
    locate_element_in_dom_tree_with_box_2d,
    match_element_with_box_2d,
)
from browser_use.controller.views import (
    ClearInputTextAction,
    ClickElementAction,
    DoneAction,
    ExtractPageContentAction,
    GoToUrlAction,
    HoverAction,
    InputTextAction,
    NoParamsAction,
    OpenTabAction,
    ScrollAction,
    ScrollToTextAction,
    SearchGoogleAction,
    SendKeysAction,
    SwitchTabAction,
    UploadFileAction,
    WaitAction,
)
from browser_use.utils import (
    VARIABLE_PATTERN,
    box_2d_to_rectangle,
    calculate_iou,
    log_llm_call_stats,
    rectangle_to_box_2d,
    replace_variable_placeholders_in_string,
    substitute_variables,
    time_execution_sync,
    unnormalize_box_2d,
    unnormalize_point_2d,
)

logger = logging.getLogger(__name__)

Context = TypeVar('Context')


def _normalize_upload_locate_candidates(locate: Optional[str]) -> List[str]:
    raw_locate = (locate or "").strip()
    if not raw_locate:
        return ['input[type="file"]']

    candidates = [raw_locate]

    # LLMs sometimes produce pseudo syntax such as:
    #   div:has-text="点击上传或拖拽文件到此处"
    # Playwright expects :has-text("...").
    normalized = re.sub(
        r':has-text=(["\'])(.*?)\1',
        lambda m: f':has-text("{m.group(2)}")',
        raw_locate,
    )
    if normalized != raw_locate:
        candidates.append(normalized)

    candidates.append('input[type="file"]')

    deduped: List[str] = []
    for candidate in candidates:
        if candidate and candidate not in deduped:
            deduped.append(candidate)
    return deduped


async def _safe_locator_count(locator: Locator, selector: str) -> Optional[int]:
    try:
        return await locator.count()
    except Exception as e:
        logger.info("upload: locator %r is not usable (%s); trying fallback", selector, e)
        return None


async def _resolve_file_upload_locator(
        page: Page,
        locate: Optional[str],
        upload_index: Optional[int],
) -> tuple[Locator, str]:
    """
    Pick a file input for Playwright set_input_files.
    The OS file chooser is outside browser screenshots, so upload automation must target input[type=file] directly.
    """
    raw_locate = (locate or "").strip()
    base: Optional[Locator] = None
    count = 0
    selected_scope = ""

    for candidate in _normalize_upload_locate_candidates(raw_locate):
        candidate_locator = page.locator(candidate)
        candidate_count = await _safe_locator_count(candidate_locator, candidate)
        if not candidate_count:
            continue

        if 'input' in candidate and 'type=file' in candidate.replace('"', '').replace("'", ""):
            base = candidate_locator
            count = candidate_count
            selected_scope = candidate
            break

        scoped_inputs = candidate_locator.locator('input[type="file"]')
        scoped_count = await _safe_locator_count(scoped_inputs, f'{candidate} >> input[type="file"]')
        if scoped_count:
            base = scoped_inputs
            count = scoped_count
            selected_scope = f'{candidate} >> input[type="file"]'
            break

        logger.info(
            "upload: locator %r matched %s element(s), but none contained input[type=file]; trying fallback",
            candidate,
            candidate_count,
        )

    if count == 0:
        hint = raw_locate if raw_locate else 'input[type="file"]'
        raise ValueError(f"No file upload control matched ({hint})")

    if upload_index is not None:
        if upload_index < 0 or upload_index >= count:
            raise IndexError(
                f"upload_index {upload_index} is out of range for {count} matching element(s)"
            )
        picked = base.nth(upload_index)
        desc = (
            f"{selected_scope!r} nth={upload_index}"
            if selected_scope
            else f'input[type="file"] nth={upload_index}'
        )
        return picked, desc

    if count == 1:
        desc = repr(selected_scope) if selected_scope else 'input[type="file"]'
        return base.nth(0), f"{desc} (single match)"

    scored: List[tuple[int, int, float]] = []
    for i in range(count):
        loc = base.nth(i)
        try:
            visible = await loc.is_visible()
        except Exception:
            visible = False
        box = await loc.bounding_box()
        area = float(box["width"] * box["height"]) if box else 0.0
        score = 0
        if visible:
            score += 10
        if area > 4.0:
            score += 5
        elif area > 0.0:
            score += 2
        scored.append((i, score, area))

    scored.sort(key=lambda t: (-t[1], -t[2], t[0]))
    best_i = scored[0][0]
    scope = selected_scope if selected_scope else "input[type=file]"
    logger.info(
        "upload: locator %r matched %s file input(s); picked index %s (prefer visible / non-trivial size)",
        scope,
        count,
        best_i,
    )
    return base.nth(best_i), f"{scope!r} nth={best_i}"


def _find_scrollable_element_index_at_point(
        point_2d: List[int],
        scrollable_elements: Dict[int, Any],
        page_height: int,
        page_width: int,
) -> Optional[int]:
    cursor_y, cursor_x = unnormalize_point_2d(point_2d, page_height, page_width)
    scrollable_element_index = None
    for index, element in scrollable_elements.items():
        if (
                element.rectangle["x"] <= cursor_x <= element.rectangle["x"] + element.rectangle["width"]
                and element.rectangle["y"] <= cursor_y <= element.rectangle["y"] + element.rectangle["height"]
        ):
            scrollable_element_index = index
    return scrollable_element_index


class Controller(Generic[Context]):
    def __init__(
            self,
            exclude_actions: Optional[List[str]] = None,
            codify: bool = True,
            codify_functions: Optional[Dict[str, Callable[..., Awaitable[Any]]]] = None,
            actor_box_format: str = "ltrb",
            locating_llm_box_format: str = "ltrb",
    ):
        if exclude_actions is None:
            exclude_actions = []

        box_format_to_box_parser = {
            "ltrb": lambda box: [box[1], box[0], box[3], box[2]],
            "tlbr": lambda box: box,
        }
        box_format_to_point_parser = {
            "ltrb": lambda point: [point[1], point[0]],
            "tlbr": lambda point: point,
        }
        self.actor_box_parser = box_format_to_box_parser[actor_box_format]
        self.actor_point_parser = box_format_to_point_parser[actor_box_format]
        self.locating_llm_box_parser = box_format_to_box_parser[locating_llm_box_format]

        self.codify = codify
        self.codify_functions = codify_functions or {
            "done": convert_done_action,
            "click": convert_click_action,
            "go_to_url": convert_go_to_url_action,
            "open_tab": convert_open_tab_action,
            "scroll_down": convert_scroll_down_action,
            "scroll_up": convert_scroll_up_action,
            "scroll_right": convert_scroll_right_action,
            "scroll_left": convert_scroll_left_action,
            "scroll_to_text": convert_scroll_to_text_action,
            "send_keys": convert_send_keys_action,
            "search_google": convert_search_google_action,
            "go_back": convert_go_back_action,
            "wait": convert_wait_action,
            "input_text": convert_input_text_action,
            "switch_tab": convert_switch_tab_action,
            "clear_input_text": convert_clear_input_text_action,
            "hover": convert_hover_action,
        }
        self.registry = Registry[Context](exclude_actions, self.codify, self.codify_functions)

        @self.registry.action(
            'Complete task, finish waiting or proceed to the next step'
            ' - with return text and if the task is finished (success=True) '
            'or not yet completely finished (success=False), because last step is reached',
            param_model=DoneAction,
        )
        async def done(
                params: DoneAction,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            codified = None
            if codify_function:
                try:
                    codified = await codify_function(params)
                except Exception as e:
                    logger.exception(f"When codifying done action {params.model_dump()}, error occurs: {e}")

            return ActionResult(
                is_done=True,
                success=params.success,
                extracted_content=params.text,
                codified=codified,
            )

        @self.registry.action(
            'Search the query in Google in the current tab, '
            'the query should be a search query like humans search in Google, '
            'concrete and not vague or super long. More the single most important items. ',
            param_model=SearchGoogleAction,
        )
        async def search_google(
                params: SearchGoogleAction,
                browser_context: BrowserContext,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            page = await browser_context.get_current_page()

            codified = None
            if codify_function:
                try:
                    codified = await codify_function(params)
                except Exception as e:
                    logger.exception(f"When codifying search_google action {params.model_dump()}, error occurs: {e}")

            await page.goto(f'https://www.google.com/search?q={params.query}&udm=14')
            await page.wait_for_load_state()
            msg = f'🔍  Searched for "{params.query}" in Google'
            logger.info(msg)
            return ActionResult(extracted_content=msg, codified=codified)

        @self.registry.action('Navigate to URL in the current tab', param_model=GoToUrlAction)
        async def go_to_url(
                params: GoToUrlAction,
                browser_context: BrowserContext,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            page = await browser_context.get_current_page()

            codified = None
            if codify_function:
                try:
                    codified = await codify_function(params)
                except Exception as e:
                    logger.exception(f"When codifying go_to_url action {params.model_dump()}, error occurs: {e}")

            await page.goto(params.url)
            await page.wait_for_load_state()
            msg = f'🔗  Navigated to {params.url}'
            logger.info(msg)
            return ActionResult(extracted_content=msg, codified=codified)

        @self.registry.action('Go back', param_model=NoParamsAction)
        async def go_back(
                params: NoParamsAction,
                browser_context: BrowserContext,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            codified = None
            if codify_function:
                try:
                    codified = await codify_function(params)
                except Exception as e:
                    logger.exception(f"When codifying go_back action {params.model_dump()}, error occurs: {e}")

            await browser_context.go_back()
            msg = '🔙  Navigated back'
            logger.info(msg)
            return ActionResult(extracted_content=msg, codified=codified)

        # wait for x seconds
        @self.registry.action(
            'Wait for x seconds default 8',
            param_model=WaitAction,
        )
        async def wait(
                params: WaitAction,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            codified = None
            if codify_function:
                try:
                    codified = await codify_function(params)
                except Exception as e:
                    logger.exception(f"When codifying wait action {params.model_dump()}, error occurs: {e}")

            msg = f'🕒  Waiting for {params.seconds} seconds'
            logger.info(msg)
            time.sleep(params.seconds)
            return ActionResult(extracted_content=msg, codified=codified)

        # Element Interaction Actions
        @self.registry.action(
            'Input text into a input interactive element',
            param_model=InputTextAction,
        )
        async def input_text(
                params: InputTextAction,
                browser_context: BrowserContext,
                locating_llm: Optional[BaseChatModel] = None,
                has_sensitive_data: bool = False,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
                context: Optional[Dict[str, Any]] = None,
        ):
            # 先用 named_results 替换 ${name}，再用 env 替换
            if context and context.get("named_results"):
                params.text = substitute_variables(params.text, context["named_results"])
            params.text = replace_variable_placeholders_in_string(
                params.text, VARIABLE_PATTERN, keep_if_missing=True
            )
            # first thing first, parse box to tlbr format
            params.box_2d = self.actor_box_parser(params.box_2d)

            session = await browser_context.get_session()
            visible_interactive_elements = await browser_context.get_inview_interactive_elements()
            page_width, page_height = await browser_context.get_page_size()
            unnormalized_box_2d = unnormalize_box_2d(params.box_2d, page_height, page_width)
            matched_element, max_iou = match_element_with_box_2d(
                box_2d=unnormalized_box_2d,
                elements=visible_interactive_elements.values(),
            )

            # 当匹配到非语义化标签，优先使用语义化交互祖先
            semantic_ancestor = find_semantic_interactive_ancestor(matched_element)
            if semantic_ancestor is not None:
                logger.info(
                    f'Matched <{matched_element.tag_name}> (IoU={max_iou:.2f}), '
                    f'promoting to semantic interactive ancestor <{semantic_ancestor.tag_name}>'
                )
                matched_element = semantic_ancestor
                max_iou = calculate_iou(
                    (unnormalized_box_2d[1], unnormalized_box_2d[0],
                     unnormalized_box_2d[3], unnormalized_box_2d[2]),
                    (semantic_ancestor.rectangle["left"], semantic_ancestor.rectangle["top"],
                     semantic_ancestor.rectangle["right"], semantic_ancestor.rectangle["bottom"]),
                )

            rectangle = matched_element.rectangle
            iou_tolerance = calculate_iou_tolerance(params.box_2d, max_tolerance=0.5)

            if max_iou < iou_tolerance and locating_llm:
                logger.warning(f"Matching with actor box_2d: {params.box_2d} fail, now retry with locating llm.")
                rectangle = await self.locate_element_with_locating_llm(
                    locating_llm,
                    params.detailed_input_field_description,
                    session.cached_state.screenshot,
                    browser_context,
                )
            params.box_2d = rectangle_to_box_2d(rectangle, page_height, page_width)
            updated_params = {"box_2d": params.box_2d, "text": params.text}

            codified = None
            if codify_function:
                try:
                    codified = await codify_function(params, browser_context)
                except Exception as e:
                    logger.exception(f"When codifying input_text action {params.model_dump()}, error occurs: {e}")

            await browser_context.input_text_rectangle(rectangle, params.text)
            if not has_sensitive_data:
                msg = f'⌨️  Input {params.text} into rectangle: {rectangle}'
            else:
                msg = f'⌨️  Input sensitive data into rectangle: {rectangle}'
            logger.info(msg)
            return ActionResult(
                extracted_content=msg,
                updated_params=updated_params,
                codified=codified,
            )

        @self.registry.action(
            "Click element. The description should contain element position in the page, appearance and text.",
            param_model=ClickElementAction
        )
        async def click(
                params: ClickElementAction,
                browser_context: BrowserContext,
                locating_llm: Optional[BaseChatModel] = None,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            # first thing first, parse box to tlbr format
            params.box_2d = self.actor_box_parser(params.box_2d)

            session = await browser_context.get_session()

            visible_interactive_elements = await browser_context.get_inview_interactive_elements()
            page_width, page_height = await browser_context.get_page_size()
            unnormalized_box_2d = unnormalize_box_2d(params.box_2d, page_height, page_width)
            matched_element, max_iou = match_element_with_box_2d(
                box_2d=unnormalized_box_2d,
                elements=visible_interactive_elements.values(),
            )

            # 当匹配到非语义化标签（如 <span>），优先使用语义化交互祖先（如 <button>）
            semantic_ancestor = find_semantic_interactive_ancestor(matched_element)
            if semantic_ancestor is not None:
                logger.info(
                    f'Matched <{matched_element.tag_name}> (IoU={max_iou:.2f}), '
                    f'promoting to semantic interactive ancestor <{semantic_ancestor.tag_name}>'
                )
                matched_element = semantic_ancestor
                max_iou = calculate_iou(
                    (unnormalized_box_2d[1], unnormalized_box_2d[0],
                     unnormalized_box_2d[3], unnormalized_box_2d[2]),
                    (semantic_ancestor.rectangle["left"], semantic_ancestor.rectangle["top"],
                     semantic_ancestor.rectangle["right"], semantic_ancestor.rectangle["bottom"]),
                )

            rectangle = matched_element.rectangle
            iou_tolerance = calculate_iou_tolerance(params.box_2d, max_tolerance=0.5, min_tolerance=0.33)

            if max_iou < iou_tolerance and locating_llm:
                logger.warning(f"Matching with actor box_2d: {params.box_2d} fail, now retry with locating llm.")
                rectangle = await self.locate_element_with_locating_llm(
                    locating_llm,
                    params.detailed_element_description,
                    session.cached_state.screenshot,
                    browser_context,
                )
            box_2d = rectangle_to_box_2d(rectangle, page_height, page_width)
            params.box_2d = box_2d
            updated_params = {"box_2d": box_2d}

            pages_before_action = session.context.pages
            try:
                codified = None
                if codify_function:
                    try:
                        codified = await codify_function(params, browser_context)
                    except Exception as e:
                        logger.exception(f"When codifying click action {params.model_dump()}, error occurs: {e}")

                download_path = await browser_context.click(rectangle, params.hover)
                if download_path:
                    msg = f'💾  Downloaded file to {download_path}'
                else:
                    msg = f'🖱️  Clicked button with bounding box: {rectangle}'

                logger.info(msg)

                pages_after_action = session.context.pages
                new_pages = [p for p in pages_after_action if p not in pages_before_action]
                if new_pages:
                    new_page = new_pages[0]
                    logger.info("New page opened after clicking - switch to it.")
                    await new_page.bring_to_front()
                    await new_page.wait_for_load_state()

                return ActionResult(
                    extracted_content=msg,
                    updated_params=updated_params,
                    codified=codified,
                )
            except Exception as e:
                logger.warning(
                    f'Error occurs when clicking element with box_2d: {params.box_2d} '
                    f'"{params.detailed_element_description}"'
                    f'Error: {e}'
                )
                return ActionResult(error=str(e))

        @self.registry.action(
            "Upload a local file directly with Playwright set_input_files. "
            "Use this when the task asks to upload/choose/select/import a local file path. "
            "Do not wait for or operate the OS file chooser dialog because it is outside browser screenshots. "
            "Navigate to the page or step containing the upload control first, then call this action with the file path.",
            param_model=UploadFileAction,
        )
        async def upload(
                params: UploadFileAction,
                browser_context: BrowserContext,
        ):
            file_path = Path(params.path).expanduser()
            if not file_path.is_absolute():
                file_path = Path.cwd() / file_path
            file_path = file_path.resolve()
            if not file_path.exists():
                raise FileNotFoundError(f"Upload file does not exist: {file_path}")
            if not file_path.is_file():
                raise ValueError(f"Upload path is not a file: {file_path}")

            page = await browser_context.get_current_page()
            upload_locator, locator_note = await _resolve_file_upload_locator(
                page,
                params.locate,
                params.upload_index,
            )
            await upload_locator.set_input_files(str(file_path))
            msg = f"📎  Uploaded file {file_path} via {locator_note}"
            logger.info(msg)
            return ActionResult(extracted_content=msg)

        # Tab Management Actions
        @self.registry.action('Switch tab', param_model=SwitchTabAction)
        async def switch_tab(
                params: SwitchTabAction,
                browser_context: BrowserContext,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            codified = None
            if codify_function:
                try:
                    codified = await codify_function(params)
                except Exception as e:
                    logger.exception(f"When codifying switch_tab action {params.model_dump()}, error occurs: {e}")

            await browser_context.switch_to_tab(params.page_id)
            # Wait for tab to be ready
            page = await browser_context.get_current_page()
            await page.wait_for_load_state()
            msg = f'🔄  Switched to tab {params.page_id}'
            logger.info(msg)
            return ActionResult(extracted_content=msg, codified=codified)

        @self.registry.action('Open url in new tab', param_model=OpenTabAction)
        async def open_tab(
                params: OpenTabAction,
                browser_context: BrowserContext,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            codified = None
            if codify_function:
                try:
                    codified = await codify_function(params)
                except Exception as e:
                    logger.exception(f"When codifying open_tab action {params.model_dump()}, error occurs: {e}")

            await browser_context.create_new_tab(params.url)
            msg = f'🔗  Opened new tab with {params.url}'
            logger.info(msg)
            return ActionResult(extracted_content=msg, codified=codified)

        @self.registry.action(
            'Clear the text in a input interactive element',
            param_model=ClearInputTextAction,
        )
        async def clear_input_text(
                params: ClearInputTextAction,
                browser_context: BrowserContext,
                locating_llm: Optional[BaseChatModel] = None,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            # first thing first, parse box to tlbr format
            params.box_2d = self.actor_box_parser(params.box_2d)

            session = await browser_context.get_session()
            visible_interactive_elements = await browser_context.get_inview_interactive_elements()
            page_width, page_height = await browser_context.get_page_size()
            unnormalized_box_2d = unnormalize_box_2d(params.box_2d, page_height, page_width)
            matched_element, max_iou = match_element_with_box_2d(
                box_2d=unnormalized_box_2d,
                elements=visible_interactive_elements.values(),
            )
            rectangle = matched_element.rectangle
            iou_tolerance = calculate_iou_tolerance(params.box_2d, max_tolerance=0.5)

            if max_iou < iou_tolerance and locating_llm:
                logger.warning(f"Matching with actor box_2d: {params.box_2d} fail, now retry with locating llm.")
                rectangle = await self.locate_element_with_locating_llm(
                    locating_llm,
                    params.detailed_input_field_description,
                    session.cached_state.screenshot,
                    browser_context,
                )
            box_2d = rectangle_to_box_2d(rectangle, page_height, page_width)
            params.box_2d = box_2d
            updated_params = {"box_2d": box_2d}

            codified = None
            if codify_function:
                try:
                    codified = await codify_function(params, browser_context)
                except Exception as e:
                    logger.exception(f"When codifying clear_input_text action {params.model_dump()}, error occurs: {e}")

            await browser_context.clear_input_text_rectangle(rectangle)
            msg = f'⌨️  Clear text in a input field with rectangle: {rectangle}'
            logger.info(msg)
            return ActionResult(
                extracted_content=msg,
                updated_params=updated_params,
                codified=codified,
            )

        # Content Actions
        @self.registry.action(
            'Extract page content to retrieve specific information from the page, '
            'e.g. all company names, a specific description, all information about, '
            'links with companies in structured format or simply links',
            param_model=ExtractPageContentAction,
        )
        async def extract_content(
                params: ExtractPageContentAction,
                browser_context: BrowserContext,
                page_extraction_llm: BaseChatModel,
        ):
            session = await browser_context.get_session()
            screenshot_base64 = session.cached_state.screenshot

            input_message = [
                HumanMessage(
                    content=[
                        {
                            'type': 'text',
                            'text': f'''
Your task is to extract the content of the page.
You will be given a page and a goal and you should extract all relevant information around this goal from the page.
If the goal is vague, summarize the page. Respond in json format.
Extraction query: {params.query}.
'''
                        },
                        {
                            'type': 'image_url',
                            'image_url': {'url': f'data:image/png;base64,{screenshot_base64}'},
                        }
                    ]
                )
            ]

            try:
                log_llm_call_stats(page_extraction_llm, input_message)
                output = page_extraction_llm.invoke(input_message)
                msg = f'📄  Extracted from page: {output.content}'
                logger.info(msg)
                return ActionResult(extracted_content=msg)
            except Exception as e:
                msg = f"Error extracting content: {e}"
                logger.exception(msg)
                return ActionResult(extracted_content=msg)

        @self.registry.action(
            'Scroll down the page by pixel amount - '
            'if no amount is specified, scroll down visible height of this scrollable element.',
            param_model=ScrollAction,
        )
        async def scroll_down(
                params: ScrollAction,
                browser_context: BrowserContext,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            # first thing first, parse point to tlbr format
            params.point_2d = self.actor_point_parser(params.point_2d)

            page = await browser_context.get_current_page()
            scrollable_elements = await browser_context.get_scrollable_elements()
            page_width, page_height = await browser_context.get_page_size()
            scrollable_element_index = _find_scrollable_element_index_at_point(
                params.point_2d, scrollable_elements, page_height, page_width
            )
            if scrollable_element_index is None:
                raise ValueError(
                    f'No scrollable element found at cursor position {params.point_2d} - '
                    f'double check or use alternative actions'
                )
            element = scrollable_elements[scrollable_element_index]

            params.index = scrollable_element_index
            # params.amount = min(params.amount, element.visible_rect["height"]) \
            #     if params.amount is not None else element.visible_rect["height"]
            params.amount = element.visible_rect["height"]
            elements = page.locator(f'xpath={element.generate_xpath(contain_class=True)}')
            if await elements.count() != 1:
                logger.warning(
                    "Multiple or no scrollable elements found with the given xpath, most often something changed."
                    "We will use the first element to scroll down."
                )

            codified = None
            if codify_function:
                try:
                    codified = await codify_function(params, browser_context)
                except Exception as e:
                    logger.exception(f"When codifying scroll_down action {params.model_dump()}, error occurs: {e}")

            element_handle = await elements.element_handle()
            await element_handle.evaluate(f"ele => ele.scrollTop += {params.amount}")

            msg = f'🔍  Scrolled down the page by {params.amount} pixels'
            logger.info(msg)
            return ActionResult(
                extracted_content=msg,
                codified=codified,
            )

        # scroll up
        @self.registry.action(
            'Scroll up the page by pixel amount - '
            'if no amount is specified, scroll up visible height of this scrollable element.',
            param_model=ScrollAction,
        )
        async def scroll_up(
                params: ScrollAction,
                browser_context: BrowserContext,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            # first thing first, parse point to tlbr format
            params.point_2d = self.actor_point_parser(params.point_2d)

            page = await browser_context.get_current_page()
            scrollable_elements = await browser_context.get_scrollable_elements()
            page_width, page_height = await browser_context.get_page_size()
            scrollable_element_index = _find_scrollable_element_index_at_point(
                params.point_2d, scrollable_elements, page_height, page_width
            )
            if scrollable_element_index is None:
                raise ValueError(
                    f'No scrollable element found at cursor position {params.point_2d} - '
                    f'double check or use alternative actions'
                )
            element = scrollable_elements[scrollable_element_index]

            params.index = scrollable_element_index
            # params.amount = min(params.amount, element.visible_rect["height"]) \
            #     if params.amount is not None else element.visible_rect["height"]
            params.amount = element.visible_rect["height"]
            elements = page.locator(f'xpath={element.generate_xpath(contain_class=True)}')
            if await elements.count() != 1:
                raise RuntimeError(
                    "Multiple or no scrollable elements found with the given xpath, most often something changed."
                )

            codified = None
            if codify_function:
                try:
                    codified = await codify_function(params, browser_context)
                except Exception as e:
                    logger.exception(f"When codifying scroll_up action {params.model_dump()}, error occurs: {e}")

            element_handle = await elements.element_handle()
            await element_handle.evaluate(f"ele => ele.scrollTop -= {params.amount}")

            msg = f'🔍  Scrolled up the page by {params.amount} pixels'
            logger.info(msg)
            return ActionResult(
                extracted_content=msg,
                codified=codified,
            )

        @self.registry.action(
            'Scroll right the page by pixel amount - '
            'if no amount is specified, scroll right visible height of this scrollable element.',
            param_model=ScrollAction,
        )
        async def scroll_right(
                params: ScrollAction,
                browser_context: BrowserContext,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            # first thing first, parse point to tlbr format
            params.point_2d = self.actor_point_parser(params.point_2d)

            page = await browser_context.get_current_page()
            scrollable_elements = await browser_context.get_scrollable_elements()
            page_width, page_height = await browser_context.get_page_size()
            scrollable_element_index = _find_scrollable_element_index_at_point(
                params.point_2d, scrollable_elements, page_height, page_width
            )
            if scrollable_element_index is None:
                raise ValueError(
                    f'No scrollable element found at cursor position {params.point_2d} - '
                    f'double check or use alternative actions'
                )
            element = scrollable_elements[scrollable_element_index]

            params.index = scrollable_element_index
            # params.amount = min(params.amount, element.visible_rect["width"]) \
            #     if params.amount is not None else element.visible_rect["width"]
            params.amount = element.visible_rect["width"]
            elements = page.locator(f'xpath={element.generate_xpath(contain_class=True)}')
            if await elements.count() != 1:
                logger.warning(
                    "Multiple or no scrollable elements found with the given xpath, most often something changed."
                    "We will use the first element to scroll down."
                )

            codified = None
            if codify_function:
                try:
                    codified = await codify_function(params, browser_context)
                except Exception as e:
                    logger.exception(f"When codifying scroll_right action {params.model_dump()}, error occurs: {e}")

            element_handle = await elements.element_handle()
            await element_handle.evaluate(f"ele => ele.scrollLeft += {params.amount}")

            msg = f'🔍  Scrolled right the page by {params.amount} pixels'
            logger.info(msg)
            return ActionResult(
                extracted_content=msg,
                codified=codified,
            )

        @self.registry.action(
            'Scroll left the page by pixel amount - '
            'if no amount is specified, scroll left visible height of this scrollable element.',
            param_model=ScrollAction,
        )
        async def scroll_left(
                params: ScrollAction,
                browser_context: BrowserContext,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            # first thing first, parse point to tlbr format
            params.point_2d = self.actor_point_parser(params.point_2d)

            page = await browser_context.get_current_page()
            scrollable_elements = await browser_context.get_scrollable_elements()
            page_width, page_height = await browser_context.get_page_size()
            scrollable_element_index = _find_scrollable_element_index_at_point(
                params.point_2d, scrollable_elements, page_height, page_width
            )
            if scrollable_element_index is None:
                raise ValueError(
                    f'No scrollable element found at cursor position {params.point_2d} - '
                    f'double check or use alternative actions'
                )
            element = scrollable_elements[scrollable_element_index]

            params.index = scrollable_element_index
            # params.amount = min(params.amount, element.visible_rect["width"]) \
            #     if params.amount is not None else element.visible_rect["width"]
            params.amount = element.visible_rect["width"]
            elements = page.locator(f'xpath={element.generate_xpath(contain_class=True)}')
            if await elements.count() != 1:
                logger.warning(
                    "Multiple or no scrollable elements found with the given xpath, most often something changed."
                    "We will use the first element to scroll down."
                )

            codified = None
            if codify_function:
                try:
                    codified = await codify_function(params, browser_context)
                except Exception as e:
                    logger.exception(f"When codifying scroll_left action {params.model_dump()}, error occurs: {e}")

            element_handle = await elements.element_handle()
            await element_handle.evaluate(f"ele => ele.scrollLeft -= {params.amount}")

            msg = f'🔍  Scrolled left the page by {params.amount} pixels'
            logger.info(msg)
            return ActionResult(
                extracted_content=msg,
                codified=codified,
            )

        # send keys
        @self.registry.action(
            'Send strings of special keys like Escape,Backspace, Insert, PageDown, Delete, Enter, '
            'Shortcuts such as `ControlOrMeta+A`, `ControlOrMeta+Shift+T` are supported as well. '
            'This gets used in keyboard.press. ',
            param_model=SendKeysAction,
        )
        async def send_keys(
                params: SendKeysAction,
                browser_context: BrowserContext,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            page = await browser_context.get_current_page()

            codified = None
            if codify_function:
                try:
                    codified = await codify_function(params, browser_context)
                except Exception as e:
                    logger.exception(f"When codifying send_keys action {params.model_dump()}, error occurs: {e}")

            try:
                await page.keyboard.press(params.keys)
            except Exception as e:
                if 'Unknown key' in str(e):
                    # loop over the keys and try to send each one
                    for key in params.keys:
                        try:
                            await page.keyboard.press(key)
                        except Exception as e:
                            logger.debug(f'Error sending key {key}: {str(e)}')
                            raise e
                else:
                    raise e
            msg = f'⌨️  Sent keys: {params.keys}'
            logger.info(msg)
            return ActionResult(extracted_content=msg, codified=codified)

        @self.registry.action(
            description='Scroll to the text on the page.',
            param_model=ScrollToTextAction,
        )
        async def scroll_to_text(
                params: ScrollToTextAction,
                browser_context: BrowserContext,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            page = await browser_context.get_current_page()

            codified = None
            if codify_function:
                try:
                    codified = await codify_function(params, browser_context)
                except Exception as e:
                    logger.exception(f"When codifying scroll_to_text action {params.model_dump()}, error occurs: {e}")

            try:
                # Try different locator strategies
                locators = [
                    page.get_by_text(params.text, exact=False),
                    page.locator(f'text={params.text}'),
                    page.locator(f"//*[contains(text(), '{params.text}')]"),
                ]

                for locator in locators:
                    try:
                        # First check if element exists and is visible
                        if await locator.count() > 0 and await locator.first.is_visible():
                            await locator.first.scroll_into_view_if_needed()
                            await asyncio.sleep(0.5)  # Wait for scroll to complete
                            msg = f'🔍  Scrolled to text: {params.text}'
                            logger.info(msg)
                            return ActionResult(extracted_content=msg)
                    except Exception as e:
                        logger.debug(f'Locator attempt failed: {str(e)}')
                        continue

                msg = f"Text '{params.text}' not found or not visible on page"
                logger.info(msg)
                return ActionResult(extracted_content=msg, codified=codified)

            except Exception as e:
                msg = f"Failed to scroll to text '{params.text}': {str(e)}"
                logger.exception(msg)
                return ActionResult(error=msg)

        @self.registry.action(
            description='Get all options from a native dropdown',
        )
        async def get_dropdown_options(index: int, browser_context: BrowserContext) -> ActionResult:
            """Get all options from a native dropdown"""
            page = await browser_context.get_current_page()
            selector_map = await browser_context.get_selector_map()
            dom_element = selector_map[index]

            try:
                # Frame-aware approach since we know it works
                all_options = []
                frame_index = 0

                for frame in page.frames:
                    try:
                        options = await frame.evaluate(
                            """
                            (xpath) => {
                                const select = document.evaluate(xpath, document, null,
                                    XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                                if (!select) return null;

                                return {
                                    options: Array.from(select.options).map(opt => ({
                                        text: opt.text, //do not trim, because we are doing exact match in select_dropdown_option
                                        value: opt.value,
                                        index: opt.index
                                    })),
                                    id: select.id,
                                    name: select.name
                                };
                            }
                        """,
                            dom_element.xpath,
                        )

                        if options:
                            logger.debug(f'Found dropdown in frame {frame_index}')
                            logger.debug(f'Dropdown ID: {options["id"]}, Name: {options["name"]}')

                            formatted_options = []
                            for opt in options['options']:
                                # encoding ensures AI uses the exact string in select_dropdown_option
                                encoded_text = json.dumps(opt['text'])
                                formatted_options.append(f'{opt["index"]}: text={encoded_text}')

                            all_options.extend(formatted_options)

                    except Exception as frame_e:
                        logger.debug(f'Frame {frame_index} evaluation failed: {str(frame_e)}')

                    frame_index += 1

                if all_options:
                    msg = '\n'.join(all_options)
                    msg += '\nUse the exact text string in select_dropdown_option'
                    logger.info(msg)
                    return ActionResult(extracted_content=msg)
                else:
                    msg = 'No options found in any frame for dropdown'
                    logger.info(msg)
                    return ActionResult(extracted_content=msg)

            except Exception as e:
                logger.exception(f'Failed to get dropdown options: {str(e)}')
                msg = f'Error getting options: {str(e)}'
                logger.info(msg)
                return ActionResult(extracted_content=msg)

        @self.registry.action(
            description='Select dropdown option for interactive element index by the text of the option you want to select',
        )
        async def select_dropdown_option(
                index: int,
                text: str,
                browser_context: BrowserContext,
        ) -> ActionResult:
            """Select dropdown option by the text of the option you want to select"""
            page = await browser_context.get_current_page()
            selector_map = await browser_context.get_selector_map()
            dom_element = selector_map[index]

            # Validate that we're working with a select element
            if dom_element.tag_name != 'select':
                logger.error(
                    f'Element is not a select! Tag: {dom_element.tag_name}, Attributes: {dom_element.attributes}')
                msg = f'Cannot select option: Element with index {index} is a {dom_element.tag_name}, not a select'
                return ActionResult(extracted_content=msg)

            logger.debug(f"Attempting to select '{text}' using xpath: {dom_element.xpath}")
            logger.debug(f'Element attributes: {dom_element.attributes}')
            logger.debug(f'Element tag: {dom_element.tag_name}')

            _xpath = '//' + dom_element.xpath

            try:
                frame_index = 0
                for frame in page.frames:
                    try:
                        logger.debug(f'Trying frame {frame_index} URL: {frame.url}')

                        # First verify we can find the dropdown in this frame
                        find_dropdown_js = """
                            (xpath) => {
                                try {
                                    const select = document.evaluate(xpath, document, null,
                                        XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
                                    if (!select) return null;
                                    if (select.tagName.toLowerCase() !== 'select') {
                                        return {
                                            error: `Found element but it's a ${select.tagName}, not a SELECT`,
                                            found: false
                                        };
                                    }
                                    return {
                                        id: select.id,
                                        name: select.name,
                                        found: true,
                                        tagName: select.tagName,
                                        optionCount: select.options.length,
                                        currentValue: select.value,
                                        availableOptions: Array.from(select.options).map(o => o.text.trim())
                                    };
                                } catch (e) {
                                    return {error: e.toString(), found: false};
                                }
                            }
                        """

                        dropdown_info = await frame.evaluate(find_dropdown_js, dom_element.xpath)

                        if dropdown_info:
                            if not dropdown_info.get('found'):
                                logger.error(f'Frame {frame_index} error: {dropdown_info.get("error")}')
                                continue

                            logger.debug(f'Found dropdown in frame {frame_index}: {dropdown_info}')

                            # "label" because we are selecting by text
                            # nth(0) to disable error thrown by strict mode
                            # timeout=1000 because we are already waiting for all network events,
                            # therefore ideally we don't need to wait a lot here (default 30s)
                            selected_option_values = (
                                await frame.locator('//' + dom_element.xpath).nth(0).select_option(label=text,
                                                                                                   timeout=1000)
                            )

                            msg = f'selected option {text} with value {selected_option_values}'
                            logger.info(msg + f' in frame {frame_index}')

                            return ActionResult(extracted_content=msg)

                    except Exception as frame_e:
                        logger.exception(f'Frame {frame_index} attempt failed: {str(frame_e)}')
                        logger.exception(f'Frame type: {type(frame)}')
                        logger.exception(f'Frame URL: {frame.url}')

                    frame_index += 1

                msg = f"Could not select option '{text}' in any frame"
                logger.info(msg)
                return ActionResult(extracted_content=msg)

            except Exception as e:
                msg = f'Selection failed: {str(e)}'
                logger.exception(msg)
                return ActionResult(error=msg)

        @self.registry.action(
            "Hover over the element. The description should contain element position in the page, appearance and text.",
            param_model=HoverAction,
        )
        async def hover(
                params: HoverAction,
                browser_context: BrowserContext,
                locating_llm: Optional[BaseChatModel] = None,
                codify_function: Optional[Callable[..., Awaitable[Any]]] = None,
        ):
            session = await browser_context.get_session()

            visible_interactive_elements = await browser_context.get_inview_interactive_elements()
            page_width, page_height = await browser_context.get_page_size()
            unnormalized_box_2d = unnormalize_box_2d(params.box_2d, page_height, page_width)
            matched_element, max_iou = match_element_with_box_2d(
                box_2d=unnormalized_box_2d,
                elements=visible_interactive_elements.values(),
            )
            rectangle = matched_element.rectangle
            iou_tolerance = calculate_iou_tolerance(params.box_2d, max_tolerance=0.5)

            updated_params = None
            if max_iou < iou_tolerance and locating_llm:
                logger.warning(f"Matching with actor box_2d: {params.box_2d} fail, now retry with locating llm.")
                rectangle = await self.locate_element_with_locating_llm(
                    locating_llm,
                    params.detailed_element_description,
                    session.cached_state.screenshot,
                    browser_context,
                )
                box_2d = rectangle_to_box_2d(rectangle, page_height, page_width)
                updated_params = {"box_2d": rectangle_to_box_2d(rectangle, page_height, page_width)}
                params.box_2d = box_2d

            try:
                codified = None
                if codify_function:
                    try:
                        codified = await codify_function(params, browser_context)
                    except Exception as e:
                        logger.exception(f"When codifying hover action {params.model_dump()}, error occurs: {e}")

                await browser_context.hover(rectangle)
                msg = f'🖱️  Hover element with rectangle: {rectangle}'
                logger.info(msg)
                return ActionResult(
                    extracted_content=msg,
                    updated_params=updated_params,
                    codified=codified,
                )
            except Exception as e:
                logger.warning(
                    f'Error occurred: {e} when hovering over element with box_2d: '
                    f'{params.box_2d} "{params.detailed_element_description}"'
                )
                return ActionResult(error=str(e))

    # Register ---------------------------------------------------------------

    def action(self, description: str, **kwargs):
        """Decorator for registering custom actions

        @param description: Describe the LLM what the function does (better description == better function calling)
        """
        return self.registry.action(description, **kwargs)

    # Act --------------------------------------------------------------------

    @time_execution_sync('--act')
    async def act(
            self,
            action: ActionModel,
            browser_context: BrowserContext,
            #
            aux_llms: Optional[Dict[str, BaseChatModel]] = None,
            sensitive_data: Optional[Dict[str, str]] = None,
            available_file_paths: Optional[List[str]] = None,
            #
            context: Context | None = None,
    ) -> ActionResult:
        """Execute an action"""

        try:
            for action_name, params in action.model_dump(exclude_unset=True).items():
                if params is not None:
                    result = await self.registry.execute_action(
                        action_name,
                        params,
                        browser_context=browser_context,
                        aux_llms=aux_llms,
                        sensitive_data=sensitive_data,
                        available_file_paths=available_file_paths,
                        context=context,
                    )

                    if isinstance(result, str):
                        return ActionResult(extracted_content=result)
                    elif isinstance(result, ActionResult):
                        return result
                    elif result is None:
                        return ActionResult()
                    else:
                        raise ValueError(f'Invalid action result type: {type(result)} of {result}')
            return ActionResult()
        except Exception as e:
            raise e

    async def locate_element_with_locating_llm(
            self,
            locating_llm: BaseChatModel,
            element_description: str,
            screenshot_b64: str,
            browser_context: BrowserContext
    ) -> Dict[str, float]:
        messages = [
            LocatingLLMPrompt.get_system_message(),
            LocatingLLMPrompt.get_user_message(element_description, screenshot_b64),
        ]
        log_llm_call_stats(locating_llm, messages)
        locating_llm_output = locating_llm.invoke(messages)
        locating_llm_output = parse_response(locating_llm_output, syntax="json")
        locating_llm_output = json.loads(locating_llm_output)

        if isinstance(locating_llm_output, list):
            locating_llm_output = locating_llm_output[0]

        top, left, bottom, right = self.locating_llm_box_parser(locating_llm_output["box_2d"])
        matched_element, max_iou = await locate_element_in_dom_tree_with_box_2d([top, left, bottom, right], browser_context)
        rectangle = matched_element.rectangle

        if max_iou < 0.75:
            page_width, page_height = await browser_context.get_page_size()
            rectangle = box_2d_to_rectangle([top, left, bottom, right], page_height, page_width)
        return rectangle

    async def execute_actions_in_cache(
            self,
            steps_cache: List[Dict[str, Any]],
            browser_context: BrowserContext,
    ) -> List[ActionResult]:
        for step_cache in steps_cache:
            cmd_state = step_cache["metadata"]["cmd_state"]
            if not step_cache.get("result", None):
                raise ValueError(f"Cache of command: \n{cmd_state} \nhas no result, skip.")
            for action_result in step_cache["result"]:
                if not action_result.get("codified", None):
                    raise ValueError(f"Cache of command: \n{cmd_state} \nhas no codified, skip.")

        executing_results = []
        session = await browser_context.get_session()
        for cache_index, step_cache in enumerate(steps_cache):
            action_results = step_cache["result"]
            for action_result in action_results:
                _codified = action_result["codified"]
                solutions = []
                if (
                    "locator" in _codified
                    and _codified["locator"]
                    and "executable_code_with_locator" in _codified
                    and _codified["executable_code_with_locator"]
                ):
                    locator = _codified["locator"]
                    executable_code_with_locator = _codified["executable_code_with_locator"]

                    async def validating_function() -> bool:
                        try:
                            page = await browser_context.get_current_page()  # noqa: F841 - used in eval below
                            await eval(f"""page.{locator}.first.wait_for(state="attached", timeout=5000)""")
                        except Exception as _e:
                            logger.error(f"Element page.{locator} not found: {_e}\nTry to fallback to xpath...")
                            return False
                        return True

                    async def executing_function() -> None:
                        try:
                            page = await browser_context.get_current_page()
                            await self.execute_async_action_code(executable_code_with_locator, page, session.context)
                        except Exception as _e:
                            logger.exception(f"Code: {executable_code_with_locator} failed: {_e}")
                            raise RuntimeError(f"Code: {executable_code_with_locator} failed: {_e}")

                    solutions.append(
                        {
                            "validating_function": validating_function,
                            "executing_function": executing_function,
                        }
                    )

                if (
                    "xpath" in _codified
                    and _codified["xpath"]
                    and "executable_code_with_xpath" in _codified
                    and _codified["executable_code_with_xpath"]
                ):
                    xpath = _codified["xpath"]
                    executable_code_with_xpath = _codified["executable_code_with_xpath"]

                    async def validating_function() -> bool:
                        try:
                            page = await browser_context.get_current_page()  # noqa: F841 - used in eval below
                            await eval(f"""page.locator(f"xpath={xpath}").first.wait_for(state="attached", timeout=5000)""")
                        except Exception as _e:
                            logger.error(f'Element page.locator(f"xpath={xpath}") not found: {_e}')
                            return False
                        return True

                    async def executing_function() -> None:
                        try:
                            page = await browser_context.get_current_page()
                            await self.execute_async_action_code(executable_code_with_xpath, page, session.context)
                        except Exception as _e:
                            logger.exception(f"Code: {executable_code_with_xpath} failed: {_e}")
                            raise RuntimeError(f"Code: {executable_code_with_xpath} failed: {_e}")

                    solutions.append(
                        {
                            "validating_function": validating_function,
                            "executing_function": executing_function,
                        }
                    )

                if (
                    "code" in _codified
                    and _codified["code"]
                ):
                    code = _codified["code"]

                    # No need to validate element existence
                    async def validating_function() -> bool:
                        return True

                    async def executing_function() -> None:
                        try:
                            page = await browser_context.get_current_page()
                            await self.execute_async_action_code(code, page, session.context)
                        except Exception as _e:
                            logger.exception(f"Code: {code} failed: {_e}")
                            raise RuntimeError(f"Code: {code} failed: {_e}")

                    solutions.append(
                        {
                            "validating_function": validating_function,
                            "executing_function": executing_function,
                        }
                    )

                cmd_state = step_cache["metadata"]["cmd_state"]
                if not solutions:
                    raise RuntimeError(f"Cache of command: \n{cmd_state} \nhas no cached code, skip.")

                for solution in solutions:
                    validating_function: Callable[[], Awaitable[bool]] = solution["validating_function"]
                    executing_function: Callable[[], Awaitable[Any]] = solution["executing_function"]
                    # if validating failed, fallback to next solution
                    # if executing failed, raise error directly
                    if await validating_function():
                        try:
                            await executing_function()
                            executing_result = ActionResult(**action_result)
                            executing_results.append(executing_result)
                            break
                        except Exception as _e:
                            raise _e
                        finally:
                            page = await browser_context.get_current_page()
                            await page.wait_for_load_state()
                else:
                    # all solutions validating_function failed
                    if cache_index == 0:
                        # if this is the first cache to be executed, raise warning and return
                        # because no code has been executed at this time, falling back to VLM is still possible
                        raise RuntimeWarning("All solutions of the first cache failed. Falling back to VLM...")
                    else:
                        # if this is not the first cache to be executed, raise error and return
                        # because at least one code block has been executed at this time, falling back to VLM is risky
                        raise RuntimeError("All solutions of the cache failed.")

            time.sleep(2)
        return executing_results

    @staticmethod
    async def execute_async_action_code(
            code: str,
            page: Optional[Page] = None,
            playwright_browser_context: Optional[PlaywrightBrowserContext] = None,
    ):
        # Add pass to the end of code to make it a valid Python code
        code = code + "\npass"

        exec_globals = {
            '__builtins__': __builtins__,
            'asyncio': asyncio,
        }
        if page is not None:
            exec_globals['page'] = page
        if playwright_browser_context is not None:
            exec_globals['context'] = playwright_browser_context
        exec_locals = {}
        wrapped = "async def __ex():\n" + "\n".join(f"    {line}" for line in code.split("\n"))
        exec(wrapped, exec_globals, exec_locals)
        return await exec_locals['__ex']()
