# -*- coding: utf-8 -*-
# Author: Yichen Lu
# Time: 2025/9/18

import logging
import re
from typing import Iterable, List, Optional, Tuple, Union

from playwright.async_api import Locator
from pydantic import conlist

from browser_use.browser.context import BrowserContext
from browser_use.dom.views import DOMBaseNode, DOMElementNode
from browser_use.utils import calculate_iou, unnormalize_box_2d

logger = logging.getLogger(__name__)

# 语义化交互标签：这些标签本身就是交互元素，点击它们比点击其内部子元素更可靠
SEMANTIC_INTERACTIVE_TAGS = {'button', 'a', 'input', 'select', 'textarea', 'summary'}


def find_semantic_interactive_ancestor(element: DOMElementNode) -> Optional[DOMElementNode]:
    """当匹配到的元素是非语义化标签（如 <span>）时，向上查找最近的语义化交互祖先（如 <button>）。

    这解决了 VLM 输出的 box_2d 紧贴文字导致 IoU 优先匹配到 <span> 而非 <button> 的问题。
    """
    if element.tag_name in SEMANTIC_INTERACTIVE_TAGS:
        return None  # 已经是语义化元素，无需回溯
    current = element.parent
    while current is not None:
        if (current.tag_name in SEMANTIC_INTERACTIVE_TAGS
                and current.is_interactive
                and current.rectangle is not None):
            return current
        current = current.parent
    return None


def match_element_with_box_2d(box_2d: Iterable[float], elements: Iterable[DOMBaseNode]) -> Tuple[DOMElementNode, float]:
    # match the element with IoU
    top, left, bottom, right = box_2d
    matched_element = None
    max_iou = -1
    for element in elements:
        if not isinstance(element, DOMElementNode) or element.rectangle is None:
            continue
        iou = calculate_iou(
            (left, top, right, bottom),
            (
                element.rectangle["left"],
                element.rectangle["top"],
                element.rectangle["right"],
                element.rectangle["bottom"],
            )
        )
        if iou > max_iou:
            max_iou = iou
            matched_element = element

    if matched_element is None:
        raise Exception('Element not found - retry or use alternative actions')

    return matched_element, max_iou


def calculate_iou_tolerance(
        box_2d: Iterable[Union[float, int]],
        max_tolerance: float = 0.667,
        min_tolerance: float = 0.2,
):
    top, left, bottom, right = box_2d
    iou = calculate_iou(
        (left, top, right, bottom),
        (left + 1, top + 1, right + 1, bottom + 1),
    )
    return max(min(iou, max_tolerance), min_tolerance)


async def locate_element_in_dom_tree_with_box_2d(
        box_2d: List[int],
        browser_context: BrowserContext,
) -> Tuple[DOMElementNode, float]:
    page_width, page_height = await browser_context.get_page_size()
    unnormalized_box_2d = unnormalize_box_2d(box_2d, page_height, page_width)
    element_tree = await browser_context.get_element_tree()
    elements = element_tree.recursively_get_all_children()
    matched_element, max_iou = match_element_with_box_2d(unnormalized_box_2d, elements)
    return matched_element, max_iou


async def locate_element_with_center_point(box_2d: Iterable[float], browser_context: BrowserContext):
    page = await browser_context.get_current_page()
    page_width, page_height = await browser_context.get_page_size()
    unnormalized_box_2d = unnormalize_box_2d(box_2d, page_height, page_width)
    top, left, bottom, right = unnormalized_box_2d
    center_x, center_y = (left + right) / 2, (top + bottom) / 2

    injected_script = """
([x, y]) => {
    // 函数：为给定的元素生成一个 XPath
    function createXPathFromElement(element, stopAtBoundary = true) {
        const segments = [];
        let currentElement = element;

        while (currentElement && currentElement.nodeType === Node.ELEMENT_NODE) {
          // Stop if we hit a shadow root or iframe
          if (
            stopAtBoundary &&
            (currentElement.parentNode instanceof ShadowRoot ||
              currentElement.parentNode instanceof HTMLIFrameElement)
          ) {
            break;
          }

          let index = 0;
          let sibling = currentElement.previousSibling;
          while (sibling) {
            if (
              sibling.nodeType === Node.ELEMENT_NODE &&
              sibling.nodeName === currentElement.nodeName
            ) {
              index++;
            }
            sibling = sibling.previousSibling;
          }

          const tagName = currentElement.nodeName.toLowerCase();
          const xpathIndex = index > 0 ? `[${index + 1}]` : "";
          segments.unshift(`${tagName}${xpathIndex}`);

          currentElement = currentElement.parentNode;
        }

        return segments.join("/");
    }

    // 1. 获取指定坐标的最上层元素
    const element = document.elementFromPoint(x, y);

    if (!element) {
        return {
            xpath: null,
            tagName: null,
            error: 'No element found at the given coordinates.'
        };
    }

    // 2. 为找到的元素生成 XPath
    const xpath = createXPathFromElement(element);

    // 3. 返回包含 XPath 和其他信息的对象
    return {
        xpath: xpath,
        tagName: element.tagName.toLowerCase(),
        html: element.outerHTML
    };
}
    """

    element_info = await page.evaluate(injected_script, [center_x, center_y])
    return element_info


async def match_element_with_center_point_and_xpath(
        locator: Locator,
        box_2d: conlist(Union[int, float], min_length=4, max_length=4),
) -> Optional[Locator]:
    # 1. 使用 all() 获取所有匹配元素的 Locator 列表
    all_elements = await locator.all()

    # 2. 如果XPath没有找到任何元素，直接返回None
    if not all_elements:
        return None

    # 3. 如果只有一个元素，直接返回它，无需计算包围盒
    if len(all_elements) == 1:
        return all_elements[0]

    # 4. 如果有多个匹配元素，计算输入box_2d的中心点
    top, left, bottom, right = box_2d
    center_x = (left + right) / 2
    center_y = (top + bottom) / 2

    # 5. 遍历所有找到的元素，筛选出中心点落在其包围盒内的元素
    matching_elements = []
    for element in all_elements:
        # 获取元素的包围盒。如果元素不可见，返回值为None
        # bounding_box() 是一个异步方法，需要 await
        element_box = await element.bounding_box()

        if element_box:
            # 检查中心点是否在元素的包围盒内部
            # element_box 格式: {'x': float, 'y': float, 'width': float, 'height': float}
            ex, ey = element_box['x'], element_box['y']
            ew, eh = element_box['width'], element_box['height']

            if (ex <= center_x < ex + ew) and (ey <= center_y < ey + eh):
                matching_elements.append(element)

    # 6. 根据筛选结果返回
    if not matching_elements:
        return None
    else:
        logger.warning(
            "Multiple elements found with the given xpath, most often something changed. "
            "In this case, we will use the first element by default."
        )
        return matching_elements[0]


async def match_element_with_iou_and_xpath(
        locator: Locator,
        box_2d: conlist(Union[int, float], min_length=4, max_length=4),
) -> Tuple[Optional[Locator], float]:
    # 1. 使用 all() 获取所有匹配元素的 Locator 列表
    all_elements = await locator.all()

    # 2. 如果XPath没有找到任何元素，直接返回None
    if not all_elements:
        return None, -1

    # 3. 遍历所有找到的元素，筛选出中心点落在其包围盒内的元素
    top, left, bottom, right = box_2d
    max_iou, matched_element = -1, None
    for element in all_elements:
        # 获取元素的包围盒。如果元素不可见，返回值为None
        # bounding_box() 是一个异步方法，需要 await
        element_box = await element.bounding_box()

        if element_box:
            # 检查中心点是否在元素的包围盒内部
            # element_box 格式: {'x': float, 'y': float, 'width': float, 'height': float}
            _left, _top = element_box['x'], element_box['y']
            _right, _bottom = _left + element_box['width'], _top + element_box['height']

            _iou = calculate_iou(
                (left, top, right, bottom),
                (_left, _top, _right, _bottom)
            )

            if _iou > max_iou:
                max_iou = _iou
                matched_element = element

    # 4. 根据筛选结果返回
    return matched_element, max_iou


def convert_to_locatable_xpath(xpath_string: str) -> str:
    """
    将一个可能包含非HTML命名空间标签 (如 SVG, MathML) 的 XPath 字符串，
    转换为一个在自动化工具 (如 Selenium) 中更健壮、可定位的 XPath。

    它通过将特定的非HTML标签（如 'svg', 'path', 'math' 等）替换为
    `*[local-name()='tag_name']` 的形式来实现，从而忽略命名空间问题。

    Args:
        xpath_string: 从浏览器开发者工具复制的原始 XPath 字符串。

    Returns:
        一个转换后、更健壮的 XPath 字符串。
    """
    if not xpath_string:
        return ""

    # 定义已知的非 HTML 命名空间标签
    NON_HTML_TAGS = {
        # SVG 标签
        'svg', 'path', 'circle', 'rect', 'line', 'polygon', 'g', 'defs', 'use',
        'text', 'textPath', 'tspan', 'image', 'clipPath', 'mask', 'filter',
        'feGaussianBlur', 'feOffset', 'marker', 'pattern',
        # MathML 标签
        'math', 'mi', 'mn', 'mo', 'ms', 'mtext', 'mrow', 'mfrac', 'msqrt',
        'mroot', 'mstyle', 'merror', 'mpadded', 'mphantom', 'mfenced', 'msup',
        'msub', 'msubsup'
    }

    # 按 '/' 分割 XPath 路径的各个节点
    parts = xpath_string.split('/')
    converted_parts = []

    for part in parts:
        if not part:
            # 处理开头的 '/' 或 '//' 产生空字符串的情况
            converted_parts.append(part)
            continue

        # 使用正则表达式从 'tag[...]' 中提取 'tag'
        # 例如，从 'div[6]' 提取 'div'，从 'path[@id="icon"]' 提取 'path'
        match = re.match(r"([a-zA-Z0-9_:]+)", part)
        if not match:
            # 如果部分不以标签名开头（虽然不常见），则保持原样
            converted_parts.append(part)
            continue

        tag_name = match.group(1)

        if tag_name.lower() in NON_HTML_TAGS:
            tag_end_index = len(tag_name)
            predicate = part[tag_end_index:]
            new_part = f"*[local-name()='{tag_name}']{predicate}"
            converted_parts.append(new_part)
        else:
            converted_parts.append(part)

    return '/'.join(converted_parts)
