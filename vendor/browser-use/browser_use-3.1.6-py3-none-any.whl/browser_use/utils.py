from __future__ import annotations

import base64
import io
import json
import logging
import os
import re
import time
import typing as t
from functools import wraps
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from browser_use.agent.views import AgentOutput

from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
from Crypto.Util.Padding import pad, unpad
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import BaseMessage, HumanMessage
from PIL import Image
from pydantic import ValidationError

logger = logging.getLogger(__name__)

# Define generic type variables for return type and parameters
R = t.TypeVar("R")
P = t.ParamSpec("P")

# AES密钥（必须是16、24或32字节，对应AES-128、192、256）
KEY = b"q25dij32nv723zkjn36gxbn2jd6va3m6"  # 32字节

VARIABLE_PATTERN = r"\$\{\s*([a-zA-Z0-9_.]+)\s*\}"


def _resolve_dot_path(value_str: str, dotpath: str) -> t.Optional[str]:
    """
    Given a JSON-encoded string and a dot-separated path, return the nested leaf value.

    Examples:
        _resolve_dot_path('{"code": "CN", "name": "China"}', "code") → "CN"
        _resolve_dot_path('{"a": {"b": 1}}', "a.b")                  → "1"
        _resolve_dot_path('not-json', "field")                        → None
        _resolve_dot_path('{"a": 1}', "missing")                      → None

    Returns None if the JSON is invalid or the path cannot be traversed.
    Caller is responsible for emitting a warning and preserving the original placeholder.
    """
    try:
        obj = json.loads(value_str)
    except (json.JSONDecodeError, TypeError):
        return None
    for part in dotpath.split("."):
        if isinstance(obj, dict) and part in obj:
            obj = obj[part]
        else:
            return None
    if isinstance(obj, (dict, list)):
        return json.dumps(obj, ensure_ascii=False)
    return str(obj)


def time_execution_sync(
    additional_text: str = "",
) -> t.Callable[[t.Callable[P, R]], t.Callable[P, R]]:
    def decorator(func: t.Callable[P, R]) -> t.Callable[P, R]:
        @wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            start_time = time.time()
            result = func(*args, **kwargs)
            execution_time = time.time() - start_time
            logger.debug(
                f"{additional_text} Execution time: {execution_time:.2f} seconds"
            )
            return result

        return wrapper

    return decorator


def log_response(response: "AgentOutput") -> None:
    """Utility function to log the model's response."""

    logger.info(f"🧠 Reasoning: {response.current_state.reasoning}")
    logger.info(f"☑️ Expected outcome: {response.current_state.expected_outcome}")
    for i, action in enumerate(response.action):
        logger.info(
            f"🛠️  Action {i + 1}/{len(response.action)}: {action.model_dump_json(exclude_unset=True)}"
        )


def time_execution_async(
    additional_text: str = "",
) -> t.Callable[
    [t.Callable[P, t.Coroutine[t.Any, t.Any, R]]],
    t.Callable[P, t.Coroutine[t.Any, t.Any, R]],
]:
    def decorator(
        func: t.Callable[P, t.Coroutine[t.Any, t.Any, R]],
    ) -> t.Callable[P, t.Coroutine[t.Any, t.Any, R]]:
        @wraps(func)
        async def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            start_time = time.time()
            result = await func(*args, **kwargs)
            execution_time = time.time() - start_time
            logger.debug(
                f"{additional_text} Execution time: {execution_time:.2f} seconds"
            )
            return result

        return wrapper

    return decorator


def singleton(cls):
    instance = [None]

    def wrapper(*args, **kwargs):
        if instance[0] is None:
            instance[0] = cls(*args, **kwargs)
        return instance[0]

    return wrapper


def calculate_iou(box_a, box_b):
    """
    left, top, right, bottom
    """

    left_a, top_a, right_a, bottom_a = box_a
    left_b, top_b, right_b, bottom_b = box_b

    inter_left = max(left_a, left_b)
    inter_top = max(top_a, top_b)
    inter_right = min(right_a, right_b)
    inter_bottom = min(bottom_a, bottom_b)

    inter_width = max(0, inter_right - inter_left)
    inter_height = max(0, inter_bottom - inter_top)
    inter_area = inter_width * inter_height

    area_a = (right_a - left_a) * (bottom_a - top_a)
    area_b = (right_b - left_b) * (bottom_b - top_b)
    union_area = area_a + area_b - inter_area

    iou = inter_area / (union_area + 1e-6)

    return iou


def base64_to_image(image_base64: str) -> Image:
    if "," in image_base64:
        image_base64 = image_base64.split(",")[1]
    image_bytes = base64.b64decode(image_base64)
    image = Image.open(io.BytesIO(image_bytes))
    return image


def encode_image_base64(image: Image, scale: float = 1.0, im_format: str = "PNG"):
    resized = image.resize((int(image.width * scale), int(image.height * scale)))
    if im_format.lower() in ["jpg", "jpeg"]:
        resized = resized.convert("RGB")

    buffered = io.BytesIO()
    resized.save(buffered, format=im_format)
    image_bytes = buffered.getvalue()
    image_base64 = base64.b64encode(image_bytes).decode("utf-8")
    return image_base64


def box_2d_to_rectangle(box_2d: t.List[t.Union[int, float]], page_height, page_width):
    top, left, bottom, right = box_2d
    top, left, bottom, right = (
        top / 1000 * page_height,
        left / 1000 * page_width,
        bottom / 1000 * page_height,
        right / 1000 * page_width,
    )

    if not (0 <= top <= bottom <= page_height and 0 <= left <= right <= page_width):
        logger.warning(f"Bounding box {[top, left, bottom, right]} is invalid")

    return {
        "top": top,
        "left": left,
        "bottom": bottom,
        "right": right,
        "width": right - left,
        "height": bottom - top,
        "x": left,
        "y": top,
    }


def rectangle_to_box_2d(
    rectangle: t.Dict[str, t.Union[int, float]], page_height, page_width
) -> t.List[int]:
    top, left, bottom, right = (
        rectangle["top"],
        rectangle["left"],
        rectangle["bottom"],
        rectangle["right"],
    )

    return [
        int(top * 1000 / page_height),
        int(left * 1000 / page_width),
        int(bottom * 1000 / page_height),
        int(right * 1000 / page_width),
    ]


def unnormalize_box_2d(
    box_2d: t.Iterable[t.Union[int, float]], page_height, page_width
):
    top, left, bottom, right = box_2d
    top, left, bottom, right = (
        top / 1000 * page_height,
        left / 1000 * page_width,
        bottom / 1000 * page_height,
        right / 1000 * page_width,
    )

    # if not (0 <= top <= bottom <= page_height and 0 <= left <= right <= page_width):
    #     logger.warning(f'Bounding box (tlbr) {[top, left, bottom, right]} is invalid')

    return top, left, bottom, right


def unnormalize_point_2d(
    point_2d: t.Iterable[t.Union[int, float]], page_height, page_width
):
    y, x = point_2d
    normalized_y, normalized_x = (
        y / 1000 * page_height,
        x / 1000 * page_width,
    )
    return normalized_y, normalized_x


def normalize_box_2d(box_2d: t.Iterable[t.Union[int, float]], page_height, page_width):
    top, left, bottom, right = box_2d
    top, left, bottom, right = (
        top / page_height * 1000,
        left / page_width * 1000,
        bottom / page_height * 1000,
        right / page_width * 1000,
    )

    # if not (0 <= top <= bottom <= 1000 and 0 <= left <= right <= 1000):
    #     logger.warning(f'Bounding box (tlbr) {[top, left, bottom, right]} is invalid')

    return top, left, bottom, right


def box_2d_to_box_prompt(box_format: str, box_2d: t.Iterable[t.Union[int, float]]):
    top, left, bottom, right = box_2d
    m = {"t": top, "l": left, "b": bottom, "r": right}
    return f"[{', '.join([str(int(m[c])) for c in box_format])}]"


def box_format_to_box_format_prompt(box_format: str):
    m = {
        "t": "top",
        "l": "left",
        "b": "bottom",
        "r": "right",
    }
    return f"[{', '.join([m[c] for c in box_format])}]"


def _estimate_input_size(messages: t.List[BaseMessage]) -> tuple[int, int]:
    """Estimate input size for LLM call. Returns (char_count, byte_count)."""
    total_chars = 0
    total_bytes = 0
    for msg in messages:
        c = getattr(msg, "content", None)
        if isinstance(c, str):
            total_chars += len(c)
            total_bytes += len(c.encode("utf-8"))
        elif isinstance(c, list):
            for part in c:
                if isinstance(part, dict):
                    if part.get("type") == "text":
                        t = part.get("text", "")
                        total_chars += len(t)
                        total_bytes += len(t.encode("utf-8"))
                    elif part.get("type") == "image_url":
                        url = part.get("image_url", "")
                        if isinstance(url, dict):
                            url = url.get("url", "")
                        total_bytes += len(str(url))
                elif isinstance(part, str):
                    total_chars += len(part)
                    total_bytes += len(part.encode("utf-8"))
    return total_chars, total_bytes


def _get_model_name(llm: BaseChatModel) -> str:
    """Get model name from LLM instance for logging."""
    return getattr(llm, "model", None) or getattr(llm, "model_name", "unknown")


def log_llm_call_stats(llm: BaseChatModel, messages: t.List[BaseMessage]) -> None:
    """Log LLM call stats before invoking (model name, input size) for timeout analysis."""
    input_chars, input_bytes = _estimate_input_size(messages)
    model_name = _get_model_name(llm)
    estimated_tokens = input_chars // 4
    logger.info(
        "LLM call: model=%s, input_chars=%d, input_bytes=%d, msg_count=%d, estimated_tokens≈%d",
        model_name,
        input_chars,
        input_bytes,
        len(messages),
        estimated_tokens,
    )


def invoke_llm_with_retry(
    llm: BaseChatModel,
    input_messages: t.List[BaseMessage],
    parsing_func: t.Callable[[str], t.Any],
    max_llm_retry: int = 3,
):
    """
    调用 LLM 并支持重试。捕获模型调用超时 (APITimeoutError) 及其他异常，
    记录日志后重试。超时情况下会等待 3 秒再重试。
    max_llm_retry: 最大重试次数，默认 3（即最多尝试 3 次）。
    """
    consecutive_failures = 0
    parsing_error, error_output = None, ""

    while consecutive_failures < max_llm_retry:
        if parsing_error is not None:
            error_message = HumanMessage(
                content=f"""
Your previous response is posted below:
{error_output}

This response is invalid and contains the following error:
{parsing_error}

Please correct your response and try again.
"""
            )
            input_messages.append(error_message)
        try:
            log_llm_call_stats(llm, input_messages)
            response: BaseMessage = llm.invoke(input_messages)
            raw_output = str(response.content)
        except Exception as e:
            is_timeout = (
                type(e).__name__ == "APITimeoutError"
                or "timeout" in str(e).lower()
                or "timed out" in str(e).lower()
            )
            if is_timeout:
                logger.warning(
                    "模型调用超时 (APITimeoutError)，第 %d 次重试（最多 %d 次）: %s",
                    consecutive_failures + 1,
                    max_llm_retry,
                    e,
                )
            else:
                logger.exception("❌ LLM invoke error: %s. Launching retry...", e)
            consecutive_failures += 1
            if consecutive_failures >= max_llm_retry:
                raise e
            if is_timeout:
                delay = 3
                logger.info("等待 %d 秒后重试...", delay)
                time.sleep(delay)
            continue

        try:
            output = parsing_func(raw_output)
            return output
        except ValidationError as e:
            logger.exception(f"❌ LLM parsing error: {e}. Launching retry...")
            parsing_error = e
            error_output = raw_output
            consecutive_failures += 1
            if consecutive_failures >= max_llm_retry:
                raise e
            continue

    raise RuntimeError(f"❌ LLM invoke failed after {max_llm_retry} retries.")


def replace_variable_placeholders_in_string(
    s: str,
    variable_pattern: t.Optional[str] = None,
    exclusive_variables: t.Optional[t.Set[str]] = None,
    keep_if_missing: bool = False,
):
    """
    用环境变量替换字符串中的 ${VAR}。
    keep_if_missing: 若为 True，当变量不在 env 中时保留占位符不替换（供运行时 named_results 替换）；默认 False 会抛错。
    """
    exclusive_variables = exclusive_variables or set()
    pattern = variable_pattern or VARIABLE_PATTERN

    def _replacer(match):
        full_match_text = match.group(0)
        variable_key = match.group(1)

        if variable_key in exclusive_variables:
            logger.info(f"Variable {full_match_text} is exclusive, skip replacing")
            return full_match_text

        variable_value = os.getenv(variable_key)

        if variable_value is None:
            if keep_if_missing:
                return full_match_text
            # 模型可能把明文密码当变量名（如 ${111111}），若变量名为纯数字则视为字面量
            if variable_key.isdigit():
                variable_value = variable_key
                logger.info(
                    f"Variable {full_match_text} treated as literal (numeric name), use as-is"
                )
            else:
                logger.error(f"Variable {full_match_text} not found in env variables")
                raise ValueError(
                    f"Variable {full_match_text} not found in env variables"
                )

        logger.info(f'Replace variable {full_match_text} with value "{variable_value}"')
        return str(variable_value)

    return re.sub(pattern, _replacer, s)


def substitute_variables(
    s: str,
    variable_map: t.Dict[str, t.Any],
    pattern: t.Optional[str] = None,
) -> str:
    """
    使用 variable_map 替换字符串中的 ${name}，用于运行时变量（如 aiQuery 的 name 结果）。
    若变量不在 map 中则保留原占位符不替换。
    """
    if not s or not variable_map:
        return s
    pattern = pattern or VARIABLE_PATTERN

    def _replacer(match):
        variable_key = match.group(1).strip()

        # Fast path: plain key (no dot) — existing behaviour
        if "." not in variable_key:
            if variable_key in variable_map:
                val = variable_map[variable_key]
                if isinstance(val, (dict, list)):
                    return json.dumps(val, ensure_ascii=False)
                return str(val)
            return match.group(0)

        # Dot-path: ${base_key.field.subfield}
        # Split on the FIRST dot only — base_key is the named_results entry,
        # everything after is the path inside the stored JSON value.
        dot_pos = variable_key.index(".")
        base_key = variable_key[:dot_pos]
        rest_path = variable_key[dot_pos + 1 :]

        if base_key not in variable_map:
            logger.warning(
                f"[substitute_variables] Cannot resolve '${{{{}}}}': "
                f"'{base_key}' not in named_results — preserving placeholder".format(
                    variable_key
                )
            )
            return match.group(0)

        resolved = _resolve_dot_path(str(variable_map[base_key]), rest_path)
        if resolved is None:
            logger.warning(
                f"[substitute_variables] Cannot resolve '${{{{}}}}': "
                f"path '{rest_path}' not found in value of '{base_key}' "
                f"— preserving placeholder".format(variable_key)
            )
            return match.group(0)
        return resolved

    return re.sub(pattern, _replacer, s)


def encrypt(plaintext: str, key: bytes = KEY) -> str:
    """
    使用AES-CBC加密字符串
    :param plaintext: 明文字符串
    :param key: 密钥（必须是16/24/32字节）
    :return: Base64编码的密文（包含IV）
    """
    # 生成随机的初始化向量 IV
    iv = get_random_bytes(AES.block_size)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    # 对明文进行PKCS7填充并加密
    padded_data = pad(plaintext.encode("utf-8"), AES.block_size)
    ciphertext = cipher.encrypt(padded_data)
    # 返回 base64 编码的 IV + 密文
    return base64.b64encode(iv + ciphertext).decode("utf-8")


def decrypt(encrypted_data: str, key: bytes = KEY) -> str:
    """
    使用AES-CBC解密字符串；若非加密格式（如明文 API Key）则原样返回。
    :param encrypted_data: Base64编码的加密数据（包含IV），或明文
    :param key: 密钥（必须是16/24/32字节）
    :return: 明文字符串
    """
    if not (encrypted_data and encrypted_data.strip()):
        return encrypted_data or ""
    try:
        raw_data = base64.b64decode(encrypted_data)
        if len(raw_data) <= AES.block_size:
            return encrypted_data
        iv = raw_data[: AES.block_size]
        ciphertext = raw_data[AES.block_size :]
        cipher = AES.new(key, AES.MODE_CBC, iv)
        padded_plaintext = cipher.decrypt(ciphertext)
        plaintext = unpad(padded_plaintext, AES.block_size)
        return plaintext.decode("utf-8")
    except Exception:
        return encrypted_data


def get_polymorphic_type(base_cls):
    classes = [base_cls]
    classes.extend(base_cls.__subclasses__())
    return t.Union[tuple(classes)]
