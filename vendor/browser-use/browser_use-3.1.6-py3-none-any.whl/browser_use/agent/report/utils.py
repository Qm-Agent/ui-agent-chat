"""报告生成工具函数模块"""

import ast
import base64
import io
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from PIL import Image

logger = logging.getLogger(__name__)


def preprocess(data: dict, quality: int = 90) -> dict:
    """预处理报告数据，压缩图片"""
    if not isinstance(data, dict) or "history" not in data:
        return data
    return process_json_images(data, quality=quality)


def compress_base64_image(base64_str: str, quality: int = 90) -> str:
    """
    将 base64 编码的 PNG 图片转换为压缩后的 JPG 格式 base64
    """
    if not base64_str or not isinstance(base64_str, str):
        return base64_str

    header = ""
    if "," in base64_str:
        header, base64_str = base64_str.split(",", 1)

    try:
        img_data = base64.b64decode(base64_str)
        img = Image.open(io.BytesIO(img_data))

        if img.mode in ("RGBA", "P"):
            img = img.convert("RGB")

        buffer = io.BytesIO()
        img.save(buffer, format="JPEG", quality=quality, optimize=True)
        compressed_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
        return f"data:image/jpeg;base64,{compressed_base64}"
    except Exception as e:
        logger.warning(f"压缩图片失败: {e}")
        return header + "," + base64_str if header else base64_str


def process_json_images(data: dict, quality: int = 90) -> dict:
    """
    递归遍历 JSON 数据并压缩所有图片
    """
    if not isinstance(data, dict) or "history" not in data:
        return data

    for item in data["history"]:
        if "state" in item and "screenshot" in item["state"]:
            item["state"]["screenshot"] = compress_base64_image(
                item["state"]["screenshot"], quality
            )
        if "screenshot_before_actions" in item and item["screenshot_before_actions"]:
            item["screenshot_before_actions"] = compress_base64_image(
                item["screenshot_before_actions"], quality
            )

        if "conversations" in item:
            for conv in item["conversations"]:
                for msg in conv.get("input_messages", []):
                    content = msg.get("content")
                    if isinstance(content, list):
                        # 移除 input_messages 中的图片（报告不使用，仅浪费体积）
                        msg["content"] = [
                            part for part in content
                            if not (isinstance(part, dict) and part.get("type") == "image_url")
                        ]
    return data


def _coerce_assertion_value(value: Any) -> Optional[bool]:
    """Convert serialized assertion values into bool when unambiguous."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        normalized = value.strip().lower()
        if normalized == "true":
            return True
        if normalized == "false":
            return False
    return None


def _extract_assertion_from_mapping(value: Any) -> Optional[bool]:
    if not isinstance(value, dict) or "assertion" not in value:
        return None
    return _coerce_assertion_value(value.get("assertion"))


def _parse_serialized_assertion(value: Any) -> Optional[bool]:
    """Read assertion from JSON or Python-dict string produced by ActionResult."""
    if isinstance(value, dict):
        return _extract_assertion_from_mapping(value)
    if not isinstance(value, str) or "assertion" not in value:
        return None

    try:
        parsed = json.loads(value)
    except Exception:
        try:
            parsed = ast.literal_eval(value)
        except Exception:
            return None

    return _extract_assertion_from_mapping(parsed)


def _item_has_error(item: dict) -> bool:
    return any(r and r.get("error") for r in item.get("result") or [])


def _extract_assertion_from_item(item: dict) -> Optional[bool]:
    """Extract assertion result from asserter conversation or result payload."""
    for conv in reversed(item.get("conversations") or []):
        if conv.get("role") != "asserter":
            continue
        assertion = _parse_serialized_assertion(conv.get("output_message"))
        if assertion is not None:
            return assertion

    for result in reversed(item.get("result") or []):
        if not result:
            continue
        assertion = _parse_serialized_assertion(result.get("extracted_content"))
        if assertion is not None:
            return assertion
        assertion = _extract_assertion_from_mapping(result.get("codified"))
        if assertion is not None:
            return assertion

    return None


def _find_last_assertion(history: List[dict]) -> Optional[Tuple[int, bool]]:
    for idx in range(len(history) - 1, -1, -1):
        assertion = _extract_assertion_from_item(history[idx])
        if assertion is not None:
            return idx, assertion
    return None


def report_success_from_data(data: dict) -> bool:
    """根据 history 判断整次执行是否成功，最终断言优先于已恢复的中间错误。"""
    history = data.get("history") or []
    if not history:
        return True

    last_assertion = _find_last_assertion(history)
    if last_assertion is not None:
        assertion_idx, assertion = last_assertion
        if _item_has_error(history[assertion_idx]):
            return False
        if any(_item_has_error(item) for item in history[assertion_idx + 1 :]):
            return False
        return assertion

    # 无断言时保持旧行为：检查所有步骤是否有错误
    for item in history:
        if _item_has_error(item):
            return False
    return True


def relabel_quick_history_ai_commands(
    data: dict,
    ai_quick_text: Optional[str] = None,
) -> dict:
    """Relabel quick CLI's serialized ai command as aiQuick for reports/results."""
    if not isinstance(data, dict):
        return data

    def relabel_cmd_state(cmd_state: Any) -> None:
        if not isinstance(cmd_state, dict):
            return
        command = cmd_state.get("command")
        if isinstance(command, dict) and "ai" in command and "aiQuick" not in command:
            internal_ai_text = command.pop("ai")
            command["aiQuick"] = ai_quick_text or internal_ai_text
        relabel_cmd_state(cmd_state.get("sub_cmd_state"))

    for item in data.get("history") or []:
        if not isinstance(item, dict):
            continue
        metadata = item.get("metadata") or {}
        relabel_cmd_state(metadata.get("cmd_state"))
    return data


# ============ 轮播亮点提取函数 ============

def calc_duration_ms(metadata: dict) -> Optional[int]:
    """计算步骤耗时（毫秒）"""
    start = metadata.get("step_start_time")
    end = metadata.get("step_end_time")
    if start and end:
        try:
            s = datetime.fromisoformat(start)
            e = datetime.fromisoformat(end)
            return int((e - s).total_seconds() * 1000)
        except Exception:
            pass
    return None


def get_step_title(item: dict, idx: int) -> str:
    """生成步骤标题"""
    metadata = item.get("metadata", {})
    step_num = metadata.get("step_number", idx + 1)
    actions = item.get("executed_actions", [])
    if actions:
        action_names = [list(a.keys())[0] for a in actions if a]
        if action_names:
            return f"Step {step_num}: {', '.join(action_names[:2])}"
    return f"Step {step_num}"


def extract_highlights(data: dict) -> List[Dict[str, Any]]:
    """
    从 history 中提取轮播元数据——展示所有步骤，完整回放执行过程。

    截图不内嵌到 highlights 中，仅存 history_index 索引，
    JS 运行时从 fullData.history[index] 按需取图，避免 HTML 中截图重复存储。

    规则：
    1. 每个步骤均入轮播，按执行顺序排列
    2. 失败步骤标记 status='failed' 并附带错误信息
    """
    history = data.get("history", [])
    if not history:
        return []

    highlights = []
    for idx, item in enumerate(history):
        state = item.get("state", {})
        metadata = item.get("metadata", {})
        results = item.get("result", [])

        # 判断是否有截图（不存储，仅标记）
        screenshot = state.get("screenshot") if state else None
        screenshot_before = item.get("screenshot_before_actions")
        has_image = bool(screenshot_before or screenshot)

        has_error = any(r and r.get("error") for r in results)
        error_msg = ""
        if has_error:
            for r in results:
                if r and r.get("error"):
                    error_msg = r["error"]
                    break

        step_num = metadata.get("step_number", idx + 1)
        highlights.append({
            "id": f"step-{step_num}",
            "history_index": idx,
            "has_image": has_image,
            "title": get_step_title(item, idx),
            "subtitle": (state.get("title", "")[:50] if state else ""),
            "status": "failed" if has_error else "success",
            "timestamp": metadata.get("step_start_time", ""),
            "step_number": step_num,
            "duration_ms": calc_duration_ms(metadata),
            "error_message": error_msg[:100] if error_msg else None,
            "url": (state.get("url", "") if state else ""),
        })

    return highlights


def prepare_report_data(data: dict, quality: int = 90) -> tuple:
    """
    准备报告数据

    Returns:
        tuple: (json_str, highlights_json, title_suffix)
    """
    data = preprocess(data, quality=quality)
    # 将 JSON 转换为字符串，并转义特殊字符防止 HTML 注入
    json_str = json.dumps(data, ensure_ascii=False).replace('<', '\\u003c').replace('>', '\\u003e')

    # 提取轮播亮点
    highlights = extract_highlights(data)
    highlights_json = json.dumps(highlights, ensure_ascii=False)

    title_suffix = "success" if report_success_from_data(data) else "failed"

    return json_str, highlights_json, title_suffix


def save_report(html_content: str, output_file: str) -> str:
    """保存报告到文件"""
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(html_content)
    logger.info(f"Build report: {Path(output_file).absolute()}")
    return output_file
