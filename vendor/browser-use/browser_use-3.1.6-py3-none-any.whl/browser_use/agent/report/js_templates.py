"""报告生成 JavaScript 模板模块"""

import json

JS_UTILITIES = """
    const fullData = {json_str};
    const highlightsData = {highlights_json};
    const reportLogText = {log_text_json};

    // ========== 工具函数 ==========
    function escapeHtml(text) {
        if (typeof text !== 'string') return String(text);
        return text.replace(/&/g, "&amp;")
                   .replace(/</g, "&lt;")
                   .replace(/>/g, "&gt;")
                   .replace(/"/g, "&quot;")
                   .replace(/'/g, "&#039;");
    }

    function getImgSrc(rawStr) {
        if (!rawStr) return "";
        let str = String(rawStr).trim();
        if (str.startsWith('http') || str.startsWith('data:image')) return str;
        return `data:image/jpeg;base64,${str}`;
    }

    /** 从 fullData.history 按 highlight 的 history_index 取截图（优先 before，回退 after） */
    function getHighlightImage(item) {
        if (item == null || item.history_index == null) return null;
        const hist = fullData.history[item.history_index];
        if (!hist) return null;
        return hist.screenshot_before_actions || (hist.state && hist.state.screenshot) || null;
    }

    function truncate(str, n) {
        return (str.length > n) ? str.substr(0, n-1) + '...' : str;
    }

    function openImageLightboxFromSrc(src, altText = '截图放大预览') {
        if (!src) return;
        const lightbox = document.getElementById('image-lightbox');
        const content = document.getElementById('image-lightbox-content');
        if (!lightbox || !content) return;

        content.src = src;
        content.alt = altText;
        lightbox.classList.add('show');
        document.body.style.overflow = 'hidden';
    }

    function closeImageLightbox() {
        const lightbox = document.getElementById('image-lightbox');
        const content = document.getElementById('image-lightbox-content');
        if (!lightbox || !content) return;

        lightbox.classList.remove('show');
        content.src = '';
        document.body.style.overflow = '';
    }

    function initImageLightbox() {
        const lightbox = document.getElementById('image-lightbox');
        const closeBtn = document.getElementById('image-lightbox-close');
        const content = document.getElementById('image-lightbox-content');
        if (!lightbox || !closeBtn || !content) return;

        closeBtn.addEventListener('click', closeImageLightbox);
        lightbox.addEventListener('click', (e) => {
            if (e.target === lightbox) {
                closeImageLightbox();
            }
        });
        content.addEventListener('click', (e) => e.stopPropagation());
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && lightbox.classList.contains('show')) {
                closeImageLightbox();
            }
        });
    }
"""

JS_CAROUSEL = """
    // ========== 轮播组件（优化版） ==========
    const Carousel = {
        // 单一状态对象
        state: {
            items: [],
            currentIndex: 0,
            isPlaying: true,
            isTransitioning: false,
            interval: 2000
        },

        // 定时器引用
        timer: null,

        // 预加载的图片缓存
        imageCache: new Map(),

        // 初始化
        init(data) {
            this.state.items = data || [];
            this.state.currentIndex = 0;

            if (this.state.items.length === 0) {
                this._renderEmpty();
                return;
            }

            this._renderTimeline();
            this._renderDots();
            this._bindEvents();
            this._updateView();
            this._preloadAdjacent();

            if (this.state.items.length > 1) {
                this._startAutoPlay();
            } else {
                document.getElementById('btn-play').style.display = 'none';
                document.getElementById('carousel-progress').style.display = 'none';
            }
        },

        // 渲染空状态
        _renderEmpty() {
            const container = document.getElementById('timeline-carousel');
            container.innerHTML = '<div class="timeline-empty"><span>📊</span><span>暂无关键截图</span></div>';
            document.getElementById('carousel-controls').style.display = 'none';
            document.getElementById('carousel-progress').style.display = 'none';
        },

        // 渲染缩略图时间轴
        _renderTimeline() {
            const container = document.getElementById('timeline-carousel');
            container.innerHTML = this.state.items.map((item, idx) => {
                const failClass = item.status === 'failed' ? 'failed' : '';
                const img = getHighlightImage(item);
                if (img) {
                    return `<img class="timeline-thumb ${failClass}"
                                 src="${getImgSrc(img)}"
                                 data-index="${idx}"
                                 alt="${escapeHtml(item.title)}"
                                 title="${escapeHtml(item.title)}"
                                 role="tab"
                                 tabindex="0"
                                 loading="lazy"
                                 aria-selected="${idx === 0}">`;
                } else {
                    return `<div class="timeline-thumb-placeholder ${failClass}"
                                 data-index="${idx}"
                                 title="${escapeHtml(item.title)}"
                                 role="tab"
                                 tabindex="0"
                                 aria-selected="${idx === 0}">
                                <span aria-hidden="true">📷</span>
                            </div>`;
                }
            }).join('');
        },

        // 渲染指示点
        _renderDots() {
            const container = document.getElementById('carousel-dots');
            if (this.state.items.length <= 1 || this.state.items.length > 12) {
                container.style.display = 'none';
                return;
            }
            container.innerHTML = this.state.items.map((item, idx) =>
                `<div class="carousel-dot"
                      data-index="${idx}"
                      role="tab"
                      tabindex="0"
                      aria-label="跳转到 ${item.title}"
                      aria-selected="${idx === 0}"></div>`
            ).join('');
        },

        // 绑定事件
        _bindEvents() {
            const self = this;

            // 缩略图点击
            document.getElementById('timeline-carousel').addEventListener('click', (e) => {
                const thumb = e.target.closest('[data-index]');
                if (thumb) {
                    self.goTo(parseInt(thumb.dataset.index));
                }
            });

            // 缩略图键盘支持
            document.getElementById('timeline-carousel').addEventListener('keydown', (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    const thumb = e.target.closest('[data-index]');
                    if (thumb) {
                        e.preventDefault();
                        self.goTo(parseInt(thumb.dataset.index));
                    }
                }
            });

            // 控制按钮
            document.getElementById('btn-prev').onclick = () => self.prev();
            document.getElementById('btn-next').onclick = () => self.next();
            document.getElementById('btn-play').onclick = () => self.togglePlay();
            const previewImage = document.getElementById('preview-image');
            if (previewImage) {
                previewImage.addEventListener('click', () => {
                    openImageLightboxFromSrc(previewImage.src, previewImage.alt || '执行步骤截图');
                });
            }

            // 指示点点击
            document.getElementById('carousel-dots').addEventListener('click', (e) => {
                const dot = e.target.closest('[data-index]');
                if (dot) {
                    self.goTo(parseInt(dot.dataset.index));
                }
            });

            // 键盘快捷键
            document.addEventListener('keydown', (e) => {
                if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;

                switch(e.key) {
                    case 'ArrowLeft':
                        e.preventDefault();
                        self.prev();
                        break;
                    case 'ArrowRight':
                        e.preventDefault();
                        self.next();
                        break;
                    case 'Home':
                        e.preventDefault();
                        self.goTo(0);
                        break;
                    case 'End':
                        e.preventDefault();
                        self.goTo(self.state.items.length - 1);
                        break;
                    case ' ':
                        e.preventDefault();
                        self.togglePlay();
                        break;
                }
            });

            // 页面可见性变化
            document.addEventListener('visibilitychange', () => {
                if (document.hidden) {
                    self._pause();
                } else if (self.state.isPlaying) {
                    self._startAutoPlay();
                }
            });

            // 触摸滑动支持
            let touchStartX = 0;
            let touchEndX = 0;
            const wrapper = document.getElementById('preview-wrapper');

            wrapper.addEventListener('touchstart', (e) => {
                touchStartX = e.changedTouches[0].screenX;
            }, { passive: true });

            wrapper.addEventListener('touchend', (e) => {
                touchEndX = e.changedTouches[0].screenX;
                const diff = touchStartX - touchEndX;
                const threshold = 50;

                if (Math.abs(diff) > threshold) {
                    if (diff > 0) self.next();
                    else self.prev();
                }
            }, { passive: true });
        },

        // 跳转到指定索引
        goTo(index) {
            if (this.state.isTransitioning) return;

            const len = this.state.items.length;
            if (len === 0) return;

            // 边界检查
            if (index < 0 || index >= len) {
                console.warn(`Carousel index ${index} out of bounds [0, ${len})`);
                return;
            }

            this.state.isTransitioning = true;
            this.state.currentIndex = index;

            this._updateView();
            this._preloadAdjacent();
            this._resetTimer();

            setTimeout(() => {
                this.state.isTransitioning = false;
            }, 300);
        },

        // 上一张
        prev() {
            const len = this.state.items.length;
            if (len === 0) return;
            const newIndex = (this.state.currentIndex - 1 + len) % len;
            this.goTo(newIndex);
        },

        // 下一张
        next() {
            const len = this.state.items.length;
            if (len === 0) return;
            const newIndex = (this.state.currentIndex + 1) % len;
            this.goTo(newIndex);
        },

        // 更新视图
        _updateView() {
            const items = this.state.items;
            if (items.length === 0) return;

            const idx = this.state.currentIndex;
            const item = items[idx];

            // 更新大图
            const imgEl = document.getElementById('preview-image');
            const emptyEl = document.getElementById('preview-empty');
            const errorEl = document.getElementById('preview-error');

            errorEl.style.display = 'none';

            const imgSrc = getHighlightImage(item);
            if (imgSrc) {
                imgEl.src = getImgSrc(imgSrc);
                imgEl.style.display = 'block';
                imgEl.className = 'preview-image' + (item.status === 'failed' ? ' fail-border' : '');
                imgEl.alt = item.title;
                emptyEl.style.display = 'none';

                // 图片加载状态
                imgEl.onload = () => {
                    imgEl.classList.remove('loading');
                };
                imgEl.onerror = () => {
                    imgEl.src = this._getFallbackImage(item);
                };
            } else {
                imgEl.style.display = 'none';
                emptyEl.style.display = 'flex';
            }

            // 显示错误信息
            if (item.error_message) {
                document.getElementById('preview-error-text').textContent = item.error_message;
                errorEl.style.display = 'flex';
            }

            // 更新缩略图高亮
            document.querySelectorAll('.timeline-thumb, .timeline-thumb-placeholder').forEach((el, i) => {
                el.classList.toggle('active', i === idx);
                el.setAttribute('aria-selected', i === idx);
            });

            // 更新指示点
            document.querySelectorAll('.carousel-dot').forEach((el, i) => {
                el.classList.toggle('active', i === idx);
                el.setAttribute('aria-selected', i === idx);
            });

            // 更新状态文字
            const statusEl = document.getElementById('carousel-status');
            if (statusEl) statusEl.textContent = `Step ${idx + 1}/${items.length}`;

            // 更新详情面板
            const detailTitle = document.getElementById('detail-title');
            const statusBadge = document.getElementById('detail-status');
            if (detailTitle) detailTitle.textContent = item.title;
            if (statusBadge) {
                statusBadge.style.display = 'inline-block';
                statusBadge.className = 'carousel-status-badge ' + item.status;
                statusBadge.textContent = item.status === 'failed' ? '✗ 失败' : '✓ 成功';
            }

            let detailHtml = `
                <div class="detail-row">
                    <span class="detail-label">页面:</span>
                    <span class="detail-value">${item.subtitle || '-'}</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">耗时:</span>
                    <span class="detail-value">${item.duration_ms ? (item.duration_ms/1000).toFixed(2) + 's' : '-'}</span>
                </div>
            `;

            if (item.error_message) {
                detailHtml += `<div class="error-message">❌ ${escapeHtml(item.error_message)}</div>`;
            }

            const detailContent = document.getElementById('detail-content');
            if (detailContent) detailContent.innerHTML = detailHtml;

            // 滚动缩略图到可见区域
            const thumbs = document.querySelectorAll('.timeline-thumb, .timeline-thumb-placeholder');
            if (thumbs[idx]) {
                thumbs[idx].scrollIntoView({ behavior: 'smooth', inline: 'center', block: 'nearest' });
            }
        },

        // 预加载相邻图片
        _preloadAdjacent() {
            const items = this.state.items;
            const current = this.state.currentIndex;
            const len = items.length;

            const preloadIndices = [
                current,
                (current - 1 + len) % len,
                (current + 1) % len
            ];

            preloadIndices.forEach(idx => {
                const imgData = items[idx] ? getHighlightImage(items[idx]) : null;
                if (!this.imageCache.has(idx) && imgData) {
                    const img = new Image();
                    img.src = getImgSrc(imgData);
                    this.imageCache.set(idx, img);
                }
            });
        },

        // 开始自动播放
        _startAutoPlay() {
            if (this.state.items.length <= 1) return;

            this._pause();
            this.timer = setInterval(() => this.next(), this.state.interval);
            this.state.isPlaying = true;

            document.getElementById('btn-play').innerHTML = '<span aria-hidden="true">⏸</span>';
            document.getElementById('btn-play').setAttribute('aria-label', '暂停自动播放');

            // 显示并启动进度条
            const progress = document.getElementById('carousel-progress');
            const bar = document.getElementById('progress-bar');
            progress.style.display = 'block';
            bar.style.transition = 'none';
            bar.style.width = '0%';

            requestAnimationFrame(() => {
                bar.style.transition = `width ${this.state.interval}ms linear`;
                bar.style.width = '100%';
            });
        },

        // 暂停
        _pause() {
            if (this.timer) {
                clearInterval(this.timer);
                this.timer = null;
            }

            document.getElementById('btn-play').innerHTML = '<span aria-hidden="true">▶</span>';
            document.getElementById('btn-play').setAttribute('aria-label', '开始自动播放');
        },

        // 重置定时器
        _resetTimer() {
            this._pause();
            if (this.state.isPlaying) {
                this._startAutoPlay();
            }
        },

        // 切换播放状态
        togglePlay() {
            this.state.isPlaying = !this.state.isPlaying;
            if (this.state.isPlaying) {
                this._startAutoPlay();
            } else {
                this._pause();
                document.getElementById('carousel-progress').style.display = 'none';
            }
        },

        // 公开的暂停方法
        pause() {
            this.state.isPlaying = false;
            this._pause();
            const progress = document.getElementById('carousel-progress');
            if (progress) progress.style.display = 'none';
        },

        // 生成占位图
        _getFallbackImage(item) {
            const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="400" height="300">
                <rect fill="#f5f5f5" width="100%" height="100%"/>
                <text x="50%" y="45%" text-anchor="middle" fill="#999" font-size="16">截图加载失败</text>
                <text x="50%" y="55%" text-anchor="middle" fill="#ccc" font-size="12">${escapeHtml(item.title)}</text>
            </svg>`;
            return `data:image/svg+xml,${encodeURIComponent(svg)}`;
        },

        // 销毁组件
        destroy() {
            this._pause();
            document.onkeydown = null;
            document.onvisibilitychange = null;
            this.imageCache.clear();
            this.state.items = [];
        }
    };
"""

JS_TREE_AND_DETAIL = """
    // ========== 原有功能 ==========
    function getStepDurationSec(inst) {
        if (!inst || !inst.metadata) return 0;
        const m = inst.metadata;
        if (m.duration_seconds != null && m.duration_seconds >= 0) return m.duration_seconds;
        if (m.step_start_time && m.step_end_time) {
            const start = new Date(m.step_start_time);
            const end = new Date(m.step_end_time);
            if (!isNaN(start) && !isNaN(end)) return (end - start) / 1000;
        }
        return 0;
    }

    function getCommandDisplay(cmdState) {
        if (!cmdState || !cmdState.command) {
            return { key: '', value: '', fullTitle: 'Unknown Command', isAiQuick: false };
        }
        const commandObj = cmdState.command;
        for (let key in commandObj) {
            if (key !== 'cache') {
                const val = commandObj[key];
                const displayVal = typeof val === 'object' ? JSON.stringify(val) : String(val);
                return {
                    key,
                    value: displayVal,
                    fullTitle: `${key}: ${displayVal}`,
                    isAiQuick: key === 'aiQuick'
                };
            }
        }
        return { key: '', value: '', fullTitle: 'Empty or Init Actions', isAiQuick: false };
    }

    function getCommandTitle(cmdState) {
        const display = getCommandDisplay(cmdState);
        return display.isAiQuick ? display.fullTitle : truncate(display.fullTitle, 40);
    }

    function getFullCommandTitle(cmdState) {
        return getCommandDisplay(cmdState).fullTitle;
    }

    function getInstructionTitle(inst) {
        if (!inst.executed_actions || inst.executed_actions.length === 0) return "Empty or Run with Cached Code";
        const keys = inst.executed_actions.flatMap(a => Object.keys(a));
        return truncate(keys.join(', '), 30);
    }

    function getStepMeta(inst) {
        const durationSec = (inst.metadata && inst.metadata.duration_seconds != null)
            ? inst.metadata.duration_seconds
            : (inst.metadata && inst.metadata.step_start_time && inst.metadata.step_end_time)
                ? (new Date(inst.metadata.step_end_time) - new Date(inst.metadata.step_start_time)) / 1000
                : null;
        const hasError = (inst.result || []).some(r => r && r.error);
        return { durationSec, success: !hasError };
    }

    function formatValue(val, depth = 0) {
        if (val === null) return '<span class="json-bool">null</span>';
        if (typeof val === 'boolean') return `<span class="json-bool">${val}</span>`;
        if (typeof val === 'number') return `<span class="json-num">${val}</span>`;
        if (typeof val === 'string') {
            if (val.length > 500 && !val.includes(' ')) {
                return `<span class="json-string">"data:image/jpeg;base64,..."</span>`;
            }
            return `<span class="json-string">"${escapeHtml(val)}"</span>`;
        }
        if (Array.isArray(val)) {
            if (val.length === 0) return '[]';
            let html = '[<div class="json-container">';
            val.forEach((item, i) => {
                html += `<div class="json-kv">${formatValue(item, depth + 1)}${i < val.length - 1 ? ',' : ''}</div>`;
            });
            return html + '</div>]';
        }
        if (typeof val === 'object') {
            const keys = Object.keys(val);
            if (keys.length === 0) return '{}';
            let html = '{<div class="json-container">';
            keys.forEach((key, i) => {
                html += `<div class="json-kv"><span class="json-key">"${key}"</span>: ${formatValue(val[key], depth + 1)}${i < keys.length - 1 ? ',' : ''}</div>`;
            });
            return html + '</div>}';
        }
        return escapeHtml(String(val));
    }

    function setActive(el) {
        document.querySelectorAll('.tree-node').forEach(n => n.classList.remove('active-node'));
        el.classList.add('active-node');
    }

    // 构建递归树结构
    function buildCommandTree(history) {
        const treeRoot = { children: {}, instructions: [] };

        history.forEach(item => {
            let current = treeRoot;
            let stateLevel = item.metadata.cmd_state;

            const path = [];
            let temp = stateLevel;
            while(temp) {
                path.push(temp);
                temp = temp.sub_cmd_state;
            }

            path.forEach((nodeState, idx) => {
                const key = `task-${nodeState.task_index}-cmd-${JSON.stringify(nodeState.cmd_index)}`;
                if (!current.children[key]) {
                    current.children[key] = {
                        state: nodeState,
                        title: getCommandTitle(nodeState),
                        fullTitle: getFullCommandTitle(nodeState),
                        commandDisplay: getCommandDisplay(nodeState),
                        children: {},
                        instructions: []
                    };
                }

                if (idx === path.length - 1) {
                    current.children[key].instructions.push(item);
                }
                current = current.children[key];
            });
        });
        return treeRoot;
    }

    function renderTree(node, container) {
        for (let key in node.children) {
            const childNode = node.children[key];

            const cmdEl = document.createElement('div');
            cmdEl.className = 'tree-node cmd-group';
            if (childNode.commandDisplay && childNode.commandDisplay.isAiQuick) {
                cmdEl.classList.add('aiquick-command');
                cmdEl.innerHTML = `<span class="cmd-key">📁 aiQuick</span><span class="cmd-full-text">${escapeHtml(childNode.commandDisplay.value)}</span>`;
            } else {
                cmdEl.textContent = "📁 " + childNode.title;
            }
            cmdEl.onclick = (e) => { e.stopPropagation(); setActive(cmdEl); showCommand(childNode); };
            container.appendChild(cmdEl);

            const subTreeContainer = document.createElement('div');
            subTreeContainer.className = 'sub-tree';
            container.appendChild(subTreeContainer);

            renderTree(childNode, subTreeContainer);

            childNode.instructions.forEach(inst => {
                const instEl = document.createElement('div');
                instEl.className = 'tree-node inst-item';
                const meta = getStepMeta(inst);
                const title = getInstructionTitle(inst);
                const durationStr = meta.durationSec != null ? meta.durationSec.toFixed(2) + 's' : '–';
                const statusClass = meta.success ? 'success' : 'fail';
                const statusText = meta.success ? '✓' : '✗';
                instEl.innerHTML = `<span class="inst-title">${escapeHtml(title)}</span><span class="step-meta"><span class="step-duration">${durationStr}</span><span class="step-status ${statusClass}">${statusText}</span></span>`;
                instEl.onclick = (e) => { e.stopPropagation(); setActive(instEl); showInstruction(inst); };
                subTreeContainer.appendChild(instEl);

                const convContainer = document.createElement('div');
                convContainer.className = 'sub-tree';
                subTreeContainer.appendChild(convContainer);

                inst.conversations.forEach((conv, ci) => {
                    const convEl = document.createElement('div');
                    convEl.className = 'tree-node conv-item';
                    const role = conv.role || "unknown";
                    convEl.innerHTML = `<span class="role-tag">${role}</span> Conversation ${ci+1}`;
                    convEl.onclick = (e) => { e.stopPropagation(); setActive(convEl); showConversation(conv, inst); };
                    convContainer.appendChild(convEl);
                });
            });
        }
    }

    function showCommand(childNode) {
        const instructions = childNode.instructions || [];
        let firstInstWithScreenshot = null;
        for (let i = 0; i < instructions.length; i++) {
            const inst = instructions[i];
            if ((inst.screenshot_before_actions || (inst.state && inst.state.screenshot))) {
                firstInstWithScreenshot = inst;
                break;
            }
        }
        const inst = firstInstWithScreenshot || instructions[0];
        const screenshots = inst ? { before: inst.screenshot_before_actions || null, after: (inst.state && inst.state.screenshot) || null } : {};
        const outputs = [];
        instructions.forEach(instr => {
            (instr.conversations || []).forEach(c => {
                if (c.output_message) outputs.push({ role: c.role, output: c.output_message });
            });
        });
        const displayState = {...childNode.state};
        delete displayState.sub_cmd_state;
        renderUnifiedDetailPanel({ screenshots, outputs, details: { type: 'command', data: displayState } });
    }

    function showInstruction(inst) {
        const screenshots = { before: inst.screenshot_before_actions || null, after: (inst.state && inst.state.screenshot) || null };
        const outputs = (inst.conversations || []).map(c => ({ role: c.role, output: c.output_message })).filter(o => o.output != null);
        renderUnifiedDetailPanel({ screenshots, outputs, details: { type: 'inst', data: { inst } } });
    }

    function showConversation(conv, parentInst) {
        const screenshots = parentInst ? { before: parentInst.screenshot_before_actions || null, after: (parentInst.state && parentInst.screenshot) || null } : {};
        const outputs = conv.output_message ? [{ role: conv.role, output: conv.output_message }] : [];
        renderUnifiedDetailPanel({ screenshots, outputs, details: { type: 'conv', data: { conv, role: conv.role } } });
    }

    function renderUnifiedDetailPanel(ctx) {
        const screenshots = ctx.screenshots || {};
        const outputs = ctx.outputs || [];
        const details = ctx.details || { type: 'none', data: null };

        // 停止轮播自动播放
        Carousel.pause();

        // 隐藏轮播相关元素
        document.getElementById('timeline-carousel').style.display = 'none';
        document.getElementById('carousel-controls').style.display = 'none';
        document.getElementById('carousel-progress').style.display = 'none';
        document.getElementById('preview-empty').style.display = 'none';
        document.getElementById('preview-image').style.display = 'none';
        document.getElementById('preview-error').style.display = 'none';

        // 隐藏大图预览区域
        const previewContainer = document.querySelector('.preview-container');
        if (previewContainer) previewContainer.style.display = 'none';

        // 展开详情面板
        const detailPanel = document.getElementById('detail-panel');
        detailPanel.classList.add('expanded');

        let screenshotHtml = '';
        if (screenshots.before || screenshots.after) {
            const beforeHtml = screenshots.before
                ? `<div style="border:1px solid var(--border-color);border-radius:6px;padding:12px;background:#fff;margin-bottom:12px;"><div style="font-weight:600;font-size:14px;color:var(--primary-dark);margin-bottom:10px;">操作前截图</div><img src="${getImgSrc(screenshots.before)}" data-full-src="${getImgSrc(screenshots.before)}" class="js-inline-preview" alt="操作前截图" style="max-width:100%;max-height:40vh;border-radius:4px;cursor:zoom-in;"></div>`
                : '';
            const afterHtml = screenshots.after
                ? `<div style="border:1px solid var(--border-color);border-radius:6px;padding:12px;background:#fff;"><div style="font-weight:600;font-size:14px;color:var(--primary-dark);margin-bottom:10px;">操作后截图</div><img src="${getImgSrc(screenshots.after)}" data-full-src="${getImgSrc(screenshots.after)}" class="js-inline-preview" alt="操作后截图" style="max-width:100%;max-height:40vh;border-radius:4px;cursor:zoom-in;"></div>`
                : '';
            screenshotHtml = beforeHtml + afterHtml;
        } else {
            screenshotHtml = '<p style="color:var(--text-muted);font-size:13px;">无截图</p>';
        }

        let outputHtml = '';
        if (outputs.length > 0) {
            const roleLabels = { planner: '规划', actor: '执行', asserter: '断言' };
            outputs.forEach((o, i) => {
                const roleLabel = roleLabels[o.role] || o.role || '未知';
                outputHtml += '<div style="padding:12px;border:1px solid var(--border-color);border-radius:5px;margin-bottom:10px;"><div style="font-size:14px;font-weight:bold;margin-bottom:6px;">' + roleLabel + '</div>';
                outputHtml += '<div class="json-container">' + formatValue(o.output) + '</div></div>';
            });
        } else {
            outputHtml = '<p style="color:var(--text-muted);font-size:13px;">无输出</p>';
        }

        let detailHtml = '';
        if (details.type === 'command' && details.data) {
            const displayState = {...details.data};
            delete displayState.sub_cmd_state;
            const commandDisplay = getCommandDisplay(details.data);
            detailHtml = '';
            if (commandDisplay.isAiQuick) {
                detailHtml = '<div class="command-full-title"><div class="command-full-title-label">aiQuick 完整指令</div><div class="command-full-title-text">' + escapeHtml(commandDisplay.value) + '</div></div>';
            }
            detailHtml += '<div class="json-container">' + formatValue(displayState) + '</div>';
        } else if (details.type === 'inst' && details.data) {
            const d = details.data;
            const meta = getStepMeta(d.inst);
            detailHtml = '<div style="padding:6px 0;">';
            detailHtml += '<div style="display:flex;margin-bottom:8px;"><span style="width:80px;color:var(--text-muted);">耗时</span><span style="flex:1;">' + (meta.durationSec != null ? meta.durationSec.toFixed(2) + 's' : '–') + '</span></div>';
            detailHtml += '<div style="display:flex;margin-bottom:8px;"><span style="width:80px;color:var(--text-muted);">状态</span><span style="flex:1;"><span style="padding:1px 4px;border-radius:3px;color:#fff;background:' + (meta.success ? 'var(--success)' : 'var(--error)') + ';">' + (meta.success ? '✓ 成功' : '✗ 失败') + '</span></span></div>';
            if (d.inst.executed_actions && d.inst.executed_actions.length > 0) {
                detailHtml += '<div style="display:flex;margin-bottom:8px;"><span style="width:80px;color:var(--text-muted);">执行动作</span><div class="json-container" style="flex:1;">' + formatValue(d.inst.executed_actions) + '</div></div>';
            }
            if (d.inst.result && d.inst.result.length > 0) {
                detailHtml += '<div style="display:flex;"><span style="width:80px;color:var(--text-muted);">执行结果</span><div class="json-container" style="flex:1;">' + formatValue(d.inst.result) + '</div></div>';
            }
            detailHtml += '</div>';
        } else if (details.type === 'conv' && details.data) {
            const d = details.data;
            const roleLabels = { planner: '规划', actor: '执行', asserter: '断言' };
            const roleLabel = roleLabels[d.role] || d.role || '未知';
            detailHtml = '<div style="padding:6px 0;"><div style="display:flex;margin-bottom:8px;"><span style="width:80px;color:var(--text-muted);">角色</span><span style="flex:1;">' + roleLabel + '</span></div></div>';
            if (d.conv.output_message) {
                detailHtml += '<div class="json-container" style="margin-top:8px;">' + formatValue(d.conv.output_message) + '</div>';
            }
        } else {
            detailHtml = '<p style="color:var(--text-muted);font-size:13px;">无详情</p>';
        }

        // 更新详情面板
        detailPanel.innerHTML = `
            <button id="btn-back-to-carousel" class="carousel-btn" style="margin-bottom:16px;">
                ← 返回概览
            </button>
            <div style="margin-bottom:16px;">
                <div style="font-weight:600;color:var(--primary-dark);margin-bottom:12px;">执行截图</div>
                ${screenshotHtml}
            </div>
            <div style="margin-bottom:16px;">
                <div style="font-weight:600;color:var(--primary-dark);margin-bottom:12px;">AI 输出</div>
                ${outputHtml}
            </div>
            <div>
                <div style="font-weight:600;color:var(--primary-dark);margin-bottom:12px;">详情</div>
                ${detailHtml}
            </div>
        `;

        // 绑定返回按钮事件
        document.getElementById('btn-back-to-carousel').onclick = showCarouselMode;
        detailPanel.querySelectorAll('.js-inline-preview').forEach(img => {
            img.addEventListener('click', () => {
                openImageLightboxFromSrc(img.dataset.fullSrc || img.src, img.alt || '执行截图');
            });
        });
    }

    function showCarouselMode() {
        // 恢复轮播显示
        document.getElementById('timeline-carousel').style.display = 'flex';
        document.getElementById('carousel-controls').style.display = 'flex';
        document.getElementById('carousel-progress').style.display = 'block';
        document.getElementById('preview-empty').style.display = 'flex';
        document.getElementById('preview-image').style.display = 'block';

        // 恢复大图预览区域
        const previewContainer = document.querySelector('.preview-container');
        if (previewContainer) previewContainer.style.display = 'flex';

        // 收起详情面板
        const detailPanel = document.getElementById('detail-panel');
        detailPanel.classList.remove('expanded');
        detailPanel.innerHTML = `
            <div class="carousel-step-info">
                <span class="carousel-step-title" id="detail-title">选择步骤查看详情</span>
                <span class="carousel-status-badge" id="detail-status" style="display: none;"></span>
            </div>
            <div id="detail-content"></div>
        `;

        // 清除侧栏选中状态
        document.querySelectorAll('.tree-node').forEach(n => n.classList.remove('active-node'));
    }
"""

JS_LOG_DRAWER = """
    const LogDrawer = {
        state: {
            isOpen: false,
            keyword: '',
            level: 'all',
            lines: [],
            filteredLines: [],
            errorCount: 0,
            warnCount: 0,
        },

        init(rawLogText) {
            this.state.lines = this._parseLines(rawLogText || '');
            this.state.filteredLines = this.state.lines;
            this._cacheCounts();
            this._bindEvents();
            this._applyFilters();
            this._renderSummary();
        },

        _parseLines(raw) {
            if (!raw || !raw.trim()) return [];
            return raw.split(/\\r?\\n/).map((line, idx) => {
                let level = 'other';
                if (/\\bERROR\\b/.test(line)) level = 'error';
                else if (/\\bWARN(?:ING)?\\b/.test(line)) level = 'warn';
                else if (/\\bINFO\\b/.test(line)) level = 'info';
                return { idx, text: line, level };
            });
        },

        _cacheCounts() {
            this.state.errorCount = this.state.lines.filter(item => item.level === 'error').length;
            this.state.warnCount = this.state.lines.filter(item => item.level === 'warn').length;
            const badge = document.getElementById('log-error-badge');
            if (badge && this.state.errorCount > 0) {
                badge.textContent = String(this.state.errorCount);
                badge.classList.add('show');
            }
        },

        _bindEvents() {
            const toggleBtn = document.getElementById('btn-log-drawer-toggle');
            const closeBtn = document.getElementById('btn-log-drawer-close');
            const backdrop = document.getElementById('log-drawer-backdrop');
            const searchInput = document.getElementById('log-search-input');
            const levelSelect = document.getElementById('log-level-filter');
            const copyBtn = document.getElementById('btn-log-copy-all');
            const jumpBottomBtn = document.getElementById('btn-log-jump-bottom');
            const totalPill = document.getElementById('log-total-count');
            const errorPill = document.getElementById('log-error-count');
            const warnPill = document.getElementById('log-warn-count');

            if (toggleBtn) toggleBtn.addEventListener('click', () => this.toggle());
            if (closeBtn) closeBtn.addEventListener('click', () => this.close());
            if (backdrop) backdrop.addEventListener('click', () => this.close());

            if (searchInput) {
                let timer = null;
                searchInput.addEventListener('input', (e) => {
                    clearTimeout(timer);
                    timer = setTimeout(() => {
                        this.state.keyword = String(e.target.value || '').trim().toLowerCase();
                        this._applyFilters();
                    }, 300);
                });
            }

            if (levelSelect) {
                levelSelect.addEventListener('change', (e) => {
                    this.state.level = String(e.target.value || 'all');
                    this._applyFilters();
                });
            }

            if (copyBtn) {
                copyBtn.addEventListener('click', async () => {
                    try {
                        await navigator.clipboard.writeText(reportLogText || '');
                        copyBtn.textContent = '已复制';
                        setTimeout(() => { copyBtn.textContent = '复制全部'; }, 1200);
                    } catch (err) {
                        console.warn('Copy log failed:', err);
                    }
                });
            }

            if (jumpBottomBtn) {
                jumpBottomBtn.addEventListener('click', () => {
                    const body = document.getElementById('log-drawer-body');
                    if (body) body.scrollTop = body.scrollHeight;
                });
            }

            if (totalPill) {
                totalPill.addEventListener('click', () => {
                    this._setLevelFilter('all');
                    this.open();
                    this._scrollToTop();
                });
            }
            if (errorPill) {
                errorPill.addEventListener('click', () => {
                    this._setLevelFilter('error');
                    this.open();
                    this._scrollToFirstLevel('error');
                });
            }
            if (warnPill) {
                warnPill.addEventListener('click', () => {
                    this._setLevelFilter('warn');
                    this.open();
                    this._scrollToFirstLevel('warn');
                });
            }

            document.addEventListener('keydown', (e) => {
                if (e.key === 'Escape' && this.state.isOpen) {
                    this.close();
                }
            });
        },

        _applyFilters() {
            const { lines, keyword, level } = this.state;
            this.state.filteredLines = lines.filter(item => {
                if (level !== 'all' && item.level !== level) return false;
                if (keyword && !item.text.toLowerCase().includes(keyword)) return false;
                return true;
            });
            this._renderBody();
            this._renderSummary();
        },

        _renderBody() {
            const body = document.getElementById('log-drawer-body');
            const footer = document.getElementById('log-drawer-footer');
            if (!body) return;

            if (this.state.lines.length === 0) {
                body.innerHTML = '<div class="log-drawer-empty">暂无执行日志</div>';
                if (footer) footer.textContent = '显示 0 / 0 行';
                return;
            }

            if (this.state.filteredLines.length === 0) {
                body.innerHTML = '<div class="log-drawer-empty">没有匹配当前筛选条件的日志</div>';
                if (footer) footer.textContent = `显示 0 / ${this.state.lines.length} 行`;
                return;
            }

            body.innerHTML = this.state.filteredLines
                .map(item => (
                    `<div class="log-line level-${item.level}">`
                    + `<span class="log-level-pill ${item.level}">${item.level.toUpperCase()}</span>`
                    + `<span class="log-line-text">${escapeHtml(item.text || ' ')}</span>`
                    + `</div>`
                ))
                .join('');

            if (footer) {
                footer.textContent = `显示 ${this.state.filteredLines.length} / ${this.state.lines.length} 行`;
            }
        },

        _renderSummary() {
            const totalEl = document.getElementById('log-total-count');
            const errorEl = document.getElementById('log-error-count');
            const warnEl = document.getElementById('log-warn-count');
            if (totalEl) totalEl.textContent = `TOTAL ${this.state.lines.length}`;
            if (errorEl) errorEl.textContent = `ERROR ${this.state.errorCount}`;
            if (warnEl) warnEl.textContent = `WARN ${this.state.warnCount}`;
            this._syncSummaryActiveState();
        },

        _syncSummaryActiveState() {
            const totalEl = document.getElementById('log-total-count');
            const errorEl = document.getElementById('log-error-count');
            const warnEl = document.getElementById('log-warn-count');
            [totalEl, errorEl, warnEl].forEach(el => el && el.classList.remove('active'));
            if (this.state.level === 'all' && totalEl) totalEl.classList.add('active');
            if (this.state.level === 'error' && errorEl) errorEl.classList.add('active');
            if (this.state.level === 'warn' && warnEl) warnEl.classList.add('active');
        },

        _setLevelFilter(level) {
            this.state.level = level;
            const levelSelect = document.getElementById('log-level-filter');
            if (levelSelect) levelSelect.value = level;
            this._applyFilters();
        },

        _scrollToTop() {
            const body = document.getElementById('log-drawer-body');
            if (body) body.scrollTop = 0;
        },

        _scrollToFirstLevel(level) {
            const body = document.getElementById('log-drawer-body');
            if (!body) return;
            requestAnimationFrame(() => {
                const target = body.querySelector(`.log-line.level-${level}`);
                if (!target) return;
                body.querySelectorAll('.log-line.focused').forEach(el => el.classList.remove('focused'));
                target.classList.add('focused');
                target.scrollIntoView({ behavior: 'smooth', block: 'center' });
                setTimeout(() => target.classList.remove('focused'), 1800);
            });
        },

        toggle() {
            if (this.state.isOpen) this.close();
            else this.open();
        },

        open() {
            const drawer = document.getElementById('log-drawer');
            const backdrop = document.getElementById('log-drawer-backdrop');
            const toggleBtn = document.getElementById('btn-log-drawer-toggle');
            if (drawer) {
                drawer.classList.add('show');
                drawer.setAttribute('aria-hidden', 'false');
            }
            if (backdrop) {
                backdrop.classList.add('show');
                backdrop.setAttribute('aria-hidden', 'false');
            }
            if (toggleBtn) {
                toggleBtn.classList.add('active');
                toggleBtn.setAttribute('aria-expanded', 'true');
                toggleBtn.childNodes[0].nodeValue = '收起执行日志 ';
            }
            this.state.isOpen = true;
        },

        close() {
            const drawer = document.getElementById('log-drawer');
            const backdrop = document.getElementById('log-drawer-backdrop');
            const toggleBtn = document.getElementById('btn-log-drawer-toggle');
            if (drawer) {
                drawer.classList.remove('show');
                drawer.setAttribute('aria-hidden', 'true');
            }
            if (backdrop) {
                backdrop.classList.remove('show');
                backdrop.setAttribute('aria-hidden', 'true');
            }
            if (toggleBtn) {
                toggleBtn.classList.remove('active');
                toggleBtn.setAttribute('aria-expanded', 'false');
                toggleBtn.childNodes[0].nodeValue = '查看执行日志 ';
            }
            this.state.isOpen = false;
        },
    };
"""

JS_INIT = """
    // ========== 初始化 ==========
    function init() {
        initImageLightbox();
        LogDrawer.init(reportLogText);

        // 初始化轮播
        Carousel.init(highlightsData);

        // 初始化树结构
        const treeData = buildCommandTree(fullData.history);
        const rootContainer = document.getElementById('tree-root');
        renderTree(treeData, rootContainer);

        // 计算并展示执行摘要统计
        renderExecStats(fullData.history);
    }

    function renderExecStats(history) {
        if (!history || history.length === 0) return;
        let totalMs = 0, successCount = 0, failCount = 0, incompleteCount = 0;
        history.forEach(item => {
            const meta = getStepMeta(item);
            totalMs += getStepDurationSec(item) * 1000;
            if (meta.success) successCount++;
            else {
                const results = item.result || [];
                const hasError = results.some(r => r && r.error);
                if (hasError) failCount++;
                else incompleteCount++;
            }
        });
        const totalSteps = history.length;
        const totalSec = totalMs / 1000;
        const durationStr = totalSec >= 60
            ? Math.floor(totalSec / 60) + 'm ' + Math.round(totalSec % 60) + 's'
            : totalSec.toFixed(1) + 's';

        const el = document.getElementById('exec-stats');
        if (!el) return;
        let html = '<span class="stat-item">⏱ ' + durationStr + '</span>';
        html += '<span class="stat-item">📊 ' + totalSteps + ' 步</span>';
        if (successCount > 0) html += '<span class="stat-item stat-success">✓ ' + successCount + ' 成功</span>';
        if (failCount > 0) html += '<span class="stat-item stat-fail">✗ ' + failCount + ' 失败</span>';
        if (incompleteCount > 0) html += '<span class="stat-item stat-incomplete">○ ' + incompleteCount + ' 未完成</span>';
        el.innerHTML = html;
    }

    init();
"""


def get_js_script(json_str: str, highlights_json: str, log_text: str = "") -> str:
    """生成完整的 JavaScript 脚本"""
    log_text_json = (
        json.dumps(log_text, ensure_ascii=False)
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
    )
    utilities = (
        JS_UTILITIES.replace("{json_str}", json_str)
        .replace("{highlights_json}", highlights_json)
        .replace("{log_text_json}", log_text_json)
    )
    return f"""<script>
    {utilities}
    {JS_CAROUSEL}
    {JS_TREE_AND_DETAIL}
    {JS_LOG_DRAWER}
    {JS_INIT}
</script>
"""
