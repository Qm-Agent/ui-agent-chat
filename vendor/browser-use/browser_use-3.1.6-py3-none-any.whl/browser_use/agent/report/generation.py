"""
报告生成主模块

该模块负责生成浏览器自动化执行报告的独立 HTML 文件。
"""

import logging
import re
from importlib import metadata
from pathlib import Path
from typing import Optional, Union

from .js_templates import get_js_script
from .templates import get_html_document
from .utils import (
    prepare_report_data,
    report_success_from_data,
    save_report,
)

# 向后兼容：导出 _report_success_from_data（内部使用）
_report_success_from_data = report_success_from_data

logger = logging.getLogger(__name__)


def get_browser_use_version() -> str:
    """获取当前 browser-use 包版本号"""
    pyproject_path = Path(__file__).resolve().parents[3] / "pyproject.toml"
    if pyproject_path.exists():
        try:
            content = pyproject_path.read_text(encoding="utf-8")
            match = re.search(r'^version\s*=\s*"([^"]+)"', content, re.MULTILINE)
            if match:
                return match.group(1)
        except Exception as exc:
            logger.warning("Failed to read browser-use version from pyproject.toml: %s", exc)

    try:
        return metadata.version("browser-use")
    except metadata.PackageNotFoundError:
        logger.warning("browser-use package metadata not found, fallback to unknown")
    except Exception as exc:
        logger.warning("Failed to detect browser-use version: %s", exc)
    return "unknown"


def read_report_log(log_file: Optional[Union[str, Path]]) -> str:
    """读取日志文件内容供报告展示。"""
    if not log_file:
        return ""

    log_path = Path(log_file)
    if not log_path.exists() or not log_path.is_file():
        return ""

    try:
        return log_path.read_text(encoding="utf-8", errors="replace")
    except Exception as exc:
        logger.warning("Failed to read report log file %s: %s", log_path, exc)
        return ""


def create_standalone_report(
    data: dict,
    output_file: str = "agent_history.html",
    quality: int = 90,
    log_file: Optional[Union[str, Path]] = None,
    browser_info: Optional[str] = None,
) -> str:
    """
    创建独立的 HTML 报告文件

    Args:
         包含执行历史的字典数据
        output_file: 输出文件路径
        quality: 图片压缩质量 (1-100)
        browser_info: 浏览器标识信息（如 "Chrome 139"）

    Returns:
        输出文件的绝对路径
    """
    # 准备报告数据
    json_str, highlights_json, title_suffix = prepare_report_data(data, quality=quality)
    browser_use_version = get_browser_use_version()
    if browser_info:
        browser_use_version = f"{browser_use_version} | {browser_info}"
    log_text = read_report_log(log_file)

    # 生成 HTML 文档结构
    html_document = get_html_document(title_suffix, browser_use_version)

    # 生成 JavaScript 脚本
    js_script = get_js_script(json_str, highlights_json, log_text)

    # 组合完整的 HTML（在 </body> 前插入 JS）
    html_content = html_document.replace("</body>", js_script + "\n</body>")

    # 保存报告
    return save_report(html_content, output_file)


if __name__ == "__main__":
    import json
    import sys

    # 示例用法
    if len(sys.argv) > 1:
        input_file = sys.argv[1]
        with open(input_file, "r", encoding="utf-8") as f:
            test_json = json.load(f)
        create_standalone_report(test_json)
    else:
        print("Usage: python -m browser_use.agent.report.generation <result.json>")
