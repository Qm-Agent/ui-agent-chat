"""
任务级日志 Handler 模块

每个 Agent 任务独立写入自己的 log.log，解决批量/并发执行时
多任务日志混入同一文件的问题。

设计：
- 全局挂载一个 _TaskDispatchHandler（引用计数，无任务时自动摘除）
- 每个任务通过 ContextVar 注册自己的 MemoryHandler（UUID 键）
- 分发 handler 按 ContextVar 将日志路由到对应任务的 handler
- asyncio 并发安全：ContextVar 在每个 asyncio.Task 中独立，天然隔离
- 通过 MemoryHandler 批量写盘（每 buffer_capacity 条或 ERROR 立即 flush）
"""

import logging
import logging.handlers
import threading
import uuid
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
from typing import Generator, Optional, Union

_FORMATTER = logging.Formatter("%(asctime)s - %(levelname)-8s [%(name)s] %(message)s")
_LOGGER_NAME = "browser_use"
_BUFFER_CAPACITY = 20

# 当前协程/任务的 task_id，asyncio Task 间天然隔离
_active_task_id: ContextVar[Optional[str]] = ContextVar("_active_task_id", default=None)

# task_id -> MemoryHandler 注册表
_registry: dict[str, logging.handlers.MemoryHandler] = {}
_registry_lock = threading.Lock()

# 全局分发 handler 引用计数（为 0 时从 logger 摘除）
_dispatch_refcount = 0
_dispatch_refcount_lock = threading.Lock()


class _TaskDispatchHandler(logging.Handler):
    """
    全局单例 handler，挂载在 browser_use logger 上。
    按 ContextVar 将日志记录路由到当前任务的 MemoryHandler。
    无活跃任务上下文时静默丢弃（不写任何文件）。
    """

    def emit(self, record: logging.LogRecord) -> None:
        task_id = _active_task_id.get()
        if task_id is None:
            return
        with _registry_lock:
            handler = _registry.get(task_id)
        if handler is not None:
            handler.emit(record)


_global_dispatch = _TaskDispatchHandler()


def _attach_dispatch() -> None:
    global _dispatch_refcount
    with _dispatch_refcount_lock:
        if _dispatch_refcount == 0:
            logging.getLogger(_LOGGER_NAME).addHandler(_global_dispatch)
        _dispatch_refcount += 1


def _detach_dispatch() -> None:
    global _dispatch_refcount
    with _dispatch_refcount_lock:
        _dispatch_refcount -= 1
        if _dispatch_refcount == 0:
            logging.getLogger(_LOGGER_NAME).removeHandler(_global_dispatch)


@contextmanager
def task_log_handler(
    log_dir: Optional[Union[str, Path]],
    buffer_capacity: int = _BUFFER_CAPACITY,
) -> Generator[Optional[Path], None, None]:
    """
    上下文管理器：为单次 Agent 任务创建隔离的日志写入通道。

    行为：
    - 在 log_dir 下创建独立的 log.log，并发任务互不干扰
    - 每 buffer_capacity 条或遇到 ERROR 时批量写盘
    - 退出（含异常/中断）时强制 flush，防止日志截断
    - log_dir 为 None 时降级为 no-op，yield None

    并发安全：
    - 使用 ContextVar 实现 asyncio Task 级别的日志路由
    - 全局 _TaskDispatchHandler 引用计数，无任务时自动从 logger 摘除

    Args:
        log_dir: 任务日志目录，None 则跳过文件日志
        buffer_capacity: 触发批量写盘的缓冲行数，默认 20

    Yields:
        log.log 的绝对路径，或 None
    """
    if not log_dir:
        yield None
        return

    log_path = Path(log_dir) / "log.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)

    task_id = str(uuid.uuid4())

    # OS 级 8KB 缓冲，减少底层 syscall
    stream = open(log_path, "a", buffering=8192, encoding="utf-8")
    file_handler = logging.StreamHandler(stream)
    file_handler.setFormatter(_FORMATTER)

    mem_handler = logging.handlers.MemoryHandler(
        capacity=buffer_capacity,
        flushLevel=logging.ERROR,  # ERROR 及以上立即落盘
        target=file_handler,
        flushOnClose=True,
    )

    # 注册到分发表，设置当前协程上下文
    with _registry_lock:
        _registry[task_id] = mem_handler
    token = _active_task_id.set(task_id)
    _attach_dispatch()

    try:
        yield log_path
    finally:
        try:
            mem_handler.flush()
        finally:
            _active_task_id.reset(token)
            with _registry_lock:
                _registry.pop(task_id, None)
            _detach_dispatch()
            mem_handler.close()
            stream.close()
