"""
报告生成包

该包负责生成浏览器自动化执行报告的独立 HTML 文件。

包结构:
- generation.py  # 主入口
- utils.py       # 工具函数
- templates.py   # HTML 和 CSS 模板
- js_templates.py # JavaScript 模板
"""

from .generation import _report_success_from_data, create_standalone_report
from .js_templates import get_js_script
from .templates import get_html_document
from .utils import (
    compress_base64_image,
    extract_highlights,
    prepare_report_data,
    preprocess,
    process_json_images,
    report_success_from_data,
    save_report,
)

__all__ = [
    'create_standalone_report',
    '_report_success_from_data',
    'prepare_report_data',
    'save_report',
    'report_success_from_data',
    'preprocess',
    'compress_base64_image',
    'process_json_images',
    'extract_highlights',
    'get_html_document',
    'get_js_script',
]
