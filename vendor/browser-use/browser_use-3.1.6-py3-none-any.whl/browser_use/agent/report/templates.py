"""报告生成模板模块 - 包含 CSS 样式和 HTML 结构"""

# ============ CSS 变量和基础样式 ============
CSS_VARIABLES = """
    :root {
        --border-color: #E5E5E5;
        --bg-side: #F8F8F8;
        --bg-main: #FFF;
        --bg-dark: #2d2d2d;
        --text-main: #3b3b3b;
        --text-muted: #777;
        --primary: #06b1ab;
        --primary-dark: #01204E;
        --success: #2ecc71;
        --error: #e74c3c;

        /* 轮播组件变量 */
        --timeline-height: 70px;
        --thumb-width: 80px;
        --thumb-height: 50px;
        --dot-size: 10px;
        --transition-fast: 0.15s;
        --transition-normal: 0.3s;
        --transition-slow: 0.5s;
    }
"""

CSS_BASE = """
    * { box-sizing: border-box; }
    html, body { padding: 0; margin: 0; line-height: 1; }
    body {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans", Helvetica, Arial, sans-serif;
        font-size: 14px;
        color: var(--text-main);
        margin: 0;
        display: flex;
        flex-direction: column;
        height: 100vh;
        background: var(--bg-side);
        -webkit-font-smoothing: antialiased;
        line-height: 1.5;
    }
"""

CSS_PAGE_NAV = """
    .page-nav {
        height: 50px;
        padding: 0 16px;
        border-bottom: 1px solid var(--border-color);
        background: var(--bg-side);
        display: flex;
        align-items: center;
        flex-shrink: 0;
        z-index: 100;
    }
    .page-nav .task-list-name { font-weight: bold; color: var(--text-main); }
    .page-nav .header-right {
        display: flex;
        align-items: center;
        gap: 12px;
        margin-left: auto;
    }
    .page-nav .report-version-chip {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 3px 10px;
        border-radius: 4px;
        background: #eef7f7;
        border: 1px solid #d7eceb;
        font-size: 12px;
        color: var(--text-muted);
        font-variant-numeric: tabular-nums;
    }
    .page-nav .exec-stats {
        display: flex;
        align-items: center;
        gap: 12px;
        font-size: 13px;
        color: var(--text-muted);
    }
    .page-nav .btn-log-drawer {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        border: 1px solid var(--border-color);
        border-radius: 6px;
        background: #fff;
        color: var(--text-main);
        padding: 6px 10px;
        cursor: pointer;
        font-size: 12px;
        transition: all var(--transition-fast);
    }
    .page-nav .btn-log-drawer:hover {
        border-color: var(--primary);
        color: var(--primary-dark);
    }
    .page-nav .btn-log-drawer.active {
        border-color: var(--primary);
        background: rgba(6, 177, 171, 0.08);
    }
    .page-nav .log-error-badge {
        display: none;
        min-width: 18px;
        height: 18px;
        border-radius: 999px;
        align-items: center;
        justify-content: center;
        padding: 0 5px;
        font-size: 11px;
        line-height: 1;
        color: #fff;
        background: var(--error);
        font-variant-numeric: tabular-nums;
    }
    .page-nav .log-error-badge.show {
        display: inline-flex;
    }
    .page-nav .stat-item {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 3px 10px;
        border-radius: 4px;
        background: #f0f0f0;
        font-variant-numeric: tabular-nums;
    }
    .page-nav .stat-item.stat-success { background: rgba(46,204,113,0.12); color: #1e8449; }
    .page-nav .stat-item.stat-fail { background: rgba(231,76,60,0.12); color: var(--error); }
    .page-nav .stat-item.stat-incomplete { background: rgba(241,196,15,0.12); color: #b7950b; }
"""

CSS_TIMELINE_CAROUSEL = """
    .timeline-carousel {
        height: var(--timeline-height);
        background: #fff;
        border-bottom: 1px solid var(--border-color);
        display: flex;
        align-items: center;
        padding: 0 16px;
        overflow-x: auto;
        gap: 8px;
        flex-shrink: 0;
        scroll-behavior: smooth;
        position: sticky;
        top: 0;
        z-index: 10;
    }
    .timeline-carousel::-webkit-scrollbar {
        height: 4px;
    }
    .timeline-carousel::-webkit-scrollbar-thumb {
        background: var(--border-color);
        border-radius: 2px;
    }
    .timeline-thumb {
        flex-shrink: 0;
        width: var(--thumb-width);
        height: var(--thumb-height);
        border-radius: 4px;
        border: 2px solid transparent;
        cursor: pointer;
        object-fit: cover;
        transition: all var(--transition-normal) cubic-bezier(0.4, 0, 0.2, 1);
        opacity: 0.7;
    }
    .timeline-thumb:hover {
        opacity: 1;
        border-color: var(--primary);
        transform: scale(1.05);
    }
    .timeline-thumb.active {
        border-color: var(--primary);
        opacity: 1;
        box-shadow: 0 2px 8px rgba(6, 177, 171, 0.3);
    }
    .timeline-thumb.failed {
        border-color: var(--error);
    }
    .timeline-thumb.loading {
        background: linear-gradient(90deg, var(--bg-side) 25%, #e0e0e0 50%, var(--bg-side) 75%);
        background-size: 200% 100%;
        animation: shimmer 1.5s infinite;
    }
    @keyframes shimmer {
        0% { background-position: -200% 0; }
        100% { background-position: 200% 0; }
    }
    .timeline-thumb-placeholder {
        width: var(--thumb-width);
        height: var(--thumb-height);
        background: var(--bg-side);
        border-radius: 4px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
        color: var(--text-muted);
        cursor: pointer;
        transition: all var(--transition-normal);
        border: 2px solid transparent;
    }
    .timeline-thumb-placeholder:hover {
        border-color: var(--primary);
    }
    .timeline-thumb-placeholder.active {
        border-color: var(--primary);
    }
    .timeline-thumb-placeholder.failed {
        border-color: var(--error);
    }
    .timeline-empty {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--text-muted);
        font-size: 13px;
    }
"""

CSS_MAIN_LAYOUT = """
    .main-layout {
        display: flex;
        flex: 1;
        min-height: 0;
        overflow: hidden;
    }
    #sidebar {
        width: 280px;
        background: var(--bg-side);
        border-right: 1px solid var(--border-color);
        flex-shrink: 0;
        height: 100%;
        overflow: hidden;
        position: sticky;
        top: 0;
    }
    .side-bar {
        display: flex;
        flex-direction: column;
        width: 100%;
        height: 100%;
        overflow-y: auto;
        box-sizing: border-box;
        padding-top: 0;
    }
    .side-sub-title {
        padding: 10px 10px 4px;
        margin-bottom: 6px;
        font-weight: bold;
        color: var(--text-main);
    }
    .tree-container { padding: 10px; }
    .tree-node {
        cursor: pointer;
        padding: 8px 10px;
        margin: 2px 0;
        border-radius: 4px;
        transition: all var(--transition-fast);
        user-select: none;
        word-break: break-all;
        line-height: 1.4;
        display: block;
    }
    .tree-node:hover { background: #dcdcdc80; }
    .active-node { background: var(--primary) !important; color: #fff !important; }
    .cmd-group {
        font-weight: bold;
        font-size: 0.95em;
        border-left: 3px solid var(--primary);
        margin-top: 6px;
        background: rgba(6,177,171,0.08);
    }
    .cmd-group.aiquick-command {
        user-select: text;
        cursor: text;
        font-weight: normal;
        font-size: 13px;
        line-height: 1.55;
    }
    .cmd-group.aiquick-command .cmd-key {
        display: block;
        font-weight: 700;
        color: var(--primary-dark);
        margin-bottom: 4px;
    }
    .cmd-group.aiquick-command .cmd-full-text {
        display: block;
        white-space: pre-wrap;
        overflow-wrap: anywhere;
        word-break: break-word;
        color: var(--text-main);
    }
    .sub-tree { margin-left: 18px; border-left: 1px dashed var(--border-color); }
    .inst-item { font-size: 0.9em; color: var(--text-main); display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 4px; }
    .inst-item .inst-title { flex: 1 1 auto; min-width: 0; }
    .inst-item:before { content: "🔧 "; flex-shrink: 0; }
    .step-meta { font-size: 11px; color: var(--text-muted); flex-shrink: 0; }
    .step-meta .step-duration { margin-right: 6px; }
    .step-meta .step-status { padding: 1px 4px; border-radius: 3px; }
    .step-meta .step-status.success { background: var(--success); color: #fff; }
    .step-meta .step-status.fail { background: var(--error); color: #fff; }
    .conv-item { font-size: 0.85em; color: var(--text-muted); }
    .conv-item:before { content: "💬 "; }
    .command-full-title {
        padding: 10px 12px;
        border: 1px solid var(--border-color);
        border-radius: 5px;
        background: rgba(6,177,171,0.06);
        margin-bottom: 12px;
    }
    .command-full-title-label {
        font-size: 12px;
        color: var(--text-muted);
        margin-bottom: 6px;
    }
    .command-full-title-text {
        font-size: 13px;
        line-height: 1.6;
        white-space: pre-wrap;
        overflow-wrap: anywhere;
        word-break: break-word;
        color: var(--text-main);
    }
    .role-tag {
        font-size: 11px;
        background: var(--primary);
        padding: 2px 6px;
        border-radius: 3px;
        margin-right: 6px;
        color: #fff;
    }
"""

CSS_MAIN_CONTENT = """
    #main {
        flex: 1;
        display: flex;
        flex-direction: column;
        min-width: 0;
        background: var(--bg-main);
    }
    .preview-container {
        flex: 1;
        display: flex;
        flex-direction: column;
        min-height: 0;
        padding: 16px;
    }
    .preview-image-wrapper {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        background: var(--bg-dark);
        border-radius: 8px;
        overflow: hidden;
        position: relative;
        min-height: 300px;
    }
    .preview-image {
        max-width: 100%;
        max-height: 100%;
        object-fit: contain;
        cursor: zoom-in;
        opacity: 0;
        animation: fadeIn var(--transition-normal) ease forwards;
    }
    .preview-image.fail-border {
        border: 3px solid var(--error);
    }
    .preview-image.loading {
        opacity: 0.5;
    }
    @keyframes fadeIn {
        from { opacity: 0; transform: scale(0.98); }
        to { opacity: 1; transform: scale(1); }
    }
    .preview-empty {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        color: #999;
        font-size: 16px;
        text-align: center;
    }
    .preview-empty-icon {
        font-size: 48px;
        margin-bottom: 12px;
        opacity: 0.6;
    }
    .preview-error {
        position: absolute;
        bottom: 16px;
        left: 16px;
        right: 16px;
        background: rgba(231, 76, 60, 0.95);
        color: #fff;
        padding: 12px 16px;
        border-radius: 6px;
        font-size: 13px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
"""

CSS_CAROUSEL_CONTROLS = """
    .carousel-control-bar {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 12px;
        padding: 12px;
        background: var(--bg-side);
        border-radius: 8px;
        margin-top: 12px;
        flex-wrap: wrap;
    }
    .carousel-btn {
        background: #fff;
        border: 1px solid var(--border-color);
        border-radius: 6px;
        padding: 6px 14px;
        cursor: pointer;
        font-size: 14px;
        transition: all var(--transition-fast);
        display: inline-flex;
        align-items: center;
        gap: 4px;
    }
    .carousel-btn:hover:not(:disabled) {
        background: var(--primary);
        color: #fff;
        border-color: var(--primary);
    }
    .carousel-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
    }
    .carousel-btn:focus {
        outline: 2px solid var(--primary);
        outline-offset: 2px;
    }
    .carousel-dots {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
        justify-content: center;
    }
    .carousel-dot {
        width: var(--dot-size);
        height: var(--dot-size);
        border-radius: 50%;
        background: var(--border-color);
        cursor: pointer;
        transition: all var(--transition-fast);
    }
    .carousel-dot:hover {
        background: var(--primary);
    }
    .carousel-dot.active {
        background: var(--primary);
        transform: scale(1.3);
    }
    .carousel-dot:focus {
        outline: 2px solid var(--primary);
        outline-offset: 2px;
    }
    .carousel-status {
        font-size: 13px;
        color: var(--text-muted);
        min-width: 80px;
        text-align: center;
    }
    .carousel-step-info {
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .carousel-step-title {
        font-weight: 500;
        color: var(--text-main);
    }
    .carousel-status-badge {
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 11px;
        font-weight: 500;
    }
    .carousel-status-badge.success {
        background: rgba(46, 204, 113, 0.15);
        color: var(--success);
    }
    .carousel-status-badge.failed {
        background: rgba(231, 76, 60, 0.15);
        color: var(--error);
    }
    .carousel-progress {
        height: 3px;
        background: var(--border-color);
        border-radius: 2px;
        overflow: hidden;
        margin-top: 8px;
    }
    .carousel-progress-bar {
        height: 100%;
        background: var(--primary);
        width: 0;
        transition: width linear;
    }
"""

CSS_DETAIL_PANEL = """
    .detail-panel {
        padding: 16px;
        border-top: 1px solid var(--border-color);
        background: var(--bg-side);
        max-height: 280px;
        overflow-y: auto;
        transition: max-height 0.3s ease;
    }
    .detail-panel.expanded {
        max-height: none;
        flex: 1;
    }
    .detail-row {
        display: flex;
        margin-bottom: 8px;
    }
    .detail-label {
        width: 80px;
        color: var(--text-muted);
        flex-shrink: 0;
    }
    .detail-value {
        flex: 1;
        word-break: break-all;
    }
    .error-message {
        background: rgba(231, 76, 60, 0.1);
        border-left: 3px solid var(--error);
        padding: 8px 12px;
        border-radius: 4px;
        margin-top: 8px;
        font-size: 13px;
        color: var(--error);
    }
"""

CSS_IMAGE_LIGHTBOX = """
    .image-lightbox {
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.85);
        display: none;
        align-items: center;
        justify-content: center;
        z-index: 1000;
        cursor: zoom-out;
        padding: 24px;
    }
    .image-lightbox.show {
        display: flex;
    }
    .image-lightbox-content {
        max-width: min(96vw, 1600px);
        max-height: 90vh;
        border-radius: 8px;
        box-shadow: 0 8px 36px rgba(0, 0, 0, 0.35);
        cursor: default;
    }
    .image-lightbox-close {
        position: absolute;
        top: 16px;
        right: 16px;
        width: 36px;
        height: 36px;
        border: none;
        border-radius: 999px;
        background: rgba(255, 255, 255, 0.18);
        color: #fff;
        font-size: 24px;
        line-height: 1;
        cursor: pointer;
    }
    .image-lightbox-close:hover {
        background: rgba(255, 255, 255, 0.28);
    }
"""

CSS_LOG_DRAWER = """
    .log-drawer-backdrop {
        position: fixed;
        inset: 50px 0 0 280px;
        background: rgba(0, 0, 0, 0.22);
        opacity: 0;
        pointer-events: none;
        transition: opacity var(--transition-normal);
        z-index: 220;
    }
    .log-drawer-backdrop.show {
        opacity: 1;
        pointer-events: auto;
    }
    .log-drawer {
        position: fixed;
        top: 50px;
        right: 0;
        height: calc(100vh - 50px);
        width: clamp(420px, 42vw, 720px);
        background: #fff;
        border-left: 1px solid var(--border-color);
        box-shadow: -10px 0 24px rgba(0, 0, 0, 0.12);
        transform: translateX(100%);
        transition: transform var(--transition-normal);
        z-index: 230;
        display: flex;
        flex-direction: column;
    }
    .log-drawer.show {
        transform: translateX(0);
    }
    .log-drawer-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 12px 14px;
        border-bottom: 1px solid var(--border-color);
        background: #fafafa;
    }
    .log-drawer-title {
        margin: 0;
        font-size: 15px;
        font-weight: 600;
    }
    .log-drawer-meta {
        margin-top: 4px;
        font-size: 12px;
        color: var(--text-muted);
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
    }
    .log-meta-pill {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-height: 20px;
        padding: 0 8px;
        border-radius: 999px;
        font-size: 11px;
        font-weight: 700;
        border: 1px solid transparent;
        letter-spacing: 0.2px;
        font-variant-numeric: tabular-nums;
        cursor: pointer;
        user-select: none;
        transition: transform var(--transition-fast), box-shadow var(--transition-fast);
    }
    .log-meta-pill:hover {
        transform: translateY(-1px);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.12);
    }
    .log-meta-pill.active {
        box-shadow: 0 0 0 2px rgba(6, 177, 171, 0.35);
    }
    .log-meta-pill.error {
        color: #fff;
        background: #e53e3e;
        border-color: #c53030;
    }
    .log-meta-pill.warn {
        color: #7b341e;
        background: #fbd38d;
        border-color: #f6ad55;
    }
    .log-meta-pill.total {
        color: #2d3748;
        background: #edf2f7;
        border-color: #cbd5e0;
    }
    .log-drawer-close {
        border: none;
        background: transparent;
        font-size: 22px;
        line-height: 1;
        cursor: pointer;
        color: var(--text-muted);
    }
    .log-drawer-toolbar {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
        padding: 10px 12px;
        border-bottom: 1px solid var(--border-color);
    }
    .log-drawer-toolbar input,
    .log-drawer-toolbar select,
    .log-drawer-toolbar button {
        border: 1px solid var(--border-color);
        border-radius: 6px;
        background: #fff;
        font-size: 12px;
        color: var(--text-main);
        padding: 6px 8px;
    }
    .log-drawer-toolbar input {
        flex: 1;
        min-width: 220px;
    }
    .log-drawer-body {
        flex: 1;
        min-height: 0;
        overflow: auto;
        background: #0e1116;
        color: #d4d9e4;
        font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace;
        font-size: 12px;
        line-height: 1.5;
        padding: 10px 0;
    }
    .log-line {
        white-space: pre-wrap;
        word-break: break-word;
        padding: 4px 12px;
        border-left: 3px solid transparent;
        display: flex;
        align-items: flex-start;
        gap: 8px;
    }
    .log-level-pill {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 46px;
        padding: 1px 7px;
        border-radius: 999px;
        font-size: 10px;
        font-weight: 800;
        line-height: 1.4;
        letter-spacing: 0.3px;
        flex-shrink: 0;
        margin-top: 1px;
        border: 1px solid transparent;
    }
    .log-line-text {
        white-space: pre-wrap;
        word-break: break-word;
        flex: 1;
    }
    .log-line.level-error {
        border-left-color: #ff4d4f;
        background: rgba(255, 77, 79, 0.18);
        box-shadow: inset 0 0 0 1px rgba(255, 77, 79, 0.22);
    }
    .log-line.level-warn {
        border-left-color: #ed8936;
        background: rgba(237, 137, 54, 0.16);
        box-shadow: inset 0 0 0 1px rgba(237, 137, 54, 0.22);
    }
    .log-line.level-info {
        border-left-color: #63b3ed;
    }
    .log-line.level-other {
        border-left-color: #718096;
    }
    .log-line.focused {
        box-shadow: inset 0 0 0 2px rgba(6, 177, 171, 0.45);
        animation: logFocusPulse 1.6s ease;
    }
    @keyframes logFocusPulse {
        0% { box-shadow: inset 0 0 0 2px rgba(6, 177, 171, 0.85); }
        100% { box-shadow: inset 0 0 0 2px rgba(6, 177, 171, 0.15); }
    }
    .log-level-pill.error {
        color: #fff;
        background: #e53e3e;
        border-color: #c53030;
    }
    .log-level-pill.warn {
        color: #7b341e;
        background: #fbd38d;
        border-color: #f6ad55;
    }
    .log-level-pill.info {
        color: #1e3a5f;
        background: #bee3f8;
        border-color: #90cdf4;
    }
    .log-level-pill.other {
        color: #edf2f7;
        background: #4a5568;
        border-color: #2d3748;
    }
    .log-drawer-empty {
        padding: 20px 14px;
        color: #9aa4b2;
    }
    .log-drawer-footer {
        border-top: 1px solid var(--border-color);
        background: #fafafa;
        padding: 8px 12px;
        font-size: 12px;
        color: var(--text-muted);
    }
"""

CSS_LEGACY = """
    .detail-side .meta-kv {
        padding: 10px 0;
        overflow: hidden;
    }
    .detail-side .meta-kv .meta {
        box-sizing: border-box;
        padding: 6px 0;
        width: 100%;
        display: flex;
        flex-direction: row;
        line-height: 1.5;
    }
    .detail-side .meta-kv .meta .meta-key {
        width: 120px;
        text-align: right;
        padding-right: 16px;
        flex-shrink: 0;
        color: var(--text-muted);
    }
    .detail-side .meta-kv .meta .meta-value { flex: 1 1; word-break: break-all; }
    .img-container { margin: 15px 0; }
    .img-container img {
        max-width: 100%;
        max-height: 600px;
        border: 1px solid var(--border-color);
        border-radius: 4px;
        cursor: zoom-in;
    }
    .json-container {
        font-family: 'Monaco', 'Consolas', monospace;
        font-size: 13px;
        line-height: 1.6;
        white-space: pre-wrap;
    }
    .json-kv { margin-left: 24px; border-left: 1px dashed #ccc; padding-left: 10px; }
    .json-key { color: #c7254e; font-weight: bold; }
    .json-string { color: #27ae60; word-break: break-all; }
    .json-bool { color: #2980b9; font-weight: bold; }
    .json-num { color: #8e44ad; }
"""

CSS_RESPONSIVE = """
    @media (max-width: 768px) {
        :root {
            --timeline-height: 60px;
            --thumb-width: 60px;
            --thumb-height: 40px;
        }
        #sidebar { width: 240px; }
        .carousel-control-bar { gap: 8px; }
        .carousel-btn { padding: 4px 10px; font-size: 13px; }
    }

    @media (max-width: 480px) {
        #sidebar { display: none; }
        .carousel-dots { display: none; }
    }
"""

# 组合所有 CSS
CSS_ALL = f"""
        /* === CSS 变量 === */
        {CSS_VARIABLES}

        /* === 基础样式 === */
        {CSS_BASE}

        /* === 顶部导航栏 === */
        {CSS_PAGE_NAV}

        /* === 横向缩略图时间轴 === */
        {CSS_TIMELINE_CAROUSEL}

        /* === 主体布局 === */
        {CSS_MAIN_LAYOUT}

        /* === 右侧内容区 === */
        {CSS_MAIN_CONTENT}

        /* === 轮播控制条 === */
        {CSS_CAROUSEL_CONTROLS}

        /* === 详情面板 === */
        {CSS_DETAIL_PANEL}

        /* === 图片页内放大预览 === */
        {CSS_IMAGE_LIGHTBOX}

        /* === 执行日志抽屉 === */
        {CSS_LOG_DRAWER}

        /* === 原有样式（兼容） === */
        {CSS_LEGACY}

        /* === 响应式适配 === */
        {CSS_RESPONSIVE}
"""


# ============ HTML 结构模板 ============
HTML_HEADER = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0" />
    <title>report-uiAgent - {title_suffix}</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/prismjs@1/themes/prism.min.css">
    <style>
        {css_content}
    </style>
</head>
<body>
"""

HTML_PAGE_NAV = """
<!-- 顶部导航 -->
<div class="page-nav" role="banner">
    <span class="task-list-name">report-uiAgent - {title_suffix}</span>
    <div class="header-right">
        <button id="btn-log-drawer-toggle" class="btn-log-drawer" aria-expanded="false" aria-controls="log-drawer">
            查看执行日志
            <span id="log-error-badge" class="log-error-badge" aria-label="错误日志数">0</span>
        </button>
        <span class="report-version-chip" title="uiAgent version">uiAgent version: v{browser_use_version}</span>
        <div class="exec-stats" id="exec-stats"></div>
    </div>
</div>
"""

HTML_MAIN_LAYOUT = """
<!-- 主体布局 -->
<div class="main-layout">
    <!-- 左侧边栏 -->
    <aside id="sidebar" role="navigation" aria-label="执行历史导航">
        <div class="side-bar">
            <div id="tree-root" class="tree-container" role="tree"></div>
        </div>
    </aside>

    <!-- 右侧内容区 -->
    <main id="main" role="main">
        <!-- 横向缩略图时间轴 -->
        <div id="timeline-carousel"
             class="timeline-carousel"
             role="region"
             aria-label="执行步骤缩略图时间轴">
        </div>

        <!-- 大图预览 -->
        <div class="preview-container">
            <div id="preview-wrapper"
                 class="preview-image-wrapper"
                 role="region"
                 aria-roledescription="carousel"
                 aria-label="执行步骤截图预览">
                <div id="preview-empty" class="preview-empty">
                    <div class="preview-empty-icon" aria-hidden="true">🖼️</div>
                    <div>选择步骤查看截图</div>
                </div>
                <img id="preview-image"
                     class="preview-image"
                     style="display: none;"
                     alt="执行步骤截图"
                     loading="lazy"
                     role="img">
                <div id="preview-error" class="preview-error" style="display: none;">
                    <span aria-hidden="true">❌</span>
                    <span id="preview-error-text"></span>
                </div>
            </div>

            <!-- 进度条 -->
            <div class="carousel-progress" id="carousel-progress" style="display: none;">
                <div class="carousel-progress-bar" id="progress-bar"></div>
            </div>

            <!-- 轮播控制条 -->
            <div class="carousel-control-bar" id="carousel-controls" role="toolbar" aria-label="轮播控制">
                <button class="carousel-btn"
                        id="btn-prev"
                        aria-label="上一张截图"
                        title="上一张 (←)">
                    <span aria-hidden="true">◀</span> 上一步
                </button>
                <div class="carousel-dots" id="carousel-dots" role="tablist" aria-label="步骤指示器"></div>
                <button class="carousel-btn"
                        id="btn-next"
                        aria-label="下一张截图"
                        title="下一张 (→)">
                    下一步 <span aria-hidden="true">▶</span>
                </button>
                <div class="carousel-status" id="carousel-status" aria-live="polite">Step 0/0</div>
                <button class="carousel-btn"
                        id="btn-play"
                        aria-label="暂停自动播放"
                        title="播放/暂停 (空格)">
                    <span aria-hidden="true">⏸</span>
                </button>
            </div>
        </div>

        <!-- 详情面板 -->
        <div class="detail-panel" id="detail-panel" aria-live="polite">
            <div class="carousel-step-info">
                <span class="carousel-step-title" id="detail-title">选择步骤查看详情</span>
                <span class="carousel-status-badge" id="detail-status" style="display: none;"></span>
            </div>
            <div id="detail-content"></div>
        </div>
    </main>
</div>
"""

HTML_IMAGE_LIGHTBOX = """
<div id="image-lightbox" class="image-lightbox" role="dialog" aria-modal="true" aria-label="截图放大预览">
    <button id="image-lightbox-close" class="image-lightbox-close" aria-label="关闭预览">×</button>
    <img id="image-lightbox-content" class="image-lightbox-content" alt="截图放大预览" />
</div>
"""

HTML_LOG_DRAWER = """
<div id="log-drawer-backdrop" class="log-drawer-backdrop" aria-hidden="true"></div>
<aside id="log-drawer" class="log-drawer" aria-label="执行日志抽屉" aria-hidden="true">
    <div class="log-drawer-header">
        <div>
            <h2 class="log-drawer-title">执行日志</h2>
            <div id="log-drawer-meta" class="log-drawer-meta">
                <span id="log-total-count" class="log-meta-pill total">TOTAL 0</span>
                <span id="log-error-count" class="log-meta-pill error">ERROR 0</span>
                <span id="log-warn-count" class="log-meta-pill warn">WARN 0</span>
            </div>
        </div>
        <button id="btn-log-drawer-close" class="log-drawer-close" aria-label="关闭执行日志">×</button>
    </div>
    <div class="log-drawer-toolbar">
        <input id="log-search-input" type="text" placeholder="搜索关键字（如 Timeout / 403 / aiWaitFor）" />
        <select id="log-level-filter" aria-label="日志级别筛选">
            <option value="all">ALL</option>
            <option value="error">ERROR</option>
            <option value="warn">WARN</option>
            <option value="info">INFO</option>
        </select>
        <button id="btn-log-copy-all" type="button">复制全部</button>
        <button id="btn-log-jump-bottom" type="button">跳到底部</button>
    </div>
    <div id="log-drawer-body" class="log-drawer-body"></div>
    <div id="log-drawer-footer" class="log-drawer-footer">显示 0 / 0 行</div>
</aside>
"""

HTML_FOOTER = """
</body>
</html>
"""


def get_html_document(title_suffix: str, browser_use_version: str = "unknown") -> str:
    """生成完整的 HTML 文档结构"""
    header = HTML_HEADER.format(title_suffix=title_suffix, css_content=CSS_ALL)
    nav = HTML_PAGE_NAV.format(
        title_suffix=title_suffix, browser_use_version=browser_use_version
    )
    return (
        header
        + nav
        + HTML_MAIN_LAYOUT
        + HTML_LOG_DRAWER
        + HTML_IMAGE_LIGHTBOX
        + HTML_FOOTER
    )
