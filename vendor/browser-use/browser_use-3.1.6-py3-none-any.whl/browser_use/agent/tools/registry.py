"""
browser_use/agent/tools/registry.py
------------------------------------
Tool registry + @tool decorator + auto-discovery for browser_use builtin tools.

Design constraints (see docs/tools/tools_design.md v6.1):
- @tool is a pure marker decorator; registration happens in autodiscover_builtin().
- builtin/*.py must import `tool` from HERE (browser_use.agent.tools.registry),
  NOT from the parent __init__.py, to avoid circular imports.
"""

from __future__ import annotations

import importlib
import logging
import pkgutil
from typing import Callable, Dict, List, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

class ToolRegistry:
    """Central registry for built-in sync/async tools."""

    _tools: Dict[str, Callable] = {}

    @classmethod
    def get(cls, name: str) -> Optional[Callable]:
        """Return the callable for `name`, or None if not registered."""
        return cls._tools.get(name)

    @classmethod
    def list_tools(cls) -> List[str]:
        """Return a sorted list of all registered tool names."""
        return sorted(cls._tools.keys())

    @classmethod
    def register(cls, name: str, func: Callable) -> bool:
        """
        Register a tool callable once.

        Returns:
            True  -> registered
            False -> skipped because name already exists
        """
        if name in cls._tools:
            return False
        cls._tools[name] = func
        return True

    @classmethod
    def unregister(cls, name: str) -> None:
        """Remove a tool registration if it exists."""
        cls._tools.pop(name, None)

    @classmethod
    def count(cls) -> int:
        """Return number of currently registered tools."""
        return len(cls._tools)

    @classmethod
    def snapshot(cls) -> Dict[str, Callable]:
        """Return a shallow copy of registry state (for tests)."""
        return dict(cls._tools)

    @classmethod
    def restore(cls, snapshot: Dict[str, Callable]) -> None:
        """Replace registry state (for tests)."""
        cls._tools.clear()
        cls._tools.update(snapshot)


def tool(name: str) -> Callable:
    """
    Pure marker decorator.  Sets func._tool_name = name and returns func unchanged.
    Registration is deferred to autodiscover_builtin().

    Usage (in builtin/*.py):
        from browser_use.agent.tools.registry import tool

        @tool("randomPhone")
        def random_phone() -> str: ...
    """
    def decorator(func: Callable) -> Callable:
        func._tool_name = name
        return func
    return decorator


def autodiscover_builtin() -> None:
    """
    Scan browser_use.agent.tools.builtin for all modules, import each, and
    register every callable that carries a _tool_name attribute.

    Idempotent: already-registered names are skipped (first-registered wins).
    Safe: a per-module try/except ensures one bad file never blocks the others.
    """
    import browser_use.agent.tools.builtin as builtin_pkg

    for _, module_name, _ in pkgutil.iter_modules(builtin_pkg.__path__):
        try:
            module = importlib.import_module(
                f"browser_use.agent.tools.builtin.{module_name}"
            )
        except Exception as exc:
            logger.warning(
                f"[tools] Failed to load builtin module '{module_name}': {exc}"
            )
            continue

        for attr in vars(module).values():
            if callable(attr) and hasattr(attr, "_tool_name"):
                t_name: str = attr._tool_name
                if not ToolRegistry.register(t_name, attr):
                    logger.warning(
                        f"[tools] Duplicate tool name '{t_name}' in module "
                        f"'{module_name}' — skipped (first-registered wins)"
                    )
                else:
                    logger.debug(f"[tools] Registered tool '{t_name}' from '{module_name}'")
