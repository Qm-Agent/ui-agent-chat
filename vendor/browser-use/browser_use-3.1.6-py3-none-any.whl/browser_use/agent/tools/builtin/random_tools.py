"""
browser_use/agent/tools/builtin/random_tools.py
-------------------------------------------------
Built-in random-data generation tools.

IMPORTANT: import `tool` from registry directly — NOT from parent __init__
           to avoid circular imports.
"""

import random
import string

# Must import from registry directly (not from browser_use.agent.tools)
from browser_use.agent.tools.registry import tool


@tool("randomPhone")
def random_phone() -> str:
    """Generate a random 11-digit Chinese mobile number (starts with 1[3-9])."""
    prefixes = [
        '130', '131', '132', '133', '134', '135', '136', '137', '138', '139',
        '150', '151', '152', '153', '155', '156', '157', '158', '159',
        '166', '170', '171', '172', '173', '175', '176', '177', '178',
        '180', '181', '182', '183', '184', '185', '186', '187', '188', '189',
        '191', '198', '199',
    ]
    prefix = random.choice(prefixes)
    suffix = ''.join(random.choices(string.digits, k=8))
    return prefix + suffix


@tool("randomInt")
def random_int(min: int = 0, max: int = 100) -> int:
    """Return a random integer in the closed interval [min, max]."""
    return random.randint(min, max)


@tool("randomFloat")
def random_float(min: float = 0.0, max: float = 1.0, precision: int = 2) -> float:
    """Return a random float in [min, max] rounded to `precision` decimal places."""
    value = random.uniform(min, max)
    return round(value, precision)


@tool("randomStr")
def random_str(length: int = 8, charset: str = "alphanumeric") -> str:
    """
    Return a random string of the given length.

    charset options:
      - "alphanumeric" (default): a-z, A-Z, 0-9
      - "alpha": a-z, A-Z
      - "numeric": 0-9
      - any other string is used as the character pool directly
    """
    charsets = {
        "alphanumeric": string.ascii_letters + string.digits,
        "alpha": string.ascii_letters,
        "numeric": string.digits,
    }
    pool = charsets.get(charset, charset)
    if not pool:
        pool = string.ascii_letters + string.digits
    return ''.join(random.choices(pool, k=length))
