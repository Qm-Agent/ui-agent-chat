"""
browser_use/agent/tools/builtin/time_tools.py
----------------------------------------------
Built-in time / UUID generation tools.

IMPORTANT: import `tool` from registry directly — NOT from parent __init__
           to avoid circular imports.
"""

import uuid as _uuid
from datetime import datetime

# Must import from registry directly (not from browser_use.agent.tools)
from browser_use.agent.tools.registry import tool


@tool("timestamp")
def timestamp(format: str = "%Y-%m-%d %H:%M:%S") -> str:
    """Return the current local time formatted by `format` (strftime syntax)."""
    return datetime.now().strftime(format)


@tool("currentDate")
def current_date() -> str:
    """Return today's date as YYYY-MM-DD."""
    return datetime.now().strftime("%Y-%m-%d")


@tool("currentDatetime")
def current_datetime() -> str:
    """Return the current local date and time as YYYY-MM-DD HH:MM:SS."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


@tool("uuid")
def generate_uuid() -> str:
    """Return a random UUID4 string."""
    return str(_uuid.uuid4())
