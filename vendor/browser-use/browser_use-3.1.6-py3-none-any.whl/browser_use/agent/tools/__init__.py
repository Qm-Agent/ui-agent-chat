"""
browser_use/agent/tools/__init__.py
-------------------------------------
Public surface of the tools sub-package.

Importing this module triggers autodiscover_builtin(), which scans
browser_use/agent/tools/builtin/ and registers all @tool-decorated functions
into ToolRegistry. Idempotent — safe to import multiple times.
"""

from browser_use.agent.tools.registry import ToolRegistry, autodiscover_builtin, tool

# Auto-discover and register all built-in tools at import time.
autodiscover_builtin()

__all__ = ["ToolRegistry", "tool", "autodiscover_builtin"]
