from __future__ import annotations

import json
import traceback
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Type, TypeAlias, Union

from langchain_core.messages import BaseMessage
from openai import RateLimitError
from PIL import Image
from pydantic import BaseModel, ConfigDict, Field, ValidationError, create_model

from browser_use.agent.tasks import BaseCommandConfig
from browser_use.browser.views import BrowserStateHistory
from browser_use.controller.registry.views import ActionModel, RegisteredAction
from browser_use.utils import get_polymorphic_type, substitute_variables

CommandArgType: TypeAlias = Union[BaseCommandConfig, str, int, float, Dict, None]


class AgentBrain(BaseModel):
    """Current state of the agent"""
    reasoning: str
    expected_outcome: str


class AgentOutput(BaseModel):
    """Output model for agent

    @dev note: this model is extended with custom actions in AgentService.
    You can also use some fields that are not in this model as provided by the linter,
    as long as they are registered in the DynamicActions model.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    current_state: AgentBrain
    action: List[ActionModel] = Field(
        ...,
        description='List of actions to execute',
        json_schema_extra={'min_items': 1},  # Ensure at least one action is provided
    )

    @staticmethod
    def type_with_custom_actions(custom_actions: Type[ActionModel]) -> Type['AgentOutput']:
        """Extend actions with custom actions"""
        model_ = create_model(
            'AgentOutput',
            __base__=AgentOutput,
            action=(
                List[custom_actions],
                Field(..., description='List of actions to execute', json_schema_extra={'min_items': 1}),
            ),
            __module__=AgentOutput.__module__,
        )
        model_.__doc__ = 'AgentOutput model with custom actions'
        return model_


class PlannerOutput(BaseModel):
    """Output model for agent

    @dev note: this model is extended with custom actions in AgentService.
    You can also use some fields that are not in this model as provided by the linter,
    as long as they are registered in the DynamicActions model.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    state_analysis: str
    progress_evaluation: str
    reasoning: str
    plan: str = Field(
        ...,
        description='Plan containing a todo list in markdown format',
    )
    is_ultimate_task_done: bool = Field(
        ...,
        description='Whether the ultimate task is done',
    )
    source: str = Field(description='Source of the plan')

    @staticmethod
    def type_with_custom_actions(custom_actions: Type[ActionModel]) -> Type['PlannerOutput']:
        """Extend actions with custom actions"""
        model_ = create_model(
            'PlannerOutput',
            __base__=PlannerOutput,
            plan_action=(
                List[custom_actions],
                Field(..., description='List of actions to execute', json_schema_extra={'min_items': 1}),
            ),
            __module__=PlannerOutput.__module__,
        )
        model_.__doc__ = 'AgentOutput model with custom actions'
        return model_


class AsserterOutput(BaseModel):
    reasoning: str
    related_element_description: str
    assertion: bool
    codified: Optional[Dict] = None


class LocatingLLMOutput(BaseModel):
    box_2d: List[int]
    label: Optional[str] = None


class AgentSettings(BaseModel):
    """Options for the agent"""
    log_dir: Optional[Union[str, Path]] = None
    max_failures: int = 2
    max_steps: int = 10
    max_llm_retry: int = 3

    retry_delay: int = 10
    max_input_tokens: int = 128000
    available_file_paths: Optional[List[str]] = None
    override_system_message: Optional[str] = None
    include_attributes: List[str] = [
        'title',
        'type',
        'name',
        'role',
        'tabindex',
        'aria-label',
        'placeholder',
        'value',
        'alt',
        'aria-expanded',
    ]
    max_actions_per_step: int = 10
    wait_between_steps: float = 3.


class CommandState(BaseModel):
    """Holds all state information for a command"""
    model_config = ConfigDict(arbitrary_types_allowed=True)

    task_index: Optional[Union[int, List[int]]] = None
    cmd_index: Optional[Union[int, List[int]]] = None
    command: get_polymorphic_type(BaseCommandConfig) = Field(default_factory=BaseCommandConfig)
    sub_cmd_state: Optional[CommandState] = None

    @property
    def leaf_cmd_state(self):
        cmd_state = self
        while cmd_state.sub_cmd_state:
            cmd_state = cmd_state.sub_cmd_state
        return cmd_state

    @property
    def cmd_type(self) -> str:
        return self.command.type

    @property
    def cmd_argument(self) -> CommandArgType:
        return self.command.argument

    @property
    def cmd_description(self) -> str:
        return self.command.description

    @property
    def cmd_config(self) -> Dict[str, Any]:
        return self.command.config

    def register_deeper_cmd_state(self):
        _leaf_cmd_state = self.leaf_cmd_state

        if isinstance(_leaf_cmd_state.cmd_index, int):
            sub_cmd_index = [_leaf_cmd_state.cmd_index, -1]
        elif isinstance(_leaf_cmd_state.cmd_index, List):
            sub_cmd_index = _leaf_cmd_state.cmd_index + [-1]
        else:
            raise ValueError(
                f"cmd_index must be int or List when registering deeper cmd state, "
                f"got {type(_leaf_cmd_state.cmd_index)}"
            )

        _leaf_cmd_state.sub_cmd_state = CommandState(
            task_index=_leaf_cmd_state.task_index,
            cmd_index=sub_cmd_index,
        )

    def update_leaf_cmd_state(
            self,
            task_index: Optional[int],
            cmd_index: int,
            command: BaseCommandConfig,
    ):
        _leaf_cmd_state = self.leaf_cmd_state

        if task_index is not None:
            _leaf_cmd_state.task_index = task_index
        if isinstance(_leaf_cmd_state.cmd_index, int) or _leaf_cmd_state.cmd_index is None:
            _leaf_cmd_state.cmd_index = cmd_index
        elif isinstance(_leaf_cmd_state.cmd_index, List):
            _leaf_cmd_state.cmd_index[-1] = cmd_index
        else:
            raise ValueError(f"cmd_index must be int or List or None, got {type(_leaf_cmd_state.cmd_index)}")

        _leaf_cmd_state.command = command

    def delete_leaf_cmd_state(self):
        cmd_state = self
        if cmd_state.sub_cmd_state is None:
            raise ValueError("No sub command state to delete")

        while cmd_state.sub_cmd_state.sub_cmd_state is not None:
            cmd_state = cmd_state.sub_cmd_state
        cmd_state.sub_cmd_state = None


AgentMessageType: TypeAlias = Union[str, BaseMessage, BaseModel]
AgentInputType: TypeAlias = Union[str, List[AgentMessageType]]
AgentOutputType: TypeAlias = Union[str, BaseMessage, AgentOutput, PlannerOutput, AsserterOutput, LocatingLLMOutput]


class Conversation(BaseModel):
    """Wrap a conversation between the user and the agent"""
    model_config = ConfigDict(arbitrary_types_allowed=True)

    role: str
    input_messages: AgentInputType = Field(default_factory=list)
    output_message: AgentOutputType = Field(default_factory=str)


class AgentState(BaseModel):
    """Holds all state information for an Agent"""
    model_config = ConfigDict(arbitrary_types_allowed=True)

    agent_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    n_steps: int = 0
    consecutive_failures: int = 0

    cmd_state: CommandState = Field(default_factory=CommandState)

    current_cmd_report_paths: List[str] = Field(default_factory=list)
    archived_reports: List[Dict] = Field(default_factory=list)
    conversations: List[Conversation] = Field(default_factory=list)

    planner_outputs: List[PlannerOutput] = Field(default_factory=list)
    actor_outputs: List[AgentOutput] = Field(default_factory=list)
    asserter_outputs: List[AsserterOutput] = Field(default_factory=list)

    screenshots_before_actions: List[Image.Image] = Field(default_factory=list)
    current_action_space: List[RegisteredAction] = Field(default_factory=list)
    executed_actions: List[List[ActionModel]] = Field(default_factory=list)
    results: List[List[ActionResult]] = Field(default_factory=list)

    # 运行时变量：aiQuery 等带 name 的步骤写入，供后续步骤 ${name} 引用
    named_results: Dict[str, Any] = Field(default_factory=dict)

    history: AgentHistoryList = Field(default_factory=lambda: AgentHistoryList(history=[]))

    @property
    def current_cmd_state(self):
        return self.cmd_state.leaf_cmd_state

    @property
    def current_command(self) -> BaseCommandConfig:
        return self.current_cmd_state.command

    @property
    def current_cmd_type(self) -> str:
        return self.current_cmd_state.cmd_type

    @property
    def current_cmd_argument(self) -> CommandArgType:
        return self.current_cmd_state.cmd_argument

    @property
    def current_cmd_description(self) -> str:
        return self.current_cmd_state.cmd_description

    @property
    def resolved_cmd_description(self) -> str:
        """经 named_results 变量替换后的任务描述，供 LLM 使用。"""
        return substitute_variables(self.current_cmd_description, self.named_results)

    @property
    def current_cmd_config(self) -> Dict[str, Any]:
        return self.current_cmd_state.cmd_config

    def register_deeper_cmd_state(self):
        self.cmd_state.register_deeper_cmd_state()

    def update_current_cmd_state(
            self,
            task_index: Optional[int],
            cmd_index: int,
            command: BaseCommandConfig,
    ):
        self.cmd_state.update_leaf_cmd_state(
            task_index=task_index,
            cmd_index=cmd_index,
            command=command,
        )

    def delete_current_cmd_state(self):
        self.cmd_state.delete_leaf_cmd_state()

    @property
    def last_result(self):
        if self.results:
            return self.results[-1]
        else:
            return None

    @property
    def last_screenshot_before_actions(self) -> Optional[Image.Image]:
        """Get the last screenshot before actions"""
        if self.screenshots_before_actions:
            return self.screenshots_before_actions[-1]
        else:
            return None

    def format_last_actor_loop_results_for_planner(self) -> str:
        last_actor_output = self.last_actor_output
        if last_actor_output is None:
            return ""
        message = f"Reasons for last actions:\n{last_actor_output.current_state.reasoning}\n"
        message += f"Expected outcome of last actions:\n{last_actor_output.current_state.expected_outcome}\n"
        message += f"Last executed actions:\n{self.last_executed_actions_description}\n"
        return message

    @property
    def last_executed_actions(self) -> List[ActionModel]:
        if self.executed_actions:
            return self.executed_actions[-1]
        else:
            return []

    @property
    def last_executed_actions_description(self):
        description = ""
        for i, action in enumerate(self.last_executed_actions):
            if not action.model_dump(exclude_unset=True):
                continue
            action_name, params = list(action.model_dump(exclude_unset=True).items())[0]
            description += f"[{i + 1}]. {action_name}({', '.join([f'{k}={v}' for k, v in params.items()])}) \n"
        return description

    def detect_repeated_actions(self, window: int = 3) -> Optional[str]:
        """检测最近 window 步是否执行了相同的操作，返回重复操作描述或 None"""
        if len(self.executed_actions) < window:
            return None

        recent = self.executed_actions[-window:]
        serialized = []
        for actions in recent:
            step_sig = []
            for action in actions:
                dumped = action.model_dump(exclude_unset=True)
                if dumped:
                    action_name = list(dumped.keys())[0]
                    step_sig.append(action_name)
            serialized.append(tuple(step_sig))

        if len(set(serialized)) == 1 and serialized[0]:
            action_desc = ', '.join(serialized[0])
            return (
                f"WARNING: The same action [{action_desc}] has been repeated "
                f"{window} times in a row with no progress."
            )
        return None

    @property
    def last_planner_output(self) -> Optional[PlannerOutput]:
        """Get the last planner output"""
        if self.planner_outputs:
            return self.planner_outputs[-1]
        else:
            return None

    @property
    def last_actor_output(self) -> Optional[AgentOutput]:
        """Get the last actor output"""
        if self.actor_outputs:
            return self.actor_outputs[-1]
        else:
            return None

    @property
    def last_asserter_output(self) -> Optional[AsserterOutput]:
        """Get the last asserter output"""
        if self.asserter_outputs:
            return self.asserter_outputs[-1]
        else:
            return None

    def pop_conversations(self) -> List[Conversation]:
        conversations = self.conversations
        self.conversations = []
        return conversations

    def end_cmd_episode(self):
        self.planner_outputs = []
        self.actor_outputs = []
        self.screenshots_before_actions = []
        self.conversations = []

    def register_planner_io(self, planner_input: AgentInputType, planner_output: Union[PlannerOutput, str]):
        self.planner_outputs.append(planner_output)
        self.conversations.append(
            Conversation(
                role='planner',
                input_messages=planner_input,
                output_message=planner_output,
            )
        )

    def register_actor_io(self, actor_input: AgentInputType, actor_output: Union[AgentOutput, str]):
        self.actor_outputs.append(actor_output)
        self.conversations.append(
            Conversation(
                role='actor',
                input_messages=actor_input,
                output_message=actor_output,
            )
        )

    def register_asserter_io(self, asserter_input: AgentInputType, asserter_output: Union[AsserterOutput, str]):
        self.asserter_outputs.append(asserter_output)
        self.conversations.append(
            Conversation(
                role='asserter',
                input_messages=asserter_input,
                output_message=asserter_output,
            )
        )

    def register_screenshot_before_actions(self, screenshot: Image.Image):
        self.screenshots_before_actions.append(screenshot)

    def register_executed_actions(self, executed_actions: List[ActionModel]):
        self.executed_actions.append(executed_actions)

    def register_result(self, result: List[ActionResult]):
        self.results.append(result)

    def register_history(self, history: AgentHistory):
        self.history.history.append(history)

    def register_report_path(self, report_path: Union[str, Path]):
        self.current_cmd_report_paths.append(str(report_path))

    def update_action_space(self, action_space: List[RegisteredAction]):
        self.current_action_space = action_space


class ActionResult(BaseModel):
    """Result of executing an action"""

    is_done: Optional[bool] = False
    success: Optional[bool] = None
    extracted_content: Optional[str] = None
    error: Optional[str] = None
    updated_params: Optional[Dict] = None
    codified: Optional[Dict[str, Any]] = None


class StepMetadata(BaseModel):
    """Metadata for a single step including timing and token information"""

    step_start_time: datetime
    step_end_time: datetime = Field(default_factory=datetime.now)
    step_number: int = 0
    cmd_state: CommandState = Field(default_factory=CommandState)

    @property
    def duration_seconds(self) -> float:
        """Calculate step duration in seconds"""
        return (self.step_end_time - self.step_start_time).total_seconds()

    def model_dump(self, **kwargs) -> dict[str, Any]:
        return {
            "step_start_time": self.step_start_time.isoformat(),
            "step_end_time": self.step_end_time.isoformat(),
            "step_number": self.step_number,
            "cmd_state": self.cmd_state.model_dump(**kwargs),
            "duration_seconds": self.duration_seconds,
        }


class AgentHistory(BaseModel):
    """History item for agent actions"""

    conversations: List[Conversation] = Field(default_factory=list)
    result: List[ActionResult]
    state: BrowserStateHistory
    executed_actions: Optional[List[ActionModel]] = None
    metadata: Optional[StepMetadata] = None
    screenshot_before_actions: Optional[str] = None  # base64, 操作前截图

    model_config = ConfigDict(arbitrary_types_allowed=True, protected_namespaces=())

    def model_dump(self, **kwargs) -> Dict[str, Any]:
        """Custom serialization handling circular references"""

        # Handle action serialization
        conversations_dump = []
        if self.conversations:
            for conversation in self.conversations:
                conversation_dump = conversation.model_dump()
                if hasattr(conversation.output_message, "action"):
                    action_dump = []
                    for action in conversation.output_message.action:
                        if not action.model_dump(exclude_unset=True):
                            continue
                        action_name, params = list(action.model_dump(exclude_unset=True).items())[0]
                        action_dump.append(
                            {
                                action_name: params,
                            }
                        )
                    conversation_dump['output_message']['action'] = action_dump
                conversations_dump.append(conversation_dump)

        executed_actions_dump = []
        if self.executed_actions:
            for action in self.executed_actions:
                if not action.model_dump(exclude_unset=True):
                    continue
                action_name, params = list(action.model_dump(exclude_unset=True).items())[0]
                executed_actions_dump.append(
                    {
                        action_name: params,
                    }
                )

        metadata_dump = self.metadata.model_dump(by_alias=True, exclude_none=True) if self.metadata else None
        if self.metadata and hasattr(self.metadata, "cmd_state") and hasattr(self.metadata.cmd_state, "command"):
            metadata_dump["cmd_state"]["command"] = self.metadata.cmd_state.command.model_dump(
                by_alias=True,
                exclude_none=True,
            )

        return {
            'conversations': conversations_dump,
            'result': [r.model_dump(**kwargs) for r in self.result],
            'state': self.state.to_dict(),
            'executed_actions': executed_actions_dump,
            'metadata': metadata_dump,
            'screenshot_before_actions': self.screenshot_before_actions,
        }


class AgentHistoryList(BaseModel):
    """List of agent history items"""

    history: List[AgentHistory]

    def total_duration_seconds(self) -> float:
        """Get total duration of all steps in seconds"""
        total = 0.0
        for h in self.history:
            if h.metadata:
                total += h.metadata.duration_seconds
        return total

    def __repr__(self) -> str:
        """Representation of the AgentHistoryList object"""
        return self.__str__()

    def save_to_file(self, filepath: Union[Path, str]) -> None:
        """Save history to JSON file with proper serialization"""
        try:
            Path(filepath).parent.mkdir(parents=True, exist_ok=True)
            data = self.model_dump()
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=4)
        except Exception as e:
            raise e

    def model_dump(self, **kwargs) -> Dict[str, Any]:
        """Custom serialization that properly uses AgentHistory's model_dump"""
        return {
            'history': [h.model_dump(**kwargs) for h in self.history],
        }

    @classmethod
    def load_from_file(cls, filepath: Union[Path, str], output_model: Type[AgentOutput]) -> 'AgentHistoryList':
        """Load history from JSON file"""
        with open(filepath, 'r', encoding='utf-8') as f:
            data = json.load(f)
        # loop through history and validate output_model actions to enrich with custom actions
        for h in data['history']:
            if h['model_output']:
                if isinstance(h['model_output'], Dict):
                    h['model_output'] = output_model.model_validate(h['model_output'])
                else:
                    h['model_output'] = None
            if 'interacted_element' not in h['state']:
                h['state']['interacted_element'] = None
        history = cls.model_validate(data)
        return history

    def errors(self) -> List[Union[str, None]]:
        """Get all errors from history, with None for steps without errors"""
        errors = []
        for h in self.history:
            step_errors = [r.error for r in h.result if r.error]

            # each step can have only one error
            errors.append(step_errors[0] if step_errors else None)
        return errors

    def is_done(self) -> bool:
        """Check if the agent is done"""
        if self.history and len(self.history[-1].result) > 0:
            last_result = self.history[-1].result[-1]
            return last_result.is_done is True
        return False

    def is_successful(self) -> Optional[bool]:
        """
        Check if the agent completed successfully - the agent decides in the last step if it was successful or not.
        None if not done yet.
        """
        if self.history and len(self.history[-1].result) > 0:
            last_result = self.history[-1].result[-1]
            if last_result.is_done is True:
                return last_result.success
        return None

    def done_text(self) -> Optional[str]:
        """Get the extracted content from the final done action, if present."""
        if self.history and len(self.history[-1].result) > 0:
            last_result = self.history[-1].result[-1]
            if last_result.is_done is True:
                return last_result.extracted_content
        return None

    def has_errors(self) -> bool:
        """Check if the agent has any non-None errors"""
        return any(error is not None for error in self.errors())

    def urls(self) -> List[Union[str, None]]:
        """Get all unique URLs from history"""
        return [h.state.url if h.state.url is not None else None for h in self.history]

    def screenshots(self) -> List[Union[str, None]]:
        """Get all screenshots from history"""
        return [h.state.screenshot if h.state.screenshot is not None else None for h in self.history]

    def action_names(self) -> List[str]:
        """Get all action names from history"""
        action_names = []
        for action in self.model_actions():
            actions = list(action.keys())
            if actions:
                action_names.append(actions[0])
        return action_names

    def action_results(self) -> List[ActionResult]:
        """Get all results from history"""
        results = []
        for h in self.history:
            results.extend([r for r in h.result if r])
        return results

    def extracted_content(self) -> List[str]:
        """Get all extracted content from history"""
        content = []
        for h in self.history:
            content.extend([r.extracted_content for r in h.result if r.extracted_content])
        return content

    def number_of_steps(self) -> int:
        """Get the number of steps in the history"""
        return len(self.history)


class AgentError:
    """Container for agent error handling"""

    VALIDATION_ERROR = 'Invalid model output format. Please follow the correct schema.'
    RATE_LIMIT_ERROR = 'Rate limit reached. Waiting before retry.'
    NO_VALID_ACTION = 'No valid action found'

    @staticmethod
    def format_error(error: Exception, include_trace: bool = False) -> str:
        """Format error message based on error type and optionally include trace"""
        if isinstance(error, ValidationError):
            return f'{AgentError.VALIDATION_ERROR}\nDetails: {str(error)}'
        if isinstance(error, RateLimitError):
            return AgentError.RATE_LIMIT_ERROR
        if include_trace:
            return f'{str(error)}\nStacktrace:\n{traceback.format_exc()}'
        return f'{str(error)}'
