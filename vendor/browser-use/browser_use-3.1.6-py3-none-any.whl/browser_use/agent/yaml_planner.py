# -*- coding: utf-8 -*-
# Author: Yichen Lu
# Time: 2025/6/20

import json
from easydict import EasyDict

from browser_use.agent.tasks import BaseCommandConfig


class YamlPlanner(object):
    model_name = "yaml_planner"

    def __init__(self, command: BaseCommandConfig):
        self.command = command

    def invoke(self, *args, **kwargs):
        output = {
            "state_analysis": "None",
            "progress_evaluation": "0%",
            "next_step_suggestion": f"Complete task: {self.command.description}",
            "reasoning": "None",
            "is_ultimate_task_done": False,
            "plan": f"- {self.command.description}"
        }

        return EasyDict(
            content=json.dumps(output, ensure_ascii=False, indent=4)
        )
