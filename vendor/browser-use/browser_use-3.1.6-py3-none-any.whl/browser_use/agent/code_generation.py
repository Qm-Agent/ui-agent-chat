# -*- coding: utf-8 -*-
# Author: Yichen Lu
# Time: 2025/9/16

import json
import logging
from typing import Dict, Any, Optional
from langchain_core.language_models import BaseChatModel

from browser_use.agent.message_manager.utils import parse_response
from browser_use.utils import log_llm_call_stats
from browser_use.agent.prompts import LocatingLLMPrompt, AssertionCodeGenerationPrompt
from browser_use.browser.context import BrowserContext
from browser_use.controller.utils import (
    locate_element_in_dom_tree_with_box_2d,
    locate_element_with_center_point,
    match_element_with_center_point_and_xpath,
    match_element_with_iou_and_xpath,
    convert_to_locatable_xpath,
)
from browser_use.controller.views import (
    ClickElementAction,
    InputTextAction,
    ClearInputTextAction,
    ScrollAction,
    SwitchTabAction,
    OpenTabAction,
    GoToUrlAction,
    DoneAction,
    SearchGoogleAction,
    NoParamsAction,
    WaitAction,
    SendKeysAction,
    HoverAction,
    ScrollToTextAction,
)
from browser_use.utils import unnormalize_box_2d

logger = logging.getLogger(__name__)


async def _get_locator_string(element_handle, xpath: str) -> str:
    """获取用于 page.locator 的代码片段。若当前 Playwright 的 ElementHandle 无 generate_locator_string 则用 xpath 回退。"""
    try:
        return await element_handle.generate_locator_string()
    except AttributeError:
        # 当前环境使用的是 pip 安装的 Playwright，ElementHandle 无 generate_locator_string（仅 browser_use 内置 playwright 有）
        escaped = xpath.replace("\\", "\\\\").replace('"', '\\"')
        return f'locator("xpath={escaped}")'


async def convert_click_action(params: ClickElementAction, browser_context: BrowserContext) -> Dict[str, Any]:
    page = await browser_context.get_current_page()
    box_2d = params.box_2d
    element_info = await locate_element_with_center_point(box_2d, browser_context)
    page_width, page_height = await browser_context.get_page_size()
    unnormalized_box_2d = unnormalize_box_2d(box_2d, page_height, page_width)
    xpath = element_info["xpath"]
    xpath = convert_to_locatable_xpath(xpath)
    locator = page.locator(f"xpath={xpath}")
    element = await match_element_with_center_point_and_xpath(locator, unnormalized_box_2d)
    if element is None:
        raise ValueError(f"Locator not found for xpath {xpath}")

    element_handle = await element.element_handle()
    generated_locator = await _get_locator_string(element_handle, xpath)
    return {
        "playwright_functions": ["click"],
        "html": element_info["html"],
        "xpath": xpath,
        "executable_code_with_xpath": f"""
# Click: {params.model_dump()}
await page.locator(f"xpath={xpath}").first.click(timeout=5000)
""",
        "locator": generated_locator,
        "executable_code_with_locator": f"""
# Click: {params.model_dump()}
await page.{generated_locator}.first.click(timeout=5000)
""",
    }


async def convert_go_to_url_action(params: GoToUrlAction, *args, **kwargs) -> Dict[str, Any]:
    return {
        "playwright_functions": ["goto"],
        "code": f"""
# GoToURL: {params.model_dump()}
await page.goto("{params.url}")
""",
    }


async def convert_done_action(params: DoneAction, *args, **kwargs) -> Dict[str, Any]:
    return {
        "playwright_functions": [],
        "code": f"""
# Done: {params.model_dump()}
""",
    }


async def convert_search_google_action(params: SearchGoogleAction, *args, **kwargs) -> Dict[str, Any]:
    return {
        "playwright_functions": ["goto"],
        "code": f"""
# SearchGoogle: {params.model_dump()}
await page.goto("{params.query}")
""",
    }


async def convert_go_back_action(params: NoParamsAction, *args, **kwargs) -> Dict[str, Any]:
    return {
        "playwright_functions": ["go_back"],
        "code": f"""
# GoBack: {params.model_dump()}
await page.go_back()
""",
    }


async def convert_wait_action(params: WaitAction, *args, **kwargs) -> Dict[str, Any]:
    return {
        "playwright_functions": ["wait_for_timeout"],
        "code": f"""
# Wait: {params.model_dump()}
await page.wait_for_timeout({params.seconds * 1000})
""",
    }


async def convert_input_text_action(params: InputTextAction, browser_context: BrowserContext) -> Dict[str, Any]:
    page = await browser_context.get_current_page()
    box_2d = params.box_2d

    element_info = await locate_element_with_center_point(box_2d, browser_context)
    page_width, page_height = await browser_context.get_page_size()
    unnormalized_box_2d = unnormalize_box_2d(box_2d, page_height, page_width)
    xpath = element_info["xpath"]
    xpath = convert_to_locatable_xpath(xpath)
    locator = page.locator(f"xpath={xpath}")
    element = await match_element_with_center_point_and_xpath(locator, unnormalized_box_2d)
    if element is None:
        raise ValueError(f"Locator not found for xpath {xpath}")

    element_handle = await element.element_handle()
    generated_locator = await _get_locator_string(element_handle, xpath)
    return {
        "playwright_functions": ["fill"],
        "html": element_info["html"],
        "xpath": xpath,
        "executable_code_with_xpath": f"""
# InputText: {params.model_dump()}
await page.locator(f"xpath={xpath}").first.click(timeout=5000)
await page.keyboard.press('ControlOrMeta+A')
await page.keyboard.type("{params.text}", delay=20)
""",
        "locator": generated_locator,
        "executable_code_with_locator": f"""
# InputText: {params.model_dump()}
await page.{generated_locator}.first.click(timeout=5000)
await page.keyboard.press('ControlOrMeta+A')
await page.keyboard.type("{params.text}", delay=20)
""",
    }


async def convert_switch_tab_action(params: SwitchTabAction, *args, **kwargs) -> Dict[str, Any]:
    return {
        "playwright_functions": ["bring_to_front", "wait_for_load_state"],
        "code": f"""
# SwitchToTab: {params.model_dump()}
await page.evaluate("1")
pages = context.pages
page = pages[{params.page_id}]
await page.bring_to_front()
await page.wait_for_load_state()
""",
    }


async def convert_open_tab_action(params: OpenTabAction, *args, **kwargs) -> Dict[str, Any]:
    return {
        "playwright_functions": ["goto"],
        "code": f"""
# OpenTab: {params.model_dump()}
page = await context.new_page()
await page.goto("{params.url}")
""",
    }


async def convert_clear_input_text_action(params: ClearInputTextAction, browser_context: BrowserContext) -> Dict[str, Any]:
    page = await browser_context.get_current_page()
    box_2d = params.box_2d

    element_info = await locate_element_with_center_point(box_2d, browser_context)
    page_width, page_height = await browser_context.get_page_size()
    unnormalized_box_2d = unnormalize_box_2d(box_2d, page_height, page_width)
    xpath = element_info["xpath"]
    xpath = convert_to_locatable_xpath(xpath)
    locator = page.locator(f"xpath={xpath}")
    element = await match_element_with_center_point_and_xpath(locator, unnormalized_box_2d)
    if element is None:
        raise ValueError(f"Locator not found for xpath {xpath}")

    element_handle = await element.element_handle()
    generated_locator = await _get_locator_string(element_handle, xpath)
    return {
        "playwright_functions": ["fill"],
        "html": element_info["html"],
        "xpath": xpath,
        "executable_code_with_xpath": f"""
# ClearInputText: {params.model_dump()}
await page.locator(f"xpath={xpath}").first.click(timeout=5000)
await page.keyboard.press('ControlOrMeta+A')
await page.keyboard.press('Backspace')
""",
        "locator": generated_locator,
        "executable_code_with_locator": f"""
# ClearInputText: {params.model_dump()}
await page.{generated_locator}.first.click(timeout=5000)
await page.keyboard.press('ControlOrMeta+A')
await page.keyboard.press('Backspace')
""",
    }


async def convert_scroll_down_action(params: ScrollAction, browser_context: BrowserContext) -> Dict[str, Any]:
    page = await browser_context.get_current_page()
    scrollable_elements = await browser_context.get_scrollable_elements()
    if params.index not in scrollable_elements:
        raise ValueError(
            f'Scrollable element index {params.index} does not exist - '
            f'double check or use alternative actions'
        )
    element = scrollable_elements[params.index]

    amount = params.amount if params.amount is not None else element.client_height
    xpath = element.generate_xpath(contain_class=True)
    xpath = convert_to_locatable_xpath(xpath)
    elements = page.locator(f'xpath={xpath}')
    if await elements.count() != 1:
        logger.warning(
            "Multiple or no scrollable elements found with the given xpath, most often something changed."
            "We will use the first element to scroll down."
        )

    element_handle = await elements.element_handle()
    generated_locator = await _get_locator_string(element_handle, xpath)

    return {
        "playwright_functions": ["evaluate"],
        "xpath": xpath,
        "executable_code_with_xpath": f"""
# ScrollDown: {params.model_dump()}
await page.locator(f'xpath={xpath}').first.evaluate(f"ele => ele.scrollTop += {amount}")
""",
        "locator": generated_locator,
        "executable_code_with_locator": f"""
# ScrollDown: {params.model_dump()}
await page.{generated_locator}.first.evaluate(f"ele => ele.scrollTop += {amount}")
""",
    }


async def convert_scroll_up_action(params: ScrollAction, browser_context: BrowserContext) -> Dict[str, Any]:
    page = await browser_context.get_current_page()
    scrollable_elements = await browser_context.get_scrollable_elements()
    if params.index not in scrollable_elements:
        raise ValueError(
            f'Scrollable element index {params.index} does not exist - '
            f'double check or use alternative actions'
        )
    element = scrollable_elements[params.index]

    amount = params.amount if params.amount is not None else element.client_height
    xpath = element.generate_xpath(contain_class=True)
    xpath = convert_to_locatable_xpath(xpath)
    elements = page.locator(f'xpath={xpath}')
    if await elements.count() != 1:
        logger.warning(
            "Multiple or no scrollable elements found with the given xpath, most often something changed."
            "We will use the first element to scroll up."
        )

    element_handle = await elements.element_handle()
    generated_locator = await _get_locator_string(element_handle, xpath)

    return {
        "playwright_functions": ["evaluate"],
        "xpath": xpath,
        "executable_code_with_xpath": f"""
# ScrollUp: {params.model_dump()}
await page.page.locator(f'xpath={xpath}').first.evaluate(f"ele => ele.scrollTop -= {amount}")
""",
        "locator": generated_locator,
        "executable_code_with_locator": f"""
# ScrollUp: {params.model_dump()}
await page.{generated_locator}.first.evaluate(f"ele => ele.scrollTop -= {amount}")
""",
    }


async def convert_scroll_right_action(params: ScrollAction, browser_context: BrowserContext) -> Dict[str, Any]:
    page = await browser_context.get_current_page()
    scrollable_elements = await browser_context.get_scrollable_elements()
    if params.index not in scrollable_elements:
        raise ValueError(
            f'Scrollable element index {params.index} does not exist - '
            f'double check or use alternative actions'
        )
    element = scrollable_elements[params.index]

    amount = params.amount if params.amount is not None else element.client_height
    xpath = element.generate_xpath(contain_class=True)
    xpath = convert_to_locatable_xpath(xpath)
    elements = page.locator(f'xpath={xpath}')
    if await elements.count() != 1:
        logger.warning(
            "Multiple or no scrollable elements found with the given xpath, most often something changed."
            "We will use the first element to scroll right."
        )

    element_handle = await elements.element_handle()
    generated_locator = await _get_locator_string(element_handle, xpath)

    return {
        "playwright_functions": ["evaluate"],
        "xpath": xpath,
        "executable_code_with_xpath": f"""
# ScrollUp: {params.model_dump()}
await page.locator(f'xpath={xpath}').first.evaluate(f"ele => ele.scrollLeft += {amount}")
""",
        "locator": generated_locator,
        "executable_code_with_locator": f"""
# ScrollUp: {params.model_dump()}
await page.{generated_locator}.first.evaluate(f"ele => ele.scrollLeft += {amount}")
""",
    }


async def convert_scroll_left_action(params: ScrollAction, browser_context: BrowserContext) -> Dict[str, Any]:
    page = await browser_context.get_current_page()
    scrollable_elements = await browser_context.get_scrollable_elements()
    if params.index not in scrollable_elements:
        raise ValueError(
            f'Scrollable element index {params.index} does not exist - '
            f'double check or use alternative actions'
        )
    element = scrollable_elements[params.index]

    amount = params.amount if params.amount is not None else element.client_height
    xpath = element.generate_xpath(contain_class=True)
    xpath = convert_to_locatable_xpath(xpath)
    elements = page.locator(f'xpath={xpath}')
    if await elements.count() != 1:
        logger.warning(
            "Multiple or no scrollable elements found with the given xpath, most often something changed."
            "We will use the first element to scroll left."
        )

    element_handle = await elements.element_handle()
    generated_locator = await _get_locator_string(element_handle, xpath)

    return {
        "playwright_functions": ["evaluate"],
        "xpath": xpath,
        "executable_code_with_xpath": f"""
# ScrollUp: {params.model_dump()}
await page.locator(f'xpath={xpath}').first.evaluate(f"ele => ele.scrollLeft -= {amount}")
""",
        "locator": generated_locator,
        "executable_code_with_locator": f"""
# ScrollUp: {params.model_dump()}
await page.{generated_locator}.first.evaluate(f"ele => ele.scrollLeft -= {amount}")
""",
    }


async def convert_send_keys_action(params: SendKeysAction, *args, **kwargs) -> Dict[str, Any]:
    return {
        "playwright_functions": ["press"],
        "code": f"""
# SendKeys: {params.model_dump()}
await page.keyboard.press("{params.keys}")
""",
    }


async def convert_hover_action(params: HoverAction, browser_context: BrowserContext) -> Dict[str, Any]:
    page = await browser_context.get_current_page()
    box_2d = params.box_2d

    element_info = await locate_element_with_center_point(box_2d, browser_context)
    page_width, page_height = await browser_context.get_page_size()
    unnormalized_box_2d = unnormalize_box_2d(box_2d, page_height, page_width)
    xpath = element_info["xpath"]
    xpath = convert_to_locatable_xpath(xpath)
    locator = page.locator(f"xpath={xpath}")
    element = await match_element_with_center_point_and_xpath(locator, unnormalized_box_2d)
    if element is None:
        raise ValueError(f"Locator not found for xpath {xpath}")

    element_handle = await element.element_handle()
    generated_locator = await _get_locator_string(element_handle, xpath)
    return {
        "playwright_functions": ["hover"],
        "html": element_info["html"],
        "xpath": xpath,
        "executable_code_with_xpath": f"""
# Hover: {params.model_dump()}
await page.locator(f"xpath={xpath}").first.hover(timeout=5000)
""",
        "locator": generated_locator,
        "executable_code_with_locator": f"""
# Hover: {params.model_dump()}
await page.{generated_locator}.first.hover(timeout=5000)
""",
    }


async def convert_scroll_to_text_action(params: ScrollToTextAction, *args, **kwargs) -> Dict[str, Any]:
    text_repr = repr(params.text)
    return {
        "playwright_functions": ["scroll_into_view_if_needed", "wait_for_timeout"],
        "code": f"""
# ScrollToText: {params.model_dump()}
locators = [
    page.get_by_text({text_repr}, exact=False),
    page.locator(f'text={params.text}'),
    page.locator(f"//*[contains(text(), '{params.text}')]"),
]
for locator in locators:
    if await locator.count() > 0 and await locator.first.is_visible():
        await locator.first.scroll_into_view_if_needed()
        await page.wait_for_timeout(500)
        break
""",
    }


async def convert_ai_assert(
        params: Dict[str, Any],
        browser_context: BrowserContext,
        aux_llms: Dict[str, BaseChatModel],
) -> Optional[Dict[str, Any]]:
    # Step 1: Detection bbox of the most assert related element
    # Step 2: Locate the element with iou and get the xpath and html
    # Step 3: Generate the locator string for the element
    # Step 4: Generate the assertion code with coding_llm

    # Step 1: Detection bbox of the most assert related element
    page = await browser_context.get_current_page()
    if not params["assertion"]:
        return None

    description = params["related_element_description"]

    screenshot_b64 = await browser_context.take_screenshot(b64=True)
    messages = [
        LocatingLLMPrompt.get_system_message(),
        LocatingLLMPrompt.get_user_message(description, screenshot_b64),
    ]
    locating_llm = aux_llms["locating_llm"]
    log_llm_call_stats(locating_llm, messages)
    locating_llm_output = locating_llm.invoke(messages)
    locating_llm_output = parse_response(locating_llm_output, syntax="json")
    locating_llm_output = json.loads(locating_llm_output)

    if isinstance(locating_llm_output, list):
        locating_llm_output = locating_llm_output[0]

    # Step 2: Locate the element with iou and get the xpath and html
    left, top, right, bottom = locating_llm_output["box_2d"]
    matched_element, max_iou = await locate_element_in_dom_tree_with_box_2d([top, left, bottom, right], browser_context)
    xpath, html = matched_element.xpath, matched_element.full_html

    # Step 3: Generate the locator string for the element
    xpath = convert_to_locatable_xpath(xpath)
    elements = page.locator(f"xpath={xpath}")
    element, max_iou = await match_element_with_iou_and_xpath(elements, [top, left, bottom, right])
    element_handle = await element.element_handle()
    generated_locator = await _get_locator_string(element_handle, xpath)
    logger.info(f"Generate locator string: {generated_locator} for xpath: {xpath}")
    logger.info(f"Inner HTML of the element: {await element.inner_html()}")

    # Step 4: Generate the assertion code with coding_llm
    assertion = params["aiAssert"]
    messages = [
        AssertionCodeGenerationPrompt.get_system_message(),
        AssertionCodeGenerationPrompt.get_user_message(html, generated_locator, assertion)
    ]
    coding_llm = aux_llms["coding_llm"]
    log_llm_call_stats(coding_llm, messages)
    coding_llm_output = coding_llm.invoke(messages)
    coding_llm_output = parse_response(coding_llm_output, syntax="python")

    return {
        "code": f"""
# aiAssert: {assertion}
{coding_llm_output}
""",
    }


async def convert_assert_text(
        params: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    if not params["assertion"]:
        return None

    locator_to_attrs = dict(params["locator_to_attrs"])
    assert_text = params["assertText"]

    code = f"""
# assertText: {assert_text}
locator_to_attrs = {locator_to_attrs}
assertion_flag = False
"""

    for locator, attrs in locator_to_attrs.items():
        code_seg = f"""
try:
    await page.{locator}.first.wait_for(state="attached", timeout=5000)
    element = page.{locator}.first
    for attr in {attrs}:
        if attr == "innerText":
            attribute_value = await element.inner_text()
        else:
            attribute_value = await element.get_attribute(attr)
    
        if isinstance(attribute_value, str) and "{assert_text}" in attribute_value:
            assertion_flag = True
except Exception as e:
    pass
"""
        code += code_seg

    code += f"""
if not assertion_flag:
    raise RuntimeError('Cannot find text: "{assert_text}" in the element')
"""

    return {
        "code": code,
    }


async def convert_wait_for_text(
        params: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    locator_to_attrs = dict(params["locator_to_attrs"])
    waiting_text = params["waitForText"]
    timeout = params["timeout"]

    code = f"""
# waitForText: {waiting_text}
from datetime import datetime 
locator_to_attrs = {locator_to_attrs}
existence_flag = False
start_time = datetime.now()
while (datetime.now() - start_time).total_seconds() < {timeout}:
"""

    for locator, attrs in locator_to_attrs.items():
        code_seg = f"""
    try:
        await page.{locator}.first.wait_for(state="attached", timeout=100)
        element = page.{locator}.first
        for attr in {attrs}:
            if attr == "innerText":
                attribute_value = await element.inner_text()
            else:
                attribute_value = await element.get_attribute(attr)
    
            if isinstance(attribute_value, str) and "{waiting_text}" in attribute_value:
                existence_flag = True
        if existence_flag:
            break

    except Exception as e:
        pass
"""
        code += code_seg

    code += f"""
if not existence_flag:
    raise RuntimeError('Cannot find text: "{waiting_text}" in the element')
"""

    return {
        "code": code,
    }
