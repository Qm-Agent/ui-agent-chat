from __future__ import annotations

import asyncio
import functools
import json
import logging
import os
import re
import time
from asyncio import iscoroutinefunction
from collections import defaultdict
from copy import deepcopy
from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import (
    Any,
    Awaitable,
    Callable,
    Dict,
    Generic,
    List,
    Optional,
    Tuple,
    TypeVar,
    Union,
)

from dotenv import load_dotenv
from google.api_core.exceptions import ResourceExhausted
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import BaseMessage
from omegaconf import DictConfig, ListConfig
from openai import RateLimitError
from PIL import Image
from playwright.async_api import Locator, Page

from browser_use.agent import tasks as agent_tasks
from browser_use.agent.code_generation import (
    convert_assert_text,
    convert_done_action,
    convert_wait_for_text,
)
from browser_use.agent.message_manager.service import MessageManager
from browser_use.agent.message_manager.utils import (
    extract_json_from_model_output,
    parse_response,
)
from browser_use.agent.prompts import SystemPrompt
from browser_use.agent.quick import prepare_quick_task, read_quick_display_query_raw
from browser_use.agent.report import _report_success_from_data, create_standalone_report
from browser_use.agent.report.log_handler import task_log_handler
from browser_use.agent.report.utils import relabel_quick_history_ai_commands
from browser_use.agent.tools import (
    ToolRegistry,
)

# triggers autodiscover_builtin() on first import
from browser_use.agent.views import (
    ActionResult,
    AgentError,
    AgentHistory,
    AgentHistoryList,
    AgentOutput,
    AgentSettings,
    AgentState,
    AsserterOutput,
    CommandState,
    Conversation,
    PlannerOutput,
    StepMetadata,
)
from browser_use.agent.yaml_planner import YamlPlanner
from browser_use.browser.browser import Browser
from browser_use.browser.context import BrowserContext
from browser_use.browser.views import BrowserStateHistory
from browser_use.cache.manager import DEFAULT_CACHE_BLACKLIST, CacheConfig, CacheManager
from browser_use.controller.registry.views import ActionModel, RegisteredAction
from browser_use.controller.service import Controller
from browser_use.controller.views import (
    DoneAction,
    ExtractPageContentAction,
    GoToUrlAction,
    ScrollToTextAction,
    WaitAction,
)
from browser_use.utils import (
    encode_image_base64,
    invoke_llm_with_retry,
    log_response,
    substitute_variables,
    time_execution_async,
    time_execution_sync,
)

load_dotenv()
logger = logging.getLogger(__name__)

Context = TypeVar("Context")


CMD_TO_ACTION_SPACE = dict()
CMDS = dict()


_DONE_SUCCESS_BLOCKER_PATTERNS = (
    "登录失败",
    "账号锁定",
    "账户锁定",
    "密码错误",
    "无权限",
    "没有权限",
    "权限不足",
    "无法访问",
    "无法继续",
    "无法完成",
    "不能继续",
    "任务阻塞",
    "需要人工",
    "人工介入",
    "access denied",
    "permission denied",
    "login failed",
    "unable to continue",
    "cannot continue",
    "blocked",
)

_DONE_SUCCESS_PASS_PATTERNS = (
    "验证通过",
    "断言通过",
    "符合预期",
    "已完成",
    "成功完成",
    "passed",
    "verified",
    "successfully",
)


def _done_success_text_indicates_failure(done_text: Optional[str]) -> bool:
    if not done_text:
        return False

    normalized = done_text.strip().lower()
    if not normalized:
        return False

    if any(pattern in normalized for pattern in _DONE_SUCCESS_PASS_PATTERNS):
        return False
    return any(pattern in normalized for pattern in _DONE_SUCCESS_BLOCKER_PATTERNS)


def _parse_env_bool(env_key: str, current_value: bool) -> bool:
    env_value = os.getenv(env_key)
    if env_value is None:
        return current_value

    normalized = env_value.strip().lower()
    truthy = {"1", "true", "yes", "on"}
    falsy = {"0", "false", "no", "off"}
    if normalized in truthy:
        logger.info(f"[Cache] cache.enabled overridden by {env_key}=true")
        return True
    if normalized in falsy:
        logger.info(f"[Cache] cache.enabled overridden by {env_key}=false")
        return False

    logger.warning(
        f"[Cache] Invalid {env_key} value: {env_value!r}; "
        f"falling back to cache.enabled={current_value!r}"
    )
    return current_value


def _parse_cache_blacklist(cache_cfg: Any | None) -> List[str]:
    configured = (
        list(getattr(cache_cfg, "blacklist", DEFAULT_CACHE_BLACKLIST))
        if cache_cfg is not None
        else list(DEFAULT_CACHE_BLACKLIST)
    )
    env_value = os.getenv("BU_CACHE_BLACKLIST")
    if env_value is None:
        return configured

    blacklist = [item.strip() for item in env_value.split(",") if item.strip()]
    logger.info("[Cache] cache.blacklist overridden by BU_CACHE_BLACKLIST")
    return blacklist


async def _resolve_file_upload_locator(
    page: Page,
    locate: Optional[str],
    upload_index: Optional[int],
) -> tuple[Locator, str]:
    """
    在页面中选定唯一 file 控件供 set_input_files 使用。
    - locate：可选 Playwright 选择器（CSS、xpath=...、text=... 等）；缺省为全部 input[type=file]。
    - upload_index：在匹配集合内强制取第几个（0 起）；不设时在多个匹配下优先可见且布局面积较大的入口。
    """
    raw_locate = (locate or "").strip()
    base = (
        page.locator(raw_locate) if raw_locate else page.locator('input[type="file"]')
    )
    count = await base.count()
    if count == 0:
        hint = raw_locate if raw_locate else 'input[type="file"]'
        raise ValueError(f"No file upload control matched ({hint})")

    if upload_index is not None:
        if upload_index < 0 or upload_index >= count:
            raise IndexError(
                f"upload_index {upload_index} is out of range for {count} matching element(s)"
            )
        picked = base.nth(upload_index)
        desc = (
            f"{raw_locate!r} nth={upload_index}"
            if raw_locate
            else f'input[type="file"] nth={upload_index}'
        )
        return picked, desc

    if count == 1:
        desc = repr(raw_locate) if raw_locate else 'input[type="file"]'
        return base.nth(0), f"{desc} (single match)"

    scored: List[tuple[int, int, float]] = []
    for i in range(count):
        loc = base.nth(i)
        try:
            visible = await loc.is_visible()
        except Exception:
            visible = False
        box = await loc.bounding_box()
        area = float(box["width"] * box["height"]) if box else 0.0
        score = 0
        if visible:
            score += 10
        if area > 4.0:
            score += 5
        elif area > 0.0:
            score += 2
        scored.append((i, score, area))

    scored.sort(key=lambda t: (-t[1], -t[2], t[0]))
    best_i = scored[0][0]
    scope = raw_locate if raw_locate else "input[type=file]"
    logger.info(
        "upload: locator %r matched %s file input(s); picked index %s (prefer visible / non-trivial size)",
        scope,
        count,
        best_i,
    )
    return base.nth(best_i), f"{scope!r} nth={best_i}"


def _normalize_aiquery_result_for_name(content: str) -> str:
    """
    将 aiQuery 提取的原始内容（可能含 ```json ... ```）清洗为适合 ${name} 替换的字符串。
    优先解析 JSON 并取 answer 或单值，否则去掉 markdown 代码块后返回。
    """
    if not content or not content.strip():
        return ""
    s = content.strip()
    # 去掉 markdown 代码块
    if s.startswith("```"):
        lines = s.split("\n")
        if lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        s = "\n".join(lines)
    s = s.strip()
    # 尝试解析 JSON，取 answer、单值或“数量”语义
    try:
        obj = json.loads(s)
        if isinstance(obj, dict) and "answer" in obj:
            return str(obj["answer"]).strip()
        if isinstance(obj, dict) and len(obj) == 1:
            val = next(iter(obj.values()))
            # 如 "有几个子标题" 返回 {"xxx": ["a","b","c","d"]}，则 name 取数量 4 更符合预期
            if isinstance(val, list):
                return str(len(val))
            return str(val).strip()
        if isinstance(obj, (str, int, float, bool)):
            return str(obj)
        if isinstance(obj, list):
            if len(obj) == 1:
                return str(obj[0]).strip()
            return str(len(obj))  # 列表时用长度作为结果
        return json.dumps(obj, ensure_ascii=False)
    except (json.JSONDecodeError, TypeError):
        pass
    return s


class Agent(Generic[Context]):
    @time_execution_sync("--init (agent)")
    def __init__(
        self,
        config: Union[DictConfig, ListConfig],
        tasks: agent_tasks.Tasks,
        llm: BaseChatModel,
        planner: Union[BaseChatModel, YamlPlanner],
        asserter: BaseChatModel,
        aux_llms: Optional[Dict[str, BaseChatModel]] = None,
        # Optional parameters
        browser: Optional[Browser] = None,
        browser_context: Optional[BrowserContext] = None,
        controller: Optional[Controller[Context]] = None,
        sensitive_data: Optional[Dict[str, str]] = None,
        # Initial agent run parameters
        initial_actions: Optional[List[Dict[str, Dict[str, Any]]]] = None,
        # Agent settings
        log_dir: Optional[str] = None,
        override_system_message: Optional[str] = None,
        max_input_tokens: int = 128000,
        available_file_paths: Optional[List[str]] = None,
        include_attributes: Tuple[str] = (
            "title",
            "type",
            "name",
            "role",
            "aria-label",
            "placeholder",
            "value",
            "alt",
            "aria-expanded",
            "data-date-format",
        ),
        context: Context | None = None,
        before_run: Callable[["Agent"], Awaitable[None]] | None = None,
        react_mode: str = "legacy",
    ):
        # Core components
        self.config = config
        self.tasks = tasks
        self.react_mode = react_mode if react_mode in ("legacy", "enhanced") else "legacy"

        self.llm = llm
        self.planner = self.planner_llm = planner
        self.asserter = asserter
        self.aux_llms = aux_llms

        self.actor_box_format = self.model_name_to_box_format(self.config.models.actor)
        self.planner_box_format = self.model_name_to_box_format(
            self.config.models.planner
        )
        self.asserter_box_format = self.model_name_to_box_format(
            self.config.models.asserter
        )
        self.locating_llm_box_format = self.model_name_to_box_format(
            self.config.models.aux_llms.locating_llm
        )

        self.controller = controller or Controller(
            codify=self.config.controller.codify,
            actor_box_format=self.actor_box_format,
            locating_llm_box_format=self.locating_llm_box_format,
        )
        self.sensitive_data = sensitive_data

        self.settings = AgentSettings(
            planner=planner,
            save_conversation_dir=log_dir,
            max_failures=self.config.agent.max_failures,
            max_steps=self.config.agent.max_steps,
            max_llm_retry=self.config.agent.max_llm_retry,
            retry_delay=self.config.agent.retry_delay,
            override_system_message=override_system_message,
            max_input_tokens=max_input_tokens,
            available_file_paths=available_file_paths,
            include_attributes=include_attributes,
            max_actions_per_step=self.config.agent.max_actions_per_step,
            wait_between_steps=self.config.agent.wait_between_steps,
        )

        # Initialize state
        self.state = AgentState()

        # Action setup
        self._setup_output_models()
        self.initial_actions = (
            self.convert_actions(initial_actions) if initial_actions else None
        )

        # Cache setup
        self.cache_manager = self._init_cache_manager()
        if self.cache_manager is not None:
            self._cache_blacklist = self.cache_manager.config.blacklist
        else:
            self._cache_blacklist = _parse_cache_blacklist(
                getattr(self.config, "cache", None)
            )

        # Browser setup
        self.injected_browser = browser is not None
        self.injected_browser_context = browser_context is not None
        self.browser = (
            browser if browser is not None else (None if browser_context else Browser())
        )
        if browser_context:
            self.browser_context = browser_context
            self.browser_context._cache_manager = self.cache_manager
        elif self.browser:
            self.browser_context = BrowserContext(
                browser=self.browser,
                config=self.browser.config.new_context_config,
                cache_manager=self.cache_manager,
            )
        else:
            self.browser = Browser()
            self.browser_context = BrowserContext(
                browser=self.browser,
                config=self.browser.config.new_context_config,
                cache_manager=self.cache_manager,
            )

        # Initialize message manager with state
        self.message_manager = MessageManager(
            agent_state=self.state,
            browser_context=self.browser_context,
            actor_system_message=SystemPrompt(
                max_actions_per_step=self.settings.max_actions_per_step,
                override_system_message=override_system_message,
                box_format=self.actor_box_format,
            ).get_system_message(),
            include_attributes=self.settings.include_attributes,
            actor_box_format=self.model_name_to_box_format(self.config.models.actor),
            planner_box_format=self.model_name_to_box_format(
                self.config.models.planner
            ),
            asserter_box_format=self.model_name_to_box_format(
                self.config.models.asserter
            ),
            locating_llm_box_format=self.model_name_to_box_format(
                self.config.models.aux_llms.locating_llm
            ),
            react_mode=self.react_mode,
        )

        # Context
        self.context = context
        self.before_run = before_run

    def _save_successful_commands_to_cache(self) -> None:
        """Extract successful commands from history and save to L2 cache.

        Saves in the format that execute_actions_in_cache() expects:
        [{"metadata": {"cmd_state": ...}, "result": [{"codified": ...}]}]
        """
        if self.cache_manager is None:
            return
        try:
            # Group consecutive history items by command (cmd_state)
            # Each command may span multiple steps
            cmd_groups: Dict[str, list] = {}
            for item in self.state.history.history:
                if item.metadata is None or item.metadata.cmd_state is None:
                    continue
                cmd_state = item.metadata.cmd_state
                command = cmd_state.command
                cmd_type = getattr(command, "type", "") or ""
                cmd_desc = getattr(command, "description", "") or ""
                if not cmd_type:
                    continue
                # Skip if any result has an error
                if any(r.error for r in item.result):
                    continue
                # Collect codified results for this step
                codified_results = []
                for r in item.result:
                    if r.codified:
                        codified_results.append({"codified": r.codified})
                if not codified_results:
                    continue

                # Build cache entry in the format execute_actions_in_cache expects
                step_entry = {
                    "metadata": {"cmd_state": cmd_state.model_dump()},
                    "result": codified_results,
                }

                group_key = f"{cmd_type}:{cmd_desc}"
                if group_key not in cmd_groups:
                    cmd_groups[group_key] = {
                        "url": item.state.url if item.state else "",
                        "cmd_type": cmd_type,
                        "cmd_desc": cmd_desc,
                        "steps": [],
                    }
                cmd_groups[group_key]["steps"].append(step_entry)

            # Save each command group
            for group in cmd_groups.values():
                if group["url"] and group["steps"]:
                    self.cache_manager.on_command_success(
                        group["url"],
                        group["cmd_type"],
                        group["cmd_desc"],
                        group["steps"],
                    )
        except Exception as e:
            logger.warning(f"[Cache] Failed to save commands to L2 cache: {e}")

    def _init_cache_manager(self) -> Optional[CacheManager]:
        """Initialize CacheManager from config if cache section exists."""
        try:
            # Deprecation warnings for old agent-level cache config
            if hasattr(self.config, "agent"):
                if getattr(self.config.agent, "enable_cache", None) is not None:
                    logger.warning(
                        "[Deprecated] agent.enable_cache is deprecated, use cache.enabled"
                    )
                if getattr(self.config.agent, "cache_blacklist", None) is not None:
                    logger.warning(
                        "[Deprecated] agent.cache_blacklist is deprecated, use cache.blacklist"
                    )

            cache_cfg = getattr(self.config, "cache", None)
            if cache_cfg is None:
                return None

            cache_enabled = _parse_env_bool(
                "BU_CACHE_ENABLED", getattr(cache_cfg, "enabled", False)
            )

            cache_config = CacheConfig(
                enabled=cache_enabled,
                global_dir=getattr(cache_cfg, "global_dir", "~/.browser-use/cache"),
                blacklist=_parse_cache_blacklist(cache_cfg),
                runtime=dict(getattr(cache_cfg, "runtime", {})),
                action=dict(getattr(cache_cfg, "action", {})),
            )
            if not cache_config.enabled:
                return None
            manager = CacheManager(cache_config)
            manager.initialize()
            return manager
        except Exception as e:
            logger.warning(f"[Cache] Failed to initialize CacheManager: {e}")
            return None

    @time_execution_async("--run (agent)")
    async def run(self) -> AgentHistoryList:
        """Execute the task with maximum number of steps"""
        log_dir = self.config.log_dir if self.config.log_dir else None
        _log_path: Optional[Path] = None
        _report_params: Optional[dict] = None
        run_failed = False
        try:
            with task_log_handler(log_dir) as log_path:
                _log_path = log_path
                try:
                    if self.before_run:
                        await self.before_run(self)

                    # Execute initial actions if provided
                    if self.initial_actions:
                        try:
                            await self.execute_actions(self.initial_actions)
                        except Exception as e:
                            error_message = f"Error executing initial actions: {e}"
                            logger.error(error_message)
                            raise e

                    for task_index, task in self.tasks.build_task_iterator():
                        self.state.named_results.clear()  # 每个 task 开始时清空，避免跨 task 引用
                        for cmd_index, command in enumerate(task.flow):
                            try:
                                await self.before_executing_command(
                                    task_index, cmd_index, command
                                )
                                if (
                                    self.state.current_cmd_state.command.cache
                                    and self.state.current_cmd_state.cmd_type
                                    not in self._cache_blacklist
                                ):
                                    # Execute cached command
                                    try:
                                        (
                                            fallback_to_ai,
                                            msg,
                                        ) = await self.execute_cached_actions(
                                            self.state.current_cmd_state
                                        )
                                        # only fallback_to_ai being False suggests that the cache was executed successfully
                                        # fallback_to_ai being True suggests that cache execution failed
                                        # and falling-back to ai is safe

                                        if not fallback_to_ai:
                                            continue
                                    except Exception as e:
                                        raise e

                                # Into ai mode
                                self.adapt_plan_and_planner()
                                success, msg = await CMDS[
                                    self.state.current_cmd_state.cmd_type
                                ](self)
                                if not success:
                                    logger.error(msg)
                                    raise RuntimeError(msg)
                            except Exception as e:
                                logger.exception(f"Error executing command: {e}")
                                raise e

                except Exception as e:
                    run_failed = True
                    raise e
                finally:
                    try:
                        history = self.state.history.model_dump(by_alias=True)
                        prefix = Path(self.config.task_file).stem
                        if prefix == "quick_task":
                            quick_display_query = read_quick_display_query_raw(
                                self.config
                            )
                            history = relabel_quick_history_ai_commands(
                                history,
                                ai_quick_text=quick_display_query,
                            )
                        with open(
                            Path(self.config.log_dir) / f"{prefix}_result.json", "w"
                        ) as file:
                            json.dump(history, file, indent=4, ensure_ascii=False)
                        # 收集报告参数，等 with 块退出（日志完整落盘）后生成报告
                        run_success = (
                            False if run_failed else _report_success_from_data(history)
                        )
                        report_suffix = "success" if run_success else "failed"
                        report_path = (
                            Path(self.config.log_dir)
                            / f"{prefix}_report_{report_suffix}.html"
                        )
                        _report_params = {
                            "history": history,
                            "report_path": report_path,
                        }
                    except Exception as e:
                        logger.exception(f"Error dumping agent log: {e}")
            return self.state.history
        finally:
            # with 块已退出，task_log_handler 已 flush，log.log 完整落盘，此时生成报告
            # 放在外层 finally 确保异常时也能生成报告
            if _report_params:
                try:
                    browser_info = None
                    try:
                        from browser_use.browser.profiles import get_browser_profile
                        bt = self.browser.config.browser_type if self.browser else "chrome"
                        profile = get_browser_profile(bt)
                        browser_info = profile.display_name
                    except Exception:
                        pass
                    create_standalone_report(
                        _report_params["history"],
                        _report_params["report_path"],
                        log_file=_log_path,
                        browser_info=browser_info,
                    )
                except Exception as e:
                    logger.exception(f"Error building report: {e}")

            # L2 auto-save: persist successful commands to cache
            self._save_successful_commands_to_cache()

            # Log cache stats
            if self.cache_manager is not None:
                stats = self.cache_manager.get_stats()
                if any(v > 0 for v in stats.values()):
                    logger.info(f"[Cache] Stats: {stats}")

            if not self.injected_browser_context:
                await self.browser_context.close()

            if not self.injected_browser and self.browser:
                await self.browser.close()

    @staticmethod
    def model_name_to_box_format(model_name: str):
        model_name = model_name.lower()
        if "gemini" in model_name:
            return "tlbr"
        elif "qwen3-vl" in model_name:
            return "ltrb"

    @property
    def available_commands(self) -> set[str]:
        return set(CMD_TO_ACTION_SPACE.keys())

    async def before_executing_command(
        self,
        task_index: Optional[int],
        cmd_index: int,
        command: agent_tasks.BaseCommandConfig,
    ):
        self.update_action_space(command.type)
        self.state.update_current_cmd_state(
            task_index=task_index,
            cmd_index=cmd_index,
            command=command,
        )
        logger.info(f"🎯 Executing command: {command.description}")

        # L2 auto-lookup: inject cached actions if available and command.cache is empty
        if self.cache_manager is not None and not command.cache:
            try:
                page = await self.browser_context.get_current_page()
                current_url = page.url
                cached_actions = self.cache_manager.on_command_start(
                    current_url, command.type, command.description or ""
                )
                if cached_actions is not None:
                    command.cache = cached_actions
            except Exception as e:
                logger.debug(
                    f"[Cache] L2 lookup in before_executing_command failed: {e}"
                )

    def get_resolved_cmd_argument(self) -> str:
        """返回当前命令 argument 经 named_results 变量替换后的字符串，供后续步骤引用 ${name}。"""
        raw = self.state.current_cmd_argument
        s = str(raw) if raw is not None else ""
        return substitute_variables(s, self.state.named_results)

    @staticmethod
    def register_agent_command(
        cmd_type: str,
        alias: Optional[Union[List[str], str]] = None,
        inclusive_actions: List[str] = None,
        exclusive_actions: List[str] = None,
    ):
        CMD_TO_ACTION_SPACE[cmd_type] = {
            "inclusive_actions": inclusive_actions,
            "exclusive_actions": exclusive_actions,
        }

        if alias:
            if isinstance(alias, str):
                alias = [alias]
            elif isinstance(alias, List):
                assert all(
                    isinstance(a, str) for a in alias
                ), "alias must be a list of strings"
            else:
                logger.warning(f"Invalid alias: {alias}")
                alias = []
        else:
            alias = []

        for _alias in alias:
            assert _alias not in CMD_TO_ACTION_SPACE, f"Command {_alias} already exists"
            CMD_TO_ACTION_SPACE[_alias] = {
                "inclusive_actions": inclusive_actions,
                "exclusive_actions": exclusive_actions,
            }

        def wrapper(func):
            if not iscoroutinefunction(func):

                @functools.wraps(func)
                async def async_wrapper(*args, **kwargs):
                    return await asyncio.to_thread(func, *args, **kwargs)

                wrapped_func = async_wrapper
            else:
                wrapped_func = func
            CMDS[cmd_type] = wrapped_func
            for __alias in alias:
                assert __alias not in CMDS, f"Command {__alias} already exists"
                CMDS[__alias] = wrapped_func
            return wrapped_func

        return wrapper

    @register_agent_command("aiAction")
    async def ai_action(self):
        self.state.consecutive_failures = 0
        while self.state.consecutive_failures < self.settings.max_failures:
            try:
                await self.step()
                self.state.consecutive_failures = 0
                break
            except Exception as e:
                logger.exception(f"Error in step: {e}. Retrying...")
        else:
            msg = (
                f"❌ Stopping due to {self.settings.max_failures} consecutive failures"
            )
            self.state.consecutive_failures = 0
            await self._register_failure_history_item(msg)
            self.state.end_cmd_episode()
            return False, msg

        self.state.end_cmd_episode()
        return True, f"✅ aiAction: {self.state.current_cmd_description} completed."

    @register_agent_command("ai")
    async def ai_react(self):
        self.state.consecutive_failures = 0
        try:
            for step in range(self.settings.max_steps):
                # Check if we should stop due to too many failures
                if self.state.consecutive_failures >= self.settings.max_failures:
                    msg = f"❌ Stopping due to {self.settings.max_failures} consecutive failures"
                    logger.error(msg)
                    await self._register_failure_history_item(msg)
                    return False, msg

                try:
                    await self.step()
                except Exception as e:
                    logger.exception(f"Error in step: {e}. Retrying...")
                    continue

                if self.state.history.is_done():
                    success = self.state.history.is_successful()
                    if success is True:
                        done_text = self.state.history.done_text()
                        if _done_success_text_indicates_failure(done_text):
                            logger.warning(
                                "done(success=True) text indicates a blocking failure; treating task as failed: %s",
                                done_text,
                            )
                            return False, "❌ Task ended with failure text despite done(success=True)"
                        await self.log_completion()
                        return True, "✅ Task completed"
                    return False, "❌ Task ended with done(success=False)"
            else:
                msg = "❌ Failed to complete task in maximum steps"
                logger.info(msg)
                await self._register_failure_history_item(msg)
                return False, msg
        finally:
            self.state.end_cmd_episode()

    @register_agent_command("aiQuick")
    async def ai_quick(self):
        cmd = self.state.current_command
        if not isinstance(cmd, agent_tasks.AiQuickConfig):
            return False, "aiQuick command config is invalid"

        try:
            quick_spec = prepare_quick_task(
                cmd.aiQuick,
                explicit_url=cmd.url,
                require_url=not cmd.resume,
                include_url_context=True,
            )
        except ValueError as exc:
            return False, str(exc)

        original_ai_quick_text = cmd.aiQuick
        original_sensitive_data = self.sensitive_data
        original_max_steps = self.settings.max_steps
        original_react_mode = self.react_mode
        original_message_react_mode = self.message_manager.react_mode

        merged_sensitive_data = dict(original_sensitive_data or {})
        merged_sensitive_data.update(quick_spec.sensitive_data)
        self.sensitive_data = merged_sensitive_data or None
        self.react_mode = "enhanced"
        self.message_manager.react_mode = "enhanced"
        if cmd.maxSteps is not None:
            self.settings.max_steps = int(cmd.maxSteps)
        elif self.settings.max_steps < 40:
            self.settings.max_steps = 40

        cmd.aiQuick = quick_spec.task_text
        try:
            if not cmd.resume and quick_spec.url:
                action = self.ActionModel(go_to_url=GoToUrlAction(url=quick_spec.url))
                await self.multi_act([action])
            return await self.ai_react()
        finally:
            cmd.aiQuick = original_ai_quick_text
            self.sensitive_data = original_sensitive_data
            self.settings.max_steps = original_max_steps
            self.react_mode = original_react_mode
            self.message_manager.react_mode = original_message_react_mode

    @register_agent_command("sleep")
    async def sleep(self):
        ms = int(self.get_resolved_cmd_argument())
        step_start_time = datetime.now()
        msg = f"💤 Sleep for {ms / 1000:.3f} seconds"
        logger.info(msg)

        actor_messages = await self.message_manager.build_actor_input_messages()
        actor_output = msg
        self.state.register_actor_io(actor_messages, actor_output)

        action = self.ActionModel(wait=WaitAction(seconds=ms / 1000))
        result = await self.multi_act([action])

        step_end_time = datetime.now()
        self.state.n_steps += 1
        self.state.register_executed_actions([action])

        self.state.register_result(result)
        metadata = StepMetadata(
            step_start_time=step_start_time,
            step_end_time=step_end_time,
            step_number=self.state.n_steps,
            cmd_state=deepcopy(self.state.cmd_state),
        )
        await self.make_history_item(
            conversations=self.state.pop_conversations(),
            result=result,
            executed_actions=self.state.last_executed_actions,
            metadata=metadata,
        )
        self.state.end_cmd_episode()

        return True, f"💤 Slept for {ms / 1000:.3f} seconds"

    @register_agent_command("goTo")
    async def go_to(self):
        url = self.get_resolved_cmd_argument()
        step_start_time = datetime.now()
        msg = f"🚀 Go to {url}"
        logger.info(msg)

        actor_messages = await self.message_manager.build_actor_input_messages()
        actor_output = msg
        self.state.register_actor_io(actor_messages, actor_output)

        action = self.ActionModel(go_to_url=GoToUrlAction(url=url))
        result = await self.multi_act([action])

        step_end_time = datetime.now()
        self.state.n_steps += 1
        self.state.register_executed_actions([action])
        self.state.register_result(result)
        metadata = StepMetadata(
            step_start_time=step_start_time,
            step_end_time=step_end_time,
            step_number=self.state.n_steps,
            cmd_state=deepcopy(self.state.cmd_state),
        )
        await self.make_history_item(
            conversations=self.state.pop_conversations(),
            result=result,
            executed_actions=self.state.last_executed_actions,
            metadata=metadata,
        )
        self.state.end_cmd_episode()

        return True, f"Go to {url}"

    @register_agent_command("aiWaitFor", inclusive_actions=["wait", "done"])
    async def ai_wait_for(self):
        start_time = datetime.now()
        timeout = int(self.state.current_cmd_config.get("timeout", 120_000)) / 1000
        result = []

        # 「页面加载完成」时先短暂等待，避免刚跳转后 get_state 报 Execution context destroyed
        wait_target = self.get_resolved_cmd_argument().strip()
        if wait_target == "页面加载完成":
            await asyncio.sleep(5)

        try:
            while (datetime.now() - start_time).total_seconds() < timeout:
                try:
                    waiting_messages = (
                        await self.message_manager.build_waiting_input_messages()
                    )
                except Exception as e:
                    logger.warning(
                        f"build_waiting_input_messages failed (e.g. navigation): {e}, retry after 3s"
                    )
                    await asyncio.sleep(3)
                    continue

                try:
                    waiting_actor_output = invoke_llm_with_retry(
                        self.llm,
                        waiting_messages,
                        functools.partial(
                            self.waiting_actor_parsing_function,
                            output_model=self.AgentOutput,
                        ),
                        self.settings.max_llm_retry,
                    )
                except Exception as e:
                    error_message = f"""
❌ Failed to generate waiting actor output after {self.settings.max_llm_retry} attempts.
Error: {e}.\nLaunching retry until timeout...
"""
                    logger.exception(error_message)
                    continue

                self.state.register_actor_io(waiting_messages, waiting_actor_output)
                result: List[ActionResult] = await self.multi_act(
                    waiting_actor_output.action
                )
                self.state.register_executed_actions(waiting_actor_output.action)
                self.state.register_result(result)

                action_name, params = list(
                    waiting_actor_output.action[0]
                    .model_dump(exclude_unset=True)
                    .items()
                )[0]
                if action_name == "done":
                    return True, waiting_actor_output.current_state.reasoning
            # 循环因超时退出（未 return done）：在 finally 前写入带 error 的 result，报告文件名/标题才能为 failed
            end_time = datetime.now()
            if (end_time - start_time).total_seconds() >= timeout:
                result = [ActionResult(error=f"❌ Timeout after {timeout} seconds")]
                self.state.register_result(result)
        except Exception as e:
            logger.exception(f"Error executing aiWaitFor: {e}")
            result = await self._handle_step_error(e)
            self.state.register_result(result)
            return False, f"Error executing aiWaitFor: {e}"
        finally:
            end_time = datetime.now()
            self.state.n_steps += 1
            metadata = StepMetadata(
                step_start_time=start_time,
                step_end_time=end_time,
                step_number=self.state.n_steps,
                cmd_state=deepcopy(self.state.cmd_state),
            )
            await self.make_history_item(
                self.state.pop_conversations(),
                result,
                self.state.last_executed_actions,
                metadata,
            )
            self.state.end_cmd_episode()

        if (end_time - start_time).total_seconds() >= timeout:
            return False, f"❌ Timeout after {timeout} seconds"

    @register_agent_command("waitForText")
    async def wait_for_text(self):
        start_time = datetime.now()
        waiting_text = self.get_resolved_cmd_argument()
        timeout = int(self.state.current_cmd_config.get("timeout", 60_000)) / 1000
        interval = int(self.state.current_cmd_config.get("interval", 5_000)) / 1000

        result = []
        page = await self.browser_context.get_current_page()

        try:
            while (datetime.now() - start_time).total_seconds() < timeout:
                waiting_messages = (
                    await self.message_manager.build_waiting_input_messages()
                )
                try:
                    xpath_to_attr_text = (
                        await self.browser_context.get_all_textual_data(page)
                    )
                except Exception as e:
                    logger.exception(f"Error collecting texts in the page: {e}")
                    result = await self._handle_step_error(e)
                    self.state.register_result(result)
                    return False, f"Error collecting texts in the page: {e}"

                locator_to_attrs = defaultdict(list)
                for xpath, attr_to_text in xpath_to_attr_text.items():
                    for attr, text in attr_to_text.items():
                        if waiting_text in text:
                            # get element by xpath
                            element = await page.query_selector(f"xpath={xpath}")
                            if element:
                                locator: str = await element.generate_locator_string()
                                locator_to_attrs[locator].append(attr)

                if locator_to_attrs:
                    waiting_actor_output = self.AgentOutput(
                        current_state={
                            "reasoning": f'Found target text: "{waiting_text}" in {locator_to_attrs}.',
                            "expected_outcome": "None",
                        },
                        action=[
                            {
                                "done": {
                                    "text": f'页面已出现文字 "{waiting_text}"，等待目标达成。',
                                    "success": True,
                                }
                            }
                        ],
                    )
                    logger.info("Waiting decision:")
                    logger.info(
                        f"Reasoning: {waiting_actor_output.current_state.reasoning}"
                    )
                    logger.info(f"Action: {waiting_actor_output.action}")
                    self.state.register_actor_io(waiting_messages, waiting_actor_output)

                    result = [
                        ActionResult(
                            extracted_content=str(waiting_actor_output.model_dump()),
                            codified=await convert_wait_for_text(
                                {
                                    "waitForText": waiting_text,
                                    "timeout": timeout,
                                    "locator_to_attrs": locator_to_attrs,
                                    "interval": interval,
                                },
                            ),
                        )
                    ]
                    self.state.register_result(result)

                    return True, waiting_actor_output.current_state.reasoning
                else:
                    waiting_actor_output = self.AgentOutput(
                        current_state={
                            "reasoning": f'Cannot find target text: "{waiting_text}" in the page.',
                            "expected_outcome": "None",
                        },
                        action=[{"wait": {"seconds": interval}}],
                    )
                    logger.info("Waiting decision:")
                    logger.info(
                        f"Reasoning: {waiting_actor_output.current_state.reasoning}"
                    )
                    logger.info(f"Action: {waiting_actor_output.action}")
                    self.state.register_actor_io(waiting_messages, waiting_actor_output)
                    result: List[ActionResult] = await self.multi_act(
                        waiting_actor_output.action
                    )
                    self.state.register_executed_actions(waiting_actor_output.action)
                    self.state.register_result(result)

            # 循环因超时退出（未找到文案）：在 finally 前写入带 error 的 result，报告文件名/标题才能为 failed
            end_time = datetime.now()
            if (end_time - start_time).total_seconds() >= timeout:
                result = [ActionResult(error=f"❌ Timeout after {timeout} seconds")]
                self.state.register_result(result)

        except Exception as e:
            logger.exception(f"Error executing waitForText: {e}")
            result = await self._handle_step_error(e)
            self.state.register_result(result)
            return False, f"Error executing waitForText: {e}"
        finally:
            end_time = datetime.now()
            self.state.n_steps += 1
            metadata = StepMetadata(
                step_start_time=start_time,
                step_end_time=end_time,
                step_number=self.state.n_steps,
                cmd_state=deepcopy(self.state.cmd_state),
            )
            await self.make_history_item(
                self.state.pop_conversations(),
                result,
                self.state.last_executed_actions,
                metadata,
            )
            self.state.end_cmd_episode()

        if (end_time - start_time).total_seconds() >= timeout:
            return False, f"❌ Timeout after {timeout} seconds"

    @staticmethod
    def waiting_actor_parsing_function(
        waiting_actor_raw_output: str,
        output_model,
    ):
        waiting_actor_output = parse_response(waiting_actor_raw_output, syntax="json")
        waiting_actor_output = json.loads(waiting_actor_output)
        logger.info("Waiting decision:")
        logger.info(f"Reasoning: {waiting_actor_output['reasoning']}")
        logger.info(f"Action: {waiting_actor_output['action']}")

        # wrap waiting output into agent output
        waiting_actor_output = {
            "current_state": {
                "reasoning": waiting_actor_output["reasoning"],
                "expected_outcome": "None",
            },
            "action": [waiting_actor_output["action"]],
        }
        waiting_actor_output = output_model(**waiting_actor_output)
        return waiting_actor_output

    @register_agent_command("aiTap", inclusive_actions=["click", "done"])
    async def ai_tap(self):
        return await self.ai_action()

    @register_agent_command("aiHover", inclusive_actions=["hover", "done"])
    async def ai_hover(self):
        return await self.ai_action()

    @register_agent_command(
        "aiInput", inclusive_actions=["click", "input_text", "clear_input_text", "done"]
    )
    async def ai_input(self):
        return await self.ai_action()

    @register_agent_command(
        "aiScroll",
        inclusive_actions=[
            "scroll_down",
            "scroll_up",
            "scroll_right",
            "scroll_left",
            "scroll_to_text",
            "done",
        ],
    )
    async def ai_scroll(self):
        return await self.ai_action()

    @register_agent_command("aiSendKeys", inclusive_actions=["send_keys", "done"])
    async def ai_send_keys(self):
        return await self.ai_action()

    @register_agent_command("aiQuery")
    async def ai_query(self):
        query = self.get_resolved_cmd_argument()
        step_start_time = datetime.now()
        msg = f'📝 Extract content "{query}"'
        logger.info(msg)

        actor_messages = await self.message_manager.build_actor_input_messages()
        actor_output = msg
        self.state.register_actor_io(actor_messages, actor_output)

        action = self.ActionModel(extract_content=ExtractPageContentAction(query=query))
        result = await self.multi_act([action])

        step_end_time = datetime.now()
        self.state.n_steps += 1
        self.state.register_executed_actions([action])
        self.state.register_result(result)
        # 若配置了 name，将提取结果写入 named_results 供后续 ${name} 引用（存清洗后的结果，便于 ${name} 替换为可读文本）
        cmd = self.state.current_command
        if isinstance(cmd, agent_tasks.AiQueryConfig) and cmd.name:
            val = None
            if result and result[0].extracted_content:
                raw = result[0].extracted_content
                prefix = "📄  Extracted from page: "
                content = raw[len(prefix) :] if raw.startswith(prefix) else raw
                val = _normalize_aiquery_result_for_name(content)
            self.state.named_results[cmd.name] = val if val is not None else ""
            logger.info(f'Stored aiQuery result under name "{cmd.name}"')
        metadata = StepMetadata(
            step_start_time=step_start_time,
            step_end_time=step_end_time,
            step_number=self.state.n_steps,
            cmd_state=deepcopy(self.state.cmd_state),
        )
        await self.make_history_item(
            conversations=self.state.pop_conversations(),
            result=result,
            executed_actions=self.state.last_executed_actions,
            metadata=metadata,
        )
        self.state.end_cmd_episode()

        return True, f'Extract content "{query}"'

    @register_agent_command("aiAssert")
    async def ai_assert(self):
        step_start_time = datetime.now()
        result = []

        try:
            assertion_messages = (
                await self.message_manager.build_asserter_input_messages()
            )
            try:
                asserter_output = invoke_llm_with_retry(
                    self.asserter,
                    assertion_messages,
                    functools.partial(
                        self.asserter_parsing_function, output_model=self.AsserterOutput
                    ),
                    self.settings.max_llm_retry,
                )
            except Exception as e:
                logger.exception(
                    f"❌ Failed to generate asserter output after {self.settings.max_llm_retry} attempts."
                )
                return False, f"Error executing aiAssert: {e}"

            self.state.register_asserter_io(assertion_messages, asserter_output)
            # When assertion is False, set error so report suffix is failed (see report_generation._report_success_from_data)
            result = [
                ActionResult(
                    extracted_content=str(asserter_output.model_dump()),
                    error=None
                    if asserter_output.assertion
                    else (asserter_output.reasoning or "Assertion failed"),
                )
            ]
            self.state.register_result(result)
            logger.info(f"Assertion: {asserter_output.assertion}")
            logger.info(f"Assertion reason: {asserter_output.reasoning}")
            return asserter_output.assertion, asserter_output.reasoning
        except Exception as e:
            logger.exception(f"Error executing asserter: {e}")
            result = await self._handle_step_error(e)
            self.state.register_result(result)
            return False, f"Error executing asserter: {e}"
        finally:
            step_end_time = datetime.now()
            self.state.n_steps += 1
            self.state.register_executed_actions([])
            metadata = StepMetadata(
                step_start_time=step_start_time,
                step_end_time=step_end_time,
                step_number=self.state.n_steps,
                cmd_state=deepcopy(self.state.cmd_state),
            )
            await self.make_history_item(
                self.state.pop_conversations(),
                result,
                self.state.last_executed_actions,
                metadata,
            )

    @staticmethod
    def asserter_parsing_function(
        asserter_raw_output: str,
        output_model,
    ):
        asserter_output = parse_response(asserter_raw_output, syntax="json")
        asserter_output = json.loads(asserter_output)
        asserter_output = output_model(**asserter_output)
        return asserter_output

    @register_agent_command("aiAssertText")
    async def ai_assert_text(self):
        return await self.ai_assert()

    @register_agent_command("assertText")
    async def assert_text(self):
        step_start_time = datetime.now()
        result = []

        assert_text = self.get_resolved_cmd_argument()
        try:
            assertion_messages = (
                await self.message_manager.build_asserter_input_messages()
            )
            try:
                # assert with playwright function not VLM
                page = await self.browser_context.get_current_page()
                xpath_to_attr_text = await self.browser_context.get_all_textual_data(
                    page
                )
            except Exception as e:
                logger.exception(f"Error collecting texts in the page: {e}")
                result = await self._handle_step_error(e)
                self.state.register_result(result)
                return False, f"Error collecting texts in the page: {e}"

            locator_to_attrs = defaultdict(list)
            for xpath, attr_to_text in xpath_to_attr_text.items():
                for attr, text in attr_to_text.items():
                    if assert_text in text:
                        # get element by xpath
                        element = await page.query_selector(f"xpath={xpath}")
                        if element:
                            locator: str = await element.generate_locator_string()
                            locator_to_attrs[locator].append(attr)

            if locator_to_attrs:
                asserter_output = self.AsserterOutput(
                    assertion=True,
                    reasoning=f'Page contains "{assert_text}"',
                    related_element_description="",
                )
            else:
                failure_message = f'Fail to detect text "{assert_text}"'
                asserter_output = self.AsserterOutput(
                    assertion=False,
                    reasoning=failure_message,
                    related_element_description="",
                )

            self.state.register_asserter_io(assertion_messages, asserter_output)
            # When assertion is False, set error so report suffix is failed (see report_generation._report_success_from_data)
            result = [
                ActionResult(
                    extracted_content=str(asserter_output.model_dump()),
                    codified=await convert_assert_text(
                        {
                            "assertText": assert_text,
                            "locator_to_attrs": locator_to_attrs,
                            **asserter_output.model_dump(),
                        },
                    ),
                    error=None
                    if asserter_output.assertion
                    else (asserter_output.reasoning or "Assertion failed"),
                )
            ]
            self.state.register_result(result)
            logger.info(f"Assertion: {asserter_output.assertion}")
            logger.info(f"Assertion reason: {asserter_output.reasoning}")
            return asserter_output.assertion, asserter_output.reasoning
        except Exception as e:
            logger.exception(f"Error executing text asserter: {e}")
            result = await self._handle_step_error(e)
            self.state.register_result(result)
            return False, f"Error executing text asserter: {e}"
        finally:
            step_end_time = datetime.now()
            self.state.n_steps += 1
            self.state.register_executed_actions([])
            metadata = StepMetadata(
                step_start_time=step_start_time,
                step_end_time=step_end_time,
                step_number=self.state.n_steps,
                cmd_state=deepcopy(self.state.cmd_state),
            )
            await self.make_history_item(
                self.state.pop_conversations(),
                result,
                self.state.last_executed_actions,
                metadata,
            )

    @register_agent_command("jsCode")
    async def js_code(self):
        result = []
        step_start_time = datetime.now()
        code = self.get_resolved_cmd_argument()
        page = await self.browser_context.get_current_page()
        wrapped = f"""
(() => {{
{code}
}})();
"""
        actor_messages = await self.message_manager.build_actor_input_messages()
        try:
            await page.evaluate(wrapped)
            result = [
                ActionResult(
                    extracted_content=f"Executed javascript code: {code}",
                    codified={"code": f'await page.evaluate("""{wrapped}""")'},
                )
            ]
            msg = f"Executed javascript code: {code}"
            self.state.register_actor_io(actor_messages, msg)
            self.state.register_result(result)
            return True, msg
        except Exception as e:
            msg = f"Error executing javascript code: {e}"
            logger.exception(msg)
            result = await self._handle_step_error(e)
            self.state.register_result(result)
            self.state.register_actor_io(actor_messages, msg)
            return False, f"Error executing javascript code: {e}"
        finally:
            step_end_time = datetime.now()
            self.state.n_steps += 1

            self.state.register_executed_actions([])
            metadata = StepMetadata(
                step_start_time=step_start_time,
                step_end_time=step_end_time,
                step_number=self.state.n_steps,
                cmd_state=deepcopy(self.state.cmd_state),
            )
            await self.make_history_item(
                conversations=self.state.pop_conversations(),
                result=result,
                executed_actions=self.state.last_executed_actions,
                metadata=metadata,
            )
            self.state.end_cmd_episode()

    @register_agent_command("pyCode")
    async def py_code(self):
        result = []
        step_start_time = datetime.now()
        code = self.get_resolved_cmd_argument()
        page = await self.browser_context.get_current_page()
        session = await self.browser_context.get_session()

        actor_messages = await self.message_manager.build_actor_input_messages()
        try:
            await self.controller.execute_async_action_code(code, page, session.context)
            result = [
                ActionResult(
                    extracted_content=f"Executed python code: {code}",
                    codified={
                        "code": code,
                    },
                )
            ]
            msg = f"Executed python code: {code}"
            self.state.register_actor_io(actor_messages, msg)
            self.state.register_result(result)
            return True, msg
        except Exception as e:
            msg = f"Error executing python code: {e}"
            logger.exception(msg)
            result = await self._handle_step_error(e)
            self.state.register_result(result)
            self.state.register_actor_io(actor_messages, msg)
            return False, f"Error executing python code: {e}"
        finally:
            step_end_time = datetime.now()
            self.state.n_steps += 1

            self.state.register_executed_actions([])
            metadata = StepMetadata(
                step_start_time=step_start_time,
                step_end_time=step_end_time,
                step_number=self.state.n_steps,
                cmd_state=deepcopy(self.state.cmd_state),
            )
            await self.make_history_item(
                conversations=self.state.pop_conversations(),
                result=result,
                executed_actions=self.state.last_executed_actions,
                metadata=metadata,
            )
            self.state.end_cmd_episode()

    @register_agent_command("toolCall")
    async def tool_call(self):
        """
        Execute a built-in tool by name, optionally store the result in named_results.

        Design notes (docs/tools/tools_design.md v6.1):
        - actor_messages = [] : no browser state needed for a pure data call
        - No _handle_step_error : tool failures are deterministic; retrying wastes max_failures quota
        - Direct call (no asyncio.to_thread) for sync tools; await for async tools (Phase 2 HTTP)
        """
        result = []
        step_start_time = datetime.now()
        cmd: agent_tasks.ToolCallConfig = self.state.current_cmd_state.command
        tool_name = cmd.toolCall

        # toolCall has no browser dependency — skip screenshot/DOM build entirely
        actor_messages = []

        try:
            # Resolve ${name} / ${name.field} placeholders in string-typed args
            resolved_args = {
                k: (
                    substitute_variables(str(v), self.state.named_results)
                    if isinstance(v, str)
                    else v
                )
                for k, v in (cmd.args or {}).items()
            }

            func = ToolRegistry.get(tool_name)
            if func is None:
                raise ValueError(
                    f"Tool '{tool_name}' not found. "
                    f"Available tools: {ToolRegistry.list_tools()}"
                )

            # Dispatch: await async tools (e.g. future HTTP tools), call sync tools directly
            if asyncio.iscoroutinefunction(func):
                raw_result = await func(**resolved_args)
            else:
                raw_result = func(**resolved_args)

            # Normalize result to str; dict/list → JSON so ${name.field} dot-path works
            if isinstance(raw_result, (dict, list)):
                result_str = json.dumps(raw_result, ensure_ascii=False)
            else:
                result_str = str(raw_result) if raw_result is not None else ""

            # Store in named_results if caller gave a name
            if cmd.name:
                self.state.named_results[cmd.name] = result_str
                display = (
                    result_str if len(result_str) <= 200 else result_str[:200] + "..."
                )
                logger.info(
                    f'[toolCall] {tool_name} → named_results["{cmd.name}"] = {display}'
                )

            msg = f"toolCall {tool_name}({resolved_args}) → {result_str}"
            result = [ActionResult(extracted_content=msg)]
            self.state.register_actor_io(actor_messages, msg)
            self.state.register_result(result)
            return True, msg

        except Exception as e:
            # Do NOT call _handle_step_error — tool failures don't consume max_failures
            msg = f"toolCall {tool_name} failed: {e}"
            logger.exception(msg)
            result = [ActionResult(error=msg)]
            self.state.register_result(result)
            self.state.register_actor_io(actor_messages, msg)
            return False, msg

        finally:
            step_end_time = datetime.now()
            self.state.n_steps += 1

            self.state.register_executed_actions([])
            metadata = StepMetadata(
                step_start_time=step_start_time,
                step_end_time=step_end_time,
                step_number=self.state.n_steps,
                cmd_state=deepcopy(self.state.cmd_state),
            )
            await self.make_history_item(
                conversations=self.state.pop_conversations(),
                result=result,
                executed_actions=self.state.last_executed_actions,
                metadata=metadata,
            )
            self.state.end_cmd_episode()

    @register_agent_command("if")
    async def if_then_else(self):
        msgs = []

        if_command = self.get_resolved_cmd_argument()
        cmd_config = self.state.current_cmd_config
        self.state.register_deeper_cmd_state()
        try:
            await self.before_executing_command(
                task_index=None,
                cmd_index=-1,
                command=if_command,
            )
            self.adapt_plan_and_planner()
            if_success, msg = await CMDS[if_command.type](self)
            msg = f"if cmd: {if_command.description}, success: {if_success}, msg: {msg}"
            msgs.append(msg)
            logger.info(msg)
        except Exception as e:
            logger.exception(f"Error executing if cmd: {e}")
            msg = f"Error executing if cmd: {e}"
            return False, msg

        if_then_else_success = True
        if if_success:
            logger.info("Into then branch...")
            then_cmds = cmd_config.get("then", [])
            for then_cmd_index, then_command in enumerate(then_cmds):
                await self.before_executing_command(
                    task_index=None,
                    cmd_index=then_cmd_index,
                    command=then_command,
                )
                try:
                    self.adapt_plan_and_planner()
                    success, msg = await CMDS[self.state.current_cmd_state.cmd_type](
                        self
                    )
                    if_then_else_success = success and if_then_else_success
                    msg = (
                        f"then cmd: {self.state.current_cmd_state.cmd_type}"
                        f" - {self.state.current_cmd_state.cmd_argument}"
                        f" - {self.state.current_cmd_state.cmd_config}, "
                        f"msg: {msg}"
                    )
                    msgs.append(msg)
                except Exception as e:
                    logger.exception(f"Error executing then cmd: {e}")
                    msg = f"Error executing then cmd: {e}"
                    return False, msg
        else:
            logger.info("Into else branch...")
            else_cmds = cmd_config.get("else", [])
            for else_cmd_index, else_command in enumerate(else_cmds):
                await self.before_executing_command(
                    task_index=None,
                    cmd_index=else_cmd_index,
                    command=else_command,
                )
                try:
                    self.adapt_plan_and_planner()
                    success, msg = await CMDS[self.state.current_cmd_state.cmd_type](
                        self
                    )
                    if_then_else_success = success and if_then_else_success
                    msg = (
                        f"else cmd: {self.state.current_cmd_state.cmd_type}"
                        f" - {self.state.current_cmd_state.cmd_argument}"
                        f" - {self.state.current_cmd_state.cmd_config}, "
                        f"msg: {msg}"
                    )
                    msgs.append(msg)
                except Exception as e:
                    logger.exception(f"Error executing else cmd: {e}")
                    msg = f"Error executing else cmd: {e}"
                    return False, msg
        self.state.delete_current_cmd_state()

        return if_then_else_success, "\n".join(msgs)

    @register_agent_command("upload")
    async def upload(self):
        result = []
        step_start_time = datetime.now()
        page = await self.browser_context.get_current_page()
        file_path = self.get_resolved_cmd_argument()

        actor_messages = await self.message_manager.build_actor_input_messages()
        try:
            # convert file_path to absolute path
            file_path = Path(file_path)
            if file_path.exists():
                file_path = file_path.absolute()
                logger.info(f"Uploading file: {file_path}")
            elif (
                not file_path.is_absolute()
                and (Path(self.tasks.task_yaml_path).parent / file_path).exists()
            ):
                file_path = (
                    Path(self.tasks.task_yaml_path).parent / file_path
                ).absolute()
                logger.info(f"Uploading file: {file_path}")
            else:
                raise FileNotFoundError(f"File {file_path} does not exist.")

            cmd = self.state.current_command
            locate_raw = (
                cmd.locate if isinstance(cmd, agent_tasks.UploadConfig) else None
            )
            upload_index = (
                cmd.upload_index if isinstance(cmd, agent_tasks.UploadConfig) else None
            )
            locate_resolved = (
                substitute_variables(str(locate_raw), self.state.named_results).strip()
                if locate_raw
                else None
            )
            upload_locator, locator_note = await _resolve_file_upload_locator(
                page,
                locate_resolved or None,
                upload_index,
            )
            await upload_locator.set_input_files(str(file_path))
            msg = f"Uploaded file: {file_path} ({locator_note})"
            result = [
                ActionResult(
                    extracted_content=msg,
                    codified={
                        "code": (
                            f"# upload target: {locator_note}\n"
                            f"await page.locator('<your selector>').set_input_files({str(file_path)!r})"
                        )
                    },
                )
            ]
            self.state.register_actor_io(actor_messages, msg)
            self.state.register_result(result)
            return True, msg
        except Exception as e:
            msg = f"Error uploading file: {e}"
            logger.exception(msg)
            result = await self._handle_step_error(e)
            self.state.register_result(result)
            self.state.register_actor_io(actor_messages, msg)
            return False, msg
        finally:
            step_end_time = datetime.now()
            self.state.n_steps += 1

            self.state.register_executed_actions([])
            metadata = StepMetadata(
                step_start_time=step_start_time,
                step_end_time=step_end_time,
                step_number=self.state.n_steps,
                cmd_state=deepcopy(self.state.cmd_state),
            )
            await self.make_history_item(
                conversations=self.state.pop_conversations(),
                result=result,
                executed_actions=self.state.last_executed_actions,
                metadata=metadata,
            )
            self.state.end_cmd_episode()

    @register_agent_command("scrollToText", inclusive_actions=["scroll_to_text"])
    async def scroll_to_text(self):
        result = []
        step_start_time = datetime.now()
        text = self.get_resolved_cmd_argument()

        actor_messages = await self.message_manager.build_actor_input_messages()
        try:
            action = self.ActionModel(scroll_to_text=ScrollToTextAction(text=text))
            result = await self.multi_act([action])
            msg = f"Scroll to text: {text}"
            self.state.register_actor_io(actor_messages, msg)
            self.state.register_result(result)
            return True, msg
        except Exception as e:
            msg = f"Error scrolling to text: {e}"
            logger.exception(msg)
            result = await self._handle_step_error(e)
            self.state.register_actor_io(actor_messages, msg)
            self.state.register_result(result)
            return False, msg
        finally:
            step_end_time = datetime.now()
            self.state.n_steps += 1

            self.state.register_executed_actions([])
            metadata = StepMetadata(
                step_start_time=step_start_time,
                step_end_time=step_end_time,
                step_number=self.state.n_steps,
                cmd_state=deepcopy(self.state.cmd_state),
            )
            await self.make_history_item(
                conversations=self.state.pop_conversations(),
                result=result,
                executed_actions=self.state.last_executed_actions,
                metadata=metadata,
            )
            self.state.end_cmd_episode()

    def update_action_space(self, command_type: str):
        action_space = CMD_TO_ACTION_SPACE[command_type]
        action_space = self.controller.registry.get_available_action_space(
            inclusive_actions=action_space["inclusive_actions"],
            exclusive_actions=action_space["exclusive_actions"],
        )
        self.state.update_action_space(action_space)

    def adapt_plan_and_planner(self):
        if isinstance(self.state.current_command, (agent_tasks.AiConfig, agent_tasks.AiQuickConfig)):
            self.planner = self.planner_llm
        else:
            self.planner = YamlPlanner(command=self.state.current_command)

    def _setup_output_models(self) -> None:
        """Setup dynamic action models from controller's registry"""
        self.ActionModel = self.controller.registry.create_action_model()
        # Create output model with the dynamic actions
        self.AgentOutput = AgentOutput.type_with_custom_actions(self.ActionModel)
        self.PlannerOutput = PlannerOutput
        self.AsserterOutput = AsserterOutput

    @time_execution_async("--step (agent)")
    async def step(self) -> None:
        """Execute one step of the task"""
        logger.info(f"📍 Step {self.state.n_steps}")
        result: List[ActionResult] = []
        step_start_time = datetime.now()

        try:
            # Run planner
            planner_input = await self.message_manager.build_planner_input_messages()
            planner_output = await self.run_planner(planner_input)
            self.state.register_planner_io(planner_input, planner_output)

            # Finish ReAct loop if planner marks task as done
            if planner_output.is_ultimate_task_done:
                logger.info(
                    "Ultimate task is done and step will be done in advance by planner."
                )
                result = [
                    ActionResult(
                        is_done=True,
                        success=True,
                        extracted_content=json.dumps(
                            planner_output.model_dump(), ensure_ascii=False, indent=4
                        ),
                        codified=await convert_done_action(
                            DoneAction(
                                text="Ultimate task is marked as done by planner.",
                                success=True,
                            )
                        ),
                    ),
                ]
                self.state.register_result(result)
                return

            # Run actor
            input_messages = await self.message_manager.build_actor_input_messages()
            try:
                model_output = await self.get_next_action(input_messages)
                self.state.register_actor_io(input_messages, model_output)
            except Exception as e:
                error_message = f"Error in actor: {e}"
                logger.exception(error_message)
                raise e

            # Run controller
            result: List[ActionResult] = await self.multi_act(model_output.action)
            self.state.register_result(result)
            self.state.n_steps += 1
            time.sleep(self.settings.wait_between_steps)

        except InterruptedError:
            logger.debug("Agent paused")
            self.state.register_result(
                [
                    ActionResult(
                        error="The agent was paused - now continuing actions might need to be repeated",
                    )
                ]
            )
            return
        except Exception as e:
            result = await self._handle_step_error(e)
            self.state.register_result(result)
            raise e
        finally:
            step_end_time = datetime.now()
            self.state.n_steps += 1
            if not result:
                return

            metadata = StepMetadata(
                step_start_time=step_start_time,
                step_end_time=step_end_time,
                step_number=self.state.n_steps,
                cmd_state=deepcopy(self.state.cmd_state),
            )
            await self.make_history_item(
                self.state.pop_conversations(),
                result,
                self.state.last_executed_actions,
                metadata,
            )

    async def _register_failure_history_item(self, error_msg: str) -> None:
        """Register a failure result into history so report suffix is failed."""
        result = [ActionResult(error=error_msg)]
        self.state.register_result(result)
        step_end_time = datetime.now()
        metadata = StepMetadata(
            step_start_time=step_end_time,
            step_end_time=step_end_time,
            step_number=self.state.n_steps + 1,
            cmd_state=deepcopy(self.state.cmd_state),
        )
        try:
            await self.make_history_item(
                self.state.pop_conversations(),
                result,
                self.state.last_executed_actions,
                metadata,
            )
        except Exception as e:
            logger.warning(
                "Failed to add failure history item (report may show success): %s", e
            )

    @time_execution_async("--handle_step_error (agent)")
    async def _handle_step_error(self, error: Exception) -> List[ActionResult]:
        """Handle all types of errors that can occur during a step"""
        include_trace = logger.isEnabledFor(logging.DEBUG)
        error_msg = AgentError.format_error(error, include_trace=include_trace)
        prefix = f"❌ Result failed {self.state.consecutive_failures + 1}/{self.settings.max_failures} times:\n "
        self.state.consecutive_failures += 1

        if isinstance(error, RateLimitError) or isinstance(error, ResourceExhausted):
            logger.warning(f"{prefix}{error_msg}")
            await asyncio.sleep(self.settings.retry_delay)
        else:
            logger.exception(f"{prefix}{error_msg}")

        return [ActionResult(error=error_msg)]

    async def make_history_item(
        self,
        conversations: List[Conversation],
        result: List[ActionResult],
        executed_actions: Optional[List[ActionModel]] = None,
        metadata: Optional[StepMetadata] = None,
        lightweight: bool = True,
    ) -> None:
        """Create and store history item.

        Args:
            lightweight: Default True. Only take 1 screenshot + basic page info
                         (url/title/tabs). Skips full get_state() which does
                         3 screenshots + DOM extraction — none of which are
                         needed for history/report recording.
        """
        if lightweight:
            page = await self.browser_context.get_current_page()
            screenshot_raw = await self.browser_context.take_screenshot(b64=False)
            screenshot_img = Image.open(BytesIO(screenshot_raw))
            screenshot_b64 = encode_image_base64(screenshot_img)
            title = await self._safe_get_page_title(page)
            tabs = await self._safe_get_tabs_info()
            state_history = BrowserStateHistory(
                url=page.url,
                title=title,
                tabs=tabs,
                screenshot=screenshot_b64,
            )
            # Cache screenshot so cache replay can reuse it as next step's "before"
            self._last_lightweight_screenshot = screenshot_img
        else:
            state = await self.browser_context.get_state()
            state_history = BrowserStateHistory(
                url=state.url,
                title=state.title,
                tabs=state.tabs,
                screenshot=state.screenshot,
            )

        screenshot_before_actions = None
        if self.state.screenshots_before_actions:
            screenshot_before_actions = encode_image_base64(
                self.state.screenshots_before_actions[-1]
            )

        history_item = AgentHistory(
            conversations=conversations,
            result=result,
            state=state_history,
            executed_actions=executed_actions,
            metadata=metadata,
            screenshot_before_actions=screenshot_before_actions,
        )

        self.state.history.history.append(history_item)
        self.state.screenshots_before_actions = []

    @staticmethod
    def _is_transient_navigation_error(error: Exception) -> bool:
        msg = str(error).lower()
        transient_signals = (
            "execution context was destroyed",
            "cannot find context with specified id",
            "navigation",
        )
        return any(signal in msg for signal in transient_signals)

    async def _safe_get_page_title(self, page: Page) -> str:
        retries = 3
        delay_seconds = 0.3
        for attempt in range(retries):
            try:
                return await page.title()
            except Exception as e:
                if not self._is_transient_navigation_error(e):
                    raise
                if attempt == retries - 1:
                    logger.warning(
                        "History degraded: fallback to empty title due to navigation race: %s",
                        e,
                    )
                    return ""
                await asyncio.sleep(delay_seconds)
        return ""

    async def _safe_get_tabs_info(self):
        retries = 3
        delay_seconds = 0.3
        for attempt in range(retries):
            try:
                return await self.browser_context.get_tabs_info()
            except Exception as e:
                if not self._is_transient_navigation_error(e):
                    raise
                if attempt == retries - 1:
                    logger.warning(
                        "History degraded: fallback to empty tabs due to navigation race: %s",
                        e,
                    )
                    return []
                await asyncio.sleep(delay_seconds)
        return []

    THINK_TAGS = re.compile(r"<think>.*?</think>", re.DOTALL)
    STRAY_CLOSE_TAG = re.compile(r".*?</think>", re.DOTALL)

    def _remove_think_tags(self, text: str) -> str:
        # Step 1: Remove well-formed <think>...</think>
        # Step 1: Remove well-formed <think>...</think>
        text = re.sub(self.THINK_TAGS, "", text)
        # Step 2: If there's an unmatched closing tag </think>,
        #         remove everything up to and including that.
        text = re.sub(self.STRAY_CLOSE_TAG, "", text)
        return text.strip()

    @time_execution_async("--get_next_action (agent)")
    async def get_next_action(self, input_messages: List[BaseMessage]) -> AgentOutput:
        """Get next action from LLM based on current state"""

        def _validate_sensitive_placeholders(actor_output: AgentOutput) -> None:
            if not self.sensitive_data:
                return

            allowed = set(self.sensitive_data.keys())
            allowed_display = ", ".join(f"${{{key}}}" for key in sorted(allowed))
            sensitive_name_pattern = re.compile(
                r"(USER|USERNAME|ACCOUNT|PASS|PASSWORD|PWD|TOKEN|SECRET)",
                re.IGNORECASE,
            )
            placeholder_pattern = re.compile(r"\$\{\s*([a-zA-Z0-9_.]+)\s*\}")
            secret_pattern = re.compile(r"<secret>\s*([^<]+?)\s*</secret>")

            def iter_strings(value: Any):
                if isinstance(value, str):
                    yield value
                elif isinstance(value, dict):
                    for item in value.values():
                        yield from iter_strings(item)
                elif isinstance(value, list):
                    for item in value:
                        yield from iter_strings(item)

            dumped_actions = [action.model_dump(exclude_unset=True) for action in actor_output.action]
            for text in iter_strings(dumped_actions):
                placeholders = placeholder_pattern.findall(text) + secret_pattern.findall(text)
                for placeholder in placeholders:
                    placeholder = placeholder.strip()
                    if placeholder in allowed:
                        continue
                    if sensitive_name_pattern.search(placeholder):
                        raise RuntimeError(
                            f'Unknown sensitive variable "{placeholder}". '
                            f"Do not invent credential variable names. Use only: {allowed_display}."
                        )

        def _actor_parsing_function(
            _actor_raw_output: str, action_space: List[RegisteredAction]
        ):
            _actor_output = self._remove_think_tags(_actor_raw_output)
            _actor_output = extract_json_from_model_output(_actor_output)
            action_names = [action.name for action in action_space]
            if "action" in _actor_output and isinstance(_actor_output["action"], List):
                for _action_config in _actor_output["action"]:
                    action_name = list(_action_config.keys())[0]
                    if (
                        isinstance(_action_config, Dict)
                        and action_name not in action_names
                    ):
                        raise RuntimeError(
                            f'Action "{action_name}" is not in the action space: {action_names}. '
                            f"ONLY use the actions in the action space."
                        )

            _actor_output = self.AgentOutput(**_actor_output)
            _validate_sensitive_placeholders(_actor_output)
            return _actor_output

        try:
            actor_output = invoke_llm_with_retry(
                self.llm,
                input_messages,
                functools.partial(
                    _actor_parsing_function,
                    action_space=self.state.current_action_space,
                ),
                self.settings.max_llm_retry,
            )
        except Exception as e:
            logger.exception(
                f"❌ Failed to generate actor output after {self.settings.max_llm_retry} attempts"
            )
            raise e

        if actor_output is None:
            raise ValueError("Could not parse response.")

        # cut the number of actions to max_actions_per_step if needed
        if len(actor_output.action) > self.settings.max_actions_per_step:
            actor_output.action = actor_output.action[
                : self.settings.max_actions_per_step
            ]

        log_response(actor_output)

        if len(actor_output.action) == 0:
            logger.warning(
                'No action will be executed. By default, the step will be marked as "Done"'
            )
            actor_output.action.append(
                self.ActionModel(
                    done=DoneAction(
                        text=f"{actor_output.current_state.reasoning}",
                        success=True,
                    )
                )
            )

        return actor_output

    @time_execution_async("--multi-act (agent)")
    async def multi_act(
        self,
        actions: List[ActionModel],
        check_for_new_elements: bool = True,
    ) -> List[ActionResult]:
        """Execute multiple actions"""
        results = []
        executed_actions = []

        cached_selector_map = await self.browser_context.get_selector_map()
        cached_path_hashes = set(
            e.hash.branch_path_hash for e in cached_selector_map.values()
        )

        await self.browser_context.remove_highlights()
        # Skip before-screenshot when page is blank (e.g. before initial go_to_url)
        page = await self.browser_context.get_current_page()
        if page.url not in ("about:blank", ""):
            screenshot = await self.browser_context.take_screenshot(b64=False)
            self.state.register_screenshot_before_actions(
                Image.open(BytesIO(screenshot))
            )

        for i, action in enumerate(actions):
            if action.get_index() is not None and i != 0:
                new_state = await self.browser_context.get_state()
                new_path_hashes = set(
                    e.hash.branch_path_hash for e in new_state.selector_map.values()
                )
                if check_for_new_elements and not new_path_hashes.issubset(
                    cached_path_hashes
                ):
                    # next action requires index but there are new elements on the page
                    msg = f"Something new appeared after action {i} / {len(actions)}"
                    logger.info(msg)
                    results.append(ActionResult(extracted_content=msg))
                    break

            try:
                # 传入 named_results 供 controller 在 input_text 等 action 中替换 ${name}
                context = dict(self.context) if isinstance(self.context, dict) else {}
                context["named_results"] = self.state.named_results
                result = await self.controller.act(
                    action,
                    self.browser_context,
                    self.aux_llms,
                    self.sensitive_data,
                    self.settings.available_file_paths,
                    context=context,
                )
            except Exception as e:
                error_msg = (
                    f"When executing action #{i + 1}: {action}, error occurred: {e}"
                )
                logger.exception(error_msg)
                result = ActionResult(error=error_msg)
                results.append(result)
                raise e
            finally:
                # L1 dirty mark: invalidate runtime cache after browser action
                if self.cache_manager is not None:
                    self.cache_manager.on_action_executed()

            results.append(result)

            # Update params
            if result.updated_params is not None:
                action.update_params(**result.updated_params)

            executed_actions.append(action)
            logger.debug(f"Executed action {i + 1} / {len(actions)}")
            if self.state.last_screenshot_before_actions is not None:
                self.state.register_screenshot_before_actions(
                    self.browser_context.highlight_action_on_screenshot(
                        self.state.last_screenshot_before_actions,
                        [action],
                    )
                )

            if results[-1].is_done or results[-1].error or i == len(actions) - 1:
                break

            await asyncio.sleep(self.browser_context.config.wait_between_actions)

        self.state.register_executed_actions(executed_actions)
        return results

    async def execute_actions(self, actions: List[ActionModel]):
        step_start_time = datetime.now()
        result = []
        actor_input_messages = await self.message_manager.build_actor_input_messages()
        try:
            result = await self.multi_act(actions, check_for_new_elements=False)
            self.state.register_result(result)
            msg = f"Successfully execute actions - {actions}"
            self.state.register_actor_io(actor_input_messages, msg)
        except Exception as e:
            result = await self._handle_step_error(e)
            error_message = (
                f"Error executing the given actions: {e}\nThe given actions: {actions}"
            )
            logger.exception(error_message)
            self.state.register_actor_io(actor_input_messages, error_message)
            raise e
        finally:
            step_end_time = datetime.now()
            self.state.n_steps += 1
            metadata = StepMetadata(
                step_start_time=step_start_time,
                step_end_time=step_end_time,
                step_number=self.state.n_steps,
                cmd_state=deepcopy(self.state.cmd_state),
            )
            try:
                await self.make_history_item(
                    conversations=self.state.pop_conversations(),
                    result=result,
                    executed_actions=self.state.last_executed_actions,
                    metadata=metadata,
                )
            except Exception as e:
                if self._is_transient_navigation_error(e):
                    logger.warning(
                        "Skip history item for transient navigation error: %s", e
                    )
                else:
                    logger.exception(
                        "Failed to create history item after execute_actions: %s", e
                    )

    async def execute_cached_actions(self, cmd_state: CommandState) -> Tuple[bool, str]:
        # Execute cached command step-by-step with per-step screenshots
        fallback_to_ai = False
        all_results: List[ActionResult] = []

        try:
            input_messages = await self.message_manager.build_actor_input_messages()
        except Exception as e:
            msg = f"Error updating current browser state: {e}"
            logger.exception(msg)
            fallback_to_ai = True
            return fallback_to_ai, msg

        steps_cache = cmd_state.command.cache
        last_after_screenshot = (
            None  # Reuse previous step's "after" as next step's "before"
        )
        try:
            for step_index, step_cache in enumerate(steps_cache):
                step_start_time = datetime.now()

                # Register "before" screenshot: reuse last step's after, or take a fresh one
                if last_after_screenshot is not None:
                    self.state.register_screenshot_before_actions(last_after_screenshot)
                else:
                    try:
                        page = await self.browser_context.get_current_page()
                        if page.url not in ("about:blank", ""):
                            screenshot = await self.browser_context.take_screenshot(
                                b64=False
                            )
                            self.state.register_screenshot_before_actions(
                                Image.open(BytesIO(screenshot))
                            )
                    except Exception as e:
                        logger.debug(
                            f"[Cache] Failed to capture before-screenshot: {e}"
                        )

                # Execute single step
                step_result = await self.controller.execute_actions_in_cache(
                    [step_cache],
                    self.browser_context,
                )
                all_results.extend(step_result)

                # L1 dirty mark
                if self.cache_manager is not None:
                    self.cache_manager.on_action_executed()

                # Create lightweight history item (1 screenshot instead of 3 + DOM)
                step_end_time = datetime.now()
                self.state.n_steps += 1
                self.state.register_result(step_result)
                step_msg = (
                    f"[Cache step {step_index + 1}/{len(steps_cache)}] "
                    f"{cmd_state.cmd_description}"
                )
                self.state.register_actor_io(input_messages, step_msg)
                metadata = StepMetadata(
                    step_start_time=step_start_time,
                    step_end_time=step_end_time,
                    step_number=self.state.n_steps,
                    cmd_state=deepcopy(cmd_state),
                )
                await self.make_history_item(
                    conversations=self.state.pop_conversations(),
                    result=step_result,
                    executed_actions=None,
                    metadata=metadata,
                    lightweight=True,
                )
                # Reuse the "after" screenshot from make_history_item as next step's "before"
                last_after_screenshot = getattr(
                    self, "_last_lightweight_screenshot", None
                )
                # Clear screenshots for next step
                self.state.screenshots_before_actions = []

            msg = f"Successfully execute cached actions - {cmd_state.cmd_description}"
            logger.info(msg)
        except ValueError as e:
            fallback_to_ai = True
            msg = (
                f"ValueError: invalid data in cache: {e}. Skipping execution of cache."
            )
            logger.exception(msg)
            self.state.register_actor_io(input_messages, msg)
        except RuntimeWarning as w:
            fallback_to_ai = True
            msg = f"RuntimeWarning: {w}. Skipping execution of cache."
            logger.warning(msg)
            self.state.register_actor_io(input_messages, msg)
        except RuntimeError as e:
            all_results.extend(await self._handle_step_error(e))
            self.state.register_result(all_results)
            msg = f"RuntimeError when executing cache: {e}."
            logger.exception(msg)
            self.state.register_actor_io(input_messages, msg)
            raise e
        except Exception as e:
            all_results.extend(await self._handle_step_error(e))
            self.state.register_result(all_results)
            msg = f"Exception when executing cache: {e}."
            logger.exception(msg)
            self.state.register_actor_io(input_messages, msg)
            raise e
        finally:
            self.state.end_cmd_episode()

        return fallback_to_ai, msg

    async def log_completion(self) -> None:
        """Log the completion of the task"""
        logger.info("✅ Task completed")
        if self.state.history.is_successful():
            logger.info("✅ Successfully")
        else:
            logger.info("❌ Unfinished")

    def convert_actions(
        self, actions: List[Dict[str, Dict[str, Any]]]
    ) -> List[ActionModel]:
        """Convert dictionary-based actions to ActionModel instances"""
        converted_actions = []
        for action_dict in actions:
            # Each action_dict should have a single key-value pair
            action_name = next(iter(action_dict))
            params = action_dict[action_name]

            # Get the parameter model for this action from registry
            action_info = self.controller.registry.registry.actions[action_name]
            param_model = action_info.param_model

            # Create validated parameters using the appropriate param model
            validated_params = param_model(**params)

            # Create ActionModel instance with the validated parameters
            action_model = self.ActionModel(**{action_name: validated_params})
            converted_actions.append(action_model)

        return converted_actions

    async def run_planner(self, planner_input_messages: List[BaseMessage]):
        """Run the planner to analyze state and suggest next steps"""
        # Skip planning if no planner_llm is set
        if not self.planner:
            return None

        try:
            planner_output = invoke_llm_with_retry(
                self.planner,
                planner_input_messages,
                functools.partial(
                    self.parse_and_log_planner_output,
                    output_model=self.PlannerOutput,
                    model_name=self.planner.model_name,
                ),
                self.settings.max_llm_retry,
            )
        except Exception as e:
            error_message = f"❌ Failed to generate planner output after {self.settings.max_llm_retry} attempts"
            logger.exception(error_message)
            raise e

        return planner_output

    @staticmethod
    def parse_and_log_planner_output(
        planner_raw_output: str,
        output_model,
        model_name: str,
    ):
        output = parse_response(planner_raw_output, syntax="json")
        output = json.loads(output)
        logger.info("Planning Analysis:")
        logger.info(f"State analysis: {output['state_analysis']}")
        logger.info(f"Progress evaluation: {output['progress_evaluation']}")
        logger.info(f"Reasoning: {output['reasoning']}")
        logger.info(f"Is ultimate task done: {output['is_ultimate_task_done']}")
        logger.info(f"Plan: {output['plan']}")

        if not isinstance(output["is_ultimate_task_done"], bool):
            logger.debug(
                f'Parsing is_ultimate_task_done: {output["is_ultimate_task_done"]}'
            )
            if isinstance(output["is_ultimate_task_done"], str):
                if output["is_ultimate_task_done"].lower() == "true":
                    output["is_ultimate_task_done"] = True
                elif output["is_ultimate_task_done"].lower() == "false":
                    output["is_ultimate_task_done"] = False
            else:
                raise ValueError(
                    f'Invalid is_ultimate_task_done: {output["is_ultimate_task_done"]}'
                )

        planner_output = output_model(**output, source=model_name)
        return planner_output
