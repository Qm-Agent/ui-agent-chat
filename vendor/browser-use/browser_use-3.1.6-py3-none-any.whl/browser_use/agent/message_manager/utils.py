from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any, Optional, Type, List, Union

from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)

from browser_use.utils import base64_to_image

logger = logging.getLogger(__name__)


def extract_json_from_model_output(content: str) -> dict:
    """Extract JSON from model output, handling both plain JSON and code-block-wrapped JSON."""
    try:
        # If content is wrapped in code blocks, extract just the JSON part
        if '```' in content:
            # Find the JSON content between code blocks
            content = content.split('```')[1]
            # Remove language identifier if present (e.g., 'json\n')
            if '\n' in content:
                content = content.split('\n', 1)[1]
        # Parse the cleaned content
        return json.loads(content)
    except json.JSONDecodeError as e:
        logger.warning(f'Failed to parse model output: {content} {str(e)}')
        raise ValueError('Could not parse response.')


def parse_response(response: Union[str, BaseMessage], syntax: Optional[str] = None):
    if isinstance(response, BaseMessage):
        response = response.content.strip()
    elif isinstance(response, str):
        response = response.strip()
    else:
        raise ValueError(f'Unknown response type: {type(response)}')

    if syntax is None:
        return response

    prefix = f"```{syntax}"
    suffix = "```"
    if prefix not in response:
        prefix = f"```"
    if prefix not in response:
        return response
    trimmed = response[response.index(prefix) + len(prefix):]
    if suffix not in trimmed:
        return trimmed
    trimmed = trimmed[:trimmed.index(suffix)]
    return trimmed


def _convert_messages_for_non_function_calling_models(input_messages: List[BaseMessage]) -> List[BaseMessage]:
    """Convert messages for non-function-calling models"""
    output_messages = []
    for message in input_messages:
        if isinstance(message, HumanMessage):
            output_messages.append(message)
        elif isinstance(message, SystemMessage):
            output_messages.append(message)
        elif isinstance(message, ToolMessage):
            output_messages.append(HumanMessage(content=message.content))
        elif isinstance(message, AIMessage):
            # check if tool_calls is a valid JSON object
            if message.tool_calls:
                tool_calls = json.dumps(message.tool_calls)
                output_messages.append(AIMessage(content=tool_calls))
            else:
                output_messages.append(message)
        else:
            raise ValueError(f'Unknown message type: {type(message)}')
    return output_messages


def save_conversation(
        input_messages: Union[List[BaseMessage], str],
        response: Any,
        target_dir: str,
        steps: Optional[int] = None,
        role: Optional[str] = None,
) -> Path:
    """Save conversation history to file."""

    # create folders if not exists
    target_dir = Path(target_dir)
    target_dir.mkdir(parents=True, exist_ok=True)

    target_name = f'conversation{f"_role-{role}" if role is not None else ""}{f"_step-{steps}" if steps is not None else ""}.md'
    target_path = target_dir / target_name
    export_input_messages_to_markdown(target_path, input_messages)
    export_response_to_markdown(target_path, response)

    return target_path


def export_input_messages_to_markdown(path: Path, messages: Union[List[BaseMessage], str]) -> None:
    """Write messages to conversation file"""
    with open(path, 'a', encoding="utf-8") as f:
        f.write(f'# Input\n')
        if isinstance(messages, str):
            f.write(messages)
        elif isinstance(messages, List):
            for mi, message in enumerate(messages):
                f.write(f'## {message.__class__.__name__}\n\n')

                if isinstance(message.content, list):
                    for ci, item in enumerate(message.content):
                        if isinstance(item, dict) and item.get('type') == 'text':
                            f.write(item['text'].strip().replace('\n', '\n\n') + '\n\n')
                        elif isinstance(item, dict) and item.get('type') == 'image_url':
                            image = base64_to_image(item['image_url']['url'])
                            dest = path.parent / f'{path.stem}_mi-{mi}_ci-{ci}.png'
                            image.save(dest)
                            f.write(f'![image]({dest.name})\n\n')
                elif isinstance(message.content, str):
                    f.write(message.content.replace('\n', '\n\n'))

                f.write('\n\n')


def export_response_to_markdown(path: Path, response: Any) -> None:
    """Write model response to conversation file"""
    with open(path, 'a', encoding="utf-8") as f:
        f.write('# RESPONSE\n')
        if isinstance(response, str):
            f.write(response)
        else:
            f.write(response.model_dump_json(exclude_unset=True))
