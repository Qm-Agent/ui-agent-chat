from __future__ import annotations

import logging
from typing import List, Optional

from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage

from browser_use.agent.prompts import ActorPrompt, AsserterPrompt, PlannerPrompt, WaitingPrompt
from browser_use.agent.views import AgentState
from browser_use.browser.context import BrowserContext
from browser_use.utils import encode_image_base64, time_execution_sync

logger = logging.getLogger(__name__)


class MessageManager:
    def __init__(
            self,
            agent_state: AgentState,
            browser_context: BrowserContext,
            actor_system_message: SystemMessage,
            include_attributes: Optional[List[str]] = None,
            actor_box_format: str = "tlbr",
            planner_box_format: str = "tlbr",
            asserter_box_format: str = "tlbr",
            locating_llm_box_format: str = "tlbr",
            react_mode: str = "legacy",
    ):
        self.agent_state = agent_state
        self.browser_context = browser_context
        self.include_attributes = include_attributes or []
        self.actor_system_prompt = actor_system_message
        self.actor_box_format = actor_box_format
        self.planner_box_format = planner_box_format
        self.asserter_box_format = asserter_box_format
        self.locating_llm_box_format = locating_llm_box_format
        self.react_mode = react_mode if react_mode == "enhanced" else "legacy"

    @property
    def enhanced_react_enabled(self) -> bool:
        return self.react_mode == "enhanced"

    @property
    def task_message(self) -> HumanMessage:
        if self.agent_state.current_command is None:
            raise ValueError("No task description provided")
        return HumanMessage(
            content=f'''Your ultimate task is: """{self.agent_state.resolved_cmd_description}""".
If you achieved your ultimate task, stop everything and use the done action in the next step to complete the task.
If not, continue as usual.
'''
        )

    @property
    def plan_message(self) -> HumanMessage:
        last_planner_output = self.agent_state.last_planner_output
        if last_planner_output is None:
            return HumanMessage(content="There is no plan from planner yet.")
        else:
            return HumanMessage(
                content=f'''This is the current plan in markdown format:
[Analysis of current situation]: {last_planner_output.state_analysis}
[Progress evaluation]: {last_planner_output.progress_evaluation}
[Plan reasoning]: {last_planner_output.reasoning}
[Plan in markdown]:
{last_planner_output.plan}
'''
            )

    @property
    def action_space_message(self) -> HumanMessage:
        action_space_description = "Available actions:\n" + "\n".join(
            [action.prompt_description() for action in self.agent_state.current_action_space]
        )
        return HumanMessage(content=action_space_description)

    @property
    def enhanced_planner_guidance_message(self) -> HumanMessage:
        return HumanMessage(
            content="""[Enhanced ReAct guidance]
Build a semantic model of the page before planning the next browser action:
- Identify the page type, the task's terminal condition, and the observable state that proves completion.
- Classify relevant controls by role: input, mode/toggle/filter, submit/commit/send, navigation, result/status.
- A mode/toggle/filter control changes how the page behaves; it is not the same as submitting or sending user input.
- If the task requires a generated result or saved state after entering text, plan an explicit commit action immediately after filling/configuring inputs: click a send/submit/confirm control or press Enter, then observe the result/status.
- On chat, search, question-answering, and composer-style pages, labels that describe a capability or mode (for example online search/tool toggles) usually configure behavior; after enabling them, still commit the typed input with a send/submit control or Enter.
- After a commit action was just performed, do not mark the task done until the result/status is visible; plan a wait/observe step first if the page is still responding.
- If the current page already has a direct primary action for the task (for example "new/create/add/import/upload"), use it instead of navigating to a broad parent menu. Do not click a parent menu label repeatedly when a task-relevant button is visible in the current content area.
- If the task provides a local file path and asks to upload/import/choose/select a file, plan to use the upload action after reaching the page step with the upload control. The OS file chooser may be invisible in screenshots; do not wait for it or try drag-and-drop unless upload is unavailable.
- If recent actions did not create task-relevant progress, change strategy instead of repeating the same semantic action."""
        )

    @property
    def enhanced_actor_guidance_message(self) -> HumanMessage:
        return HumanMessage(
            content="""[Enhanced ReAct action selection]
Before choosing an action, verify that the target element's semantic role matches the current plan:
- Use input controls only for entering text.
- Use mode/toggle/filter controls only to configure behavior; do not treat them as submit/send/confirm controls.
- When the page must produce an answer, save data, or complete a transaction, perform a commit action after filling/configuring inputs. Prefer a visible send/submit/confirm control; if none is clear, press Enter while the input is focused.
- If you have already entered text and a mode/toggle/filter click did not produce a result, do not repeat that click; commit the input instead.
- If you just performed a commit action and the page is still responding or no final result is visible yet, wait/observe before deciding success or failure.
- Prefer visible task-specific primary buttons in the main content area over broad navigation labels. For creation tasks, controls named like "新建", "创建", "添加", "导入", "上传", "New", "Create", or "Add" are usually more relevant than parent menu labels such as "管理".
- For local file upload tasks, use the upload action with the exact local file path from the task once the upload control exists on the page. Do not repeatedly click the upload area waiting for an OS file chooser, because the chooser is outside browser screenshots.
- Do not use the done action for intermediate milestones such as "page loaded", "input ready", or "waiting finished". Use done only when every requirement in the ultimate task is satisfied, or when the final allowed step is reached and the task must end as unsuccessful.
- If the last click/wait sequence produced no task-relevant progress, choose a different control or reassess the page instead of clicking the same kind of control again.
- Keep following the plan, but correct obvious role mismatches between the plan and the visible controls."""
        )

    def _format_action_signature(self, actions) -> str:
        names = []
        for action in actions:
            dumped = action.model_dump(exclude_unset=True)
            if dumped:
                names.append(next(iter(dumped.keys())))
        return " + ".join(names) if names else "no browser action"

    def build_enhanced_effect_summary_message(self) -> Optional[HumanMessage]:
        if not self.agent_state.executed_actions and not self.agent_state.results:
            return None

        lines = ["[Enhanced ReAct effect summary]"]
        last_actor_output = self.agent_state.last_actor_output
        if last_actor_output is not None and hasattr(last_actor_output, "current_state"):
            lines.append(f"Last action reasoning: {last_actor_output.current_state.reasoning}")
            lines.append(f"Expected outcome: {last_actor_output.current_state.expected_outcome}")

        if self.agent_state.last_executed_actions:
            lines.append(f"Last executed actions: {self.agent_state.last_executed_actions_description.strip()}")

        last_result = self.agent_state.last_result or []
        if last_result:
            result_notes = []
            for result in last_result:
                if result.error:
                    result_notes.append(f"error={result.error}")
                if result.extracted_content:
                    result_notes.append(f"content={result.extracted_content[:300]}")
                if result.is_done:
                    result_notes.append(f"is_done={result.is_done}")
                if result.success is not None:
                    result_notes.append(f"success={result.success}")
            if result_notes:
                lines.append("Last action results: " + " | ".join(result_notes))

        if len(self.agent_state.executed_actions) >= 4:
            recent = self.agent_state.executed_actions[-4:]
            signatures = [self._format_action_signature(actions) for actions in recent]
            unique_signatures = set(signatures)
            if len(unique_signatures) <= 2 and any("click" in sig for sig in signatures):
                lines.append(
                    "Recent pattern suggests a possible click/wait loop with little progress: "
                    + " -> ".join(signatures)
                )
                lines.append(
                    "Planner should reassess control roles and pick a different commit/navigation/observe strategy."
                )
                lines.append(
                    "If a visible main-content button directly matches the task, prefer it over repeating parent menu navigation."
                )

        recent_signatures = [
            self._format_action_signature(actions)
            for actions in self.agent_state.executed_actions[-6:]
        ]
        recent_text = " -> ".join(recent_signatures)
        if "input_text" in recent_text and "send_keys" not in recent_text:
            click_count = recent_text.count("click")
            wait_count = recent_text.count("wait")
            if click_count + wait_count >= 2:
                lines.append(
                    "Typed input exists but recent actions have not clearly committed it. "
                    "Prefer a send/submit/confirm control or press Enter before more toggle clicks or waits."
                )
        if recent_signatures and "send_keys" in recent_signatures[-1]:
            lines.append(
                "A keyboard commit action was just performed. The next step should wait/observe for the result "
                "unless the final answer/status is already visible."
            )

        if len(lines) == 1:
            return None
        return HumanMessage(content="\n".join(lines))

    @time_execution_sync('--build_actor_input_messages')
    async def build_actor_input_messages(self) -> List[BaseMessage]:
        browser_state = await self.browser_context.get_state()
        msg = [
            self.actor_system_prompt,
            self.action_space_message,
            self.plan_message,
        ]
        if self.enhanced_react_enabled:
            msg.append(self.enhanced_actor_guidance_message)
            effect_summary = self.build_enhanced_effect_summary_message()
            if effect_summary:
                msg.append(effect_summary)
        msg.append(
            ActorPrompt(
                browser_state,
                include_attributes=self.include_attributes,
                include_offscreen_elements=False,
            ).get_user_message(box_format=self.actor_box_format)
        )

        return msg

    @time_execution_sync('--build_planner_input_messages')
    async def build_planner_input_messages(self) -> List[BaseMessage]:
        planner_messages = [
            PlannerPrompt.get_system_message(box_format=self.planner_box_format),
        ]

        if self.agent_state.last_planner_output:
            plan_of_last_react_loop = self.agent_state.last_planner_output.plan
        else:
            plan_of_last_react_loop = 'No plan yet'

        task_message = HumanMessage(
            content=f'''
Your ultimate task is: """{self.agent_state.resolved_cmd_description}""".
This is the plan of last episode in markdown format:
{plan_of_last_react_loop}\n
'''
        )
        planner_messages.append(task_message)

        if self.enhanced_react_enabled:
            planner_messages.append(self.enhanced_planner_guidance_message)

        # if this step is the first step of this episode, then we don't need to include the last actions
        # and if this step is not the first step of this episode, then we need to include screenshot before last actions
        if self.agent_state.last_planner_output:
            last_actions_message = self.agent_state.format_last_actor_loop_results_for_planner()
            planner_messages.append(HumanMessage(content=last_actions_message))

            if self.agent_state.last_screenshot_before_actions:
                screenshot_before_last_actions_message = HumanMessage(
                    content=[
                        {
                            "type": "text",
                            "text": "\n[Screenshot before last action]\n"
                        },
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": (
                                    f"data:image/png;base64,"
                                    f"{encode_image_base64(self.agent_state.last_screenshot_before_actions)}"
                                ),
                            }
                        },
                    ]
                )
                planner_messages.append(screenshot_before_last_actions_message)

        # 检测重复操作并注入警告
        repeated_warning = self.agent_state.detect_repeated_actions(window=3)
        if repeated_warning:
            planner_messages.append(HumanMessage(
                content=(
                    f"⚠️ STUCK DETECTION: {repeated_warning}\n"
                    "You MUST change your strategy. Consider:\n"
                    "- The element might not be clickable at the matched position. "
                    "Try a different description or approach.\n"
                    "- Try scrolling to reveal the element better.\n"
                    "- Try using a different action \n"
                    "- Check if a popup/modal is blocking the element.\n"
                    "DO NOT repeat the same action again."
                )
            ))

        if self.enhanced_react_enabled:
            effect_summary = self.build_enhanced_effect_summary_message()
            if effect_summary:
                planner_messages.append(effect_summary)

        # add current screenshot to input messages
        browser_state = await self.browser_context.get_state()
        state_content = [
            {
                "type": "text",
                "text": (
                    "[Current screenshot / Screenshot after last action]:\n"
                    "The HTML elements related to the action were highlighted with bounding boxes "
                    "and the sequence numbers displayed in the top-left corner of the boxes.\n"
                )
            },
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/png;base64,{browser_state.screenshot}"
                }
            },
        ]

        state_message = HumanMessage(content=state_content)
        planner_messages.append(state_message)
        # repeat task message to remind the planner
        planner_messages.append(task_message)

        return planner_messages

    @time_execution_sync('--build_waiting_input_messages')
    async def build_waiting_input_messages(self) -> List[BaseMessage]:
        system_message = WaitingPrompt.get_system_message(box_format=self.actor_box_format)
        target_message = HumanMessage(
            content=f'''The waiting target is: """{self.agent_state.resolved_cmd_description}""".\n\n'''
        )

        browser_state = await self.browser_context.get_state()

        waiting_input_messages = [
            system_message,
            target_message,
            self.action_space_message,
            ActorPrompt(
                browser_state,
                include_attributes=self.include_attributes,
                include_offscreen_elements=False,
            ).get_user_message(box_format=self.actor_box_format),
        ]
        return waiting_input_messages

    @time_execution_sync('--build_assertion_input_messages')
    async def build_asserter_input_messages(self) -> List[BaseMessage]:
        browser_state = await self.browser_context.get_state()
        system_message = AsserterPrompt.get_system_message(box_format=self.asserter_box_format)
        expectation_message = HumanMessage(
            content=f'''The assertion target is: """{self.agent_state.resolved_cmd_description}""".\n\n'''
        )

        assertion_messages = [
            system_message,
            expectation_message,
        ]

        page_description = browser_state.build_page_description(
            include_attributes=self.include_attributes,
            include_offscreen_elements=False,
            box_format=self.asserter_box_format,
        )
        state_content = [
            {
                "type": "text",
                "text": f"Here is current browser state, including screenshots and website content."
                        f"[Page description]:\n {page_description}"
            },
        ]

        state_content.extend(
            [
                {
                    "type": "text",
                    "text": (
                        "[Current screenshot]:\n"
                        "The HTML elements related to the action were highlighted with bounding boxes "
                        "and the sequence numbers displayed in the top-left corner of the boxes.\n"
                    )
                },
                {
                    "type": "image_url",
                    "image_url": {
                        "url": f"data:image/png;base64,{browser_state.screenshot}"
                    }
                },
            ]
        )

        state_message = HumanMessage(content=state_content)
        assertion_messages.append(state_message)
        return assertion_messages
