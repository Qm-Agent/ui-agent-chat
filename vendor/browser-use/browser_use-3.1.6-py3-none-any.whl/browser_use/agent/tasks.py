# -*- coding: utf-8 -*-
# Author: Yichen Lu
# Time: 2025/8/7

import json
import logging
import os
from pathlib import Path
from typing import Any, ClassVar, Dict, List, Optional, Set, Tuple, Union

import yaml
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from browser_use.utils import VARIABLE_PATTERN, get_polymorphic_type, replace_variable_placeholders_in_string

logger = logging.getLogger(__name__)


CMD_CONFIG_REGISTRY = {}


def convert_dict_list_into_command_configs(list_of_cmd_dict: List[Dict[str, Any]]):
    command_configs = []
    for cmd_dict in list_of_cmd_dict:
        key = next(k for k in cmd_dict.keys())
        cmd_cls = CMD_CONFIG_REGISTRY[key]
        if key != cmd_cls.type:
            logger.warning(f'Command type "{key}" is an alias of "{cmd_cls.type}", please use "{cmd_cls.type}" instead.')
            cmd_dict[cmd_cls.type] = cmd_dict.pop(key)
        command_configs.append(cmd_cls(**cmd_dict))
    return command_configs


class BaseCommandConfig(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True, extra="allow")
    type: ClassVar[str] = ""
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    cache: Optional[List[Dict[str, Any]]] = Field(default=None, exclude=True)

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        CMD_CONFIG_REGISTRY[cls.type] = cls
        if cls.alias:
            if isinstance(cls.alias, str):
                CMD_CONFIG_REGISTRY[cls.alias] = cls
            elif isinstance(cls.alias, (List, Tuple)):
                for alias in cls.alias:
                    CMD_CONFIG_REGISTRY[alias] = cls
            else:
                raise ValueError(f"alias must be str or list or tuple, but got {type(cls.alias)}")

    @model_validator(mode="before")
    def warn_on_unknown_fields(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(data, Dict):
            return data

        declared = [
            field_info.alias if field_info.alias else field_name
            for field_name, field_info in cls.model_fields.items()
        ]

        for key in data:
            if key not in declared:
                logger.warning(f"{cls.__name__} receive unexpected key: '{key}', and it will not take effect. "
                               f"{cls.__name__} supported keys are: {declared}")
        return data

    @property
    def argument(self) -> str:
        return ""

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        return "EMPTY or initialization actions"


class UseConfig(BaseCommandConfig):
    type: ClassVar[str] = "use"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    use: str

    @property
    def argument(self) -> str:
        return self.use

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        return f'Use module "{self.use}"'


class AiTapConfig(BaseCommandConfig):
    type: ClassVar[str] = "aiTap"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    aiTap: str
    locate: Optional[str] = None

    @property
    def argument(self) -> str:
        return self.aiTap

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        if not self.locate:
            return f'[点击] {self.aiTap}'
        elif isinstance(self.locate, str):
            return f'[点击] 位于 {self.locate} 的 {self.aiTap}'
        else:
            raise ValueError(f"locate must be str, but got {type(self.locate)}")


class AiWaitForConfig(BaseCommandConfig):
    type: ClassVar[str] = "aiWaitFor"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    aiWaitFor: str
    # 默认 120s，便于「页面加载完成」等场景在跳转后充分加载
    timeout: Optional[int] = 120_000

    @property
    def argument(self) -> str:
        return self.aiWaitFor

    @property
    def config(self) -> Dict:
        return {"timeout": self.timeout}

    @property
    def description(self) -> str:
        return f"[等待] 直至 {self.aiWaitFor}"


class AiAssertConfig(BaseCommandConfig):
    type: ClassVar[str] = "aiAssert"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    aiAssert: str

    @property
    def argument(self) -> str:
        return self.aiAssert

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        return f"[断言] {self.aiAssert}"


class AiAssertTextConfig(BaseCommandConfig):
    type: ClassVar[str] = "aiAssertText"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    aiAssertText: str

    @property
    def argument(self) -> str:
        return self.aiAssertText

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        return f'[断言] 页面出现字符串 "{self.aiAssertText}"'


class AssertTextConfig(BaseCommandConfig):
    type: ClassVar[str] = "assertText"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    assertText: str

    @property
    def argument(self) -> str:
        return self.assertText

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        return f'[断言] 页面出现字符串 "{self.assertText}"'


class WaitForTextConfig(BaseCommandConfig):
    type: ClassVar[str] = "waitForText"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    waitForText: str
    timeout: Optional[int] = 30_000
    interval: Optional[int] = 5_000

    @property
    def argument(self) -> str:
        return self.waitForText

    @property
    def config(self) -> Dict:
        return {"timeout": self.timeout}

    @property
    def description(self) -> str:
        return f'[断言] 页面出现字符串 "{self.waitForText}"'


class AiInputConfig(BaseCommandConfig):
    type: ClassVar[str] = "aiInput"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    aiInput: str
    locate: Optional[str] = None

    @property
    def argument(self) -> str:
        return self.aiInput

    @property
    def config(self) -> Dict:
        return {"locate": self.locate}

    @property
    def description(self) -> str:
        if not self.locate:
            return f'[输入] {self.aiInput}'
        elif isinstance(self.locate, str):
            return f'[输入] 在 {self.locate} 中输入 "{self.aiInput}"'
        else:
            raise ValueError(f"locate must be str, but got {type(self.locate)}")


class AiScrollConfig(BaseCommandConfig):
    type: ClassVar[str] = "aiScroll"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    aiScroll: str

    @property
    def argument(self) -> str:
        return self.aiScroll

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        return f'[滚动] {self.aiScroll}'


class SleepConfig(BaseCommandConfig):
    type: ClassVar[str] = "sleep"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    sleep: int

    @property
    def argument(self) -> int:
        return self.sleep

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        return f'[等待] {self.sleep} 毫秒'


class GoToConfig(BaseCommandConfig):
    type: ClassVar[str] = "goTo"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = "goto"

    goTo: str

    @property
    def argument(self) -> str:
        return self.goTo

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        return f'[跳转] 至 {self.goTo}'


class AiHoverConfig(BaseCommandConfig):
    type: ClassVar[str] = "aiHover"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    aiHover: str
    locate: Optional[str] = None

    @property
    def argument(self) -> str:
        return self.aiHover

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        if not self.locate:
            return f'[悬停] {self.aiHover}'
        elif isinstance(self.locate, str):
            return f'[悬停] 在位于 {self.locate} 的元素 {self.aiHover} 上'
        else:
            raise ValueError(f"locate must be str, but got {type(self.locate)}")


class AiSendKeysConfig(BaseCommandConfig):
    type: ClassVar[str] = "aiSendKeys"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = "aiKeyboardPress"

    aiSendKeys: str

    @property
    def argument(self) -> str:
        return self.aiSendKeys

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        return f'[键盘输入] {self.aiSendKeys}'


class ScrollToTextConfig(BaseCommandConfig):
    type: ClassVar[str] = "scrollToText"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = "scroll_to_text"

    scrollToText: str

    @property
    def argument(self) -> str:
        return self.scrollToText

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        return f'[滚动] 至 {self.scrollToText}'


class UploadConfig(BaseCommandConfig):
    type: ClassVar[str] = "upload"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = "Upload"

    upload: str
    locate: Optional[str] = None
    upload_index: Optional[int] = None

    @property
    def argument(self) -> str:
        return self.upload

    @property
    def config(self) -> Dict:
        d: Dict[str, Any] = {}
        if self.locate is not None:
            d["locate"] = self.locate
        if self.upload_index is not None:
            d["upload_index"] = self.upload_index
        return d

    @property
    def description(self) -> str:
        if self.locate and self.upload_index is not None:
            return f'上传文件 {self.upload}（控件: {self.locate}，第 {self.upload_index} 个）'
        if self.locate:
            return f'上传文件 {self.upload}（控件: {self.locate}）'
        if self.upload_index is not None:
            return f'上传文件 {self.upload}（第 {self.upload_index} 个 file 入口）'
        return f'上传文件 {self.upload}'


class JsCodeConfig(BaseCommandConfig):
    type: ClassVar[str] = "jsCode"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    jsCode: str

    @property
    def argument(self) -> str:
        return self.jsCode

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        return f'[执行JavaScript代码] {self.jsCode}'


class PyCodeConfig(BaseCommandConfig):
    type: ClassVar[str] = "pyCode"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    pyCode: str

    @property
    def argument(self) -> str:
        return self.pyCode

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        return f'[执行Python代码] {self.pyCode}'


class ToolCallConfig(BaseCommandConfig):
    type: ClassVar[str] = "toolCall"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    toolCall: str
    args: Dict[str, Any] = Field(default_factory=dict)
    name: Optional[str] = None  # 将工具返回值写入该名称，供后续步骤 ${name} 引用

    @property
    def argument(self) -> str:
        return self.toolCall

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        return f'[工具调用] {self.toolCall}'


class AiQueryConfig(BaseCommandConfig):
    type: ClassVar[str] = "aiQuery"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    aiQuery: str
    name: Optional[str] = None  # 将本步返回值写入该名称，供后续步骤 ${name} 引用

    @property
    def argument(self) -> str:
        return self.aiQuery

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        return f'[提取内容] {self.aiQuery}'


class AiActionConfig(BaseCommandConfig):
    type: ClassVar[str] = "aiAction"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    aiAction: str
    locate: Optional[str] = None

    @property
    def argument(self) -> str:
        return self.aiAction

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        if not self.locate:
            return f'[执行] {self.aiAction}'
        elif isinstance(self.locate, str):
            return f'[执行] 对位于 {self.locate} 的元素执行 {self.aiAction}'
        else:
            raise ValueError(f"locate must be str, but got {type(self.locate)}")


class AiConfig(BaseCommandConfig):
    type: ClassVar[str] = "ai"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = ["aiReAct", "aiReact"]

    ai: str

    @property
    def argument(self) -> str:
        return self.ai

    @property
    def config(self) -> Dict:
        return {}

    @property
    def description(self) -> str:
        return self.ai


class AiQuickConfig(BaseCommandConfig):
    type: ClassVar[str] = "aiQuick"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    aiQuick: str
    url: Optional[str] = None
    resume: bool = True
    maxSteps: Optional[int] = None

    @property
    def argument(self) -> str:
        return self.aiQuick

    @property
    def config(self) -> Dict:
        return {
            "url": self.url,
            "resume": self.resume,
            "maxSteps": self.maxSteps,
        }

    @property
    def description(self) -> str:
        return self.aiQuick


CommandConfigType = get_polymorphic_type(BaseCommandConfig)


class IfConfig(BaseCommandConfig):
    type: ClassVar[str] = "if"
    alias: ClassVar[Union[str, List[str], Tuple[str]]] = None

    model_config = ConfigDict(populate_by_name=True)

    if_: CommandConfigType = Field(alias="if", default_factory=BaseCommandConfig)
    then: List[CommandConfigType] = Field(default_factory=list)
    else_: List[CommandConfigType] = Field(alias="else", default_factory=list)

    @field_validator("then", "else_", mode="before")
    def convert_then_else(cls, v: Any):
        if isinstance(v, list):
            return convert_dict_list_into_command_configs(v)
        return v

    @field_validator("if_", mode="before")
    def convert_if_field(cls, v: Any):
        if isinstance(v, dict):
            key = next(iter(v.keys()))
            cmd_cls = CMD_CONFIG_REGISTRY[key]
            return cmd_cls(**v)
        return v

    @property
    def argument(self) -> BaseCommandConfig:
        return self.if_

    @property
    def config(self) -> Dict:
        return {
            "then": self.then,
            "else": self.else_,
        }

    @property
    def description(self) -> str:
        return f"""
[if]: {self.if_.description}
[then]: {[cmd.description for cmd in self.then]}
[else]: {[cmd.description for cmd in self.else_]}'
"""


IfConfig.model_rebuild()


# TargetConfig intentionally has no tools field — tool infrastructure is framework-internal.
# Built-in tools are auto-discovered from browser_use/agent/tools/builtin/ at import time.
class TargetConfig(BaseModel):
    url: str = "about:blank"
    viewportWidth: int = 1496
    viewportHeight: int = 818
    # Cookie: file path to JSON array, or inline JSON string (e.g. '[{"name":"...","value":"...",...}]')
    cookie: Optional[str] = None


class TaskConfig(BaseModel):
    name: str = ""
    flow: List[BaseCommandConfig] = Field(default_factory=list)

    @model_validator(mode="before")
    def _convert_flow(cls, kvs):
        if not isinstance(kvs, Dict):
            return kvs
        raw_flow = kvs.get("flow", [])
        kvs["flow"] = convert_dict_list_into_command_configs(raw_flow)
        return kvs


class ImportConfig(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    from_: str = Field(alias="from")
    modules: List[str] = Field(default_factory=list)


class TasksConfig(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    target: TargetConfig = Field(default_factory=TargetConfig)
    tasks: List[TaskConfig] = Field(default_factory=list)
    import_: List[ImportConfig] = Field(alias="import", default_factory=list)


class Tasks(object):
    def __init__(
            self,
            task: str = None,
            task_yaml_path: Union[Path, str] = None,
            dump_config_dir: Optional[Union[Path, str]] = None,
            cache_path: Optional[Union[Path, str]] = None,
            extra_sensitive_variables: Optional[List[str]] = None,
    ):
        assert (task is not None and task_yaml_path is None) or (task is None and task_yaml_path is not None), \
            "Either task or task_yaml_path should be provided."
        self.task = task
        self.task_yaml_path = task_yaml_path
        self.dump_config_dir = dump_config_dir
        self.cache_path = cache_path
        self.cache = None
        self.extra_sensitive_variables = extra_sensitive_variables or []
        self.modules: Dict[str, TaskConfig] = {}
        self.imported_command_indices: Set = set()

        if self.task_yaml_path is not None:
            with open(self.task_yaml_path, "r", encoding="utf-8") as f:
                tasks_config = yaml.safe_load(f)
                self.tasks_config = TasksConfig(**tasks_config, from_=self.task_yaml_path)
        else:
            self.tasks_config = TasksConfig(
                tasks=[
                    TaskConfig(
                        flow=[{"aiReAct": task}]
                    )
                ],
                from_="task"
            )
        self.tasks_config: TasksConfig = self.replace_variable_placeholders_with_env_variables()

        # expand imported task
        self.merge_imports_into_tasks_config()

        # load cache
        self.load_cache()

        # dump config
        if self.dump_config_dir is not None:
            dump_config_path = Path(self.dump_config_dir) / "task_config.yaml"
            with open(dump_config_path, 'w', encoding="utf-8") as file:
                yaml.dump(
                    self.tasks_config.model_dump(by_alias=True),
                    file,
                    allow_unicode=True,
                    default_flow_style=False,
                )

    def __iter__(self):
        for _task_index, _task in enumerate(self.tasks_config.tasks):
            yield _task_index, _task

    def build_task_iterator(self):
        for _task_index, _task in enumerate(self.tasks_config.tasks):
            yield _task_index, _task

    def replace_variable_placeholders_with_env_variables(self):
        sensitive_variables_from_env = os.getenv("SENSITIVE_VARIABLES", "")
        sensitive_variables_from_env = sensitive_variables_from_env.split(",") + self.extra_sensitive_variables
        sensitive_variables: Set[str] = set(sensitive_variables_from_env) or set()
        logger.info(f"Load sensitive variables from env: {sensitive_variables_from_env}")
        if self.extra_sensitive_variables:
            logger.info(f"Load sensitive variables from argument: {self.extra_sensitive_variables}")
            for variable in self.extra_sensitive_variables:
                if variable not in sensitive_variables:
                    sensitive_variables.add(variable)
            logger.info(f"Final sensitive variables: {sensitive_variables}")

        # 仅替换 env 中存在的变量；不在 env 的占位符（如 ${num}）保留，由运行时 named_results 替换
        def replace_variable_placeholders_in_object(_object: Union[str, Dict, List, BaseModel]):
            if isinstance(_object, str):
                _object = replace_variable_placeholders_in_string(
                    _object, VARIABLE_PATTERN, sensitive_variables, keep_if_missing=True
                )
            elif isinstance(_object, Dict):
                for _key, _value in _object.items():
                    _object[_key] = replace_variable_placeholders_in_object(_value)
            elif isinstance(_object, List):
                for _index, _value in enumerate(_object):
                    _object[_index] = replace_variable_placeholders_in_object(_value)
            elif isinstance(_object, BaseModel):
                for _field_name in _object.model_fields.keys():
                    _field_value = getattr(_object, _field_name)
                    setattr(_object, _field_name, replace_variable_placeholders_in_object(_field_value))

                if _object.model_extra:
                    for _field_name in _object.model_extra.keys():
                        _field_value = getattr(_object, _field_name)
                        setattr(_object, _field_name, replace_variable_placeholders_in_object(_field_value))

            elif isinstance(_object, (int, float, bool)) or _object is None:
                pass
            else:
                raise TypeError(f"Unsupported type: {type(_object)}")
            return _object

        return replace_variable_placeholders_in_object(self.tasks_config)

    def get_task_config_by_name(self, task_name: str) -> Optional[TaskConfig]:
        for _task_config in self.tasks_config.tasks:
            if _task_config.name == task_name:
                return _task_config
        return None

    def merge_imports_into_tasks_config(self):
        import_config = self.tasks_config.import_
        for _import in import_config:
            _config_path = Path(_import.from_)
            _cache_path = None
            if (_config_path.parent / "result.json").exists():
                _cache_path = _config_path.parent / "result.json"

            sub_tasks_config = Tasks(task_yaml_path=_config_path, cache_path=_cache_path)
            for _module in _import.modules:
                sub_task_config: TaskConfig = sub_tasks_config.get_task_config_by_name(_module)
                if sub_task_config is None:
                    raise ValueError(f"Module {_module} not found in {_config_path}")
                self.modules[_module] = sub_task_config

        # expand sub-tasks in task flows
        for task_index, task_config in enumerate(self.tasks_config.tasks):
            expanded_flow = []
            for cmd_config in task_config.flow:
                if isinstance(cmd_config, UseConfig):
                    module_name = cmd_config.argument
                    for imported_cmd_config in self.modules[module_name].flow:
                        expanded_flow.append(imported_cmd_config)
                        self.imported_command_indices.add((task_index, len(expanded_flow) - 1))
                else:
                    expanded_flow.append(cmd_config)
            task_config.flow = expanded_flow

    def load_cache(self):
        # load cache
        if not self.cache_path:
            return

        with open(self.cache_path, "r", encoding="utf-8") as file:
            data = json.load(file)
            if "history" not in data:
                logger.warning(f"No cache found in {self.cache_path}, skip loading cache.")
                return
            self.cache = data["history"]

        for cache_index, cache_data in enumerate(self.cache):
            if (
                "metadata" not in cache_data
                or "cmd_state" not in cache_data["metadata"]
                or "task_index" not in cache_data["metadata"]["cmd_state"]
                or "cmd_index" not in cache_data["metadata"]["cmd_state"]
            ):
                logger.warning(f"Invalid cache data (index: {cache_index}), skip loading command cache.")
                continue

            task_index = cache_data["metadata"]["cmd_state"]["task_index"]
            cmd_index = cache_data["metadata"]["cmd_state"]["cmd_index"]
            if not isinstance(task_index, int) or not isinstance(cmd_index, int):
                # initial actions should be ignored
                continue

            if (
                "command" in cache_data["metadata"]["cmd_state"]
                and isinstance(cache_data["metadata"]["cmd_state"]["command"], Dict)
                and "if" in cache_data["metadata"]["cmd_state"]["command"]
            ):
                continue

            # validate command consistency
            if (
                "command" in cache_data["metadata"]["cmd_state"]
                and isinstance(cache_data["metadata"]["cmd_state"]["command"], Dict)
            ):
                cached_command_keys = cache_data["metadata"]["cmd_state"]["command"].keys()
                command_keys = set(cached_command_keys).intersection(set(CMD_CONFIG_REGISTRY.keys()))
                if len(command_keys) != 1:
                    logger.warning(f"Multiple command in cache: {command_keys}, skip loading command cache.")
                    continue
                command_key = list(command_keys)[0]
                cached_argument = cache_data["metadata"]["cmd_state"]["command"][command_key]
                argument = self.tasks_config.tasks[task_index].flow[cmd_index].argument
                if cached_argument != argument:
                    logger.warning(
                        f"Command argument mismatch, "
                        f"cached argument: {cached_argument}, argument: {argument}"
                        f"skip loading command cache."
                    )
                    continue

            if self.tasks_config.tasks[task_index].flow[cmd_index].cache is None:
                self.tasks_config.tasks[task_index].flow[cmd_index].cache = []
            self.tasks_config.tasks[task_index].flow[cmd_index].cache.append(cache_data)
        logger.info(f"Loaded cache from {self.cache_path}")


if __name__ == '__main__':
    tasks = Tasks(
        task_yaml_path="browser_use/static/tasks/知识工程/"
        "knowledgeProcessing/03.功能-核心全流程-新建文档知识库-添加文件等.yaml"
    )
    print(tasks)
    # for task in tasks:
    #     print(task)
    # d = {
    #     'from_': 'logs/知识工程-login/task_config.yaml',
    #     'modules': ['登录'],
    # }
    # print(ImportConfig(**d).from_)

    # BaseCommandConfig(**{"description": "登录", "timeout": 10})
