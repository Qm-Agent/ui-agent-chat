import datetime
import importlib.resources
from datetime import datetime
from typing import List, Optional

from langchain_core.messages import HumanMessage, SystemMessage

from browser_use.browser.views import BrowserState
from browser_use.utils import box_format_to_box_format_prompt


class SystemPrompt:
    def __init__(
            self,
            max_actions_per_step: int = 10,
            override_system_message: Optional[str] = None,
            box_format: str = "tlbr",
    ):
        self.max_actions_per_step = max_actions_per_step
        box_format_prompt = box_format_to_box_format_prompt(box_format)

        if override_system_message:
            prompt = override_system_message
        else:
            self._load_prompt_template()
            prompt = self.prompt_template.format(max_actions=self.max_actions_per_step, box_format=box_format_prompt)

        self.system_message = SystemMessage(content=prompt)

    def _load_prompt_template(self) -> None:
        """Load the prompt template from the markdown file."""
        try:
            # This works both in development and when installed as a package
            with importlib.resources.files('browser_use.agent').joinpath('system_prompt.md').open('r') as f:
                self.prompt_template = f.read()
        except Exception as e:
            raise RuntimeError(f'Failed to load system prompt template: {e}')

    def get_system_message(self) -> SystemMessage:
        """
        Get the system prompt for the agent.

        Returns:
            SystemMessage: Formatted system prompt
        """
        return self.system_message


class ActorPrompt:
    def __init__(
            self,
            state: 'BrowserState',
            include_attributes: Optional[List[str]] = None,
            include_offscreen_elements: bool = True,
    ):
        if include_attributes is None:
            include_attributes = []
        self.state = state
        self.include_attributes = include_attributes
        self.include_offscreen_elements = include_offscreen_elements

    def get_user_message(self, box_format: str = "tlbr") -> HumanMessage:
        content = []
        web_description = self.state.build_page_description(
            include_attributes=self.include_attributes,
            include_offscreen_elements=self.include_offscreen_elements,
            box_format=box_format,
        )

        state_description = f"""
[Current state starts here]
Current date and time: {datetime.now().strftime('%Y-%m-%d %H:%M')}
Current url: {self.state.url}
Available tabs:
{self.state.tabs}
Interactive elements from top layer of the current page inside the viewport:
{web_description}
"""

        if self.state.dom_tree_screenshot:
            state_description += """
The screenshot below contains the bounding boxes and labels of interactive
elements that have been found on the page:
"""
            content.extend(
                [
                    {'type': 'text', 'text': state_description},
                    {
                        'type': 'image_url',
                        'image_url': {'url': f'data:image/png;base64,{self.state.dom_tree_screenshot}'},
                    }
                ]
            )
        else:
            content.append(
                {'type': 'text', 'text': state_description}
            )

        if self.state.scrollable_elements:
            scrollable_description = f"""
[On-screen scrollable elements start]
{self.state.scrollable_elements.scrollable_elements_to_string(
    height=self.state.page_height,
    width=self.state.page_width,
    box_format=box_format,
)}
[On-screen scrollable elements end]
"""

            if self.state.scrollable_elements_screenshot:
                scrollable_description += """
The screenshot below contains the bounding boxes and labels of scrollable " \
elements that have been found on the page:
"""
                content.extend(
                    [
                        {'type': 'text', 'text': scrollable_description},
                        {
                            'type': 'image_url',
                            'image_url': {'url': f'data:image/png;base64,{self.state.scrollable_elements_screenshot}'},
                        }
                    ]
                )
            else:
                content.append(
                    {'type': 'text', 'text': scrollable_description}
                )

        return HumanMessage(content=content)


class AsserterPrompt(object):
    @classmethod
    def get_system_message(cls, box_format: str = "tlbr") -> SystemMessage:
        box_format_prompt = box_format_to_box_format_prompt(box_format)
        return SystemMessage(
            content=f"""You are an assertion agent. Your responsibility is to determine if the current state meets the given expectation. The current state includes a simplified DOM description and a screenshot of the current page. The DOM description includes On-screen Elements, Off-screen or obscured Elements, and Scrollable Elements, with the following format:

**On-screen Elements**
`[index]<type>text</type>   {{"box_2d": {box_format_prompt}}}`
- **index**: Numeric identifier for interaction
- **type**: HTML element type (button, input, etc.)
- **text**: Element description
- **box_2d**: The bounding box of the element is given if this element is visible on the page. NOTE THAT the format of box_2d is **{box_format_prompt}**
Example:
`[33]<button>Submit Form</button>   {{"box_2d": [100, 50, 150, 200]}}`

**Off-screen or obscured Elements**
`text`

**Scrollable Elements**
`[index]<type> </type>   {{"box_2d": {box_format_prompt}, "visible_height": float, "visible_width": float, "vertical_scrollable": bool, "horizontal_scrollable": bool}}`
- **index**: Numeric identifier for scrolling interaction
- **type**: HTML element type (div, etc.)
- **box_2d**: Bounding box of the element. NOTE THAT the format of box_2d is **{box_format_prompt}**
- **vertical_scrollable** and **horizontal_scrollable**: Whether the element can be scrolled vertically or horizontally.

Your output format should always be a JSON object with the following fields:
{{
    "reasoning": "A brief analysis of the current state and the reasons for the assertion.",
    "related_element_description": "The detailed description of the most assertion-related element. The description includes what it looks like and default text within the element if any), the position of input field on the page, its relative position to other elements."
    "assertion": "<True or False>"
}}
"""
        )


class WaitingPrompt(object):
    @classmethod
    def get_system_message(cls, box_format: str = "tlbr") -> SystemMessage:
        box_format_prompt = box_format_to_box_format_prompt(box_format)
        return SystemMessage(
            content=f"""You are a component of a browser control agent. Your primary responsibility is to determine whether the agent should wait for a certain target. Your requirements are as follows:
1. The input waiting target is typically in the format "等待 <waiting target>".
2. You must assess the browser's current state to determine if this target has been met, and then issue a command indicating whether to continue waiting.
3. You can only output two commands: "wait" and "done". If the agent should keep waiting, yield "wait" command, and if the target has been met, yield "done" command. Do not output any other command types.
4. Maintain a high threshold for completion. Never yield "done" based on loose speculation or the likelihood of completion.
 
The current state includes a simplified DOM description and a screenshot of the current page. The DOM description includes On-screen Elements, Off-screen or obscured Elements, and Scrollable Elements, with the following format:

**On-screen Elements**
`[index]<type>text</type>   {{"box_2d": {box_format_prompt}}}`
- **index**: Numeric identifier for interaction
- **type**: HTML element type (button, input, etc.)
- **text**: Element description
- **box_2d**: The bounding box of the element is given if this element is visible on the page. NOTE THAT the format of box_2d is **{box_format_prompt}**
Example:
`[33]<button>Submit Form</button>   {{"box_2d": [100, 50, 150, 200]}}`

**Off-screen or obscured Elements**
`text`

**Scrollable Elements**
`[index]<type> </type>   {{"box_2d": {box_format_prompt}, "visible_height": float, "visible_width": float, "vertical_scrollable": bool, "horizontal_scrollable": bool}}`
- **index**: Numeric identifier for scrolling interaction
- **type**: HTML element type (div, etc.)
- **box_2d**: Bounding box of the element. NOTE THAT the format of box_2d is **{box_format_prompt}**
- **vertical_scrollable** and **horizontal_scrollable**: Whether the element can be scrolled vertically or horizontally.

Your output format should always be a JSON object with the following fields:
{{
    "reasoning": "A brief analysis of the current state and the reasons for the command.",
    "action": {{"<wait or done>": {{ <action-specific parameter> }}}}
}}
"""
        )


class PlannerPrompt(object):
    @classmethod
    def get_system_message(cls, box_format: str = "tlbr") -> SystemMessage:
        return SystemMessage(
            content="""You are a planning agent that helps break down tasks into smaller steps and reason about the current state.
Your role is to:
1. Analyze the current state and history
2. Evaluate progress towards the ultimate task
3. Plan should be as granular as possible, with browser actions as the atomic unit
4. Create a plan or modify the current plan with last browser actions provided. Specially,
    4.1 NOTE THAT if last browser actions only completed part of a certain todo, you should divide the todo into todos and mark the completed parts as completed.
    4.2 DO NOT check-off todos that have not been completely done in the last browser actions.
    4.3 if something unexpected happened, you are free to deal with it and modify the plan accordingly.
    4.4 each todo should have a distinct purpose.
5. You are a part of the agent system, the overall task is actually given and fixed. So ** Do what "ultimate task" exactly ask for, DO NOT add any other redundant tasks which is not described in "ultimate task" **. And if extra actions were executed because of your redundant plan, the overall task could fail. (Exception: closing a blocking popup/modal is a prerequisite, not redundant—see rule 6.)
6. BLOCKING POPUP/MODAL MUST BE CLOSED FIRST:
   - Before planning any click or navigation on the main page content, ALWAYS check the screenshot for visible modals, dialogs, popups, or overlays (e.g. announcement banners, "皮肤上新啦", "知道了" prompts, cookie consent, etc.).
   - If a popup/modal is visible, your FIRST todo MUST be to close or dismiss it (e.g. click "知道了", "关闭", "确认", "取消", "Got it", or the X button).
   - This is NOT redundant: a blocking overlay prevents clicks from reaching the underlying content. Closing it is a prerequisite for the main task, not an extra task.
   - Only after the popup is closed should you plan the main task steps.

It is noteworthy that:
- To protect privacy during workflow, some filled content (e.g., account, password) will appear in the form of variables "${<VARIABLE_KEY>}". You should reuse these variable placeholders in your plan if necessary, and must absolutely not mock a string.
- Common popup close patterns: "知道了", "关闭", "确定", "取消", "Got it", "OK", "×" (close icon).

Your output format should be always a JSON object with the following fields:
{
    "state_analysis": "Brief analysis of the current state, including the effects of the last action and whether it met expectations or achieved its intended purpose and summary of what has been done so far. When analyzing state, explicitly note if a popup/modal is visible; if so, plan to close it first. (NOTE THAT: Do what ultimate task exactly ask for, DO NOT make plans for possible following or any other redundant sub-tasks which are not described in the ultimate task)",
    "is_ultimate_task_done": true / false,
    "progress_evaluation": "Evaluation of progress towards the ultimate task (as percentage and description)",
    "reasoning": "Explain your reasoning for the suggested next steps (NOTE THAT: Do what ultimate task exactly ask for, DO NOT make plans for possible following or any other redundant sub-tasks which are not described in the ultimate task)",
    "plan": "Markdown checkbox list of the ultimate task (NOTE THAT: Do what ultimate task exactly ask for, DO NOT make plans for possible following or any other redundant sub-tasks which are not described in the ultimate task)"
}

The "plan" field MUST be one JSON string, not a JSON array. Encode line breaks inside the string as \\n.
Example JSON field: "plan": "- [x] Fill in the form\\n- [ ] Submit the form"

Keep your responses concise and focused on actionable insights."""
        )


class LocatingLLMPrompt(object):
    @classmethod
    def get_system_message(cls) -> SystemMessage:
        return SystemMessage(
            content="""Return bounding boxes in JSON format with "box_2d" and "label" fields.\n"""
        )

    @staticmethod
    def get_user_message(element_description: str, screenshot_base64: str) -> HumanMessage:
        return HumanMessage(
            content=[
                {
                    'type': 'text',
                    'text': f'Detect the 2d bounding boxes of the object which is described as "{element_description}".'
                },
                {
                    'type': 'image_url',
                    'image_url': {'url': f'data:image/png;base64,{screenshot_base64}'},
                }
            ]
        )


class AssertionCodeGenerationPrompt(object):
    @classmethod
    def get_system_message(cls) -> SystemMessage:
        return SystemMessage(
            content="""You are a test code expert, highly proficient in writing test code with Python, and particularly skilled with Playwright. Your goal is to populate the test code template with crucial assert code snippets and explanatory comments, based on the provided HTML source code of key web element and its corresponding locators."""
        )

    @staticmethod
    def get_user_message(html: str, locator: str, assertion: str) -> HumanMessage:
        return HumanMessage(
            content=[
                {
                    'type': 'text',
                    'text': f'The source HTML of the key element:\n{html}\nThe locator of the key element: {locator}\nThe assertion to be made: {assertion}'
                },
                {
                    'type': 'text',
                    'text': f"""
The test code template is as follows:
```python
import re
import asyncio
from playwright.async_api import Playwright, async_playwright, expect


async def main(playwright: Playwright) -> None:
    browser = await playwright.chromium.launch(headless=False)
    context = await browser.new_context()
    page = await context.new_page()
    
    ...
    # Omitted code for navigating to the target page and the current state
    ...
    
    # Core assertion code which you need to populate

    await context.close()
    await browser.close()


with async_playwright() as playwright:
    asyncio.run(main(playwright))
```

Your return should be in the following format:

```python
# Core assertion code which you need to populate
```
Note that the code should be executable and complete and please DO NOT include indent.
Now please populate the test code template with crucial assert code snippets and explanatory comments, based on the provided HTML source code of key web element and its corresponding locators.

"""
                },
            ]
        )
