import os
import re
from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class QuickTaskSpec:
    task_text: str
    url: Optional[str]
    sensitive_data: dict[str, str]


def read_quick_display_query_raw(config: Any) -> Optional[str]:
    """Read ``quick_display_query`` without resolving ``${VAR}`` interpolations."""
    if config is None:
        return None
    getter = getattr(config, "_get_node", None)
    if callable(getter):
        try:
            node = getter("quick_display_query")
        except Exception:
            node = None
        if node is not None:
            value = node._value()
            return None if value is None else str(value)
    try:
        value = config.get("quick_display_query")
    except Exception:
        value = getattr(config, "quick_display_query", None)
    return None if value is None else str(value)


def extract_first_url(text: str) -> Optional[str]:
    match = re.search(r"https?://[A-Za-z0-9\-._~:/?#\[\]@!$&'()*+,;=%]+", text or "")
    return match.group(0) if match else None


def resolve_quick_url(text: str, explicit_url: Optional[str] = None) -> Optional[str]:
    return extract_first_url(text) or explicit_url or os.getenv("QUICK_URL") or None


def first_env_value(*keys: str) -> Optional[str]:
    for key in keys:
        value = os.getenv(key)
        if value:
            return value
    return None


def extract_inline_credentials(text: str) -> tuple[Optional[str], Optional[str]]:
    username = None
    password = None

    user_match = re.search(
        r"(?:登录账号|账号|用户名|user)\s*[:：]\s*([^\s，。；,;]+)",
        text,
        re.IGNORECASE,
    )
    if user_match:
        username = user_match.group(1)

    pass_match = re.search(
        r"(?:密码|pass|password)\s*[:：]\s*([^\s，。；,;]+)",
        text,
        re.IGNORECASE,
    )
    if pass_match:
        password = pass_match.group(1)

    return username, password


def build_quick_sensitive_data(text: str) -> tuple[str, dict[str, str]]:
    username, password = extract_inline_credentials(text)

    mentions_lower_user = "user" in text.lower()
    mentions_lower_pass = "pass" in text.lower()

    if not username:
        if mentions_lower_user:
            username = first_env_value(
                "QUICK_NAME",
                "QUICK_USERNAME",
                "user",
                "BU_USERNAME",
                "TEST_USERNAME",
                "USERNAME",
            )
        else:
            username = first_env_value(
                "QUICK_NAME",
                "QUICK_USERNAME",
                "BU_USERNAME",
                "TEST_USERNAME",
                "user",
                "USERNAME",
            )
    if not password:
        if mentions_lower_pass:
            password = first_env_value(
                "QUICK_PASSWORK",
                "QUICK_PASSWORD",
                "pass",
                "BU_PASSWORD",
                "TEST_PASSWORD",
                "PASSWORD",
            )
        else:
            password = first_env_value(
                "QUICK_PASSWORK",
                "QUICK_PASSWORD",
                "BU_PASSWORD",
                "TEST_PASSWORD",
                "pass",
                "PASSWORD",
            )

    sensitive_data: dict[str, str] = {}
    task_text = text

    if username:
        sensitive_data["USERNAME"] = username
        task_text = task_text.replace(username, "${USERNAME}")
    if password:
        sensitive_data["PASSWORD"] = password
        task_text = task_text.replace(password, "${PASSWORD}")

    if (
        username
        and password
        and (
            "${USERNAME}" not in task_text
            or "${PASSWORD}" not in task_text
        )
    ):
        task_text += (
            "。如果页面出现登录页或登录表单，请严格在 input_text.text 中使用账号占位符 "
            "${USERNAME} 和密码占位符 ${PASSWORD} 登录后继续任务；不要创造或使用其他账号密码变量名。"
        )
    elif sensitive_data and "${USERNAME}" not in task_text and username:
        task_text += "。如果页面需要登录，请严格在 input_text.text 中使用账号占位符 ${USERNAME}，不要创造其他账号变量名。"
    elif sensitive_data and "${PASSWORD}" not in task_text and password:
        task_text += "。如果页面需要登录，请严格在 input_text.text 中使用密码占位符 ${PASSWORD}，不要创造其他密码变量名。"

    return task_text, sensitive_data


def prepare_quick_task(
    text: str,
    explicit_url: Optional[str] = None,
    require_url: bool = True,
    include_url_context: bool = False,
) -> QuickTaskSpec:
    url = resolve_quick_url(text, explicit_url)
    if require_url and not url:
        raise ValueError("Quick task requires a URL in the text, explicit url, or QUICK_URL in .env.")

    task_text, sensitive_data = build_quick_sensitive_data(text)
    if url:
        task_text = task_text.replace(url, "").strip(" ，。;,")
    if not task_text:
        if url:
            task_text = f"测试页面 {url} 是否可正常访问，并判断页面是否符合预期。"
        else:
            task_text = text.strip()

    if include_url_context and url:
        task_text += f"。当前任务相关URL为：{url}。续跑模式下不要因为这个URL自动重新导航，除非任务明确要求打开或切换页面。"

    return QuickTaskSpec(task_text=task_text, url=url, sensitive_data=sensitive_data)
