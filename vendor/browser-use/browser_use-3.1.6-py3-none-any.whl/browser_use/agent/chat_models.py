from __future__ import annotations

import os
from typing import Any, Dict, Union
from urllib.parse import urlsplit

from langchain_core.messages import (
    AIMessage,
    AIMessageChunk,
    BaseMessage,
    BaseMessageChunk,
    ChatMessage,
    ChatMessageChunk,
    HumanMessage,
    HumanMessageChunk,
    SystemMessage,
    SystemMessageChunk,
    ToolMessage,
    ToolMessageChunk,
)
from langchain_openai import ChatOpenAI


# UIWarden public OpenAI-compatible model resolver.
def build_models(
    actor="qwen3.7-plus",
    planner="qwen3.7-plus",
    asserter="qwen3.7-plus",
    page_extraction_llm="qwen3.7-plus",
    locating_llm="qwen3.7-plus",
    coding_llm="qwen3.7-plus",
):
    key = os.getenv("BU_OPENAI_API_KEY", "").strip()
    base = os.getenv("BU_OPENAI_API_BASE", "").strip()
    if not key or not base:
        raise ValueError("BU_OPENAI_API_KEY and BU_OPENAI_API_BASE are required")
    url = urlsplit(base)
    if (
        url.scheme not in ("https", "http")
        or not url.hostname
        or url.username
        or url.password
        or url.query
        or url.fragment
    ):
        raise ValueError("BU_OPENAI_API_BASE must be an HTTP(S) URL without credentials, query or fragment")

    roles = (
        ("BU_ACTOR_MODEL", actor),
        ("BU_PLANNER_MODEL", planner),
        ("BU_ASSERTER_MODEL", asserter),
        ("BU_PAGE_EXTRACTION_LLM", page_extraction_llm),
        ("BU_LOCATING_LLM", locating_llm),
        ("BU_CODING_LLM", coding_llm),
    )
    names = [os.getenv(variable, "").strip() or default for variable, default in roles]
    if any(not name for name in names):
        raise ValueError("Every browser-use model role must have a non-empty model name")
    clients = {
        name: ChatOpenAI(
            model=name,
            api_key=key,
            base_url=base,
            temperature=0.0,
            timeout=120,
            max_retries=1,
        )
        for name in set(names)
    }
    resolved = [clients[name] for name in names]
    return (*resolved[:3], dict(zip(
        ("page_extraction_llm", "locating_llm", "coding_llm"),
        resolved[3:],
    )))


def convert_dict_to_message(
    message: Any, is_chunk: bool = False
) -> Union[BaseMessage, BaseMessageChunk]:
    role = message.role
    content = message.content
    if role == "user":
        return (
            HumanMessageChunk(content=content)
            if is_chunk
            else HumanMessage(content=content)
        )
    elif role == "assistant":
        return (
            AIMessageChunk(content=content) if is_chunk else AIMessage(content=content)
        )
    elif role == "system":
        return (
            SystemMessageChunk(content=content)
            if is_chunk
            else SystemMessage(content=content)
        )
    else:
        return (
            ChatMessageChunk(role=role, content=content)
            if is_chunk
            else ChatMessage(role=role, content=content)
        )


def convert_message_chunk_to_message(message_chunk: BaseMessageChunk) -> BaseMessage:
    if isinstance(message_chunk, HumanMessageChunk):
        return HumanMessage(content=message_chunk.content)
    elif isinstance(message_chunk, AIMessageChunk):
        return AIMessage(content=message_chunk.content)
    elif isinstance(message_chunk, SystemMessageChunk):
        return SystemMessage(content=message_chunk.content)
    elif isinstance(message_chunk, ChatMessageChunk):
        return ChatMessage(role=message_chunk.role, content=message_chunk.content)
    else:
        raise TypeError(f"Got unknown type {message_chunk}")


def convert_message_to_dict(message: BaseMessage) -> dict:
    """Convert a message to a dict."""

    message_dict: Dict[str, Any]
    if isinstance(message, ChatMessage):
        message_dict = {"role": message.role, "content": message.content}
    elif isinstance(message, HumanMessage):
        message_dict = {"role": "user", "content": message.content}
    elif isinstance(message, AIMessage):
        message_dict = {"role": "assistant", "content": message.content}
    elif isinstance(message, SystemMessage):
        message_dict = {"role": "system", "content": message.content}
    elif isinstance(message, ToolMessage):
        message_dict = {"role": "tool", "content": message.content}
    else:
        raise TypeError(f"Got unknown type {message}")
    return message_dict
