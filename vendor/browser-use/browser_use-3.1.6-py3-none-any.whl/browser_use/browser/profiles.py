"""
Browser profile registry for multi-browser support.

Each BrowserProfile defines how to launch a specific browser vendor + version
via Playwright. Profiles are registered at module load time and looked up by
key (``vendor`` or ``vendor:version``).

Configuration is driven by environment variables (typically set in ``.env``):

- ``BU_BROWSER_TYPE``  – single browser key, e.g. ``chrome:139``
- ``BU_BROWSER_TYPES`` – comma-separated list for multi-browser mode,
  e.g. ``chrome,chrome:147,edge:147,360:16.0``
- ``BU_CHROME_139_PATH`` / ``BU_CHROME_147_PATH`` / ``BU_EDGE_PATH`` /
  ``BU_EDGE_147_PATH`` / ``BU_360_BROWSER_PATH`` – override executable paths
"""

import logging
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data structure
# ---------------------------------------------------------------------------


@dataclass
class BrowserProfile:
    vendor: str
    version: Optional[str] = None
    display_name: str = ""
    playwright_browser: str = "chromium"
    channel: Optional[str] = None
    executable_path: Optional[str] = None
    extra_args: List[str] = field(default_factory=list)
    user_agent: Optional[str] = None

    @property
    def key(self) -> str:
        """Registry key: 'chrome', 'chrome:139', '360:16.0', 'edge:147'."""
        return f"{self.vendor}:{self.version}" if self.version else self.vendor


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

BROWSER_PROFILES: Dict[str, BrowserProfile] = {}


def register_browser(profile: BrowserProfile) -> None:
    """Register a browser profile in the global registry."""
    BROWSER_PROFILES[profile.key] = profile
    logger.debug("Registered browser profile: %s (%s)", profile.key, profile.display_name)


def get_browser_profile(key: str) -> BrowserProfile:
    """Look up a profile by key. Raises ``ValueError`` if not found."""
    if key in BROWSER_PROFILES:
        return BROWSER_PROFILES[key]
    available = ", ".join(sorted(BROWSER_PROFILES.keys()))
    raise ValueError(
        f"Unknown browser profile '{key}'. Available profiles: [{available}]"
    )


def validate_browser_profile(key: str) -> None:
    """Validate that a profile exists and its executable_path (if set) is reachable.

    Call this early (before launching Playwright) to give the user a clear,
    actionable error message instead of a cryptic Playwright crash.
    """
    profile = get_browser_profile(key)
    if profile.executable_path and not os.path.isfile(profile.executable_path):
        raise FileNotFoundError(
            f"\n{'=' * 70}\n"
            f"  Browser binary NOT FOUND for profile '{profile.key}'\n"
            f"  Display name : {profile.display_name}\n"
            f"  Expected path: {profile.executable_path}\n\n"
            f"  How to fix:\n"
            f"  1. Install the browser and set the correct path in .env:\n"
            f"     (see docs/multi-browser-testing.md for installation guide)\n"
            f"  2. Or override the path via environment variable, e.g.:\n"
            f"     BU_CHROME_139_PATH=/path/to/chrome\n"
            f"{'=' * 70}"
        )


# ---------------------------------------------------------------------------
# Built-in profiles
# ---------------------------------------------------------------------------

def _versioned_path(variable, unix_default):
    configured = os.environ.get(variable)
    if configured:
        return configured
    if os.name == "nt":
        # Never silently substitute the system browser for a requested version.
        return "__SET_" + variable + "__\\browser.exe"
    return unix_default


# ---- Chrome ----

# Chrome — Playwright built-in Chromium (default)
register_browser(BrowserProfile(
    vendor="chrome",
    display_name="Chrome (default)",
    playwright_browser="chromium",
))

# Chrome 139
register_browser(BrowserProfile(
    vendor="chrome",
    version="139",
    display_name="Chrome 139",
    playwright_browser="chromium",
    executable_path=_versioned_path("BU_CHROME_139_PATH", "/opt/chrome/chrome-139/chrome"),
))

# Chrome 147 (latest stable)
register_browser(BrowserProfile(
    vendor="chrome",
    version="147",
    display_name="Chrome 147.0.7727.102",
    playwright_browser="chromium",
    executable_path=_versioned_path("BU_CHROME_147_PATH", "/opt/chrome/chrome-147/chrome"),
))

# ---- Microsoft Edge ----

# Edge — system default via Playwright channel
register_browser(BrowserProfile(
    vendor="edge",
    display_name="Microsoft Edge (default)",
    playwright_browser="chromium",
    channel="msedge",
))

# Edge 147 (latest stable)
register_browser(BrowserProfile(
    vendor="edge",
    version="147",
    display_name="Edge 147.0.3912.72",
    playwright_browser="chromium",
    executable_path=_versioned_path("BU_EDGE_147_PATH", "/opt/edge/edge-147/msedge"),
))

# ---- 360 Browser ----

# 360 企业浏览器 13.3
register_browser(BrowserProfile(
    vendor="360",
    version="13.3",
    display_name="360 Enterprise Browser 13.3",
    playwright_browser="chromium",
    executable_path=_versioned_path("BU_360_BROWSER_PATH", "/opt/browser360ent/browser360ent-cn"),
))
