from dataclasses import dataclass, field
from typing import Any, Optional, List

from pydantic import BaseModel

from browser_use.dom.history_tree_processor.service import DOMHistoryElement
from browser_use.dom.views import DOMState, ScrollableElements


# Pydantic
class TabInfo(BaseModel):
    """Represents information about a browser tab"""

    page_id: int
    url: str
    title: str


@dataclass
class BrowserState(DOMState):
    url: str
    title: str
    tabs: List[TabInfo]
    screenshot: Optional[str] = None
    dom_tree_screenshot: Optional[str] = None
    pixels_above: int = 0
    pixels_below: int = 0
    page_height: int = 0
    page_width: int = 0
    scrollable_elements: ScrollableElements = field(default_factory=ScrollableElements)
    scrollable_elements_screenshot: Optional[str] = None
    browser_errors: List[str] = field(default_factory=list)

    def build_page_description(
            self,
            include_attributes: List[str],
            include_offscreen_elements: bool = True,
            box_format: str = "tlbr",
    ):
        page_description = self.element_tree.clickable_elements_to_string(
            include_attributes=include_attributes,
            include_offscreen_elements=include_offscreen_elements,
            height=self.page_height,
            width=self.page_width,
            box_format=box_format,
        )

        has_content_above = (self.pixels_above or 0) > 0
        has_content_below = (self.pixels_below or 0) > 0

        if page_description != '':
            if has_content_above:
                elements_text = (
                    f'... {self.pixels_above} pixels above - scroll or extract content to see more ...\n{page_description}'
                )
            else:
                page_description = f'[Start of page]\n{page_description}'
            if has_content_below:
                page_description = (
                    f'{page_description}\n... {self.pixels_below} pixels below - scroll or extract content to see more ...'
                )
            else:
                page_description = f'{page_description}\n[End of page]'
        else:
            page_description = 'empty page'
        return page_description


@dataclass
class BrowserStateHistory:
    url: str
    title: str
    tabs: List[TabInfo]
    screenshot: Optional[str] = None

    def to_dict(self) -> dict[str, Any]:
        data = {
            'tabs': [tab.model_dump() for tab in self.tabs],
            'screenshot': self.screenshot,
            'url': self.url,
            'title': self.title,
        }
        return data


class BrowserError(Exception):
    """Base class for all browser errors"""


class URLNotAllowedError(BrowserError):
    """Error raised when a URL is not allowed"""
