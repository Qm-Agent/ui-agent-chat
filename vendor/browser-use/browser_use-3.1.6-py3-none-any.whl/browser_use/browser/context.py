"""
Playwright browser on steroids.
"""

import asyncio
import base64
import gc
import json
import logging
import os
import re
import time
import uuid
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Dict, List, Optional, Tuple, TypedDict, Union

from PIL import Image, ImageDraw, ImageFont
from playwright._impl._errors import TimeoutError
from playwright.async_api import (
    Browser as PlaywrightBrowser,
)
from playwright.async_api import (
    BrowserContext as PlaywrightBrowserContext,
)
from playwright.async_api import (
    ElementHandle,
    FrameLocator,
    Page,
)

from browser_use import project_root
from browser_use.browser.views import (
    BrowserError,
    BrowserState,
    TabInfo,
    URLNotAllowedError,
)
from browser_use.dom.service import DomService
from browser_use.dom.views import DOMElementNode, SelectorMap
from browser_use.utils import (
    box_2d_to_rectangle,
    time_execution_async,
    time_execution_sync,
)

if TYPE_CHECKING:
    from browser_use.browser.browser import Browser
    from browser_use.cache.manager import CacheManager

logger = logging.getLogger(__name__)


class BrowserContextWindowSize(TypedDict):
    width: int
    height: int


def _default_browser_window_size() -> BrowserContextWindowSize:
    return {
        "width": int(os.getenv("VIEWPORT_WIDTH", 1496)),
        "height": int(os.getenv("VIEWPORT_HEIGHT", 818)),
    }


@dataclass
class BrowserContextConfig:
    """
    Configuration for the BrowserContext.

    Default values:
        cookies_file: None
            Cookie source for injection. Either:
            - Path to a JSON file (array of cookie objects), or
            - Inline JSON string (e.g. '[{"name":"x","value":"y",...}]').
            When inline, cookies are not persisted back to disk.

            disable_security: True
                    Disable browser security features

        minimum_wait_page_load_time: 0.5
            Minimum time to wait before getting page state for LLM input

            wait_for_network_idle_page_load_time: 1.0
                    Time to wait for network requests to finish before getting page state.
                    Lower values may result in incomplete page loads.

        maximum_wait_page_load_time: 5.0
            Maximum time to wait for page load before proceeding anyway

        wait_between_actions: 1.0
            Time to wait between multiple per step actions

        browser_window_size: {
                'width': 1280,
                'height': 1100,
            }
            Default browser window size

        device_scale_factor: 2.0
            Device scale factor for the browser window
            Default is 2.0

        no_viewport: False
            Disable viewport

        save_recording_path: None
            Path to save video recordings

        save_downloads_path: None
            Path to save downloads to

        trace_path: None
            Path to save trace files. It will auto name the file with the TRACE_PATH/{context_id}.zip

        locale: None
            Specify user locale, for example en-GB, de-DE, etc. Locale will affect
        navigator.language value, Accept-Language request header value as well as
        number and date formatting rules. If not provided, defaults to the system
        default locale.

        user_agent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36
        (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36'
            custom user agent to use.

        highlight_elements: True
            Highlight elements in the DOM on the screen

        viewport_expansion: 500
            Viewport expansion in pixels. This amount will increase the number of
        elements which are included in the state what the LLM will see. If set
        to -1, all elements will be included (this leads to high token usage).
        If set to 0, only the elements which are visible in the viewport will
        be included.

        allowed_domains: None
            List of allowed domains that can be accessed. If None, all domains are allowed.
            Example: ['example.com', 'api.example.com']

        include_dynamic_attributes: bool = True
            Include dynamic attributes in the CSS selector. If you want to reuse
        the css_selectors, it might be better to set this to False.
    """

    cookies_file: Optional[str] = None
    minimum_wait_page_load_time: float = 0.25
    wait_for_network_idle_page_load_time: float = 0.5
    maximum_wait_page_load_time: float = 5
    wait_between_actions: float = 0.5

    disable_security: bool = True

    browser_window_size: BrowserContextWindowSize = field(
        default_factory=_default_browser_window_size
    )
    device_scale_factor: float = 1.5
    no_viewport: Optional[bool] = None

    save_recording_path: Optional[str] = None
    save_downloads_path: Optional[str] = None
    trace_path: Optional[str] = None
    locale: Optional[str] = None
    user_agent: str = (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
        " (KHTML, like Gecko) Chrome/85.0.4183.102 Safari/537.36"
    )

    highlight_elements: bool = True
    viewport_expansion: int = 500
    allowed_domains: List[str] | None = None
    include_dynamic_attributes: bool = True

    _force_keep_context_alive: bool = False

    default_font_path: str = str(project_root / "static/fonts/Arial Unicode.ttf")

    max_state_updating_failures: int = 3
    state_updating_retry_delay: float = 2.0

    click_mode: str = "center"


@dataclass
class BrowserSession:
    context: PlaywrightBrowserContext
    cached_state: Optional[BrowserState]


@dataclass
class BrowserContextState:
    """
    State of the browser context
    """

    target_id: Optional[str] = None  # CDP target ID


class BrowserContext:
    def __init__(
        self,
        browser: "Browser",
        config: BrowserContextConfig = BrowserContextConfig(),
        state: Optional[BrowserContextState] = None,
        cache_manager: Optional["CacheManager"] = None,
    ):
        self.context_id = str(uuid.uuid4())
        logger.debug(f"Initializing new browser context with id: {self.context_id}")

        self.config = config
        self.browser = browser

        self.state = state or BrowserContextState()
        self._cache_manager = cache_manager

        # Initialize these as None - they'll be set up when needed
        self.session: BrowserSession | None = None

    async def __aenter__(self):
        """Async context manager entry"""
        await self._initialize_session()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.close()

    @time_execution_async("--close")
    async def close(self):
        """Close the browser instance"""
        logger.debug("Closing browser context")

        try:
            if self.session is None:
                return

            # Then remove CDP protocol listeners
            if self._page_event_handler and self.session.context:
                try:
                    # This actually sends a CDP command to unsubscribe
                    self.session.context.remove_listener(
                        "page", self._page_event_handler
                    )
                except Exception as e:
                    logger.debug(f"Failed to remove CDP listener: {e}")
                self._page_event_handler = None

            if self.config.trace_path:
                try:
                    await self.session.context.tracing.stop(
                        path=os.path.join(
                            self.config.trace_path, f"{self.context_id}.zip"
                        )
                    )
                except Exception as e:
                    logger.debug(f"Failed to stop tracing: {e}")

            # This is crucial - it closes the CDP connection
            if not self.config._force_keep_context_alive:
                try:
                    await self.session.context.close()
                except Exception as e:
                    logger.debug(f"Failed to close context: {e}")

        finally:
            # Dereference everything
            self.session = None
            self._page_event_handler = None

    def __del__(self):
        """Cleanup when object is destroyed"""
        if not self.config._force_keep_context_alive and self.session is not None:
            logger.debug("BrowserContext was not properly closed before destruction")
            try:
                # Use sync Playwright method for force cleanup
                if hasattr(self.session.context, "_impl_obj"):
                    asyncio.run(self.session.context._impl_obj.close())

                self.session = None
                gc.collect()
            except Exception as e:
                logger.warning(f"Failed to force close browser context: {e}")

    @time_execution_async("--initialize_session")
    async def _initialize_session(self):
        """Initialize the browser session"""
        logger.info("Initializing browser context (launching browser if needed)...")
        playwright_browser = await self.browser.get_playwright_browser()
        context = await self._create_context(playwright_browser)
        self._page_event_handler = None

        # Get or create a page to use
        pages = context.pages

        self.session = BrowserSession(
            context=context,
            cached_state=None,
        )

        active_page = None
        if self.browser.config.cdp_url:
            # If we have a saved target ID, try to find and activate it
            if self.state.target_id:
                targets = await self._get_cdp_targets()
                for target in targets:
                    if target["targetId"] == self.state.target_id:
                        # Find matching page by URL
                        for page in pages:
                            if page.url == target["url"]:
                                active_page = page
                                break
                        break

        # If no target ID or couldn't find it, use existing page or create new
        if not active_page:
            if pages:
                active_page = pages[0]
                logger.debug("Using existing page")
            else:
                active_page = await context.new_page()
                logger.debug("Created new page")

            # Get target ID for the active page
            if self.browser.config.cdp_url:
                targets = await self._get_cdp_targets()
                for target in targets:
                    if target["url"] == active_page.url:
                        self.state.target_id = target["targetId"]
                        break

        # Bring page to front
        await active_page.bring_to_front()
        await active_page.wait_for_load_state("load")

        return self.session

    def _add_new_page_listener(self, context: PlaywrightBrowserContext):
        async def on_page(page: Page):
            if self.browser.config.cdp_url:
                await page.reload()  # Reload the page to avoid timeout errors
            await page.wait_for_load_state()
            logger.debug(f"New page opened: {page.url}")
            if self.session is not None:
                self.state.target_id = None

        self._page_event_handler = on_page
        context.on("page", on_page)

    async def get_session(self) -> BrowserSession:
        """Lazy initialization of the browser and related components"""
        if self.session is None:
            return await self._initialize_session()
        return self.session

    def is_browser_available(self) -> bool:
        """
        检查浏览器是否仍可用（用户可能已主动关闭浏览器窗口）。
        当用户关闭 headed 模式下的浏览器窗口时，返回 False，便于上层任务提前退出。
        """
        try:
            if self.session is None:
                return True  # 尚未初始化，视为可用
            if not self.session.context:
                return False
            return len(self.session.context.pages) > 0
        except Exception:
            return False

    async def get_current_page(self) -> Page:
        """Get the current page"""
        session = await self.get_session()
        return await self._get_current_page(session)

    async def _create_context(self, browser: PlaywrightBrowser):
        """Creates a new browser context with anti-detection measures and loads cookies if available."""
        if self.browser.config.cdp_url and len(browser.contexts) > 0:
            context = browser.contexts[0]
        elif self.browser.config.chrome_instance_path and len(browser.contexts) > 0:
            # Connect to existing Chrome instance instead of creating new one
            context = browser.contexts[0]
        else:
            # Original code for creating new context
            context = await browser.new_context(
                viewport=self.config.browser_window_size,
                no_viewport=False,
                user_agent=self.config.user_agent,
                java_script_enabled=True,
                bypass_csp=self.config.disable_security,
                ignore_https_errors=self.config.disable_security,
                record_video_dir=self.config.save_recording_path,
                record_video_size=self.config.browser_window_size,
                locale=self.config.locale,
                device_scale_factor=self.config.device_scale_factor,
            )

        if self.config.trace_path:
            await context.tracing.start(screenshots=True, snapshots=True, sources=True)

        # Load cookies: support file path or inline JSON string (same as target.cookie in YAML)
        if self.config.cookies_file:
            raw = self.config.cookies_file.strip()
            # Heuristic: path vs inline JSON — treat as path only if not JSON-like and path exists
            if (
                not (raw.startswith("[") or raw.startswith("{"))
                and "\n" not in raw
                and os.path.exists(raw)
            ):
                with open(raw, "r", encoding="utf-8") as f:
                    cookie_content = f.read()
                self._cookies_source_is_file = True
            else:
                cookie_content = raw
                self._cookies_source_is_file = False
            try:
                cookies = json.loads(cookie_content)
                # Double-escaped: e.g. "[{\"name\":\"x\"}]" -> parse again
                if isinstance(cookies, str) and cookies.strip().startswith(("[", "{")):
                    cookies = json.loads(cookies)
                if isinstance(cookies, list):
                    # Normalize for Playwright: sameSite must be Strict|Lax|None (capitalized)
                    _pw_same_site = {"strict": "Strict", "lax": "Lax", "none": "None"}
                    playwright_cookies = []
                    for c in cookies:
                        if not isinstance(c, dict):
                            continue
                        nc = dict(c)
                        ss = (nc.get("sameSite") or "").strip()
                        ss_lower = ss.lower()
                        if ss in ("unspecified", "no_restriction", ""):
                            nc["sameSite"] = "Lax" if ss != "no_restriction" else "None"
                        elif ss_lower in _pw_same_site:
                            nc["sameSite"] = _pw_same_site[ss_lower]
                        else:
                            nc["sameSite"] = "Lax"
                        playwright_cookies.append(nc)
                    logger.info(
                        "Loaded %d cookies from %s",
                        len(playwright_cookies),
                        raw if self._cookies_source_is_file else "inline",
                    )
                    await context.add_cookies(playwright_cookies)
                else:
                    logger.warning("Cookie value did not parse to a list; skipping.")
            except json.JSONDecodeError as e:
                logger.warning("Failed to parse cookie (file or inline JSON): %s", e)

        # Expose anti-detection scripts
        await context.add_init_script(
            """
            // Webdriver property
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined
            });

            // Languages
            Object.defineProperty(navigator, 'languages', {
                get: () => ['en-US']
            });

            // Plugins
            Object.defineProperty(navigator, 'plugins', {
                get: () => [1, 2, 3, 4, 5]
            });

            // Chrome runtime
            window.chrome = { runtime: {} };

            // Permissions
            const originalQuery = window.navigator.permissions.query;
            window.navigator.permissions.query = (parameters) => (
                parameters.name === 'notifications' ?
                    Promise.resolve({ state: Notification.permission }) :
                    originalQuery(parameters)
            );
            (function () {
                const originalAttachShadow = Element.prototype.attachShadow;
                Element.prototype.attachShadow = function attachShadow(options) {
                    return originalAttachShadow.call(this, { ...options, mode: "open" });
                };
            })();
            """
        )

        return context

    async def _wait_for_stable_network(self):
        page = await self.get_current_page()

        pending_requests = set()
        last_activity = asyncio.get_event_loop().time()

        # Define relevant resource types and content types
        RELEVANT_RESOURCE_TYPES = {
            "document",
            "stylesheet",
            "image",
            "font",
            "script",
            "iframe",
        }

        RELEVANT_CONTENT_TYPES = {
            "text/html",
            "text/css",
            "application/javascript",
            "image/",
            "font/",
            "application/json",
        }

        # Additional patterns to filter out
        IGNORED_URL_PATTERNS = {
            # Analytics and tracking
            "analytics",
            "tracking",
            "telemetry",
            "beacon",
            "metrics",
            # Ad-related
            "doubleclick",
            "adsystem",
            "adserver",
            "advertising",
            # Social media widgets
            "facebook.com/plugins",
            "platform.twitter",
            "linkedin.com/embed",
            # Live chat and support
            "livechat",
            "zendesk",
            "intercom",
            "crisp.chat",
            "hotjar",
            # Push notifications
            "push-notifications",
            "onesignal",
            "pushwoosh",
            # Background sync/heartbeat
            "heartbeat",
            "ping",
            "alive",
            # WebRTC and streaming
            "webrtc",
            "rtmp://",
            "wss://",
            # Common CDNs for dynamic content
            "cloudfront.net",
            "fastly.net",
        }

        async def on_request(request):
            # Filter by resource type
            if request.resource_type not in RELEVANT_RESOURCE_TYPES:
                return

            # Filter out streaming, websocket, and other real-time requests
            if request.resource_type in {
                "websocket",
                "media",
                "eventsource",
                "manifest",
                "other",
            }:
                return

            # Filter out by URL patterns
            url = request.url.lower()
            if any(pattern in url for pattern in IGNORED_URL_PATTERNS):
                return

            # Filter out data URLs and blob URLs
            if url.startswith(("data:", "blob:")):
                return

            # Filter out requests with certain headers
            headers = request.headers
            if headers.get("purpose") == "prefetch" or headers.get(
                "sec-fetch-dest"
            ) in [
                "video",
                "audio",
            ]:
                return

            nonlocal last_activity
            pending_requests.add(request)
            last_activity = asyncio.get_event_loop().time()

        # logger.debug(f'Request started: {request.url} ({request.resource_type})')

        async def on_response(response):
            request = response.request
            if request not in pending_requests:
                return

            # Filter by content type if available
            content_type = response.headers.get("content-type", "").lower()

            # Skip if content type indicates streaming or real-time data
            if any(
                t in content_type
                for t in [
                    "streaming",
                    "video",
                    "audio",
                    "webm",
                    "mp4",
                    "event-stream",
                    "websocket",
                    "protobuf",
                ]
            ):
                pending_requests.remove(request)
                return

            # Only process relevant content types
            if not any(ct in content_type for ct in RELEVANT_CONTENT_TYPES):
                pending_requests.remove(request)
                return

            # Skip if response is too large (likely not essential for page load)
            content_length = response.headers.get("content-length")
            if content_length and int(content_length) > 5 * 1024 * 1024:  # 5MB
                pending_requests.remove(request)
                return

            nonlocal last_activity
            pending_requests.remove(request)
            last_activity = asyncio.get_event_loop().time()

        # logger.debug(f'Request resolved: {request.url} ({content_type})')

        # Attach event listeners
        page.on("request", on_request)
        page.on("response", on_response)

        try:
            # Wait for idle time
            start_time = asyncio.get_event_loop().time()
            while True:
                await asyncio.sleep(0.1)
                now = asyncio.get_event_loop().time()
                if (
                    len(pending_requests) == 0
                    and (now - last_activity)
                    >= self.config.wait_for_network_idle_page_load_time
                ):
                    break
                if now - start_time > self.config.maximum_wait_page_load_time:
                    logger.debug(
                        f"Network timeout after {self.config.maximum_wait_page_load_time}s with {len(pending_requests)} "
                        f"pending requests: {[r.url for r in pending_requests]}"
                    )
                    break

        finally:
            # Clean up event listeners
            page.remove_listener("request", on_request)
            page.remove_listener("response", on_response)

        logger.debug(
            f"Network stabilized for {self.config.wait_for_network_idle_page_load_time} seconds"
        )

    async def _wait_for_page_and_frames_load(
        self, timeout_overwrite: float | None = None
    ):
        """
        Ensures page is fully loaded before continuing.
        Waits for either network to be idle or minimum WAIT_TIME, whichever is longer.
        Also checks if the loaded URL is allowed.
        """
        # Start timing
        start_time = time.time()

        # Wait for page load
        try:
            await self._wait_for_stable_network()

            # Check if the loaded URL is allowed
            page = await self.get_current_page()
            await self._check_and_handle_navigation(page)
        except URLNotAllowedError as e:
            raise e
        except Exception:
            logger.warning("Page load failed, continuing...")
            pass

        # Calculate remaining time to meet minimum WAIT_TIME
        elapsed = time.time() - start_time
        remaining = max(
            (timeout_overwrite or self.config.minimum_wait_page_load_time) - elapsed, 0
        )

        logger.debug(
            f"--Page loaded in {elapsed:.2f} seconds, waiting for additional {remaining:.2f} seconds"
        )

        # Sleep remaining time if needed
        if remaining > 0:
            await asyncio.sleep(remaining)

    @staticmethod
    def _is_transient_navigation_error(error: Exception) -> bool:
        msg = str(error).lower()
        transient_signals = (
            "execution context was destroyed",
            "cannot find context with specified id",
            "navigation",
        )
        return any(signal in msg for signal in transient_signals)

    async def _safe_get_page_title(
        self,
        page: Page,
        *,
        retries: int = 3,
        delay_seconds: float = 0.3,
    ) -> str:
        for attempt in range(retries):
            try:
                return await page.title()
            except Exception as e:
                if not self._is_transient_navigation_error(e):
                    raise
                if attempt == retries - 1:
                    logger.warning(
                        "Fallback to empty title due to navigation race on %s: %s",
                        page.url,
                        e,
                    )
                    return ""
                await asyncio.sleep(delay_seconds)
        return ""

    def _is_url_allowed(self, url: str) -> bool:
        """Check if a URL is allowed based on the whitelist configuration."""
        if not self.config.allowed_domains:
            return True

        try:
            from urllib.parse import urlparse

            parsed_url = urlparse(url)
            domain = parsed_url.netloc.lower()

            # Remove port number if present
            if ":" in domain:
                domain = domain.split(":")[0]

            # Check if domain matches any allowed domain pattern
            return any(
                domain == allowed_domain.lower()
                or domain.endswith("." + allowed_domain.lower())
                for allowed_domain in self.config.allowed_domains
            )
        except Exception as e:
            logger.exception(f"Error checking URL allowlist: {str(e)}")
            return False

    async def _check_and_handle_navigation(self, page: Page) -> None:
        """Check if current page URL is allowed and handle if not."""
        if not self._is_url_allowed(page.url):
            logger.warning(f"Navigation to non-allowed URL detected: {page.url}")
            try:
                await self.go_back()
            except Exception as e:
                logger.exception(
                    f"Failed to go back after detecting non-allowed URL: {str(e)}"
                )
            raise URLNotAllowedError(f"Navigation to non-allowed URL: {page.url}")

    async def navigate_to(self, url: str):
        """Navigate to a URL"""
        if not self._is_url_allowed(url):
            raise BrowserError(f"Navigation to non-allowed URL: {url}")

        page = await self.get_current_page()
        await page.goto(url)
        await page.wait_for_load_state()

    async def refresh_page(self):
        """Refresh the current page"""
        page = await self.get_current_page()
        await page.reload()
        await page.wait_for_load_state()

    async def go_back(self):
        """Navigate back in history"""
        page = await self.get_current_page()
        try:
            # 10 ms timeout
            await page.go_back(timeout=10, wait_until="domcontentloaded")
        # await self._wait_for_page_and_frames_load(timeout_overwrite=1.0)
        except Exception as e:
            # Continue even if its not fully loaded, because we wait later for the page to load
            logger.debug(f"During go_back: {e}")

    async def go_forward(self):
        """Navigate forward in history"""
        page = await self.get_current_page()
        try:
            await page.go_forward(timeout=10, wait_until="domcontentloaded")
        except Exception as e:
            # Continue even if its not fully loaded, because we wait later for the page to load
            logger.debug(f"During go_forward: {e}")

    async def close_current_tab(self):
        """Close the current tab"""
        session = await self.get_session()
        page = await self._get_current_page(session)
        await page.close()

        # Switch to the first available tab if any exist
        if session.context.pages:
            await self.switch_to_tab(0)

    # otherwise the browser will be closed

    async def get_page_html(self) -> str:
        """Get the current page HTML content"""
        page = await self.get_current_page()
        return await page.content()

    async def execute_javascript(self, script: str):
        """Execute JavaScript code on the page"""
        page = await self.get_current_page()
        return await page.evaluate(script)

    async def get_page_structure(self) -> str:
        """Get a debug view of the page structure including iframes"""
        debug_script = """(() => {
			function getPageStructure(element = document, depth = 0, maxDepth = 10) {
				if (depth >= maxDepth) return '';

				const indent = '  '.repeat(depth);
				let structure = '';

				// Skip certain elements that clutter the output
				const skipTags = new Set(['script', 'style', 'link', 'meta', 'noscript']);

				// Add current element info if it's not the document
				if (element !== document) {
					const tagName = element.tagName.toLowerCase();

					// Skip uninteresting elements
					if (skipTags.has(tagName)) return '';

					const id = element.id ? `#${element.id}` : '';
					const classes = element.className && typeof element.className === 'string' ?
						`.${element.className.split(' ').filter(c => c).join('.')}` : '';

					// Get additional useful attributes
					const attrs = [];
					if (element.getAttribute('role')) attrs.push(`role="${element.getAttribute('role')}"`);
					if (element.getAttribute('aria-label')) attrs.push(`aria-label="${element.getAttribute('aria-label')}"`);
					if (element.getAttribute('type')) attrs.push(`type="${element.getAttribute('type')}"`);
					if (element.getAttribute('name')) attrs.push(`name="${element.getAttribute('name')}"`);
					if (element.getAttribute('src')) {
						const src = element.getAttribute('src');
						attrs.push(`src="${src.substring(0, 50)}${src.length > 50 ? '...' : ''}"`);
					}

					// Add element info
					structure += `${indent}${tagName}${id}${classes}${attrs.length ? ' [' + attrs.join(', ') + ']' : ''}\\n`;

					// Handle iframes specially
					if (tagName === 'iframe') {
						try {
							const iframeDoc = element.contentDocument || element.contentWindow?.document;
							if (iframeDoc) {
								structure += `${indent}  [IFRAME CONTENT]:\\n`;
								structure += getPageStructure(iframeDoc, depth + 2, maxDepth);
							} else {
								structure += `${indent}  [IFRAME: No access - likely cross-origin]\\n`;
							}
						} catch (e) {
							structure += `${indent}  [IFRAME: Access denied - ${e.message}]\\n`;
						}
					}
				}

				// Get all child elements
				const children = element.children || element.childNodes;
				for (const child of children) {
					if (child.nodeType === 1) { // Element nodes only
						structure += getPageStructure(child, depth + 1, maxDepth);
					}
				}

				return structure;
			}

			return getPageStructure();
		})()"""

        page = await self.get_current_page()
        structure = await page.evaluate(debug_script)
        return structure

    @time_execution_sync(
        "--get_state"
    )  # This decorator might need to be updated to handle async
    async def get_state(self) -> BrowserState:
        """Get the current state of the browser"""
        # L1 cache check: return cached state if clean, key matches, and within TTL
        runtime = self._cache_manager.runtime if self._cache_manager else None
        if runtime is not None:
            try:
                page = await self.get_current_page()
                current_url = page.url
                scroll_y = await page.evaluate("window.scrollY") or 0
                cached = runtime.get_state(current_url, int(scroll_y))
                if cached is not None:
                    if self._cache_manager:
                        self._cache_manager.stats.l1_hits += 1
                    return cached
                if self._cache_manager:
                    self._cache_manager.stats.l1_misses += 1
            except Exception as e:
                logger.debug(f"[Cache] L1 check failed, proceeding normally: {e}")

        # Smart wait: skip page-load wait if URL unchanged and cache is clean
        skip_wait = False
        if runtime is not None:
            try:
                page = await self.get_current_page()
                skip_wait = runtime.should_skip_page_wait(page.url)
                if skip_wait and self._cache_manager:
                    self._cache_manager.stats.smart_wait_skips += 1
                    logger.info(
                        f"[L1 smart wait] skipping page-load wait for {page.url}"
                    )
            except Exception as e:
                logger.debug(f"[Cache] Smart wait check failed: {e}")

        if not skip_wait:
            await self._wait_for_page_and_frames_load()

        session = await self.get_session()

        state_updating_consecutive_failure = 0
        while (
            state_updating_consecutive_failure < self.config.max_state_updating_failures
        ):
            try:
                session.cached_state = await self._update_state()
                break
            except Exception as e:
                logger.exception(f"Failed to update state: {str(e)}")
                state_updating_consecutive_failure += 1
                if (
                    state_updating_consecutive_failure
                    >= self.config.max_state_updating_failures
                ):
                    logger.error("Max state updating failures reached.")
                    raise e
                logger.info(
                    f"Launch retry {self.config.state_updating_retry_delay} seconds later..."
                )
                time.sleep(self.config.state_updating_retry_delay)

        # L1 cache put: store state after successful update
        if runtime is not None:
            try:
                page = await self.get_current_page()
                current_url = page.url
                scroll_y = await page.evaluate("window.scrollY") or 0
                runtime.put_state(current_url, int(scroll_y), session.cached_state)
            except Exception as e:
                logger.debug(f"[Cache] L1 put failed: {e}")

        return session.cached_state

    async def _update_state(self, focus_element: int = -1) -> BrowserState:
        """Update and return state."""
        session = await self.get_session()

        # Check if current page is still valid, if not switch to another available page
        try:
            page = await self.get_current_page()
            # Test if page is still accessible
            await page.evaluate("1")
        except Exception as e:
            logger.debug(f"Current page is no longer accessible: {str(e)}")
            # Get all available pages
            pages = session.context.pages
            if pages:
                self.state.target_id = None
                page = await self._get_current_page(session)
                safe_title = await self._safe_get_page_title(page)
                logger.debug(f"Switched to page: {safe_title}")
            else:
                raise BrowserError("Browser closed: no valid pages available")

        try:
            dom_service = DomService(page)
            await self.remove_highlights()
            screenshot = await self.take_screenshot()
            scrollable_elements = await dom_service.get_scrollable_elements(
                highlight_elements=self.config.highlight_elements,
                viewport_expansion=self.config.viewport_expansion,
            )
            scrollable_elements_screenshot = await self.take_screenshot()

            await self.remove_highlights()
            content = await dom_service.get_clickable_elements(
                focus_element=focus_element,
                viewport_expansion=self.config.viewport_expansion,
                highlight_elements=self.config.highlight_elements,
            )

            page_height = await page.evaluate("window.innerHeight")
            page_width = await page.evaluate("window.innerWidth")

            dom_tree_screenshot = await self.take_screenshot()
            pixels_above, pixels_below = await self.get_scroll_info(page)

            self.current_state = BrowserState(
                element_tree=content.element_tree,
                selector_map=content.selector_map,
                url=page.url,
                title=await self._safe_get_page_title(page),
                tabs=await self.get_tabs_info(),
                screenshot=screenshot,
                dom_tree_screenshot=dom_tree_screenshot,
                pixels_above=pixels_above,
                pixels_below=pixels_below,
                page_height=page_height,
                page_width=page_width,
                scrollable_elements=scrollable_elements,
                scrollable_elements_screenshot=scrollable_elements_screenshot,
            )

            return self.current_state
        except Exception as e:
            logger.exception(f"Failed to update state: {str(e)}")
            # Return last known good state if available
            if hasattr(self, "current_state"):
                return self.current_state
            raise

    # region - Browser Actions
    @time_execution_async("--take_screenshot")
    async def take_screenshot(
        self, full_page: bool = False, b64: bool = True
    ) -> Union[str, bytes]:
        """
        Returns a base64 encoded screenshot of the current page.
        """
        page = await self.get_current_page()

        await page.bring_to_front()
        await page.wait_for_load_state()

        screenshot = await page.screenshot(
            full_page=full_page,
            animations="disabled",
        )

        if b64:
            screenshot = base64.b64encode(screenshot).decode("utf-8")

        # await self.remove_highlights()

        return screenshot

    @time_execution_async("--remove_highlights")
    async def remove_highlights(self):
        """
        Removes all highlight overlays and labels created by the highlightElement function.
        Handles cases where the page might be closed or inaccessible.
        """
        try:
            page = await self.get_current_page()
            await page.evaluate(
                """
                try {
                    // Remove the highlight container and all its contents
                    const container = document.getElementById('playwright-highlight-container');
                    if (container) {
                        container.remove();
                    }

                    // Remove highlight attributes from elements
                    const highlightedElements = document.querySelectorAll('[browser-user-highlight-id^="playwright-highlight-"]');
                    highlightedElements.forEach(el => {
                        el.removeAttribute('browser-user-highlight-id');
                    });
                } catch (e) {
                    console.error('Failed to remove highlights:', e);
                }
                """
            )
        except Exception as e:
            logger.debug(f"Failed to remove highlights (this is usually ok): {str(e)}")
            # Don't raise the error since this is not critical functionality
            pass

    # endregion

    # region - User Actions

    @classmethod
    def _convert_simple_xpath_to_css_selector(cls, xpath: str) -> str:
        """Converts simple XPath expressions to CSS selectors."""
        if not xpath:
            return ""

        # Remove leading slash if present
        xpath = xpath.lstrip("/")

        # Split into parts
        parts = xpath.split("/")
        css_parts = []

        for part in parts:
            if not part:
                continue

            # Handle custom elements with colons by escaping them
            if ":" in part and "[" not in part:
                base_part = part.replace(":", r"\:")
                css_parts.append(base_part)
                continue

            # Handle index notation [n]
            if "[" in part:
                base_part = part[: part.find("[")]
                # Handle custom elements with colons in the base part
                if ":" in base_part:
                    base_part = base_part.replace(":", r"\:")
                index_part = part[part.find("[") :]

                # Handle multiple indices
                indices = [i.strip("[]") for i in index_part.split("]")[:-1]]

                for idx in indices:
                    try:
                        # Handle numeric indices
                        if idx.isdigit():
                            index = int(idx) - 1
                            base_part += f":nth-of-type({index + 1})"
                        # Handle last() function
                        elif idx == "last()":
                            base_part += ":last-of-type"
                        # Handle position() functions
                        elif "position()" in idx:
                            if ">1" in idx:
                                base_part += ":nth-of-type(n+2)"
                    except ValueError:
                        continue

                css_parts.append(base_part)
            else:
                css_parts.append(part)

        base_selector = " > ".join(css_parts)
        return base_selector

    @classmethod
    @time_execution_sync("--enhanced_css_selector_for_element")
    def _enhanced_css_selector_for_element(
        cls, element: DOMElementNode, include_dynamic_attributes: bool = True
    ) -> str:
        """
        Creates a CSS selector for a DOM element, handling various edge cases and special characters.

        Args:
                element: The DOM element to create a selector for

        Returns:
                A valid CSS selector string
        """
        try:
            # Get base selector from XPath
            css_selector = cls._convert_simple_xpath_to_css_selector(element.xpath)

            # Handle class attributes
            if (
                "class" in element.attributes
                and element.attributes["class"]
                and include_dynamic_attributes
            ):
                # Define a regex pattern for valid class names in CSS
                valid_class_name_pattern = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_-]*$")

                # Iterate through the class attribute values
                classes = element.attributes["class"].split()
                for class_name in classes:
                    # Skip empty class names
                    if not class_name.strip():
                        continue

                    # Check if the class name is valid
                    if valid_class_name_pattern.match(class_name):
                        # Append the valid class name to the CSS selector
                        css_selector += f".{class_name}"
                    else:
                        # Skip invalid class names
                        continue

            # Expanded set of safe attributes that are stable and useful for selection
            SAFE_ATTRIBUTES = {
                # Data attributes (if they're stable in your application)
                "id",
                # Standard HTML attributes
                "name",
                "type",
                "placeholder",
                # Accessibility attributes
                "aria-label",
                "aria-labelledby",
                "aria-describedby",
                "role",
                # Common form attributes
                "for",
                "autocomplete",
                "required",
                "readonly",
                # Media attributes
                "alt",
                "title",
                "src",
                # Custom stable attributes (add any application-specific ones)
                "href",
                "target",
            }

            if include_dynamic_attributes:
                dynamic_attributes = {
                    "data-id",
                    "data-qa",
                    "data-cy",
                    "data-testid",
                }
                SAFE_ATTRIBUTES.update(dynamic_attributes)

            # Handle other attributes
            for attribute, value in element.attributes.items():
                if attribute == "class":
                    continue

                # Skip invalid attribute names
                if not attribute.strip():
                    continue

                if attribute not in SAFE_ATTRIBUTES:
                    continue

                # Escape special characters in attribute names
                safe_attribute = attribute.replace(":", r"\:")

                # Handle different value cases
                if value == "":
                    css_selector += f"[{safe_attribute}]"
                elif any(char in value for char in "\"'<>`\n\r\t"):
                    # Use contains for values with special characters
                    # Regex-substitute *any* whitespace with a single space, then strip.
                    collapsed_value = re.sub(r"\s+", " ", value).strip()
                    # Escape embedded double-quotes.
                    safe_value = collapsed_value.replace('"', '\\"')
                    css_selector += f'[{safe_attribute}*="{safe_value}"]'
                else:
                    css_selector += f'[{safe_attribute}="{value}"]'

            return css_selector

        except Exception:
            # Fallback to a more basic selector if something goes wrong
            tag_name = element.tag_name or "*"
            return f"{tag_name}[highlight_index='{element.highlight_index}']"

    @time_execution_async("--get_locate_element")
    async def get_locate_element(
        self, element: DOMElementNode
    ) -> Optional[ElementHandle]:
        current_frame = await self.get_current_page()

        # Start with the target element and collect all parents
        parents: List[DOMElementNode] = []
        current = element
        while current.parent is not None:
            parent = current.parent
            parents.append(parent)
            current = parent

        # Reverse the parents list to process from top to bottom
        parents.reverse()

        # Process all iframe parents in sequence
        iframes = [item for item in parents if item.tag_name == "iframe"]
        for parent in iframes:
            css_selector = self._enhanced_css_selector_for_element(
                parent,
                include_dynamic_attributes=self.config.include_dynamic_attributes,
            )
            current_frame = current_frame.frame_locator(css_selector)

        css_selector = self._enhanced_css_selector_for_element(
            element, include_dynamic_attributes=self.config.include_dynamic_attributes
        )

        try:
            if isinstance(current_frame, FrameLocator):
                element_handle = await current_frame.locator(
                    css_selector
                ).element_handle()
                return element_handle
            else:
                # Try to scroll into view if hidden
                element_handle = await current_frame.query_selector(css_selector)
                if element_handle:
                    await element_handle.scroll_into_view_if_needed()
                    return element_handle
                return None
        except Exception as e:
            logger.exception(f"Failed to locate element: {str(e)}")
            return None

    @time_execution_async("--input_text_element_node")
    async def input_text_element_node(self, element_node: DOMElementNode, text: str):
        """
        Input text into an element with proper error handling and state management.
        Handles different types of input fields and ensures proper element state before input.
        """
        try:
            # Highlight before typing
            # if element_node.highlight_index is not None:
            # 	await self._update_state(focus_element=element_node.highlight_index)

            element_handle = await self.get_locate_element(element_node)

            if element_handle is None:
                raise BrowserError(f"Element: {repr(element_node)} not found")

            # Ensure element is ready for input
            try:
                await element_handle.wait_for_element_state("stable", timeout=1000)
                await element_handle.scroll_into_view_if_needed(timeout=1000)
            except Exception:
                pass

            # Get element properties to determine input method
            tag_handle = await element_handle.get_property("tagName")
            tag_name = (await tag_handle.json_value()).lower()
            is_contenteditable = await element_handle.get_property("isContentEditable")
            readonly_handle = await element_handle.get_property("readOnly")
            disabled_handle = await element_handle.get_property("disabled")

            readonly = await readonly_handle.json_value() if readonly_handle else False
            disabled = await disabled_handle.json_value() if disabled_handle else False

            if (await is_contenteditable.json_value() or tag_name == "input") and not (
                readonly or disabled
            ):
                await element_handle.evaluate('el => el.textContent = ""')
                await element_handle.type(text, delay=20)
            else:
                await element_handle.fill(text)

        except Exception as e:
            logger.debug(
                f"Failed to input text into element: {repr(element_node)}. Error: {str(e)}"
            )
            raise BrowserError(
                f"Failed to input text into index {element_node.highlight_index}"
            )

    @time_execution_async("--input_text_rectangle")
    async def input_text_rectangle(
        self, rectangle: Dict[str, float], text: str, clear_before_input: bool = True
    ):
        page = await self.get_current_page()
        try:
            x, y = (
                rectangle["left"] + rectangle["width"] / 2,
                rectangle["top"] + rectangle["height"] / 2,
            )
            ease_out_ms = 1000
            await page.mouse.move(x, y)
            await self.highlight_bounding_box(page, rectangle, ease_out_ms=ease_out_ms)
            time.sleep(ease_out_ms / 1000)
            await page.mouse.click(x, y)
            time.sleep(ease_out_ms / 1000)

            if clear_before_input:
                await page.keyboard.press("ControlOrMeta+A")
            await page.keyboard.type(text, delay=20)

        except Exception as e:
            logger.debug(
                f"Failed to input text into element with rectangle: {rectangle}. Error: {str(e)}"
            )
            raise BrowserError(
                f"Failed to input text into element with rectangle: {rectangle}"
            )

    @time_execution_async("--clear_input_text_rectangle")
    async def clear_input_text_rectangle(self, rectangle: Dict[str, float]):
        page = await self.get_current_page()
        try:
            x, y = (
                rectangle["left"] + rectangle["width"] / 2,
                rectangle["top"] + rectangle["height"] / 2,
            )
            ease_out_ms = 1000
            await page.mouse.move(x, y)
            await self.highlight_bounding_box(page, rectangle, ease_out_ms=ease_out_ms)
            time.sleep(ease_out_ms / 1000)
            await page.mouse.click(x, y)
            await page.keyboard.press("ControlOrMeta+A")
            await page.keyboard.press("Backspace")

        except Exception as e:
            logger.debug(
                f"Failed to clear text in element with rectangle: {rectangle}. Error: {str(e)}"
            )
            raise BrowserError(
                f"Failed to clear text in element with rectangle: {rectangle}"
            )

    @time_execution_async("--click")
    async def click(self, rectangle, hover=True) -> Optional[str]:
        """
        Optimized method to click an element.
        """
        page = await self.get_current_page()

        async def perform_click(click_func):
            """Performs the actual click, handling both download
            and navigation scenarios."""
            if self.config.save_downloads_path:
                try:
                    # Try short-timeout expect_download to detect a file download has been been triggered
                    async with page.expect_download(timeout=5000) as download_info:
                        await click_func()
                    download = await download_info.value
                    # Determine file path
                    suggested_filename = download.suggested_filename
                    unique_filename = await self._get_unique_filename(
                        self.config.save_downloads_path, suggested_filename
                    )
                    download_path = os.path.join(
                        self.config.save_downloads_path, unique_filename
                    )
                    await download.save_as(download_path)
                    logger.debug(f"Download triggered. Saved file to: {download_path}")
                    return download_path
                except TimeoutError:
                    # If no download is triggered, treat as normal click
                    logger.debug(
                        "No download triggered within timeout. Checking navigation..."
                    )
                    await page.wait_for_load_state()
                    await self._check_and_handle_navigation(page)
            else:
                # Standard click logic if no download is expected
                await click_func()
                await page.wait_for_load_state()
                await self._check_and_handle_navigation(page)

        def wrap_click_function(_rectangle, _hover=True):
            if self.config.click_mode == "pointer":
                candidate_points = [
                    # 中心点最高优先级
                    (
                        _rectangle["left"] + _rectangle["width"] / 2,
                        _rectangle["top"] + _rectangle["height"] / 2,
                    ),
                    # 左上
                    (
                        _rectangle["left"] + _rectangle["width"] / 4,
                        _rectangle["top"] + _rectangle["height"] / 4,
                    ),
                    # 右上
                    (
                        _rectangle["left"] + 3 * _rectangle["width"] / 4,
                        _rectangle["top"] + _rectangle["height"] / 4,
                    ),
                    # 左下
                    (
                        _rectangle["left"] + _rectangle["width"] / 4,
                        _rectangle["top"] + 3 * _rectangle["height"] / 4,
                    ),
                    # 右下
                    (
                        _rectangle["left"] + 3 * _rectangle["width"] / 4,
                        _rectangle["top"] + 3 * _rectangle["height"] / 4,
                    ),
                ]
            elif self.config.click_mode == "center":
                candidate_points = [
                    (
                        _rectangle["left"] + _rectangle["width"] / 2,
                        _rectangle["top"] + _rectangle["height"] / 2,
                    ),
                ]
            else:
                candidate_points = [
                    (
                        _rectangle["left"] + _rectangle["width"] / 2,
                        _rectangle["top"] + _rectangle["height"] / 2,
                    ),
                ]

            async def is_interactive_at(_page: Page, x: float, y: float) -> bool:
                """
                检查页面上指定坐标点的鼠标光标是否为 'pointer' 。
                """
                js_code = """
({ x, y }) => {
    const element = document.elementFromPoint(x, y);
    if (!element) {
        return false;
    }

    let currentElement = element;
    while (currentElement) {
        const style = window.getComputedStyle(currentElement);
        if (style.cursor === 'pointer') {
            return true;
        }
        // 如果光标是 'auto' 或 'default'，则有必要检查父元素。
        // 如果是其他明确的类型（如 'text', 'not-allowed'），则停止向上查找。
        if (style.cursor !== 'auto' && style.cursor !== 'default') {
            break;
        }
        currentElement = currentElement.parentElement;
    }

    return false;
}
"""
                is_pointer = await _page.evaluate(js_code, {"x": x, "y": y})
                return bool(is_pointer)

            async def func():
                ease_out_ms = 1000

                _x, _y = None, None
                for _cand_x, _cand_y in candidate_points:
                    if await is_interactive_at(page, _cand_x, _cand_y):
                        _x, _y = _cand_x, _cand_y
                        break
                if _x is None or _y is None:
                    # 使用中心点作为兜底
                    _x, _y = candidate_points[0]

                await page.mouse.move(_x, _y)
                await self.highlight_bounding_box(
                    page, _rectangle, ease_out_ms=ease_out_ms
                )
                time.sleep(ease_out_ms / 1000)
                await page.mouse.click(_x, _y)

                if not _hover:
                    await page.mouse.move(0, 0)

            return func

        try:
            return await perform_click(wrap_click_function(rectangle, _hover=hover))
        except URLNotAllowedError as e:
            raise e
        except Exception as e:
            raise Exception(
                f"Failed to click: rectangle={rectangle}, hover={hover}. Error: {str(e)}"
            )

    @time_execution_async("--hover")
    async def hover(self, box) -> None:
        """
        Optimized method to hover over an element.
        """
        page = await self.get_current_page()

        try:
            ease_out_ms = 1000
            x = box["left"] + box["width"] / 2
            y = box["top"] + box["height"] / 2
            await page.mouse.move(x, y)
            await self.highlight_bounding_box(page, box, ease_out_ms=ease_out_ms)
            time.sleep(ease_out_ms / 1000)
            await page.wait_for_load_state()
        except Exception as e:
            raise Exception(f"Failed to hover: box={box}. Error: {str(e)}")

    @time_execution_async("--get_tabs_info")
    async def get_tabs_info(self) -> List[TabInfo]:
        """Get information about all tabs"""
        session = await self.get_session()

        tabs_info = []
        for page_id, page in enumerate(session.context.pages):
            try:
                title = await self._safe_get_page_title(page)
            except Exception as e:
                logger.warning(
                    "Failed to collect title for tab %s (%s): %s", page_id, page.url, e
                )
                title = ""
            tab_info = TabInfo(page_id=page_id, url=page.url, title=title)
            tabs_info.append(tab_info)

        return tabs_info

    @time_execution_async("--switch_to_tab")
    async def switch_to_tab(self, page_id: int) -> None:
        """Switch to a specific tab by its page_id"""
        session = await self.get_session()
        pages = session.context.pages

        if page_id >= len(pages):
            raise BrowserError(f"No tab found with page_id: {page_id}")

        page = pages[page_id]

        # Check if the tab's URL is allowed before switching
        if not self._is_url_allowed(page.url):
            raise BrowserError(f"Cannot switch to tab with non-allowed URL: {page.url}")

        # Update target ID if using CDP
        if self.browser.config.cdp_url:
            targets = await self._get_cdp_targets()
            for target in targets:
                if target["url"] == page.url:
                    self.state.target_id = target["targetId"]
                    break

        await page.bring_to_front()
        await page.wait_for_load_state()

    @time_execution_async("--create_new_tab")
    async def create_new_tab(self, url: str | None = None) -> None:
        """Create a new tab and optionally navigate to a URL"""
        if url and not self._is_url_allowed(url):
            raise BrowserError(f"Cannot create new tab with non-allowed URL: {url}")

        session = await self.get_session()
        new_page = await session.context.new_page()
        await new_page.wait_for_load_state()

        if url:
            await new_page.goto(url)
            await self._wait_for_page_and_frames_load(timeout_overwrite=1)

        # Get target ID for new page if using CDP
        if self.browser.config.cdp_url:
            targets = await self._get_cdp_targets()
            for target in targets:
                if target["url"] == new_page.url:
                    self.state.target_id = target["targetId"]
                    break

    # endregion

    # region - Helper methods for easier access to the DOM
    async def _get_current_page(self, session: BrowserSession) -> Page:
        pages = session.context.pages

        # Try to find page by target ID if using CDP
        if self.browser.config.cdp_url and self.state.target_id:
            targets = await self._get_cdp_targets()
            for target in targets:
                if target["targetId"] == self.state.target_id:
                    for page in pages:
                        if page.url == target["url"]:
                            return page

        # Fallback to last page
        return pages[-1] if pages else await session.context.new_page()

    async def get_selector_map(self) -> SelectorMap:
        session = await self.get_session()
        if session.cached_state is None:
            return {}
        return session.cached_state.selector_map

    async def get_element_tree(self) -> DOMElementNode | None:
        session = await self.get_session()
        if session.cached_state is None:
            return None
        return session.cached_state.element_tree

    async def get_scrollable_elements(self) -> Dict[int, DOMElementNode]:
        session = await self.get_session()
        if session.cached_state is None:
            return {}
        return session.cached_state.scrollable_elements

    async def get_page_size(self) -> Tuple[int, int]:
        return (
            self.session.cached_state.page_width,
            self.session.cached_state.page_height,
        )

    async def get_element_by_index(self, index: int) -> ElementHandle | None:
        selector_map = await self.get_selector_map()
        element_handle = await self.get_locate_element(selector_map[index])
        return element_handle

    async def get_dom_element_by_index(self, index: int) -> DOMElementNode:
        selector_map = await self.get_selector_map()
        return selector_map[index]

    @staticmethod
    def is_inview(rectangle, page_width, page_height):
        left, top, right, bottom = (
            rectangle["left"],
            rectangle["top"],
            rectangle["right"],
            rectangle["bottom"],
        )
        return (
            0 <= left <= page_width
            or 0 <= right <= page_width
            or 0 <= top <= page_height
            or 0 <= bottom <= page_height
        )

    async def get_inview_interactive_elements(self) -> Dict[int, DOMElementNode]:
        selector_map = await self.get_selector_map()
        interactive_elements = {
            index: element
            for index, element in selector_map.items()
            if element.is_interactive and element.rectangle
        }
        page_width, page_height = await self.get_page_size()
        visible_interactive_elements = {
            index: element
            for index, element in interactive_elements.items()
            if self.is_inview(element.rectangle, page_width, page_height)
        }
        return visible_interactive_elements

    async def get_inview_scrollable_elements(self) -> Dict[int, DOMElementNode]:
        selector_map = await self.get_selector_map()
        interactive_elements = {
            index: element
            for index, element in selector_map.items()
            if element.is_interactive and element.rectangle
        }
        page_width, page_height = await self.get_page_size()
        visible_interactive_elements = {
            index: element
            for index, element in interactive_elements.items()
            if self.is_inview(element.rectangle, page_width, page_height)
        }
        return visible_interactive_elements

    async def save_cookies(self):
        """Save current cookies to file (only when cookies were loaded from a file path)."""
        if (
            self.session
            and self.session.context
            and self.config.cookies_file
            and getattr(self, "_cookies_source_is_file", False)
        ):
            try:
                cookies = await self.session.context.cookies()
                logger.debug(
                    f"Saving {len(cookies)} cookies to {self.config.cookies_file}"
                )

                # Check if the path is a directory and create it if necessary
                dirname = os.path.dirname(self.config.cookies_file)
                if dirname:
                    os.makedirs(dirname, exist_ok=True)

                with open(self.config.cookies_file, "w") as f:
                    json.dump(cookies, f)
            except Exception as e:
                logger.warning(f"Failed to save cookies: {str(e)}")

    async def is_file_uploader(
        self, element_node: DOMElementNode, max_depth: int = 3, current_depth: int = 0
    ) -> bool:
        """Check if element or its children are file uploaders"""
        if current_depth > max_depth:
            return False

        # Check current element
        is_uploader = False

        if not isinstance(element_node, DOMElementNode):
            return False

        # Check for file input attributes
        if element_node.tag_name == "input":
            is_uploader = (
                element_node.attributes.get("type") == "file"
                or element_node.attributes.get("accept") is not None
            )

        if is_uploader:
            return True

        # Recursively check children
        if element_node.children and current_depth < max_depth:
            for child in element_node.children:
                if isinstance(child, DOMElementNode):
                    if await self.is_file_uploader(child, max_depth, current_depth + 1):
                        return True

        return False

    async def get_scroll_info(self, page: Page) -> tuple[int, int]:
        """Get scroll position information for the current page."""
        scroll_y = await page.evaluate("window.scrollY")
        viewport_height = await page.evaluate("window.innerHeight")
        total_height = await page.evaluate("document.documentElement.scrollHeight")
        pixels_above = scroll_y
        pixels_below = total_height - (scroll_y + viewport_height)
        return pixels_above, pixels_below

    async def reset_context(self):
        """Reset the browser session
        Call this when you don't want to kill the context but just kill the state
        """
        # close all tabs and clear cached state
        session = await self.get_session()

        pages = session.context.pages
        for page in pages:
            await page.close()

        session.cached_state = None
        self.state.target_id = None

    async def _get_unique_filename(self, directory, filename):
        """Generate a unique filename by appending (1), (2), etc., if a file already exists."""
        base, ext = os.path.splitext(filename)
        counter = 1
        new_filename = filename
        while os.path.exists(os.path.join(directory, new_filename)):
            new_filename = f"{base} ({counter}){ext}"
            counter += 1
        return new_filename

    async def _get_cdp_targets(self) -> List[dict]:
        """Get all CDP targets directly using CDP protocol"""
        if not self.browser.config.cdp_url or not self.session:
            return []

        try:
            pages = self.session.context.pages
            if not pages:
                return []

            cdp_session = await pages[0].context.new_cdp_session(pages[0])
            result = await cdp_session.send("Target.getTargets")
            await cdp_session.detach()
            return result.get("targetInfos", [])
        except Exception as e:
            logger.debug(f"Failed to get CDP targets: {e}")
            return []

    @staticmethod
    async def highlight_bounding_box(page, box, ease_out_ms=200):
        """
        在页面上高亮一个 bounding box，并在指定时间内逐渐消失。

        Args:
            page: Playwright Page 对象。
            box (dict): 边界框坐标，格式为 {'x': float, 'y': float, 'width': float, 'height': float}。
            ease_out_ms (int): 开始渐隐前的延迟时间，单位毫秒。
        """
        if not box:
            print("Invalid bounding box provided.")
            return

        # 在浏览器环境中执行 JavaScript
        await page.evaluate(
            f"""
            () => {{
                // 创建一个 div 元素作为高亮框
                const highlightDiv = document.createElement('div');
                highlightDiv.className = 'playwright-highlight-box';
                Object.assign(highlightDiv.style, {{
                    position: 'absolute',
                    left: `{box['left']}px`,
                    top: `{box['top']}px`,
                    width: `{box['width']}px`,
                    height: `{box['height']}px`,
                    border: '2px solid red',
                    backgroundColor: 'rgba(255, 0, 0, 0.2)',
                    zIndex: '99999',
                    pointerEvents: 'none',
                    boxSizing: 'border-box',
                    opacity: '1',
                    boxShadow: '0 0 10px 2px rgba(255, 0, 0, 0.7)',
                    backgroundColor: 'rgba(255, 0, 0, 0.2)',
                    transition: `ease-out {ease_out_ms}ms`,
                    display: 'block',
                }});

                document.body.appendChild(highlightDiv);

                highlightDiv.offsetWidth;

                // 现在，在下一个事件循环周期中设置 opacity 为 0，
                // 浏览器会发现 opacity 属性发生了变化，并且 transition 属性已经设置好，
                // 从而开始渐变动画。使用 setTimeout 0 毫秒即可。
                setTimeout(() => {{
                    highlightDiv.style.opacity = '0';
                }}, 0); // 几乎立即触发，但在一个新的事件循环周期中

                // 在过渡结束后移除元素
                setTimeout(() => {{
                    highlightDiv.remove();
                }}, {ease_out_ms + 100}); // 额外加一点时间确保过渡完全结束
            }}
            """
        )

    @staticmethod
    async def highlight_mouse(page, x, y, ease_out_ms=200):
        """
        在页面上高亮一个指定位置上的小圆圈，并在指定时间内逐渐消失。

        Args:
            page: Playwright Page 对象。
            x (int): x
            y (int): y
            ease_out_ms (int): 开始渐隐前的延迟时间，单位毫秒。
        """

        # 在浏览器环境中执行 JavaScript
        await page.evaluate(
            f"""
                () => {{
                    // 创建一个 div 元素作为高亮框
                    const highlightDiv = document.createElement('div');
                    highlightDiv.className = 'playwright-highlight-box';
                    Object.assign(highlightDiv.style, {{
                        position: 'absolute',
                        left: `{y}px`,
                        top: `{x}px`,
                        width: `10px`,
                        height: `10px`,
                        borderRadius: '50%',
                        border: '2px solid red',
                        backgroundColor: 'rgba(255, 0, 0, 0.2)',
                        zIndex: '99999',
                        pointerEvents: 'none',
                        boxSizing: 'border-box',
                        opacity: '1',
                        boxShadow: '0 0 10px 2px rgba(255, 0, 0, 0.7)',
                        backgroundColor: 'rgba(255, 0, 0, 0.2)',
                        transition: `ease-out {ease_out_ms}ms`,
                        display: 'block',
                    }});

                    document.body.appendChild(highlightDiv);

                    highlightDiv.offsetWidth;

                    // 现在，在下一个事件循环周期中设置 opacity 为 0，
                    // 浏览器会发现 opacity 属性发生了变化，并且 transition 属性已经设置好，
                    // 从而开始渐变动画。使用 setTimeout 0 毫秒即可。
                    setTimeout(() => {{
                        highlightDiv.style.opacity = '0';
                    }}, 0); // 几乎立即触发，但在一个新的事件循环周期中

                    // 在过渡结束后移除元素
                    setTimeout(() => {{
                        highlightDiv.remove();
                    }}, {ease_out_ms + 100}); // 额外加一点时间确保过渡完全结束
                }}
                """
        )

    def highlight_action_on_screenshot(
        self,
        screenshot: Image,
        actions: List,
    ):
        screenshot = screenshot.copy().convert("RGBA")
        colors = [
            "#FF0000",
            "#00FF00",
            "#0000FF",
            "#FFA500",
            "#800080",
            "#008080",
            "#FF69B4",
            "#4B0082",
            "#FF4500",
            "#2E8B57",
            "#DC143C",
            "#4682B4",
        ]
        for action_index, action in enumerate(actions):
            if not action.model_dump(exclude_unset=True):
                continue
            action_name, params = list(action.model_dump(exclude_unset=True).items())[0]
            if "index" in params:
                element_index = params["index"]
                if "scroll" in action_name:
                    rectangle = self.session.cached_state.scrollable_elements[
                        element_index
                    ].rectangle
                else:
                    rectangle = self.session.cached_state.selector_map[
                        element_index
                    ].rectangle
            elif "box_2d" in params:
                rectangle = box_2d_to_rectangle(
                    params["box_2d"],
                    self.session.cached_state.page_height,
                    self.session.cached_state.page_width,
                )
            else:
                continue

            screenshot = self.draw_text_with_rounded_box(
                screenshot.copy(),
                str(action_index + 1),
                (
                    round(self.config.device_scale_factor * rectangle["left"]),
                    round(self.config.device_scale_factor * rectangle["top"]),
                ),
                self.config.default_font_path,
                font_size=24,
                text_color="#FFFFFF",
                bg_color=colors[action_index % len(colors)],
                box_width=round(self.config.device_scale_factor * rectangle["width"]),
                box_height=round(self.config.device_scale_factor * rectangle["height"]),
            )

        return screenshot

    @staticmethod
    def hex_to_rgba(hex_color, alpha=128):
        """
        将16进制颜色转换为RGBA元组。

        :param hex_color: 形如"#RRGGBB"或"RRGGBB"的16进制颜色字符串
        :param alpha: 透明度值（0-255），默认为128（半透明）
        :return: (R, G, B, A)元组
        """
        hex_color = hex_color.lstrip("#")
        if len(hex_color) != 6:
            raise ValueError("Hex color must be in the format RRGGBB or #RRGGBB")
        r, g, b = tuple(int(hex_color[i : i + 2], 16) for i in (0, 2, 4))
        return r, g, b, alpha

    def draw_text_with_rounded_box(
        self,
        image: Image.Image,
        text: str,
        position: Tuple,  # (x, y) - 背景框的左上角位置
        font_path: str,
        font_size: int,
        box_width: int,
        box_height: int,
        text_color: str = "#FFFFFF",  # 默认白色文字
        bg_color: str = "#008080",  # 默认青色背景 (例如你的图片中的绿色调)
        corner_radius: int = 10,  # 圆角半径
        padding: int = 10,  # 文字与背景框的内边距
    ) -> Image.Image:
        """
        在图片上绘制带有圆角背景框的文字。

        Args:
            image (Image.Image): PIL 图片对象。
            text (str): 要绘制的文字。
            position (tuple): 背景框的左上角 (x, y) 坐标。
            font_path (str): 字体文件的路径 (例如 'arial.ttf')。
            font_size (int): 字体大小。
            box_width (int): box宽度。
            box_height (int): box高度。
            text_color (str): 文字颜色，可以是十六进制字符串或PIL识别的颜色名。
            bg_color (str): 背景框填充颜色，可以是十六进制字符串或PIL识别的颜色名。
                            十六进制字符串支持 #RRGGBB 或 #RRGGBBAA (带透明度)。
            corner_radius (int): 背景框的圆角半径。
            padding (int): 文字与背景框的内边距 (上下左右)。
        Returns:
            Image.Image: 绘制了文字和背景框的 PIL 图片对象。
        """

        # 确保图片是 RGBA 模式，以便进行透明度混合
        if image.mode != "RGBA":
            image = image.convert("RGBA")

        # 加载字体
        try:
            font = ImageFont.truetype(font_path, font_size)
        except IOError:
            print(
                f"Error: Could not load font '{font_path}'. Falling back to default font."
            )
            font = ImageFont.load_default()
            # 尝试调整大小，但load_default()通常不支持自定义大小
            if font_size != 10:  # default font is usually 10
                print("Warning: Default font may not render at specified size.")

        # 创建一个临时的 ImageDraw 对象来测量文字尺寸
        # 注意：textbbox 的 (0,0) 参数是用来计算相对坐标的，实际不绘制。
        # 结果是 (left, top, right, bottom)
        dummy_draw = ImageDraw.Draw(Image.new("RGBA", (1, 1)))  # 最小图像用于测量
        text_bbox = dummy_draw.textbbox((0, 0), text, font=font)
        text_width = text_bbox[2] - text_bbox[0]  # right - left
        text_height = text_bbox[3] - text_bbox[1]  # bottom - top

        # 计算背景框的尺寸
        text_box_width = text_width + 2 * padding
        text_box_height = text_height + 2 * padding

        # 确保圆角半径不过大
        corner_radius = min(corner_radius, text_box_width // 2, text_box_height // 2)

        # 创建一个透明的图层来绘制背景框和文字
        # 这是一个 RGBA 图像，初始为全透明
        # index text 放在右上角
        overlay = Image.new(
            "RGBA",
            (box_width + text_box_width, max(text_box_height, box_height)),
            (0, 0, 0, 0),
        )
        draw_overlay = ImageDraw.Draw(overlay)

        # 绘制圆角背景框
        draw_overlay.rectangle(
            (0, 0, box_width, box_height),
            fill=self.hex_to_rgba(bg_color, alpha=12),
            outline=self.hex_to_rgba(bg_color, alpha=255),
            width=3,
        )

        # 绘制文字的圆角背景框
        # rounded_rectangle() 在 Pillow 8.0 及以上版本可用
        draw_overlay.rounded_rectangle(
            (box_width, 0, box_width + text_box_width, text_box_height),
            radius=corner_radius,
            fill=self.hex_to_rgba(bg_color, alpha=255),
        )

        # 计算文字在背景框内的居中位置
        # textbbox的left和top有时不为0，需要考虑进去
        text_x = box_width + padding - text_bbox[0]
        text_y = padding - text_bbox[1]

        # 绘制文字
        # text_color 也可以是十六进制，但PIL的text方法直接支持字符串
        draw_overlay.text((text_x, text_y), text, font=font, fill=text_color)

        # 将绘制好的 overlay 粘贴到主图片上
        # overlay 作为 mask 参数，确保透明度正确混合
        image.paste(overlay, position, overlay)

        return image

    async def get_all_textual_data(self, page: Optional[Page] = None):
        page = page or await self.get_current_page()
        attributes_to_check = [
            "title",
            "type",
            "name",
            "role",
            "aria-label",
            "placeholder",
            "value",
            "alt",
            "aria-expanded",
            "data-date-format",
        ]
        get_all_textual_data_script = """
(attributesToCheck) => {
    const getXPathForElement = (elm) => {
        const segs = [];
        for (; elm && elm.nodeType === 1; elm = elm.parentNode) {
            if (elm.hasAttribute('id')) {
                let uniqueIdCount = 0;
                const id = elm.getAttribute('id');
                const matches = document.querySelectorAll(`[id="${id}"]`);
                if (matches.length === 1) {
                   segs.unshift(`*[@id="${id}"]`);
                   return `//${segs.join('/')}`;
                }
            }

            let i = 1;
            for (let sib = elm.previousSibling; sib; sib = sib.previousSibling) {
                if (sib.nodeName === elm.nodeName) {
                    i++;
                }
            }
            segs.unshift(`${elm.nodeName.toLowerCase()}[${i}]`);
        }
        return segs.length ? `/${segs.join('/')}` : null;
    };

    const results = {};
    const allElements = document.querySelectorAll('*');

    allElements.forEach(element => {
        const elementData = {};

        // A. 获取元素的直接 innerText (不含子元素)
        // 这可以防止重复计算文本。例如 body 的 innerText 包含了 p 的 innerText。
        let directText = Array.from(element.childNodes)
            .filter(node => node.nodeType === Node.TEXT_NODE && node.textContent.trim())
            .map(node => node.textContent.trim())
            .join(' '); // 如果有多个直接文本节点，用空格连接

        if (directText) {
            elementData['innerText'] = directText;
        }

        // B. 检查指定的属性
        for (const attr of attributesToCheck) {
            if (element.hasAttribute(attr)) {
                const attrValue = element.getAttribute(attr);
                if (attrValue && attrValue.trim()) {
                    elementData[attr] = attrValue.trim();
                }
            }
        }

        // C. 如果该元素收集到了任何文本数据，则将其添加到最终结果中
        if (Object.keys(elementData).length > 0) {
            const xpath = getXPathForElement(element);
            if (xpath) {
                results[xpath] = elementData;
            }
        }
    });

    return results;
}
"""
        return await page.evaluate(get_all_textual_data_script, attributes_to_check)
